const { readdirSync } = require("fs");
const { join } = require("path");
const { execSync } = require("child_process");
const listPackage = require("../package.json").dependencies;
const listbuiltinModules = require("module").builtinModules;
const logger = require("./log");

module.exports = function startMDL(api, models) {
  global.client.timeStart = new Date().getTime();

  (function loadCommands() {
    const listCommand = readdirSync(global.client.mainPath + "/mdl/cmds").filter(
      (command) =>
        command.endsWith(".js") &&
        !command.includes("example") &&
        !global.config.commandDisabled.includes(command)
    );

    for (const command of listCommand) {
      try {
        const module = require(global.client.mainPath + "/mdl/cmds/" + command);
        if (!module.config || !module.run || !module.config.commandCategory)
          throw new Error(global.getText("mirai", "errorFormat"));
        if (global.client.commands.has(module.config.name || ""))
          throw new Error(global.getText("mirai", "nameExist"));

        if (module.config.dependencies) {
          for (const dep in module.config.dependencies) {
            const depPath = join(__dirname, "../nodemodules/node_modules", dep);
            try {
              if (!global.nodemodule.hasOwnProperty(dep)) {
                global.nodemodule[dep] = listPackage[dep] || listbuiltinModules.includes(dep)
                  ? require(dep)
                  : require(depPath);
              }
            } catch {
              logger.loader(global.getText("mirai", "notFoundPackage", dep, module.config.name), "warn");
              execSync(
                `npm --package-lock false --save install ${dep}${module.config.dependencies[dep] ? "@" + module.config.dependencies[dep] : ""}`,
                {
                  stdio: "inherit",
                  env: process.env,
                  shell: true,
                  cwd: join(__dirname, "../nodemodules"),
                }
              );
              global.nodemodule[dep] = require(depPath);
            }
          }
        }

        if (module.config.envConfig) {
          for (const key in module.config.envConfig) {
            global.configModule[module.config.name] = global.configModule[module.config.name] || {};
            global.config[module.config.name] = global.config[module.config.name] || {};
            global.configModule[module.config.name][key] = global.config[module.config.name][key] ?? module.config.envConfig[key];
            global.config[module.config.name][key] = global.config[module.config.name][key] ?? module.config.envConfig[key];
          }
        }

        if (module.onLoad) module.onLoad({ api, models });
        if (module.handleEvent) global.client.eventRegistered.push(module.config.name);
        global.client.commands.set(module.config.name, module);
      } catch (err) {}
    }
  })();

  (function loadEvents() {
    const events = readdirSync(global.client.mainPath + "/mdl/evt").filter(
      (event) => event.endsWith(".js") && !global.config.eventDisabled.includes(event)
    );

    for (const ev of events) {
      try {
        const event = require(global.client.mainPath + "/mdl/evt/" + ev);
        if (!event.config || !event.run)
          throw new Error(global.getText("mirai", "errorFormat"));
        if (global.client.events.has(event.config.name))
          throw new Error(global.getText("mirai", "nameExist"));

        if (event.config.dependencies) {
          for (const dep in event.config.dependencies) {
            const depPath = join(__dirname, "../nodemodules/node_modules", dep);
            try {
              if (!global.nodemodule.hasOwnProperty(dep)) {
                global.nodemodule[dep] = listPackage[dep] || listbuiltinModules.includes(dep)
                  ? require(dep)
                  : require(depPath);
              }
            } catch {
              logger.loader(global.getText("mirai", "notFoundPackage", dep, event.config.name), "warn");
              execSync(
                `npm --package-lock false --save install ${dep}${event.config.dependencies[dep] ? "@" + event.config.dependencies[dep] : ""}`,
                {
                  stdio: "inherit",
                  env: process.env,
                  shell: true,
                  cwd: join(__dirname, "../nodemodules"),
                }
              );
              global.nodemodule[dep] = require(depPath);
            }
          }
        }

        if (event.config.envConfig) {
          for (const key in event.config.envConfig) {
            global.configModule[event.config.name] = global.configModule[event.config.name] || {};
            global.config[event.config.name] = global.config[event.config.name] || {};
            global.configModule[event.config.name][key] = global.config[event.config.name][key] ?? event.config.envConfig[key];
            global.config[event.config.name][key] = global.config[event.config.name][key] ?? event.config.envConfig[key];
          }
        }

        if (event.onLoad) event.onLoad({ api, models });
        global.client.events.set(event.config.name, event);
      } catch (err) {}
    }
  })();

};