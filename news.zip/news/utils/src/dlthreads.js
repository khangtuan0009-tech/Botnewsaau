const axios = require("axios");

async function downloadv3(link) {
  // ===== Lấy ID bài post =====
  function getIDThread(link) {
    const regex = /\/post\/([^\/\?]+)/;
    const match = link.match(regex);
    return match ? match[1] : null;
  }

  const postID = getIDThread(link);
  if (!postID) throw new Error("Không tìm thấy postID Threads");

  // ===== Body request GraphQL =====
  const form = new URLSearchParams({
    av: "17841476605532201",
    __user: "0",
    __a: "1",
    __req: "p",
    __hs: "20398.HYP:barcelona_web_pkg.2.1...0",
    dpr: "2",
    __ccg: "MODERATE",
    __rev: "1029493304",
    __s: "xmtppj:hc7plq:l9jjj7",
    __hsi: "7569637263526488073",
    __dyn: "7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo1nEhw2nVE4W0qa0FE2awgo9oO0n24oaEd82lwv89k2C1Fwc60D85m1mzXwae4UaEW0Loco5G0zK5o4q0HU1IEGdwtU2ewbS1LwTwKG0hq1Iwqo9Epxq261bg5q2-2K7E4u8Dxd0LCzUaEuw9y1swnrwu813o",
    fb_api_req_friendly_name: "BarcelonaLightboxDialogRootQuery",
    doc_id: "24905660409114716",
    variables: JSON.stringify({
      postID,
      __relay_internal__pv__IsTagIndicatorEnabledrelayprovider: true,
      __relay_internal__pv__BarcelonaIsLoggedInrelayprovider: true,
      __relay_internal__pv__BarcelonaHasDeepDiverelayprovider: false,
      __relay_internal__pv__BarcelonaHasGhostPostConsumptionrelayprovider: true,
      __relay_internal__pv__BarcelonaHasSpoilerStylingInforelayprovider: true,
      __relay_internal__pv__BarcelonaHasGhostPostEmojiActivationrelayprovider: true,
    }),
  });

  try {
    const res = await axios.post("https://www.threads.com/graphql/query", form, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded",
        origin: "https://www.threads.com",
        referer: link,
        "x-ig-app-id": "1412234116260832",
        "x-fb-friendly-name": "BarcelonaLightboxDialogRootQuery",
        "x-csrftoken": "M2N6gZUx4TjZOPEUp6eTvrohPsl1H07D",
        Cookie:
          'ig_did=DC359EA8-54AF-4E15-A77E-840F5112CB17; mid=aL1OjgABAAFWm-vIZ0V2zopN7zKb; csrftoken=M2N6gZUx4TjZOPEUp6eTvrohPsl1H07D; ds_user_id=76737609517; sessionid=76737609517%3AeIu0b4Z7HrDMfb%3A1%3AAYgGgTrR9bX4B0efnqr7xz6SJHyfKpmjuI3NX6Ov1Q;',
      },
    });

    // ====== Parse dữ liệu trả về ======
    const media =
      res.data?.data?.fetch__XDTMediaDict?.items?.[0]?.media || null;
    if (!media) throw new Error("Không đọc được dữ liệu Threads");

    const username = media.user?.username || "unknown";
    const name = media.user?.name || username;
    const avatar = media.user?.profile_pic_url || null;
    const caption = media.caption?.text || "Không có mô tả";
    const preview =
      media.video_versions?.[0]?.url ||
      media.image_versions2?.candidates?.[0]?.url ||
      null;

    const results = [];

    if (media.video_versions?.length) {
      results.push({
        type: "Video",
        url: media.video_versions[0].url,
        quality: "HD",
        size: "Không rõ",
      });
    }

    if (media.image_versions2?.candidates?.length) {
      results.push({
        type: "Image",
        url: media.image_versions2.candidates[0].url,
        quality: "Original",
        size: "Không rõ",
      });
    }

    if (media.carousel_media?.length) {
      media.carousel_media.forEach((item) => {
        if (item.video_versions?.length)
          results.push({
            type: "Video",
            url: item.video_versions[0].url,
            quality: "HD",
            size: "Không rõ",
          });
        if (item.image_versions2?.candidates?.length)
          results.push({
            type: "Image",
            url: item.image_versions2.candidates[0].url,
            quality: "Original",
            size: "Không rõ",
          });
      });
    }

    const stats = {
      likes: media.like_count || 0,
      comments: media.comment_count || 0,
      favourites: media.text_post_app_info?.quote_count || 0,
      shares: media.text_post_app_info?.repost_count || 0,
    };

    return {
      id: postID,
      title: `${name}'s Media`,
      description: caption,
      preview,
      user: {
        name,
        username,
        avatar,
        bio: media.user?.biography || false,
        followers: media.user?.follower_count?.toString() || "0",
      },
      stats,
      results,
    };
  } catch (err) {
    console.error("❌ Threads error:", err.message);
    return null;
  }
}

module.exports = { downloadv3 };