const axios = require('axios');
const cheerio = require('cheerio');
const FormData = require('form-data');

async function downloadv3(url) {
  const form = new FormData();
  form.append('link', url);

  try {
    const response = await axios.post('https://m.vuiz.net/getlink/mp3zing/api.php', form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': 'https://m.vuiz.net/getlink/mp3zing/'
      },
      timeout: 30000
    });

    const res = response.data;
    if (!res || !res.success) throw new Error('Không nhận được dữ liệu hợp lệ từ máy chủ.');

    const $ = cheerio.load(res.success);
    const audioElement = $('#amazingaudioplayer-1 ul.amazingaudioplayer-audios li').first();
    const sourceElement = audioElement.find('.amazingaudioplayer-source');

    const title = audioElement.attr('data-title') || "Không rõ tên";
    const artist = audioElement.attr('data-artist') || "Không rõ ca sĩ";
    const thumb = audioElement.attr('data-image') || null;
    const source = sourceElement.attr('data-src') || null;
    const type = sourceElement.attr('data-type') || "audio/mpeg";

    const attachments = [];

    $('.menu div a').each((i, el) => {
      const link = $(el).attr('href');
      const text = $(el).text().trim();
      if (link && link.endsWith('.mp3')) {
        attachments.push({
          url: link,
          quality: text || "128Kbps",
          type: "audio"
        });
      }
    });

    if (attachments.length === 0 && source) {
      attachments.push({
        url: source,
        quality: "128Kbps",
        type: "audio"
      });
    }

    return { title, artist, thumb, attachments };
  } catch (error) {
    console.error("Lỗi tải ZingMP3:", error.message);
    return { attachments: [] };
  }
}

module.exports = { downloadv3 };