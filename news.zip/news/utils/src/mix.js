const axios = require('axios');

// Header config
const mixcloudAuth = {
  "x-csrftoken": "DiPje5fKqeGnx6SIpTJJ6rNTadEYWNou",
  "Cookie": "c=YOUR_C_COOKIE; csrftoken=DiPje5fKqeGnx6SIpTJJ6rNTadEYWNou"
};

module.exports = async function FetchMixcloud(url) {
  if (!url) throw new Error('URL is required');

  try {
    const match = url.match(/mixcloud\.com\/([^\/]+)\/([^\/]+)/);
    if (!match) throw new Error('Invalid Mixcloud URL');

    const username = match[1];
    const rawSlug = match[2];
    const slug = decodeURIComponent(rawSlug);

    // GraphQL query
    const graphqlQuery = {
      query: `
        query CloudcastInfo($username: String!, $slug: String!) {
          cloudcast: cloudcastLookup(lookup: {username: $username, slug: $slug}) {
            id
            name
            audioLength
            picture { urlRoot primaryColor }
            owner { id displayName username }
            plays
            favorites { totalCount }
            reposts { totalCount }
            waveformUrl
            previewUrl
          }
        }`,
      variables: { username, slug }
    };

    // Send request
    const res = await axios.post('https://app.mixcloud.com/graphql', graphqlQuery, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
        'Accept': '*/*',
        ...mixcloudAuth
      }
    });

    const data = res.data?.data?.cloudcast;
    if (!data) throw new Error('Cannot fetch Mixcloud info');

    // ====== Tạo link stream m4a từ previewUrl ======
    let streamLink = null;
    if (data.previewUrl) {
      // cắt ID từ previewUrl
      const idMatch = data.previewUrl.match(/previews\/(.+)\.mp3$/);
      if (idMatch) {
        const idPath = idMatch[1];
        streamLink = `https://stream.mixcloud.stream/secure/c/m4a/64/${idPath}.m4a?sig=Y0GlO7hm8taBWwwfztOmaQ`;
      }
    }

    return {
      id: data.id,
      title: data.name,
      author: data.owner.displayName,
      username: data.owner.username,
      duration: data.audioLength,
      thumbnail: `https://thumbs.mixcloud.com/${data.picture.urlRoot}/320x320.jpg`,
      plays: data.plays,
      favorites: data.favorites.totalCount,
      reposts: data.reposts.totalCount,
      waveform: data.waveformUrl,
      preview: data.previewUrl,
      stream: streamLink, // đây là link m4a
      source: 'mixcloud'
    };

  } catch (error) {
    console.error('❌ Mixcloud Error:', error.message);
    return {
      error: true,
      message: 'Cannot fetch Mixcloud media info.',
      detail: error.message || error
    };
  }
};