const axios = require("axios");
const cheerio = require("cheerio");

module.exports = async function capcutDirect(url) {
  if (!url) throw new Error("Thiếu URL CapCut");

  try {
    const response = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Accept-Language": "vi,en;q=0.9"
      }
    });

    const data = response.data;

    // ====== 1️⃣ Nếu là JSON API ======
    if (typeof data === "object" && data !== null) {
      // 🧩 Một số link trả về { success: true, data: { html: "<!doctype html>..." } }
      if (data.data && typeof data.data.html === "string") {
        const html = data.data.html;
        const $ = cheerio.load(html);

        const title =
          $("meta[property='og:title']").attr("content") ||
          $("title").text().trim() ||
          $(".template-title").text().trim();
        const description =
          $("meta[property='og:description']").attr("content") ||
          $(".desc-detail").text().trim() ||
          "Không có mô tả";
        const cover =
          $("meta[property='og:image']").attr("content") ||
          $("video").attr("poster");
        const video =
          $("meta[property='og:video:url']").attr("content") ||
          $("video").attr("src");
        const width =
          $("meta[property='og:video:width']").attr("content") || "Không rõ";
        const height =
          $("meta[property='og:video:height']").attr("content") || "Không rõ";

        const authorName = $(".author-name").text().trim() || "Không rõ";
        const authorAvatar = $(".author img").attr("src") || "";
        const authorDesc = $(".author-desc").text().trim() || "";

        const stats = $(".actions-detail").text().trim();
        const extra = $(".detail-extra-span")
          .map((i, el) => $(el).text())
          .get()
          .join(" | ");

        return {
          success: true,
          site: "capcut.com (HTML from JSON)",
          title,
          description,
          cover,
          video,
          width,
          height,
          stats,
          extra,
          authorName,
          authorAvatar,
          authorDesc
        };
      }

      // 🧩 Nếu là JSON API thật (data.data chứa template/video)
      if (data.success === true && data.data) {
        const capcutData = data.data;
        const template = capcutData.template || {};
        const author = capcutData.author || capcutData.creator || {};

        const templateId = template.templateId || capcutData.templateId;
        const title =
          template.templateName || capcutData.templateName || "Không có tiêu đề";
        const description =
          template.templateDesc || capcutData.templateDesc || "Không có mô tả";
        const cover = template.coverUrl || capcutData.coverUrl;
        const video = template.videoUrl || capcutData.videoUrl;
        const width = template.videoWidth || capcutData.videoWidth;
        const height = template.videoHeight || capcutData.videoHeight;
        const videoRatio = template.videoRatio || capcutData.videoRatio;
        const duration = template.templateDuration || capcutData.templateDuration;
        const usageAmount = template.usageAmount || capcutData.usageAmount;
        const likeAmount = template.likeAmount || capcutData.likeAmount;
        const createTime = template.createTime || capcutData.createTime;

        const authorName = author.name || "Không rõ";
        const authorAvatar = author.avatarUrl || "";
        const authorDesc = author.description || "";
        const authorProfileUrl = author.profileUrl || "";
        const authorSecUid = author.secUid || "";

        if (!video)
          throw new Error("Không tìm thấy URL video trong dữ liệu JSON CapCut");

        return {
          success: true,
          site: "nvhdz",
          templateId,
          title,
          description,
          cover,
          video,
          width,
          height,
          videoRatio,
          duration,
          usageAmount,
          likeAmount,
          createTime,
          authorName,
          authorAvatar,
          authorDesc,
          authorProfileUrl,
          authorSecUid,
          details: capcutData
        };
      }
    }

    // ====== 2️⃣ Nếu trả về HTML trực tiếp ======
    const $ = cheerio.load(data);

    const title =
      $("meta[property='og:title']").attr("content") ||
      $("title").text().trim() ||
      $(".template-title").text().trim();
    const description =
      $("meta[property='og:description']").attr("content") ||
      $(".desc-detail").text().trim() ||
      "Không có mô tả";
    const cover =
      $("meta[property='og:image']").attr("content") || $("video").attr("poster");
    const video =
      $("meta[property='og:video:url']").attr("content") || $("video").attr("src");
    const width =
      $("meta[property='og:video:width']").attr("content") || "Không rõ";
    const height =
      $("meta[property='og:video:height']").attr("content") || "Không rõ";

    const authorName = $(".author-name").text().trim() || "Không rõ";
    const authorAvatar = $(".author img").attr("src") || "";
    const authorDesc = $(".author-desc").text().trim() || "";

    const stats = $(".actions-detail").text().trim();
    const extra = $(".detail-extra-span")
      .map((i, el) => $(el).text())
      .get()
      .join(" | ");

    if (video) {
      return {
        success: true,
        site: "nvhdz",
        title,
        description,
        cover,
        video,
        width,
        height,
        stats,
        extra,
        authorName,
        authorAvatar,
        authorDesc
      };
    }

    throw new Error("Không thể trích xuất dữ liệu từ HTML CapCut");
  } catch (err) {
    console.error("❌ Lỗi tải CapCut:", err.message);
    return { success: false, error: err.message };
  }
};