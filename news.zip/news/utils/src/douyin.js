const axios = require('axios');

async function downloadv1(url) {
  if (!url) throw new Error('URL is required');
  try {
    const apiUrl = `https://apinvh.zzux.com/api/mediadl?url=${encodeURIComponent(url)}`;
    const res = await axios.get(apiUrl);

    if (res.data.error) throw new Error('Cannot download this video');

    return {
      id: res.data.id,
      title: res.data.title,
      author: {
        id: res.data.unique_id || '',
        name: res.data.author || '',
        username: res.data.unique_id || ''
      },
      unique_id: res.data.unique_id,
      duration: res.data.duration,
      thumbnail: res.data.thumbnail,
      medias: res.data.medias,
      source: res.data.source
    };
  } catch (error) {
    throw new Error(`downloadv1 Error: ${error.message}`);
  }
}

async function downloadv2(url) {
  if (!url) throw new Error('URL is required');
  try {
    const apiUrl = `https://subhatde.id.vn/downall?url=${encodeURIComponent(url)}`;
    const res = await axios.get(apiUrl);

    if (!res.data || !res.data.medias) throw new Error('Cannot download this video');

    const data = res.data;

    return {
      id: data.id,
      title: data.title,
      author: {
        id: data.author?.id || '',
        name: data.author?.name || '',
        username: data.author?.username || ''
      },
      stats: data.stats || {},
      createTime: data.createTime || '',
      music: {
        title: data.music?.title || '',
        author: data.music?.author || '',
        duration: data.music?.duration || 0,
        url: data.music?.url || ''
      },
      medias: data.medias.map(m => ({
        type: m.type,
        url: m.url,
        extension: m.extension || '',
        quality: m.quality || ''
      }))
    };
  } catch (error) {
    throw new Error(`downloadv2 Error: ${error.message}`);
  }
}

module.exports = { downloadv1, downloadv2 };