const axios = require('axios');

module.exports = async function FetchMixcloud(url) {
  if (!url) throw new Error('URL is required');

  try {
    // ====== 1️⃣ Token + Cookie cố định (lấy từ cURL bạn gửi) ======
    const FIXED_TOKEN = 'x91PN2QwpjFNd3Ru6mcpGsr3CQvhpFQuTN3ywkpp';
    const FIXED_COOKIE = `_ga=GA1.1.1409273450.1762404501; XSRF-TOKEN=eyJpdiI6ImJHekZJSFBnRmtDRnJlbm9hdnMwd1E9PSIsInZhbHVlIjoidTR0MFdYZy9DY1NGT1huenlZSzIzcjIxTXB2bENtVVhRa3VuUTBzeUtyMTZRUnBoMlJ1amNkLzB0UTZqQjNmRTVNU3FWd0FDa0Vvbk1QdGN0T2hpU2I3aDRYR05XN2dXeDhaTW9laXVJbFdiVGNKMnNYQ0tUUVRFQ1dueE1QNWwiLCJtYWMiOiJlZGQxYTNmOWQwYTZhYzQyZmNjNmZiMjBjNzNiNzAzN2Y3NzQxNThhMjMyYmQ0M2M5MjVjZDFiZDhmZjcyMTIxIiwidGFnIjoiIn0%3D; postsyncer_session_v2=eyJpdiI6ImZzNkEvS1M0a3VESTJkVGdVRWx2dnc9PSIsInZhbHVlIjoia2U2N2lmeEptWHhydEIrNGw3cGJHQ0NkT1pMYWp4ZUdLWS8vbml6bHB5WFZuamRIM1VUbFo3dEZaTVJLZVRpMVF3Qi91OVdnOXArSGJZNnVucy8vRGFudVpDQTgwYnVnOUhzRG00bWdVWHpzYmxmM2pwdUdhclhxNWJIbXNMVFUiLCJtYWMiOiI2OTExNGJkNDVmNDUyN2M5OTllZjVkYWJhM2RmOTJkMGY5NWI4NjQ3YzM4MzU5OGQwMzFkY2E0MTQwY2ZlZGEzIiwidGFnIjoiIn0%3D; _ga_EVJP1749R9=GS2.1.s1762404500$o1$g1$t1762404531$j29$l0$h0; ph_phc_QSy4ELwp4pzfXjvGoTYx9aM3jxK6JvkcY0VNtYvEnVR_posthog=%7B%22distinct_id%22%3A%22019a577e-78e5-7627-92d0-46093ccc2982%22%2C%22%24sesid%22%3A%5B1762404531910%2C%22019a577e-7a2a-7446-a6a3-c96f3c55e723%22%2C1762404497790%5D%2C%22%24initial_person_info%22%3A%7B%22r%22%3A%22https%3A%2F%2Fwww.google.com%2F%22%2C%22u%22%3A%22https%3A%2F%2Fpostsyncer.com%2Ftools%2Fmixcloud-audio-downloader%22%7D%7D`;

    // ====== 2️⃣ Gửi request đến API ======
    const res = await axios.post(
      'https://postsyncer.com/api/social-media-downloader',
      {
        url: url,
        platform: 'mixcloud'
      },
      {
        headers: {
          'authority': 'postsyncer.com',
          'accept': '*/*',
          'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
          'content-type': 'application/json',
          'origin': 'https://postsyncer.com',
          'referer': 'https://postsyncer.com/tools/mixcloud-audio-downloader',
          'user-agent': 'Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36',
          'x-csrf-token': FIXED_TOKEN,
          'cookie': FIXED_COOKIE
        },
        timeout: 20000
      }
    );

    const data = res.data;
    if (!data || data.error) {
      return {
        error: true,
        message: 'Cannot fetch Mixcloud media info.',
        detail: data?.message || 'Unknown error.'
      };
    }

    // ====== 3️⃣ Chuẩn hóa dữ liệu ======
    const result = {
      id: data.url?.split('/').filter(Boolean).pop() || null,
      title: data.title || '',
      author: data.author || '',
      duration: data.duration || 0,
      thumbnail: data.thumbnail || '',
      source: 'mixcloud',
      type: data.type || 'audio',
      medias: (data.medias || []).map(m => ({
        format_id: m.format_id || '',
        type: m.type || 'audio',
        quality: m.quality || '',
        url: m.url || '',
        extension: m.extension || ''
      }))
    };

    return result;

  } catch (error) {
    console.error('❌ Mixcloud Error:', error.message);
    return {
      error: true,
      message: 'Cannot fetch Mixcloud media info.',
      detail: error.message || error
    };
  }
};