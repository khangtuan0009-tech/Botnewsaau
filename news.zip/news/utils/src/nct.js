const axios = require('axios');
const fs = require('fs');
const path = require('path');

// ====== HÀM CHUYỂN ĐỔI THỜI GIAN ======
function conMs(ms) {
  const minutes = Math.floor(ms / 60);
  const seconds = Math.floor(ms % 60);
  return `${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}`;
}

function formatNumber(num) {
  if (isNaN(num)) return 0;
  return num.toLocaleString('de-DE');
}

// ====== LẤY CHI TIẾT 1 BÀI HÁT (JSON + link audio) ======
async function getDetail(key) {
  try {
    const { data } = await axios.get(`https://graph.nhaccuatui.com/api/v1/song/detail/${encodeURIComponent(key)}`, {
      params: { key, timestamp: Date.now() },
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    const info = data?.data;
    if (!info) return null;

    const streamUrls = info.streamURL || info.streamUrls || {};
    const bestStream = (Array.isArray(streamUrls) ? streamUrls.find(a => a.value === 320) : null)?.stream
      || (Array.isArray(streamUrls) ? streamUrls[0]?.stream : null)
      || info.playUrl
      || info.download;

    if (!bestStream) return null;

    return {
      id: info.key,
      title: info.name || info.title,
      author: info.artistName || info.artists?.map(a => a.name).join(", "),
      album: info.album?.title || "Không có",
      genre: info.genre || "Không rõ",
      duration: conMs(info.duration),
      likes: formatNumber(info.likeCount || 0),
      listens: formatNumber(info.listened || 0),
      release_date: info.dateRelease || "Không rõ",
      thumbnail: info.thumbnail,
      link: info.linkShare || info.shareUrl || info.link,
      attachments: [{ type: "Audio", url: bestStream }]
    };
  } catch (err) {
    console.error("❌ Lỗi getDetail:", err.message);
    return null;
  }
}

// ====== SEARCH BÀI HÁT (TRẢ JSON + LINK AUDIO) ======
async function search(keyword, limit = 5) {
  try {
    if (!keyword) throw new Error("Thiếu từ khóa tìm kiếm!");

    const { data } = await axios.get("https://graph.nhaccuatui.com/api/v1/search/all", {
      params: { keyword, page: 1, pageSize: limit },
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    const songs = data?.data?.songs || [];
    if (!songs.length) return [];

    const result = [];
    for (let song of songs) {
      const detail = await getDetail(song.key);
      if (detail) result.push(detail);
    }

    return result;
  } catch (err) {
    console.error("❌ Lỗi search:", err.message);
    return [];
  }
}

// ====== TẢI NHẠC VỀ CACHE ======
async function downloadStream(url, filename) {
  try {
    const cacheDir = path.join(__dirname,"..", "..", "mdl", "cmds", "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);

    const filepath = path.join(cacheDir, filename.replace(/[\\/:*?"<>|]/g, "_") + ".mp3");
    const writer = fs.createWriteStream(filepath);

    const res = await axios({ url, method: "GET", responseType: "stream" });
    res.data.pipe(writer);

    return new Promise((resolve, reject) => {
      writer.on("finish", () => resolve(filepath));
      writer.on("error", reject);
    });
  } catch (err) {
    console.error("❌ Lỗi downloadStream:", err.message);
    return null;
  }
}

module.exports = { search, getDetail, downloadStream };