const axios = require("axios");
const crypto = require("crypto");

const API_KEY = "X5BM3w8N7MKozC0B85o4KMlzLZKhV00y";
const SECRET_KEY = "acOrvUS15XRW2o9JksiK1KgQ6Vbds8ZW";
const VERSION = "1.11.13";
const BASE_URL = "https://zingmp3.vn";

const paramsAllow = ["ctime", "id", "type", "page", "count", "version"];

function sha256(str) {
  return crypto.createHash("sha256").update(str).digest("hex");
}

function hmac512(str, key) {
  return crypto.createHmac("sha512", key).update(Buffer.from(str, "utf8")).digest("hex");
}

function sortParams(obj) {
  return Object.fromEntries(Object.entries(obj).sort());
}

function filterParams(obj) {
  const sorted = sortParams(obj);
  const filtered = {};
  for (const key in sorted) {
    if (paramsAllow.includes(key) && sorted[key]) filtered[key] = sorted[key];
  }
  return filtered;
}

function encodeParams(obj) {
  return Object.keys(obj)
    .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(obj[k])}`)
    .join("");
}

function getSig(path, params) {
  const strParams = encodeParams(filterParams(params));
  return hmac512(path + sha256(strParams), SECRET_KEY);
}

async function getCookie() {
  const res = await axios.get(BASE_URL);
  return res.headers["set-cookie"]?.[1] || "";
}

async function zingRequest(path, params) {
  const cookie = await getCookie();
  const url = BASE_URL + path;
  const res = await axios.get(url, {
    headers: { Cookie: cookie },
    params: { ...params, sig: getSig(path, params) },
  });
  return res.data;
}

async function search(keyword, count = 5) {
  const ctime = Math.floor(Date.now() / 1000).toString();
  const path = "/api/v2/search";
  const params = {
    q: keyword,
    type: "song",
    count,
    ctime,
    version: VERSION,
    apiKey: API_KEY,
  };
  const res = await zingRequest(path, params);
  const data = res.data?.items?.map(song => ({
    id: song.encodeId,
    title: song.title,
    artists: song.artistsNames,
    thumbnail: song.thumbnailM || song.thumbnail,
    duration: song.duration,
  }));
  return { keyword, count: data?.length || 0, data };
}

async function download(idOrUrl) {
  // Nếu truyền link thì tách lấy encodeId
  let id = idOrUrl;
  const match = idOrUrl.match(/\/([A-Z0-9]{8})\.html/);
  if (match) id = match[1];

  const ctime = Math.floor(Date.now() / 1000).toString();

  // ===== Lấy thông tin bài hát =====
  const infoPath = "/api/v2/song/get/info";
  const infoParams = { id, ctime, version: VERSION, apiKey: API_KEY };
  const infoRes = await zingRequest(infoPath, infoParams);
  const songInfo = infoRes.data || {};

  // ===== Lấy link 128kb =====
  const streamPath = "/api/v2/song/get/streaming";
  const streamParams = { id, ctime, version: VERSION, apiKey: API_KEY };
  const streamRes = await zingRequest(streamPath, streamParams);
  const urls = streamRes.data || {};

  return {
    id,
    title: songInfo.title || "Unknown",
    artists: songInfo.artistsNames || "Unknown",
    duration: songInfo.duration || 0,
    ctime,
    author: "nvh",
    source: "ZingMP3",
    audio: urls["128"] || null,
    quality: "128kbps"
  };
}

module.exports = {
  search,
  download,
};