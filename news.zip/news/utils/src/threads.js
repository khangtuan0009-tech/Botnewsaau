const axios = require('axios');
const qs = require('qs');

async function downloadv1(url) {
  if (!url) throw new Error("Thiếu URL Threads cần tải!");

  try {
    const res = await axios.post(
      "https://savethreads.io/proxy.php",
      qs.stringify({ url }),
      {
        headers: {
          "authority": "savethreads.io",
          "accept": "*/*",
          "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          "origin": "https://savethreads.io",
          "referer": "https://savethreads.io/vi",
          "sec-ch-ua": '"Chromium";v="107", "Not=A?Brand";v="24"',
          "sec-ch-ua-mobile": "?1",
          "sec-ch-ua-platform": '"Android"',
          "user-agent": "Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36",
          "x-requested-with": "XMLHttpRequest",
          "cookie": "PHPSESSID=f556uo7tlihheiivmnin1n9hu8"
        }
      }
    );

    const data = res.data?.api;
    if (!data || data.status !== "OK") {
      throw new Error("Không lấy được dữ liệu Threads!");
    }

    const results = [];
    if (Array.isArray(data.mediaItems)) {
      for (const item of data.mediaItems) {
        results.push({
          type: item.type,
          url: item.mediaUrl,
          quality: item.mediaQuality || null,
          size: item.mediaFileSize || null,
        });
      }
    }

    return {
      id: data.id,
      title: data.title || "Không có tiêu đề",
      description: data.description || "",
      preview: data.previewUrl || data.imagePreviewUrl || null,
      user: {
        name: data.userInfo?.name,
        username: data.userInfo?.username,
        avatar: data.userInfo?.userAvatar,
        bio: data.userInfo?.userBio,
        followers: data.userStats?.followersCount || null,
      },
      stats: {
        likes: data.mediaStats?.likesCount || 0,
        comments: data.mediaStats?.commentsCount || 0,
        favourites: data.mediaStats?.favouritesCount || 0,
        shares: data.mediaStats?.sharesCount || 0,
      },
      results
    };

  } catch (err) {
    console.error("❌ Lỗi khi tải Threads:", err.message);
    return null;
  }
}

module.exports = {
  downloadv1
};