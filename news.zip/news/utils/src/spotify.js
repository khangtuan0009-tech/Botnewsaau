const axios = require('axios');
const fetch = require('node-fetch');

async function downloadv1(url) {
  if (!url) throw new Error('URL is required');

  try {
    // Lấy URL gốc nếu dùng link rút gọn
    const getOriginalUrl = async (link) => {
      try {
        const response = await fetch(link);
        return response.url;
      } catch (err) {
        throw new Error('Please input a valid URL');
      }
    };

    const originalUrl = await getOriginalUrl(url);

    // Chỉ hỗ trợ Spotify
    if (!originalUrl.includes('spotify.com/track')) {
      throw new Error('Invalid Spotify URL');
    }

    // Gọi API duy nhất
    const apiUrl = `http://apinvh.zzux.com/api/mediadl?url=${encodeURIComponent(originalUrl)}`;
    const response = await axios.get(apiUrl);

    // Kiểm tra lỗi từ API
    if (response.data.error) {
      throw new Error('Failed to fetch track data');
    }

    return {
      title: response.data.title,
      artist: response.data.author,
      duration: response.data.duration,
      thumbnail: response.data.thumbnail,
      url: response.data.medias[0].url, // link mp3 chất lượng đầu tiên
      quality: response.data.medias[0].quality,
      extension: response.data.medias[0].extension,
      type: response.data.type
    };
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
}

module.exports = { downloadv1 };