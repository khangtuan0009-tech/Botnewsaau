const axios = require('axios');

async function search(username) {
  if (!username) throw new Error('Username is required');

  try {
    const apiUrl = `https://www.instagram.com/api/v1/web/search/topsearch/?context=blended&include_reel=true&query=${encodeURIComponent(username)}&rank_token=0.21162204406586982&search_session_id=4d23483b-0b05-4231-898d-7fe58d7612bc&search_surface=web_top_search`;

    const headers = {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36',
      'authority': 'www.instagram.com',
      'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
      'referer': 'https://www.instagram.com/explore/search/',
      'sec-ch-prefers-color-scheme': 'light',
      'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
      'sec-ch-ua-full-version-list': '"Chromium";v="107.0.5304.74", "Not=A?Brand";v="24.0.0.0"',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-model': '"CPH2179"',
      'sec-ch-ua-platform': '"Android"',
      'sec-ch-ua-platform-version': '"10.0.0"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'x-asbd-id': '359341',
      'x-csrftoken': '4hqfYtTIGhouf6Gq9LDcrbiVeuulneSC',
      'x-ig-app-id': '1217981644879628',
      'x-ig-www-claim': 'hmac.AR1zF2zBlg5IqeE9mgdH-hX5dMVq9cGNsjPqzL_0GwTbEka7',
      'x-requested-with': 'XMLHttpRequest',
      'x-web-session-id': 'md2tfs:j7ytf4:1haadh',
      'Cookie': 'mid=aQxICAABAAGErBdlRu2d79LRRquC; datr=CkgMae5lqT1XPJ7HH6JppEBA; ig_did=448DDEFF-7E2D-46EC-AA87-ECED9EB7133C; dpr=1.7; ig_nrcb=1; ds_user_id=75258044368; sessionid=75258044368%3A7yPvHh3Zi6JEIv%3A27%3AAYjq4e8BjKcOdiBlrrYdB14MthwQln2we-2LCe5Itg;',
    };

    const response = await axios.get(apiUrl, { headers });
    const users = response.data?.users || [];

    if (users.length === 0) throw new Error('No users found');

    // Trả về toàn bộ danh sách người dùng tìm thấy
    return users.map(({ user }) => ({
      username: user.username,
      full_name: user.full_name,
      is_verified: user.is_verified,
      is_private: user.is_private,
      follower_count: user.follower_count,
      profile_pic_url: user.profile_pic_url,
      profile_pic_url_hd: user.profile_pic_url_hd,
      pk_id: user.pk_id,
    }));
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
}

module.exports = { search };