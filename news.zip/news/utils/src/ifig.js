const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

function compact(obj) {
  if (obj == null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) {
    const arr = obj.map(compact).filter(v => !(v == null || (typeof v === 'object' && !Array.isArray(v) && v && Object.keys(v).length === 0)));
    return arr.length ? arr : undefined;
  }
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    const vv = compact(v);
    const emptyObj = typeof vv === 'object' && !Array.isArray(vv) && vv && Object.keys(vv).length === 0;
    const emptyArr = Array.isArray(vv) && vv.length === 0;
    if (vv == null || vv === '' || Number.isNaN(vv) || emptyObj || emptyArr) continue;
    out[k] = vv;
  }
  return Object.keys(out).length ? out : undefined;
}

function pickBestImage(cands = []) {
  if (!Array.isArray(cands) || cands.length === 0) return null;
  const score = (u = "") => {
    const m = u.match(/[_-]s(\d+)(x(\d+))?/i) || u.match(/_p(\d+)x(\d+)/i);
    if (m) {
      const w = parseInt(m[1], 10) || 0;
      const h = parseInt(m[3] || m[2] || m[1], 10) || 0;
      return w * h;
    }
    if (/hd|1080|720|640/i.test(u)) return 999999;
    return 0;
  };
  const sorted = cands.slice().sort((a, b) => score(b?.url) - score(a?.url));
  return sorted[0]?.url || cands[0]?.url || null;
}

function normUser(j = {}) {
  const u = j?.data?.user || j?.user || {};
  return compact({
    id: u?.id || u?.pk || null,
    username: u?.username || null,
    name: u?.full_name || null,
    verified: !!u?.is_verified,
    private: !!u?.is_private,
    followers: Number(u?.follower_count ?? u?.edge_followed_by?.count ?? 0),
    following: Number(u?.following_count ?? u?.edge_follow?.count ?? 0),
    posts: Number(u?.media_count ?? u?.edge_owner_to_timeline_media?.count ?? 0),
    avatar: u?.profile_pic_url_hd || u?.profile_pic_url || u?.hd_profile_pic_url_info?.url || null
  });
}

function normPostsFromFeed(feedJson = {}) {
  const items = Array.isArray(feedJson?.items) ? feedJson.items : [];
  return items.map(it => {
    const cands = it?.image_versions2?.candidates
      || it?.carousel_media?.[0]?.image_versions2?.candidates
      || [];
    return {
      id: it?.id || null,
      code: it?.code || it?.shortcode || null,
      display_url: pickBestImage(cands),
    };
  }).filter(p => p.id);
}

async function resolveUser(identifier, headers, timeoutMs = 15000) {
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const isId = /^[0-9]+$/.test(String(identifier));
    if (isId) return { user_id: String(identifier), username: null };
    const username = String(identifier).replace(/^@/, "");
    const url = `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`;
    const r = await fetch(url, { headers, signal: ctrl.signal });
    if (!r.ok) throw new Error(`resolve username HTTP ${r.status}`);
    const j = await r.json();
    const id = j?.data?.user?.id || j?.user?.id;
    if (!id) throw new Error("Không tìm thấy id từ username");
    return { user_id: String(id), username };
  } finally { clearTimeout(to); }
}

async function fetchMediaDetail(id, headers, timeoutMs = 10000) {
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const url = `https://www.instagram.com/api/v1/media/${encodeURIComponent(id)}/info/`;
    const r = await fetch(url, { headers, signal: ctrl.signal });
    if (!r.ok) return null;
    const j = await r.json();
    const it = j?.items?.[0];
    if (!it) return null;

    const cands = it?.image_versions2?.candidates
      || it?.carousel_media?.[0]?.image_versions2?.candidates
      || [];
    const video = Array.isArray(it?.video_versions) && it.video_versions[0]?.url ? it.video_versions[0].url : null;

    return compact({
      id: it?.id || null,
      code: it?.code || it?.shortcode || null,
      like_count: Number(it?.like_count ?? it?.play_count ?? 0),
      comment_count: Number(it?.comment_count ?? 0),
      caption: it?.caption?.text || "",
      media_type: it?.media_type || null,
      display_url: pickBestImage(cands),
      video_url: video
    });
  } catch { return null; }
  finally { clearTimeout(to); }
}

async function infoig(identifier, opts = {}) {
  if (!identifier) throw new Error("Thiếu username hoặc user_id");

  const {
    cookie = `mid=aCDh0QALAAHYYKplZXGOF9IsHPvJ; ig_did=E5FD8A68-6BA6-4257-8F1A-E8712AFD980A; csrftoken=pGelWYleNbHlNUEjnHdBF0xM7cgo5t8E; ds_user_id=74756682556; sessionid=74756682556%3A0LKvp3zaCXRRJL%3A25%3AAYiJ5EUC8ver2D4ELvrIsc1APzqtaQTgcFZe_TFbRw;`,
    csrf = "pGelWYleNbHlNUEjnHdBF0xM7cgo5t8E",
    igAppId = "936619743392459",
    timeoutMs = 20000,
    count = 10,
    includeRaw = false,
    parallel = 5 // giới hạn concurrent gọi media detail
  } = opts;

  const feedCount = Math.max(1, Math.min(50, Number(count) || 10));

  const baseHeaders = {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9,vi;q=0.8",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "referer": "https://www.instagram.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
    "x-ig-app-id": igAppId,
    "x-csrftoken": csrf,
    "cookie": cookie
  };

  const { user_id, username } = await resolveUser(identifier, baseHeaders, Math.min(timeoutMs, 15000));

  const ctrl1 = new AbortController(); const to1 = setTimeout(() => ctrl1.abort(), timeoutMs);
  let rawUser = null; let user = null;
  try {
    const userUrl = username
      ? `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`
      : `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(user_id)}`;
    const r1 = await fetch(userUrl, { headers: baseHeaders, signal: ctrl1.signal });
    if (!r1.ok) throw new Error(`user info HTTP ${r1.status}`);
    rawUser = await r1.json();
    user = normUser(rawUser);
  } finally { clearTimeout(to1); }

  const ctrl2 = new AbortController(); const to2 = setTimeout(() => ctrl2.abort(), timeoutMs);
  let rawFeed = null; let posts = [];
  try {
    const feedUrl = `https://www.instagram.com/api/v1/feed/user/${encodeURIComponent(user_id)}/?count=${encodeURIComponent(feedCount)}`;
    const r2 = await fetch(feedUrl, { headers: baseHeaders, signal: ctrl2.signal });
    if (r2.ok) {
      rawFeed = await r2.json();
      const basePosts = normPostsFromFeed(rawFeed).slice(0, feedCount);

      // throttle calls to media detail
      const chunks = [];
      for (let i = 0; i < basePosts.length; i += parallel) chunks.push(basePosts.slice(i, i + parallel));
      const detailed = [];
      for (const group of chunks) {
        const part = await Promise.all(group.map(p => fetchMediaDetail(p.id, baseHeaders, Math.min(timeoutMs, 10000))));
        for (let i = 0; i < group.length; i++) {
          detailed.push(compact({ ...group[i], ...part[i] }));
        }
      }
      posts = compact(detailed) || [];
    } else {
      posts = [];
      rawFeed = { error: true, status: r2.status, text: await r2.text() };
    }
  } finally { clearTimeout(to2); }

  const result = compact({
    ok: true,
    user,
    posts,
    resolved: compact({ user_id, username })
  });

  if (includeRaw) result.raw = { user: rawUser, feed: rawFeed };
  return result;
}

module.exports = { infoig };


