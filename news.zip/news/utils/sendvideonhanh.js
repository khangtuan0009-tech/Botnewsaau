const chalk = require('chalk');
const axios = require("axios");
const gradient = require('gradient-string');
const con = require('../vh/config.json');
const theme = con.DESIGN.Theme;
let co;
let error;
let notificationColor;

// Gradient/theme setup (giữ nguyên logic cũ)
if (theme.toLowerCase() === 'blue') {
  co = gradient([{color: "#1affa3", pos: 0.2},{color:"cyan",pos:0.4},{color:"pink",pos:0.6},{color:"cyan",pos:0.8},{color:'#1affa3',pos:1}]);
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme == "dream2") {
  co = gradient("#a200ff","#21b5ff","#a200ff");
  notificationColor = co;
} else if (theme.toLowerCase() === 'dream') {
  co = gradient([{color: "blue", pos: 0.2},{color:"pink",pos:0.3},{color:"gold",pos:0.6},{color:"pink",pos:0.8},{color: "blue", pos:1}]);
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'test') {
  co = gradient("#243aff", "#4687f0", "#5800d4");
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'fiery') {
  co = gradient("#fc2803", "#fc6f03", "#fcba03");
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'rainbow') {
  co = gradient.rainbow;
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'pastel') {
  co = gradient.pastel;
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'cristal') {
  co = gradient.cristal;
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'red') {
  co = gradient("red", "orange");
  error = chalk.red.bold;
  notificationColor = co;
} else if (theme.toLowerCase() === 'aqua') {
  co = gradient("#0030ff", "#4e6cf2");
  error = chalk.blueBright;
  notificationColor = co;
} else if (theme.toLowerCase() === 'pink') {
  co = gradient("#d94fff", "purple");
  notificationColor = co;
} else if (theme.toLowerCase() === 'retro') {
  co = gradient.retro;
  notificationColor = co;
} else if (theme.toLowerCase() === 'sunlight') {
  co = gradient("orange", "#ffff00", "#ffe600");
  notificationColor = co;
} else if (theme.toLowerCase() === 'teen') {
  co = gradient.teen;
  notificationColor = co;
} else if (theme.toLowerCase() === 'summer') {
  co = gradient.summer;
  notificationColor = co;
} else if (theme.toLowerCase() === 'flower') {
  co = gradient.pastel;
  notificationColor = co;
} else if (theme.toLowerCase() === 'ghost') {
  co = gradient.mind;
  notificationColor = co;
} else if (theme === 'hacker') {
  co = gradient('#47a127', '#0eed19', '#27f231');
  notificationColor = co;
} else {
  co = gradient("#243aff", "#4687f0", "#5800d4");
  error = chalk.red.bold;
  notificationColor = co;
}

// 🌐 User-Agent setup
const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
  "Mozilla/5.0 (Windows NT 11.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
  "Mozilla/5.0 (Linux; Android 14; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (Linux; Android 12; Redmi Note 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15"
];

let currentUserAgent = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
setInterval(() => {
  currentUserAgent = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
  console.log(chalk.greenBright(`🌐 User-Agent refreshed: ${currentUserAgent}`));
}, 10 * 60 * 1000);

// 📥 Stream URL
async function stream_url(url) {
  try {
    const response = await axios({
      url: url,
      responseType: 'stream',
      timeout: 150000,
      headers: {
        'User-Agent': currentUserAgent,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive'
      },
      validateStatus: status => status >= 200 && status < 400
    });
    return response.data;
  } catch {
    return null;
  }
}

// 📤 Upload video
async function upload(url, api) {
  try {
    const stream = await stream_url(url);
    if (!stream) return null;

    const res = await api.postFormData('https://upload.facebook.com/ajax/mercury/upload.php', {
      upload_1024: stream
    });

    const body = JSON.parse(res.body.replace('for (;;);', ''));
    const metadata = body.payload?.metadata?.[0];
    if (metadata) return Object.entries(metadata)[0];
  } catch {}
  return null;
}

// ======================= Queue logic =======================
module.exports = async function (api) {
  const queues = {
    vdgai: { list: [], status: false, file: './video/vdgai.json' },
    vdanime: { list: [], status: false, file: './video/vdanime.json' },
    vdcos: { list: [], status: false, file: './video/vdcos.json' },
    vdtrai: { list: [], status: false, file: './video/vdtrai.json' },
    vdchill: { list: [], status: false, file: './video/vdchill.json' },
    vdnhac: { list: [], status: false, file: './video/vdnhac.json' },
    vdsad: { list: [], status: false, file: './video/vdsad.json' },
  };

  const uploadUrls = async (key) => {
    const queue = queues[key];
    if (queue.status) return; // đang upload

    try {
      delete require.cache[require.resolve(queue.file)];
      const urls = require(queue.file);

      const needed = 6 - queue.list.length; // full queue 5
      if (needed <= 0) return;

      // chỉ upload nếu queue < 2
      if (queue.list.length < 2) {
        queue.status = true;
        const uploadTasks = urls
          .filter(u => !queue.list.includes(u))
          .slice(0, needed)
          .map(u => upload(u, api));

        const results = await Promise.all(uploadTasks);
        for (const result of results) {
          if (result) queue.list.push(result);
        }
        queue.status = false;
      }
    } catch (err) {
      console.error(`Error loading URLs for ${key}:`, err.message);
      queue.status = false;
    }
  };

  Object.keys(queues).forEach((key) => {
    // check mỗi 15s nếu queue < 2
    setInterval(async () => {
      if (queues[key].list.length < 2) await uploadUrls(key);
    }, 15000);

    // log mỗi 5 phút
    setInterval(() => {
      console.log(`${notificationColor(`${key}: ${queues[key].list.length} videos`)}`);
    }, 5 * 60 * 1000);
  });

  global.vdgai = queues.vdgai.list;
  global.vdanime = queues.vdanime.list;
  global.vdcos = queues.vdcos.list;
  global.vdtrai = queues.vdtrai.list;
  global.vdchill = queues.vdchill.list;
  global.vdnhac = queues.vdnhac.list;
  global.vdsad = queues.vdsad.list;
};