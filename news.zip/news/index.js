const { spawn } = require("child_process");
const logger = require("./utils/log");
const chalk = require("chalk");
const fs = require("fs");
const path = require("path");

const dirPath = path.join(__dirname, "nvhz");
const startTimePath = path.join(dirPath, "timestart.json");

function getStartTime() {
    try {
        if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
        if (fs.existsSync(startTimePath)) {
            const data = JSON.parse(fs.readFileSync(startTimePath, "utf8"));
            if (data && data.startTime) return new Date(data.startTime);
        }
    } catch (e) {
        console.error(chalk.red("⚠️ Lỗi khi đọc timestart.json:"), e);
    }

    const now = new Date();
    fs.writeFileSync(startTimePath, JSON.stringify({ startTime: now }));
    return now;
}

const startTime = getStartTime();

// ===== HÀM TÍNH THỜI GIAN HOẠT ĐỘNG =====
function getUptime() {
    const diff = Date.now() - startTime.getTime();
    const sec = Math.floor(diff / 1000);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h} giờ ${m} phút ${s} giây`;
}

// ===== CHẠY BOT =====
function startBot(message) {
    const width = process.stdout.columns || 80;

    const bannerLines = [
        "",
        chalk.magentaBright("╔════════════════════════════════════════════════╗"),
        chalk.magentaBright("║                ZENITSU BOT SYSTEM              ║"),
        chalk.magentaBright("╚════════════════════════════════════════════════╝"),
        "",
        chalk.yellowBright(`🕒 Khởi động lần đầu: ${startTime.toLocaleString("vi-VN")}`),
        chalk.greenBright(`⏱️ Đã hoạt động được: ${getUptime()}`),
        chalk.cyanBright("👤 Created by nvh💤"),
        ""
    ];

    const center = (line) => {
        const pad = Math.max(0, Math.floor((width - line.replace(/\x1B\[[0-9;]*m/g, "").length) / 2));
        return " ".repeat(pad) + line;
    };

    console.clear();
    console.log("\n" + bannerLines.map(center).join("\n") + "\n");

    if (message) logger(message, "[ Bắt Đầu ]");

    const child = spawn("node", ["--trace-warnings", "--async-stack-traces", "zenitsu.js"], {
        cwd: __dirname,
        stdio: "inherit",
        shell: true
    });

    child.on("close", async (codeExit) => {
        const codeStr = String(codeExit);
        if (codeExit == 1) return startBot("🔁 Restarting...");
        if (codeStr.startsWith("2")) {
            const secPart = codeStr.slice(1);
            const sec = secPart === "" ? 2 : parseInt(secPart, 10);
            const delayMs = (Number.isFinite(sec) ? sec : 2) * 1000;
            await new Promise(resolve => setTimeout(resolve, delayMs));
            return startBot("🔄 Reopening...");
        }
        return;
    });

    child.on("error", function (error) {
        logger("An error occurred: " + JSON.stringify(error), "[ Starting ]");
    });
}

startBot();