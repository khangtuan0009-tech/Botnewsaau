//////////////////////////////////////////////////////
//========= Require all variable need use =========//
/////////////////////////////////////////////////////
const moment = require("moment-timezone");
const { readdirSync, readFileSync, writeFileSync, existsSync, unlinkSync, rm } = require("fs-extra");
const { join, resolve } = require("path");
const chalk = require("chalk");
const fs = require('fs-extra');
const logger = require("./utils/log.js");
const login = require("./nvhz/Fca"); 
const bypass = require("./nvhz/login/loginfb.js");

global.account = {
  appstate: fs.existsSync('./vh/appstate.json') ? JSON.parse(fs.readFileSync('./vh/appstate.json', 'utf8') || '[]') : (fs.writeFileSync('./nvhz/appstate.json', '[]'), JSON.parse('[]')),
  cookie: JSON.parse(readFileSync('./vh/appstate.json')).map(i => `${i.key}=${i.value}`).join(";"),
  token: {
    EAAAAU: JSON.parse(fs.readFileSync('./utils/tokens.json', 'utf8')).EAAAAU,
    EAAD6V7: JSON.parse(fs.readFileSync('./utils/tokens.json', 'utf8')).EAAD6V7
  }
};	

global.client = new Object({
  commands: new Map(),
  events: new Map(),
  cooldowns: new Map(),
  eventRegistered: new Array(),
  handleSchedule: new Array(),
  handleReaction: new Array(),
  handleReply: new Array(),
  mainPath: process.cwd(),
  configPath: new String(),
  getTime: function (option) {
    switch (option) {
      case "seconds": return `${moment.tz("Asia/Ho_Chi_minh").format("ss")}`;
      case "minutes": return `${moment.tz("Asia/Ho_Chi_minh").format("mm")}`;
      case "hours": return `${moment.tz("Asia/Ho_Chi_minh").format("HH")}`;
      case "date": return `${moment.tz("Asia/Ho_Chi_minh").format("DD")}`;
      case "month": return `${moment.tz("Asia/Ho_Chi_minh").format("MM")}`;
      case "year": return `${moment.tz("Asia/Ho_Chi_minh").format("YYYY")}`;
      case "fullHour": return `${moment.tz("Asia/Ho_Chi_minh").format("HH:mm:ss")}`;
      case "fullYear": return `${moment.tz("Asia/Ho_Chi_minh").format("DD/MM/YYYY")}`;
      case "fullTime": return `${moment.tz("Asia/Ho_Chi_minh").format("HH:mm:ss DD/MM/YYYY")}`;
    }
  }
});

global.data = new Object({
  threadInfo: new Map(),
  threadData: new Map(),
  userName: new Map(),
  userBanned: new Map(),
  threadBanned: new Map(),
  commandBanned: new Map(),
  threadAllowNSFW: new Array(),
  allUserID: new Array(),
  allCurrenciesID: new Array(),
  allThreadID: new Array()
});

global.utils = require("./utils");

global.bypass = bypass;

global.account = new Object();

global.nodemodule = new Object();

global.config = new Object();

global.configModule = new Object();

global.moduleData = new Array();

global.anti = resolve(__dirname, "./nvhz/anti.json");

global.api = global.api || {};

const apiPath = require("path").join(__dirname, "./utils/src");
for (const file of fs.readdirSync(apiPath)) {
  if (file.endsWith(".js")) {
    const name = require("path").basename(file, ".js");
    global.api[name] = require(require("path").join(apiPath, file));
  }
}

global.language = new Object();

//////////////////////////////////////////////////////////
//========= Find and get variable from Config =========//
/////////////////////////////////////////////////////////

var configValue;
try {
  global.client.configPath = join(global.client.mainPath, "vh", "config.json");
  configValue = require(global.client.configPath);
}
catch {
  if (existsSync(global.client.configPath.replace(/\.json/g, "") + ".temp")) {
    configValue = readFileSync(global.client.configPath.replace(/\.json/g, "") + ".temp");
    configValue = JSON.parse(configValue);
    logger.loader(`Found: ${global.client.configPath.replace(/\.json/g, "") + ".temp"}`);
  }
  else return logger.loader("config.json Đâu Mất Rồi Bro=))?", "error");
}

try {
  for (const key in configValue) global.config[key] = configValue[key];
  logger.loader("Config Done");
}
catch { return logger.loader("Can't load file config!", "error") }

const { Sequelize, sequelize } = require("./nvhz/database");

writeFileSync(global.client.configPath + ".temp", JSON.stringify(global.config, null, 4), 'utf8');

/////////////////////////////////////////
//========= Load language use =========//
/////////////////////////////////////////

const langFile = (readFileSync(`${__dirname}/vh/languages/${global.config.language || "en"}.lang`, { encoding: 'utf-8' })).split(/\r?\n|\r/);
const langData = langFile.filter(item => item.indexOf('#') != 0 && item != '');
for (const item of langData) {
  const getSeparator = item.indexOf('=');
  const itemKey = item.slice(0, getSeparator);
  const itemValue = item.slice(getSeparator + 1, item.length);
  const head = itemKey.slice(0, itemKey.indexOf('.'));
  const key = itemKey.replace(head + '.', '');
  const value = itemValue.replace(/\\n/gi, '\n');
  if (typeof global.language[head] == "undefined") global.language[head] = new Object();
  global.language[head][key] = value;
}

global.getText = function (...args) {
  const langText = global.language;    
  if (!langText.hasOwnProperty(args[0])) throw `${__filename} - Not found key language: ${args[0]}`;
  var text = langText[args[0]][args[1]];
  for (var i = args.length - 1; i > 0; i--) {
    const regEx = RegExp(`%${i}`, 'g');
    text = text.replace(regEx, args[i + 1]);
  }
  return text;
}

try {
  var appStateFile = resolve(join(global.client.mainPath, global.config.APPSTATEPATH || "appstate.json"));
  var appState = require(appStateFile);
  logger.loader(global.getText("mirai", "foundPathAppstate"))
}
catch { return logger.loader(global.getText("mirai", "notFoundPathAppstate"), "error") }

////////////////////////////////////////////////////////////
//========= Login account and start Listen Event =========//
////////////////////////////////////////////////////////////

async function loginAppstate() {
  const fs = require('fs');
  const CHECK_INTERVAL = 30 * 1000;
  let isReconnecting = false;
  const checkAccountStatus = async () => {
    try {
      if (!fs.existsSync('./vh/appstate.json')) return false;
      const appstateData = JSON.parse(fs.readFileSync('./vh/appstate.json', 'utf8'));
      if (!Array.isArray(appstateData) || appstateData.length === 0) return false;
      const requiredFields = ['key', 'value', 'expires'];
      const isValidAppState = appstateData.every(entry => requiredFields.every(field => Object.prototype.hasOwnProperty.call(entry, field)));
      if (!isValidAppState) return false;
      global.account.appstate = appstateData;
      return true;
    } catch {
      return false;
    }
  };

  const handleAccountIssues = async () => {
    if (isReconnecting) return;
    isReconnecting = true;
    try {
      const isValidAppState = await checkAccountStatus();
      if (!isValidAppState) {
        logger("Phát hiện logout, tiến hành đăng nhập lại...", "[ AUTO-LOGIN ]");
        await global.bypass.handleRelogin();
        return;
      }
      try {
        await api.getThreadList(1, null, []);
      } catch (apiError) {
        const errorStr = JSON.stringify(apiError);
        if (
          errorStr.includes("Not logged in") ||
          errorStr.includes("Login required") ||
          errorStr.includes("401") ||
          errorStr.includes("601051028565049") ||
          errorStr.includes("Error validating access token")
        ) {
          logger("ACC CÚT RỒI ĐỂ TAO ĐĂNG NHẬP LẠI", "[ AUTO-LOGIN ]");
          await global.bypass.handleRelogin();
        }
      }
    } finally {
      isReconnecting = false;
    }
  };
}

function onBot({ models }) {
  function parseCookies(cookies) {
    const trimmed = cookies.includes('useragent=') ? cookies.split('useragent=')[0] : cookies;
    return trimmed.split(';').map(pair => {
      let [key, value] = pair.trim().split('=');
      if (value !== undefined) {
        return {
          key,
          value,
          domain: "facebook.com",
          path: "/",
          hostOnly: false,
          creation: new Date().toISOString(),
          lastAccessed: new Date().toISOString()
        };
      }
    }).filter(item => item !== undefined);
  }

  const data = fs.readFileSync('./vh/cookie.txt', 'utf8');
  var appState = parseCookies(data);
  const loginData = {};
  loginData.appState = appState;

  login(loginData, async (loginError, loginApiData) => {    
    if (loginError) {
      logger('KHÔNG THỂ ĐĂNG NHẬP BẰNG ÁP TƠ TIẾN HÀNH LOGIN QUA COOKIE','[ LOGIN-ERROR ]')
      await handleRelogin();
      await new Promise((reset) => setTimeout(reset, 7000))
      logger('Bắt đầu khởi đông lại', '[ RESTART ]')
      process.exit(1)
    }

    loginApiData.setOptions(global.config.FCAOption);
    let loginState = loginApiData.getAppState();
    loginState = JSON.stringify(loginState, null, '\t');

    if (process.env.KEY && global.config.encryptSt) {
      loginState = await encryptState(loginState, process.env.KEY);
      writeFileSync(appStateFile, loginState);
    } else {
      writeFileSync(appStateFile, loginState);
    }

    global.client.api = loginApiData;
    global.config.version = "3.5.0";

    require('./utils/sendvideonhanh')(loginApiData);

    require('./utils/startMDL')(loginApiData, models);

    logger.loader(global.getText("mirai", "finishLoadModule", global.client.commands.size, global.client.events.size));
    writeFileSync(global.client["configPath"], JSON.stringify(global.config, null, 4), "utf8");
    unlinkSync(global["client"]["configPath"] + ".temp");

    const listenerData = { api: loginApiData, models };
    const listener = require("./nvhz/listen")(listenerData);

    function listenerCallback(error, message) {
      if (error) return logger(global.getText("mirai", "handleListenError", JSON.stringify(error)), "error");
      if (["presence", "typ", "read_receipt"].includes(message?.type)) return;
      if (global.config.DeveloperMode) console.log(message);
      return listener(message);
    }

    const connect_mqtt = () => {
      global.handleListen = loginApiData.listenMqtt(listenerCallback);
      setTimeout(() => {
        mqttClient.end();
        connect_mqtt();
      }, 1000 * 60 * 60 * 6);
    };

    connect_mqtt();
    loginAppstate();
  });
}

(async () => {
  try {
    await sequelize.authenticate();
    const authentication = { Sequelize, sequelize };
    const models = require("./nvhz/database/model")(authentication);
    onBot({ models });
  } catch (error) {
    logger(global.getText("mirai", "successConnectDatabase", JSON.stringify(error)), "[ DATABASE ]");
  }
})();

process.on('unhandledRejection', (reason, p) => {
  console.error('LỖI CHƯA XỬ LÝ tại:', p, 'lý do:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('LỖI KHÔNG BẮT ĐƯỢC:', err);
});