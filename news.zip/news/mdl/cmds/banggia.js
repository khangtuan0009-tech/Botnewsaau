const { createCanvas, loadImage } = require("canvas");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "banggia",
  version: "2.1.5",
  hasPermssion: 3,
  credits: "lechii 🥕",
  description: "Bảng giá thuê bot",
  commandCategory: "Tiện ích",
  usages: "",
  cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function ({ api, event }) {
  const { threadID, messageID } = event;
  const send = (msg, file) => api.sendMessage(msg, threadID, file, messageID);

  const canvas = createCanvas(1280, 900);
  const ctx = canvas.getContext("2d");

  const bg = ctx.createLinearGradient(0, 0, 0, canvas.height);
  bg.addColorStop(0, "#0d0325");
  bg.addColorStop(1, "#1a0040");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  function roundedRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  const titleGrad = ctx.createLinearGradient(0, 0, canvas.width, 0);
  titleGrad.addColorStop(0, "#4cc9f0");
  titleGrad.addColorStop(1, "#c36aff");
  ctx.font = "bold 60px Arial";
  ctx.fillStyle = titleGrad;
  ctx.textAlign = "center";
  ctx.fillText("BẢNG GIÁ THUÊ BOT", canvas.width / 2, 100);
  ctx.font = "22px Arial";
  ctx.fillStyle = "#cccccc";
  ctx.fillText("Giải pháp tự động hóa chuyên nghiệp - Tín cậy & Hiệu quả", canvas.width / 2, 140);

  const boxShadow = (x, y, w, h, r, glow) => {
    ctx.save();
    ctx.shadowColor = glow;
    ctx.shadowBlur = 25;
    roundedRect(x, y, w, h, r);
    ctx.fill();
    ctx.restore();
  };

  const colY = 200, boxH = 550;

  // --- CỘT 1 ---
  ctx.fillStyle = "#1b1845";
  boxShadow(100, colY, 330, boxH, 25, "#3c5aff");
  roundedRect(100, colY, 330, boxH, 25);
  ctx.fillStyle = "#1e1b58";
  ctx.fill();
  ctx.font = "bold 28px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText("THUÊ BOT", 265, colY + 55);

  const g1 = [
    { text: "1 tháng", price: "20.000đ", color: "#2a5eff" },
    { text: "3 tháng", price: "55.000đ", color: "#4361ee", popular: true },
    { text: "6 tháng", price: "100.000đ", color: "#3b3bc1" },
    { text: "12 tháng", price: "190.000đ", color: "#262d7d", save: true }
  ];
  let y = colY + 120;
  for (const p of g1) {
    ctx.fillStyle = p.color;
    roundedRect(120, y, 290, 65, 15);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.font = "22px Arial";
    ctx.fillText(`${p.text}  •  ${p.price}`, 265, y + 42);

    if (p.popular) {
      ctx.fillStyle = "#ffcc00";
      roundedRect(325, y - 28, 95, 26, 8);
      ctx.fill();
      ctx.fillStyle = "#3b006a";
      ctx.font = "bold 13px Arial";
      ctx.fillText("Phổ biến 🌟", 372, y - 8);
    }
    if (p.save) {
      ctx.fillStyle = "#16a34a";
      roundedRect(325, y - 28, 95, 26, 8);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.font = "bold 13px Arial";
      ctx.fillText("Tiết kiệm 💸", 372, y - 8);
    }
    y += 90;
  }

  ctx.font = "18px Arial";
  ctx.fillStyle = "#b5b5b5";
  ctx.textAlign = "left";
  const note1 = ["✅ Tự động trả lời tin nhắn 24/7", "✅ Hỗ trợ kỹ thuật miễn phí", "✅ Cập nhật tính năng mới"];
  let ty = colY + 480;
  for (const n of note1) ctx.fillText(n, 130, ty), ty += 30;

  // --- CỘT 2 ---
  ctx.textAlign = "center";
  ctx.fillStyle = "#2a0047";
  boxShadow(480, colY, 330, boxH, 25, "#b566ff");
  roundedRect(480, colY, 330, boxH, 25);
  ctx.fillStyle = "#2a0047";
  ctx.fill();
  ctx.font = "bold 28px Arial";
  ctx.fillStyle = "#ffcc00";
  ctx.fillText("BOT + ADMIN", 645, colY + 55);

  const g2 = [
    { text: "1 tháng", price: "35.000đ", color: "#ffb703" },
    { text: "3 tháng", price: "95.000đ", color: "#fb8500", popular: true },
    { text: "6 tháng", price: "180.000đ", color: "#e76f51" },
    { text: "12 tháng", price: "340.000đ", color: "#9b2226", save: true }
  ];
  y = colY + 120;
  for (const p of g2) {
    ctx.fillStyle = p.color;
    roundedRect(500, y, 290, 65, 15);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.font = "22px Arial";
    ctx.fillText(`${p.text}  •  ${p.price}`, 645, y + 42);

    if (p.popular) {
      ctx.fillStyle = "#ffcc00";
      roundedRect(705, y - 28, 95, 26, 8);
      ctx.fill();
      ctx.fillStyle = "#3b006a";
      ctx.font = "bold 13px Arial";
      ctx.fillText("Phổ biến 🌟", 752, y - 8);
    }
    if (p.save) {
      ctx.fillStyle = "#16a34a";
      roundedRect(705, y - 28, 95, 26, 8);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.font = "bold 13px Arial";
      ctx.fillText("Tiết kiệm 💸", 752, y - 8);
    }
    y += 90;
  }

  ctx.font = "18px Arial";
  ctx.fillStyle = "#b5b5b5";
  ctx.textAlign = "left";
  const note2 = [
    "✅ Tất cả tính năng Bot",
    "✅ Admin quản lý chuyên nghiệp",
    "✅ Ưu tiên hỗ trợ VIP"
  ]; 
  ty = colY + 480; // căn lại đúng độ cao
  for (const n of note2) ctx.fillText(n, 500, ty), ty += 32;

  // --- CỘT 3 ---
  ctx.textAlign = "center";
  ctx.fillStyle = "#1f1b3d";
  boxShadow(860, colY, 330, boxH, 25, "#a259ff");
  roundedRect(860, colY, 330, boxH, 25);
  ctx.fillStyle = "#1f1b3d";
  ctx.fill();
  ctx.font = "bold 28px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText("THANH TOÁN", 1025, colY + 55);

  const qrUrl = "https://files.catbox.moe/cspbbm.jpg";
  try {
    const qr = await loadImage(qrUrl);
    ctx.drawImage(qr, 930, colY + 100, 190, 190);
  } catch {
    ctx.fillStyle = "#444";
    roundedRect(930, colY + 100, 190, 190, 20);
    ctx.fill();
    ctx.fillStyle = "#ccc";
    ctx.fillText("QR ERROR", 1025, colY + 200);
  }

  ctx.font = "20px Arial";
  ctx.fillStyle = "#ccc";
  ctx.fillText("Zalopay", 1025, colY + 330);
  ctx.fillText("STK: 0398787745", 1025, colY + 360);
  ctx.fillText("CHỦ TK: Ng Văn Hưng", 1025, colY + 390);

  const contactY = colY + 450;
  ctx.fillStyle = "rgba(155, 100, 255, 0.15)";
  roundedRect(885, contactY, 310, 80, 15);
  ctx.fill();
  ctx.font = "18px Arial";
  ctx.fillStyle = "#c9b8ff";
  ctx.fillText("Liên hệ tư vấn:", 1025, contactY + 28);
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 18px Arial";
  ctx.fillText("facebook.com/nvhzx", 1025, contactY + 53);

  const btnY = contactY + 100;
  ctx.fillStyle = "rgba(180, 150, 255, 0.25)";
  roundedRect(940, btnY, 100, 35, 10);
  ctx.fill();
  roundedRect(1065, btnY, 100, 35, 10);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.font = "15px Arial";
  ctx.fillText("Tư vấn 24/7", 990, btnY + 24);
  ctx.fillText("Bảo hành", 1115, btnY + 24);

  ctx.font = "16px Arial";
  ctx.fillStyle = "#777";
  ctx.fillText("Powered by lechii 🥕", canvas.width / 2, 830);

  const outPath = path.join(__dirname, "cache", `banggia_${Date.now()}.png`);
  await fs.ensureDir(path.join(__dirname, "cache"));
  const out = fs.createWriteStream(outPath);
  const stream = canvas.createPNGStream();
  stream.pipe(out);

  out.on("finish", async () => {
    send({
      body: "📊 BẢNG GIÁ THUÊ BOT",
      attachment: fs.createReadStream(outPath)
    }, async () => {
      try { await fs.unlink(outPath); } catch {}
    });
  });
};