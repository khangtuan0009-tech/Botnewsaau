const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require("fs");
const path = require("path");

// ===== Cấu hình Gemini ===== //
const geminiApiKey = "AIzaSyAnVBB4wW0PouNYmD7tY6n_LGsbaHYU1m0";
const genAI = new GoogleGenerativeAI(geminiApiKey);

// Bộ nhớ các phiên chat theo user
const chatSessions = new Map();
let geminiModel;

// ⚙️ Khởi tạo model
function initGeminiModel() {
  if (geminiModel) return;
  const systemInstruction = `
Bạn tên là N V H
Bạn được tạo ra bởi duy nhất N V H
Mọi Câu Hỏi Đều Sẽ Có Cấu Trúc [Tên Người Hỏi: Câu Hỏi]
Nếu tên người hỏi là NG VĂN HƯNG thì bạn sẽ nhận họ là bố
Còn với người khác bạn sẽ là Bạn hoặc Tôi 
Trả lời đầy đủ, tự nhiên và có thể dùng emoji phù hợp để tăng tương tác.
Không nhắc lại tên người hỏi trong câu trả lời.
`;

  geminiModel = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
    generationConfig: {
      temperature: 0.9,
      topK: 40,
      topP: 0.8,
    },
    systemInstruction
  });
}

const requestQueue = [];
let isProcessing = false;
const DELAY_BETWEEN_REQUESTS = 2500;

// ===== Xử lý hàng đợi ===== //
async function processQueue() {
  if (isProcessing || requestQueue.length === 0) return;
  isProcessing = true;

  while (requestQueue.length > 0) {
    const { api, event, question, userId, resolve, reject } = requestQueue.shift();

    try {
      initGeminiModel();
      const session = getChatSession(userId);
      session.lastInteraction = Date.now();

      session.history.push({ role: "user", content: question });
      if (session.history.length > 20) session.history = session.history.slice(-20);

      const result = await session.chat.sendMessage(question);
      const response = result.response.text();

      session.history.push({ role: "assistant", content: response });
      cleanupOldSessions();

      resolve(response);
    } catch (err) {
      reject(err);
    }

    await new Promise(res => setTimeout(res, DELAY_BETWEEN_REQUESTS));
  }

  isProcessing = false;
}

// ===== Quản lý phiên chat ===== //
function getChatSession(userId) {
  if (!chatSessions.has(userId)) {
    const chat = geminiModel.startChat({
      history: [],
      generationConfig: { temperature: 0.9, topK: 40, topP: 0.8 }
    });
    chatSessions.set(userId, {
      chat,
      history: [],
      lastInteraction: Date.now()
    });
  }
  return chatSessions.get(userId);
}

function cleanupOldSessions() {
  const MAX_IDLE_TIME = 30 * 60 * 1000;
  const now = Date.now();
  for (const [id, session] of chatSessions.entries()) {
    if (now - session.lastInteraction > MAX_IDLE_TIME) chatSessions.delete(id);
  }
}

// ===== Gửi yêu cầu tới Gemini ===== //
async function callGeminiAPI(api, event, question, userId) {
  return new Promise((resolve, reject) => {
    requestQueue.push({ api, event, question, userId, resolve, reject });
    processQueue();
  });
}

// ===== Tạo ảnh theo prompt ===== //
async function createImageFromPrompt(prompt, outputPath) {
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
  const result = await model.generateContent([
    { text: `Tạo hình ảnh với mô tả sau: ${prompt}` }
  ]);
  const image = result.response.image();
  if (!image) throw new Error("Không tạo được ảnh từ Gemini.");

  const buffer = Buffer.from(await image.arrayBuffer());
  fs.writeFileSync(outputPath, buffer);
  return outputPath;
}

// ===== Lệnh chính Mirai ===== //
module.exports.config = {
  name: "ask",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "nvh (with image-gen)",
  description: "Trò chuyện và tạo ảnh với Gemini AI",
  commandCategory: "Box",
  usages: "[câu hỏi hoặc prompt]",
  cooldowns: 2,
  usePrefix: true,
  useprefix: false
};

const CACHE_DIR = path.join(__dirname, "cache");
if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });

module.exports.run = async ({ api, event, args }) => {
  const question = args.join(" ").trim();
  const userId = event.senderID;
  const attachments = event.messageReply?.attachments || event.attachments;

  if (!question && !attachments?.length)
    return api.sendMessage("🤔 Bạn cần nhập câu hỏi hoặc gửi ảnh kèm mô tả!", event.threadID, event.messageID);

  // Reset session
  if (question.toLowerCase() === "reset") {
    chatSessions.delete(userId);
    return api.sendMessage("🔄 Đã xóa lịch sử trò chuyện của bạn với Gemini!", event.threadID, event.messageID);
  }

  // Nếu có ảnh đính kèm → chỉnh sửa ảnh theo prompt
  if (attachments && attachments[0]?.type === "photo") {
    const imageUrl = attachments[0].url;
    const imagePath = path.join(CACHE_DIR, `${userId}_input.jpg`);
    const resultPath = path.join(CACHE_DIR, `${userId}_result.png`);

    const axios = require("axios");
    const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(imagePath, Buffer.from(response.data));

    api.sendMessage("🎨 Đang tạo ảnh theo mô tả, vui lòng chờ một chút...", event.threadID, event.messageID);

    try {
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
      const result = await model.generateContent([
        { text: `Hãy chỉnh sửa hoặc tái tạo ảnh này theo mô tả: ${question}` },
        { inlineData: { mimeType: "image/jpeg", data: Buffer.from(response.data).toString("base64") } }
      ]);

      const image = result.response.image();
      const buffer = Buffer.from(await image.arrayBuffer());
      fs.writeFileSync(resultPath, buffer);

      api.sendMessage({ body: "✨ Ảnh đã được tạo!", attachment: fs.createReadStream(resultPath) }, event.threadID, event.messageID);
    } catch (err) {
      console.error(err);
      api.sendMessage("❌ Đã xảy ra lỗi khi tạo ảnh từ ảnh gốc.", event.threadID, event.messageID);
    }
    return;
  }

  // Nếu chỉ có prompt văn bản → tạo ảnh hoặc trả lời
  if (question.toLowerCase().startsWith("vẽ") || question.toLowerCase().startsWith("tạo ảnh")) {
    const outputPath = path.join(CACHE_DIR, `${userId}_${Date.now()}.png`);
    api.sendMessage("🖌️ Đang vẽ ảnh theo mô tả của bạn...", event.threadID, event.messageID);

    try {
      const imagePath = await createImageFromPrompt(question, outputPath);
      return api.sendMessage(
        { body: "🎆 Ảnh của bạn đây:", attachment: fs.createReadStream(imagePath) },
        event.threadID,
        event.messageID
      );
    } catch (err) {
      console.error(err);
      return api.sendMessage("❌ Lỗi khi tạo ảnh từ prompt!", event.threadID, event.messageID);
    }
  }

  // Nếu không phải prompt ảnh → hỏi bình thường
  api.sendMessage("💭 Đang suy nghĩ...", event.threadID, event.messageID);

  try {
    const replyText = await callGeminiAPI(api, event, `${userId}: ${question}`, userId);
    api.sendMessage(replyText, event.threadID, event.messageID);
  } catch (error) {
    console.error(error);
    api.sendMessage("❌ Đã xảy ra lỗi khi xử lý yêu cầu Gemini.", event.threadID, event.messageID);
  }
};

// ===== Xem lịch sử ===== //
module.exports.handleReply = async ({ api, event }) => {
  if (event.body.toLowerCase() === "history") {
    const userId = event.senderID;
    const session = chatSessions.get(userId);

    if (!session || session.history.length === 0)
      return api.sendMessage("📭 Bạn chưa có lịch sử trò chuyện nào!", event.threadID, event.messageID);

    const history = session.history
      .map((msg, i) => `${i + 1}. ${msg.role === "user" ? "Bạn" : "Gemini"}: ${msg.content}`)
      .join("\n\n");

    api.sendMessage(`📜 Lịch sử trò chuyện:\n\n${history}`, event.threadID, event.messageID);
  }
};