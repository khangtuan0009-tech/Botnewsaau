module.exports.config = {
  usePrefix: true,
   "name": "sendnoti", 
   "version": "1.1.1",
   "hasPermssion": 2,
   "credits": "Niiozic",
   "description": "Gửi tin nhắn đến tất cả nhóm và reply để phản hồi",
   "commandCategory": "Admin",
   "usages": "[ Nội dung ]",
   "cooldowns": 0
};

let streamURL = (attachment) => {
   let ext = "jpg"; //default extension
   if (attachment.type == "photo") ext = "jpg";
   else if (attachment.type == "video") ext = "mp4"; 
   else if (attachment.type == "audio") ext = "mp3";
   else if (attachment.type == "animated_image") ext = "gif";
   else if (attachment.type == "share") ext = "gif";
   else if (attachment.type == "file") ext = attachment.filename.split('.').pop();

   return require('axios').get(attachment.url, {
       responseType: 'stream'
   }).then(res => (res.data.path = `tmp.${ext}`, res.data)).catch(e => null);
}

moment = require("moment-timezone");
fullTime = () => moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || DD/MM/YYYY");

module.exports.run = async({ api, event, Users }) => {
   if (!event.args[1] && (event.type == "message_reply" ? event.messageReply.attachments : event.attachments.length != 0 ? event.attachments : "nofile") == "nofile") {
       return api.sendMessage(`⚠️ Vui lòng sử dụng như sau:\n${global.config.PREFIX}sendnoti + ND cần gửi\nVí Dụ: ${global.config.PREFIX}sendnoti Alo`, event.threadID, event.messageID);
   }

   var notificationMessage = `[ Thông Báo Admin ]\n\n👤 Từ Admin: ${(await Users.getData(event.senderID)).name}\n📝 Nội dung: ${!event.args[1] ? "chỉ có tệp" : event.body.slice(event.body.indexOf(event.args[1]))}\n\n📌 Reply tin nhắn này để phản hồi`
   
   var messageData = (event.type == "message_reply" ? event.messageReply.attachments : event.attachments.length != 0 ? event.attachments : "nofile") == "nofile" ? notificationMessage : {
       body: notificationMessage,
       attachment: await Promise.all((event.type == "message_reply" ? event.messageReply.attachments : event.attachments).map(a => streamURL(a)))
   };

   var successCount = 0, errorCount = 0;
   
   for (var threadIdentifier of global.data.allThreadID || []) {
       var promiseObject = new Promise(async(resolveCallback, rejectCallback) => {
           await api.sendMessage(messageData, threadIdentifier, async(error, info) => {
               if (error) rejectCallback(++errorCount);
               else resolveCallback(++successCount)
               
               return global.client.handleReply.push({
                   name: this.config.name,
                   messageID: info.messageID,
                   author: event.senderID,
                   adminThread: event.threadID, 
                   type: "userReply"
               })
           });
       })
   }

   promiseObject.then(
       async(result) => api.sendMessage(`✅ Gửi thông báo thành công đến tất cả nhóm`, event.threadID, event.messageID)
   ).catch(
       async(error) => api.sendMessage(`⚠️ Không thể gửi thông báo đến ${error} nhóm`, event.threadID, event.messageID)
   )
};

module.exports.handleReply = async({ api, event, handleReply, Users, Threads }) => {
   switch (handleReply.type) {
       case "userReply": {
           var msg = `📩 Phản hồi từ user: ${(await Users.getData(event.senderID)).name}\n🏘️ Nhóm: ${(await Threads.getData(event.threadID)).threadInfo.threadName}\n⏰ Time: ${fullTime()}\n\n📝 Nội dung: ${event.attachments.length != 0 ? "Chỉ có tệp được gửi cho bạn" : event.body}\n\n📌 Reply tin nhắn này để phản hồi lại user`
           
           var messageData = event.attachments.length != 0 ? {
               body: msg,
               attachment: await Promise.all(event.attachments.map(a => streamURL(a)))
           } : msg;

           await api.sendMessage(messageData, handleReply.adminThread, async(error, info) => {
               if (error) {
                   return api.sendMessage(`⚠️ Không thể gửi phản hồi đến nhóm của Admin`, event.threadID, event.messageID);
               } else {
                   api.sendMessage(`✅ Phản hồi thành công đến nhóm của Admin ${(await Users.getData(handleReply.author)).name}`, event.threadID, event.messageID);
               }
               
               return global.client.handleReply.push({
                   name: this.config.name,
                   messageID: info.messageID,
                   author: handleReply.author,
                   idThread: event.threadID,
                   idMessage: event.messageID,
                   idUser: event.senderID,
                   adminThread: handleReply.adminThread, 
                   type: "adminReply"
               });
           });
           break;
       }

       case "adminReply": {
           var msg = `📩 Phản hồi từ Admin ${(await Users.getData(event.senderID)).name}\n\n📝 Nội dung: ${event.attachments.length != 0 ? "Chỉ có tệp được gửi cho bạn" : event.body}\n\n📌 reply tin nhắn này để phản hồi lại Admin`
           
           var messageData = event.attachments.length != 0 ? {
               body: msg,
               attachment: await Promise.all(event.attachments.map(a => streamURL(a)))
           } : msg;

           await api.sendMessage(messageData, handleReply.idThread, async(error, info) => {
               if (error) return api.sendMessage(`Error`, event.threadID, event.messageID);
               else api.sendMessage(`✅ Phản hồi thành công đến user ${(await Users.getData(handleReply.idUser)).name} tại nhóm ${(await Threads.getData(handleReply.idThread)).threadInfo.threadName}`, event.threadID, event.messageID)
               
               return global.client.handleReply.push({
                   name: this.config.name,
                   messageID: info.messageID,
                   author: event.senderID,
                   adminThread: handleReply.adminThread, 
                   type: "userReply"
               })
           }, handleReply.idMessage);
           break;
       }
   }
};