const stringSimilarity = require("string-similarity");

module.exports.config = {
  name: "help",
  version: "1.3.0",
  hasPermssion: 0,
  credits: "Bách Tường Đẹp zai (rework by nvh)",
  description: "Xem danh sách lệnh và chi tiết từng lệnh",
  commandCategory: "Tiện ích",
  usages: "[tên lệnh/all]",
  cooldowns: 0,
  usePrefix: true
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID } = event;
  const { commands, events } = global.client;
  const TIDdata = global.data.threadData.get(threadID) || {};
  const prefix = TIDdata.PREFIX || global.config.PREFIX;

  const type = args[0]?.toLowerCase() || "";
  const getPermission = (perm) => (
    perm == 0 ? "👤 Thành viên" :
    perm == 1 ? "👑 QTV nhóm" :
    perm == 2 ? "⚙️ Admin bot" : "🛠 Toàn quyền"
  );

  // ⏱️ uptime
  const uptime = process.uptime();
  const h = Math.floor(uptime / 3600);
  const m = Math.floor((uptime % 3600) / 60);
  const s = Math.floor(uptime % 60);

  // Xem tất cả
  if (type === "all") {
    let msg = `📚 𝗧𝗔̂́𝗧 𝗖𝗔̉ 𝗟𝗘̣̂𝗡𝗛 📚\n\n`;
    let i = 1;
    for (const cmd of commands.values()) msg += `${i++}. ${cmd.config.name}\n`;
    msg += `\n📦 Tổng lệnh: ${commands.size}\n📜 Sự kiện: ${events.size}\n💡 ${prefix}help [tên lệnh] để xem chi tiết`;
    return api.sendMessage(msg, threadID, messageID);
  }

  // Xem chi tiết lệnh
  if (type) {
    const cmd = commands.get(type);
    if (!cmd) {
      const all = Array.from(commands.keys());
      const match = stringSimilarity.findBestMatch(type, all);
      const suggest = match.bestMatch.rating >= 0.5 ? match.bestMatch.target : null;
      return api.sendMessage(
        `❌ Không có lệnh '${type}'${suggest ? `\n📌 Có phải '${suggest}'?` : ""}`,
        threadID,
        messageID
      );
    }

    const c = cmd.config;
    const msg =
`📖 𝗖𝗛𝗜 𝗧𝗜𝗘̂́𝗧 𝗟𝗘̣̂𝗡𝗛

🔹 Tên: ${c.name}
📦 Phiên bản: ${c.version}
🔗 Quyền: ${getPermission(c.hasPermssion)}
👤 Tác giả: ${c.credits}
📝 Mô tả: ${c.description}
📂 Nhóm: ${c.commandCategory}
💬 Dùng: ${prefix}${c.name} ${c.usages || ""}
⏳ Cooldown: ${c.cooldowns || 0}s`;
    return api.sendMessage(msg, threadID, messageID);
  }

  // Gộp lệnh theo nhóm
  const grouped = {};
  for (const cmd of commands.values()) {
    const cat = cmd.config.commandCategory || "Khác";
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(cmd.config.name);
  }

  // Làm gọn từng nhóm: chỉ hiển thị 1 dòng ngắn
  let msg = `🎯 𝗗𝗔𝗡𝗛 𝗠𝗨̣𝗖 𝗟𝗘̣̂𝗡𝗛 🎯\n`;
  const sorted = Object.keys(grouped).sort();
  for (const cat of sorted) {
    const list = grouped[cat];
    const short = list.length > 10 ? list.slice(0, 10).join(", ") + `… (+${list.length - 10})` : list.join(", ");
    msg += `\n⭐ ${cat.toUpperCase()} ⭐\n→ ${short}\n`;
  }

  msg += `\n────────────────────\n` +
         `📦 Tổng: ${commands.size} lệnh\n` +
         `📜 Sự kiện: ${events.size}\n` +
         `💡 ${prefix}help [tên lệnh] để xem chi tiết\n` +
         `🌐 ${prefix}help all để xem toàn bộ\n` +
         `🕒 Uptime: ${h}h ${m}m ${s}s`;

  return api.sendMessage(msg, threadID, messageID);
};