const fs = require("fs-extra");
const path = require("path");
const { exec } = require("child_process");

module.exports.config = {
  name: "pkg",
  version: "2.3.0",
  hasPermssion: 2,
  credits: "nvh",
  description: "package",
  commandCategory: "Admin",
  usages: "",
  cooldowns: 10,
  usePrefix: true
};

// ========= HÀM HỖ TRỢ ========= //
// Quét toàn bộ thư mục con, skip node_modules và folder ẩn
function getAllFiles(dir, allFiles = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (!fs.existsSync(full)) continue;
    const stat = fs.statSync(full);

    if (stat.isDirectory()) {
      if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
      getAllFiles(full, allFiles);
    } else {
      const ext = path.extname(full).toLowerCase();
      if ([".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs", ".json"].includes(ext)) {
        allFiles.push(full);
      }
    }
  }
  return allFiles;
}

// escape regex cho package name
function escapeRegex(str) {
  return str.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
}

// tạo regex check import/require
function patternsForPkg(pkgName) {
  const esc = escapeRegex(pkgName);
  return [
    new RegExp(`require\\(\\s*['"\`]${esc}['"\`]\\s*\\)`, "g"),
    new RegExp(`from\\s+['"\`]${esc}['"\`]`, "g"),
    new RegExp(`import\\(\\s*['"\`]${esc}['"\`]\\s*\\)`, "g"),
  ];
}

// check package builtin
function isBuiltin(pkg) {
  const builtins = require("module").builtinModules || [];
  return builtins.includes(pkg);
}

// tìm package.json đầu tiên để xác định root
function findPackageJson(startDir) {
  let dir = startDir;
  while (dir !== path.parse(dir).root) {
    const pkgPath = path.join(dir, "package.json");
    if (fs.existsSync(pkgPath)) return pkgPath;
    dir = path.dirname(dir);
  }
  return null;
}

// ========= LỆNH CHÍNH ========= //
module.exports.run = async ({ api, event, args }) => {
  const threadID = event.threadID;
  const senderID = event.senderID;

  const pkgPath = findPackageJson(__dirname);
  if (!pkgPath) {
    return api.sendMessage("❌ Không tìm thấy package.json ở bất kỳ đâu trong bot.", threadID, senderID);
  }

  const root = path.dirname(pkgPath);

  api.sendMessage("🕵️‍♂️ Đang quét toàn bộ bot, vui lòng chờ...", threadID);

  const pkg = fs.readJsonSync(pkgPath);
  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  const allPkgs = Object.keys(deps);

  const files = getAllFiles(root);
  const contents = files.map(f => {
    try { return fs.readFileSync(f, "utf8"); } catch { return ""; }
  });

  const unused = [];
  for (const pkgName of allPkgs) {
    if (isBuiltin(pkgName)) continue;
    const regexList = patternsForPkg(pkgName);
    let found = false;
    for (const txt of contents) {
      if (regexList.some(r => r.test(txt))) {
        found = true;
        break;
      }
    }
    if (!found) unused.push(pkgName);
  }

  if (unused.length === 0) {
    return api.sendMessage("✅ Không phát hiện package nào có vẻ thừa!", threadID);
  }

  let msg = "📦 Các package có thể không được sử dụng:\n";
  msg += unused.map((p, i) => `${i + 1}. ${p}`).join("\n");
  msg += "\n\n💬 Reply số thứ tự hoặc tên package để gỡ (có thể chọn nhiều, cách nhau bởi dấu cách).\n";
  msg += "💥 Hoặc reply 'all' để gỡ tất cả các package trên.";

  api.sendMessage(msg, threadID, (err, info) => {
    if (err) return console.error(err);
    global.client.handleReply.push({
      name: module.exports.config.name,
      messageID: info.messageID,
      author: senderID,
      list: unused,
      path: root
    });
  });
};

// ========= XỬ LÝ REPLY ========= //
module.exports.handleReply = async ({ api, event, handleReply }) => {
  if (event.senderID !== handleReply.author)
    return api.sendMessage("⚠️ Bạn không phải người gọi lệnh này.", event.threadID, event.messageID);

  const input = event.body.trim().toLowerCase();
  const list = handleReply.list;
  const root = handleReply.path;

  if (input === "all") {
    const targets = list;
    if (targets.length === 0) {
      return api.sendMessage("❌ Không có package nào để gỡ.", event.threadID);
    }

    api.sendMessage(`⚙️ Đang gỡ ${targets.length} package...\n${targets.join(", ")}`, event.threadID);

    for (const pkg of targets) {
      await new Promise(resolve => {
        exec(`npm uninstall ${pkg}`, { cwd: root }, (err, stdout, stderr) => {
          if (err) {
            api.sendMessage(`❌ Lỗi khi gỡ ${pkg}: ${stderr || err.message}`, event.threadID);
          } else {
            api.sendMessage(`✅ Đã gỡ ${pkg} thành công.`, event.threadID);
          }
          resolve();
        });
      });
    }

    return api.sendMessage("🎯 Hoàn tất quá trình gỡ tất cả package.", event.threadID);
  }

  const targets = input.split(/\s+/)
    .map(v => isNaN(v) ? v : list[parseInt(v) - 1])
    .filter(Boolean);

  if (targets.length === 0) {
    return api.sendMessage("❌ Không có package hợp lệ để gỡ.", event.threadID);
  }

  api.sendMessage(`⚙️ Đang gỡ ${targets.length} package...\n${targets.join(", ")}`, event.threadID);

  for (const pkg of targets) {
    await new Promise(resolve => {
      exec(`npm uninstall ${pkg}`, { cwd: root }, (err, stdout, stderr) => {
        if (err) {
          api.sendMessage(`❌ Lỗi khi gỡ ${pkg}: ${stderr || err.message}`, event.threadID);
        } else {
          api.sendMessage(`✅ Đã gỡ ${pkg} thành công.`, event.threadID);
        }
        resolve();
      });
    });
  }

  api.sendMessage("🎯 Hoàn tất quá trình gỡ package.", event.threadID);
};