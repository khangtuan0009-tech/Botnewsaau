const fs = require("fs");
const path = require("path");

module.exports.config = {
    name: "rs",
    version: "2.0.0",
    hasPermssion: 3,
    credits: "nvh",
    description: "Khởi Động Lại Bot",
    commandCategory: "Khác",
    cooldowns: 0,
  usePrefix: true
};

const rsFile = path.join(__dirname, "cache", ".rs.json");

module.exports.run = async function ({ event, api }) {
    try {
        // lưu thời điểm bắt đầu restart + ID box
        fs.writeFileSync(rsFile, JSON.stringify({
            start: Date.now(),
            threadID: event.threadID
        }));

        api.sendMessage("🔄 Đang khởi động lại bot...", event.threadID, () => {
            setTimeout(() => process.exit(1), 2000); // thoát sau 2s
        });
    } catch (err) {
        console.log("[RS] Lỗi:", err);
        api.sendMessage("⚠️ Không thể restart!", event.threadID);
    }
};

module.exports.onLoad = function ({ api }) {
    if (fs.existsSync(rsFile)) {
        try {
            const data = JSON.parse(fs.readFileSync(rsFile));
            const duration = ((Date.now() - data.start) / 1000).toFixed(2);

            // Lấy ngày giờ hiện tại
            const now = new Date();
            const dateStr = now.toLocaleDateString("vi-VN");
            const timeStr = now.toLocaleTimeString("vi-VN");

            // Khung thông tin
            const msg =
`✅ Bot đã khởi động lại thành công!
⏱️ Thời gian thực hiện: ${duration} giây
📅 Ngày: ${dateStr}
🕒 Giờ: ${timeStr}`;

            api.sendMessage(msg, data.threadID);
            fs.unlinkSync(rsFile); // xoá file lưu tạm
        } catch (e) {
            console.log("[RS] Lỗi đọc file:", e);
        }
    }
};