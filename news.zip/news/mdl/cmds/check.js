module.exports.config = {
  name: "check",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "DungUwU && Nghĩa (refactor by nvh)",
  description: "Check tương tác ngày/tuần/toàn bộ (full như gốc) - có % tương tác",
  commandCategory: "Tiện ích",
  usages: "[all/week/day|box|reset|lọc]",
  cooldowns: 0,
  usePrefix: true,
  dependencies: {
    "fs-extra": "",
    "moment-timezone": ""
  }
};

const fs = require('fs-extra');
const moment = require('moment-timezone');
const dirData = __dirname + '/checktt/';

module.exports.onLoad = () => {
  try {
    if (!fs.existsSync(dirData) || !fs.statSync(dirData).isDirectory()) {
      fs.mkdirSync(dirData, { recursive: true });
    }
    // Ensure every file has sensible time field (run each minute)
    setInterval(() => {
      const today = moment.tz("Asia/Ho_Chi_Minh").day();
      const files = fs.readdirSync(dirData);
      for (const file of files) {
        const p = dirData + file;
        try {
          const d = JSON.parse(fs.readFileSync(p));
          if (d.time != today) {
            d.time = today;
            // don't reset counts here, just mark day change. actual reset occurs in handler logic
            fs.writeFileSync(p, JSON.stringify(d, null, 4));
          }
        } catch (e) {
          // corrupted file -> remove
          try { fs.unlinkSync(p); } catch (e) {}
        }
      }
    }, 60 * 1000);
  } catch (e) {
    console.error('checktt onLoad error: ', e);
  }
};

module.exports.handleEvent = async function({ api, event, Threads }) {
  try {
    if (!event.isGroup) return;
    if (!event.threadID || !event.senderID) return;
    const { threadID, senderID, participantIDs } = event;
    const today = moment.tz("Asia/Ho_Chi_Minh").day();
    const filePath = dirData + threadID + '.json';

    let threadData;
    if (!fs.existsSync(filePath)) {
      threadData = {
        total: [],
        week: [],
        day: [],
        time: today,
        last: {
          time: today,
          day: [],
          week: []
        }
      };
      fs.writeFileSync(filePath, JSON.stringify(threadData, null, 4));
    } else {
      threadData = JSON.parse(fs.readFileSync(filePath));
    }

    // If day changed (someone triggered event after day change) -> roll daily -> save last snapshot
    if (threadData.time != today) {
      // snapshot last
      threadData.last = threadData.last || { time: threadData.time || today, day: [], week: [] };
      threadData.last.time = threadData.time || today;
      threadData.last.day = (threadData.day || []).map(x => ({ id: x.id, count: x.count }));
      threadData.last.week = (threadData.week || []).map(x => ({ id: x.id, count: x.count }));
      // accumulate day into week
      for (const d of (threadData.day || [])) {
        const w = threadData.week.find(u => u.id == d.id);
        if (w) w.count += d.count;
        else threadData.week.push({ id: d.id, count: d.count });
      }
      // reset day counts
      threadData.day = threadData.day.map(u => ({ id: u.id, count: 0 }));
      // update time marker
      threadData.time = today;
      fs.writeFileSync(filePath, JSON.stringify(threadData, null, 4));
    }

    // Ensure all current participants exist in arrays (keeps file clean after members join/leave)
    if (Array.isArray(participantIDs) && participantIDs.length) {
      for (const uid of participantIDs) {
        for (const key of ['day', 'week', 'total']) {
          if (!threadData[key].some(e => String(e.id) == String(uid))) {
            threadData[key].push({ id: uid, count: 0 });
          }
        }
        // also keep last snapshot arrays aligned
        if (!threadData.last) threadData.last = { time: today, day: [], week: [] };
        if (!threadData.last.day.some(e => String(e.id) == String(uid))) threadData.last.day.push({ id: uid, count: 0 });
        if (!threadData.last.week.some(e => String(e.id) == String(uid))) threadData.last.week.push({ id: uid, count: 0 });
      }
    }

    // increment counters for sender
    const inc = (arr, id) => {
      const idx = arr.findIndex(e => String(e.id) == String(id));
      if (idx == -1) arr.push({ id: id, count: 1 });
      else arr[idx].count++;
    };
    inc(threadData.total, senderID);
    inc(threadData.week, senderID);
    inc(threadData.day, senderID);

    // Trim arrays to only current participants to avoid keeping removed users forever
    if (Array.isArray(participantIDs) && participantIDs.length) {
      const ppl = participantIDs.map(x => String(x));
      threadData.day = threadData.day.filter(u => ppl.includes(String(u.id)));
      threadData.week = threadData.week.filter(u => ppl.includes(String(u.id)));
      threadData.total = threadData.total.filter(u => ppl.includes(String(u.id)));
      // last snapshots also trim
      threadData.last.day = (threadData.last.day || []).filter(u => ppl.includes(String(u.id)));
      threadData.last.week = (threadData.last.week || []).filter(u => ppl.includes(String(u.id)));
    }

    fs.writeFileSync(filePath, JSON.stringify(threadData, null, 4));
  } catch (e) {
    // swallow to avoid crashing bot
    // console.error('check handleEvent error:', e);
  }
};

module.exports.run = async function({ api, event, args, Users, Threads }) {
  try {
    const fsLocal = global.nodemodule['fs-extra'] || fs;
    const { threadID, messageID, senderID, mentions, messageReply } = event;
    const filePath = dirData + threadID + '.json';
    if (!fsLocal.existsSync(filePath)) return api.sendMessage("⚠️ Chưa có dữ liệu", threadID);

    const threadData = JSON.parse(fsLocal.readFileSync(filePath));
    const query = args[0] ? args[0].toLowerCase() : '';
    // command aliases
    if (query == 'box') {
      // forward to original box command if exists
      // emulate calling box.js as in original
      let body_ = event.args[0].replace(exports.config.name, '') + 'box info';
      let args_ = body_.split(' ');
      arguments[0].args = args_.slice(1);
      arguments[0].event.args = args_;
      arguments[0].event.body = body_;
      return require('./box.js').run(...Object.values(arguments));
    } else if (query == 'reset') {
      let dataThread = (await Threads.getData(threadID)).threadInfo;
      if (!dataThread.adminIDs.some(item => item.id == senderID)) return api.sendMessage('❎ Bạn không đủ quyền hạn để sử dụng', threadID, messageID);
      try {
        fsLocal.unlinkSync(filePath);
      } catch (e) {}
      return api.sendMessage(`✅ Đã xóa toàn bộ dữ liệu đếm tương tác của nhóm`, threadID);
    } else if (query == 'lọc') {
      let threadInfo = await api.getThreadInfo(threadID);
      if (!threadInfo.adminIDs.some(e => e.id == senderID)) return api.sendMessage("❎ Bạn không có quyền sử dụng lệnh này", threadID);
      if (!threadInfo.isGroup) return api.sendMessage("❎ Chỉ có thể sử dụng trong nhóm", threadID);
      if (!threadInfo.adminIDs.some(e => e.id == api.getCurrentUserID())) return api.sendMessage("⚠️ Bot cần quyền quản trị viên", threadID);
      if (!args[1] || isNaN(args[1])) return api.sendMessage("⚠️ Sử dụng: check lọc <số_tin_nhắn_tối_thiểu>", threadID);
      let minCount = +args[1];
      let allUser = threadInfo.participantIDs || [];
      let id_rm = [];
      for (let user of allUser) {
        if (String(user) == String(api.getCurrentUserID())) continue;
        const totalItem = threadData.total.find(e => String(e.id) == String(user));
        const cnt = totalItem ? totalItem.count : 0;
        if (cnt <= minCount) {
          try {
            await new Promise(resolve => setTimeout(resolve, 1000)); // small delay
            await api.removeUserFromGroup(user, threadID);
            id_rm.push(user);
          } catch (e) {
            // skip failures
            continue;
          }
        }
      }
      return api.sendMessage(`✅ Đã xóa ${id_rm.length} thành viên (<= ${minCount} tin nhắn)\n\n${id_rm.map(($, i) => `${i+1}. ${global.data.userName.get($) || $}`).join('\n')}`, threadID);
    }

    // build storage array for display
    const dataChoice = (query == 'all' || query == '-a') ? threadData.total : (query == 'week' || query == '-w') ? threadData.week : (query == 'day' || query == '-d') ? threadData.day : threadData.total;
    const storage = [];
    for (const item of dataChoice) {
      const userName = await Users.getNameUser(item.id) || 'Facebook User';
      storage.push({ ...item, name: userName });
    }

    // optional: if mentions provided and no flag, we may filter later (kept commented as original)
    const checkFlags = ['all', '-a', 'week', '-w', 'day', '-d'].some(e => e == query);

    // sort by count desc then name
    storage.sort((a, b) => (b.count - a.count) || a.name.localeCompare(b.name));

    // Prepare ranking array o (like original)
    const o = storage.map((x, i) => ({ rank: i + 1, id: x.id, count: x.count }));

    // If user replied or mentioned a user (or no flags) -> show personal stats (like original)
    if ((!checkFlags && Object.keys(mentions).length == 0) || (!checkFlags && Object.keys(mentions).length == 1) || (!checkFlags && event.type == 'message_reply')) {
      const UID = messageReply ? messageReply.senderID : Object.keys(mentions)[0] ? Object.keys(mentions)[0] : senderID;
      const uid = UID;
      const userRank = storage.findIndex(e => String(e.id) == String(uid));
      const totalMap = (arr, id) => (arr.find(e => String(e.id) == String(id)) || { count: 0 }).count;
      const userTotal = totalMap(threadData.total, uid);
      const userTotalWeek = totalMap(threadData.week, uid);
      const userTotalDay = totalMap(threadData.day, uid);

      // ranks (careful about sorts — create copies)
      const weekRank = [...(threadData.week || [])].sort((a, b) => b.count - a.count).findIndex(e => String(e.id) == String(uid));
      const dayRank = [...(threadData.day || [])].sort((a, b) => b.count - a.count).findIndex(e => String(e.id) == String(uid));

      const nameUID = userRank != -1 ? storage[userRank].name : (await Users.getNameUser(uid) || 'Facebook User');

      const threadInfo = await api.getThreadInfo(threadID);
      const nameThread = threadInfo.threadName || 'Nhóm Chat';
      let permission;
      if (global.config.ADMINBOT.includes(uid)) permission = `Admin Bot`;
      else if (global.config.NDH && global.config.NDH.includes(uid)) permission = `Người Hỗ Trợ`;
      else if (threadInfo.adminIDs.some(i => i.id == uid)) permission = `Quản Trị Viên`;
      else permission = `Thành Viên`;

      // last snapshot counts to calculate interaction rate relative to previous period (if exists)
      const lastDayCount = (threadData.last?.day?.find($ => String($.id) == String(uid)) || { count: 0 }).count || 0;
      const lastWeekCount = (threadData.last?.week?.find($ => String($.id) == String(uid)) || { count: 0 }).count || 0;
      const rateDayChange = lastDayCount ? ((userTotalDay - lastDayCount) / lastDayCount * 100).toFixed(2) : '0.00';
      const rateWeekChange = lastWeekCount ? ((userTotalWeek - lastWeekCount) / lastWeekCount * 100).toFixed(2) : '0.00';

      // totals for percent calculations
      const footerDay = (threadData.day || []).reduce((a, b) => a + (b.count || 0), 0) || 1;
      const footerWeek = (threadData.week || []).reduce((a, b) => a + (b.count || 0), 0) || 1;
      const footerTotal = (threadData.total || []).reduce((a, b) => a + (b.count || 0), 0) || 1;

      // build message
      let body = '';
      body += `Tên Nhóm - [ ${nameThread} ]\n\n`;
      body += `👤 Tên: ${nameUID}\n`;
      body += `🎖️ Chức vụ: ${permission}\n\n`;
      body += `💬 Tin Nhắn Trong Ngày: ${userTotalDay.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}\n`;
      body += `📊 Tỉ Lệ Tương Tác Ngày: ${((userTotalDay / footerDay) * 100).toFixed(2)}%\n`;
      body += `🥇 Hạng Trong Ngày: ${dayRank == -1 ? 'Chưa xếp hạng' : (dayRank + 1)}\n\n`;
      body += `💬 Tin Nhắn Trong Tuần: ${userTotalWeek.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}\n`;
      body += `📊 Tỉ Lệ Tương Tác Tuần: ${((userTotalWeek / footerWeek) * 100).toFixed(2)}%\n`;
      body += `🥈 Hạng Trong Tuần: ${weekRank == -1 ? 'Chưa xếp hạng' : (weekRank + 1)}\n\n`;
      body += `💬 Tổng Tin Nhắn: ${userTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}\n`;
      body += `📊 Tỉ Lệ Tương Tác Tổng: ${((userTotal / footerTotal) * 100).toFixed(2)}%\n`;
      body += `🏆 Hạng Tổng: ${userRank == -1 ? 'Chưa xếp hạng' : (userRank + 1)}\n\n`;
      body += `📌 Thả cảm xúc '❤️' tin nhắn này để xem tổng tin nhắn của toàn bộ thành viên trong nhóm`;

      return api.sendMessage(body, threadID);
    } else {
      // list output: top list
      let header = '';
      if (query == 'all' || query == '-a') header = '[ KIỂM TRA TIN NHẮN TỔNG ]\n';
      else if (query == 'week' || query == '-w') header = '[ KIỂM TRA TIN NHẮN TUẦN ]\n';
      else if (query == 'day' || query == '-d') header = '[ KIỂM TRA TIN NHẮNH NGÀY ]\n';
      else header = '[ KIỂM TRA TIN NHẮNH TỔNG ]\n';

      // Build display list
      const totalSum = storage.reduce((s, it) => s + (it.count || 0), 0) || 1;
      const display = storage.map((it, i) => `${i+1}. ${it.name} - ${it.count.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} Tin nhắn (${((it.count/totalSum)*100).toFixed(2)}%)`).join('\n');

      const footer = `\n💬 Tổng Tin Nhắn: ${storage.reduce((a, b) => a + b.count, 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
      const help = `\nReply (phản hồi) tin nhắn này theo số thứ tự để xóa thành viên ra khỏi nhóm.\n${global.config.PREFIX}check lọc <số> -> xóa thành viên có <= số tin nhắn\n${global.config.PREFIX}check reset -> reset lại toàn bộ dữ liệu tin nhắn.\n${global.config.PREFIX}check box -> xem thông tin nhóm`;

      return api.sendMessage(header + display + footer + (query == 'all' || query == '-a' ? (`\n\n${help}`) : ''), threadID, (error, info) => {
        if (error) return console.log(error);
        if (query == 'all' || query == '-a') {
          global.client.handleReply.push({
            name: this.config.name,
            messageID: info.messageID,
            tag: 'locmen',
            thread: threadID,
            author: senderID,
            storage
          });
        }
        global.client.handleReaction.push({
          name: this.config.name,
          messageID: info.messageID,
          sid: senderID
        });
      });
    }
  } catch (e) {
    console.error('check run error:', e);
    return api.sendMessage('Đã xảy ra lỗi khi thực thi lệnh.', event.threadID);
  }
};

module.exports.handleReply = async function({ api, event, handleReply, Threads }) {
  try {
    const { senderID, body } = event;
    // permission checks
    let dataThread = (await Threads.getData(event.threadID)).threadInfo;
    if (!dataThread.adminIDs.some(item => item.id == api.getCurrentUserID())) return api.sendMessage('❎ Bot cần quyền quản trị viên!', event.threadID, event.messageID);
    if (!dataThread.adminIDs.some(item => item.id == senderID)) return api.sendMessage('❎ Bạn không đủ quyền hạn để lọc thành viên!', event.threadID, event.messageID);

    if (!handleReply || !handleReply.storage) return api.sendMessage('❎ Không tìm thấy dữ liệu phản hồi', event.threadID);

    let arr = body.split(/\s+/).filter(Boolean);
    if (!arr.length) return api.sendMessage('⚠️ Vui lòng reply kèm số thứ tự (ví dụ: 1 3 5)', event.threadID);

    let removed = [];
    let failed = 0;
    for (const s of arr) {
      if (isNaN(s)) continue;
      const idx = parseInt(s) - 1;
      const id = handleReply.storage[idx] ? handleReply.storage[idx].id : null;
      if (!id) continue;
      try {
        await api.removeUserFromGroup(id, event.threadID);
        removed.push(id);
      } catch (e) {
        failed++;
      }
    }
    return api.sendMessage(`✅ Đã xóa ${removed.length} thành viên\n❎ Thất bại: ${failed}\n\n${removed.map((id, i) => `${i+1}. ${global.data.userName.get(id) || id}`).join('\n')}`, event.threadID);
  } catch (e) {
    console.error('handleReply error:', e);
  }
};

module.exports.handleReaction = function({ event, api, handleReaction }) {
  try {
    const fsLocal = require('fs');
    // only the original sender can react to trigger listing
    if (!handleReaction) return;
    if (event.userID != handleReaction.sid) return;
    if (event.reaction != "❤") return;
    // unsend the message that was reacted on
    api.unsendMessage(handleReaction.messageID);
    const data = JSON.parse(fsLocal.readFileSync(`${dirData}${event.threadID}.json`));
    const sort = (data.total || []).sort((a, b) => b.count - a.count);
    const msg = `[ KIỂM TRA TẤT CẢ TIN NHẮNH ]\n\n${sort.map(($, i) => `${i + 1}. ${global.data.userName.get($.id) || $.id} - ${$.count} tin.`).join('\n')}\n\n💬Tổng tin nhắn: ${ (data.total || []).reduce((s, $) => s + $.count, 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") }\n📊 Bạn hiện đang đứng ở hạng: ${ sort.findIndex($ => $.id == event.userID) + 1 }\n\n📌 Reply (phản hồi) tin nhắn này theo số thứ tự để xóa thành viên ra khỏi nhóm.\n${global.config.PREFIX}check lọc <số> -> xóa thành viên có <= số tin nhắn\n${global.config.PREFIX}check reset -> reset lại toàn bộ dữ liệu tin nhắn.\n${global.config.PREFIX}check box -> xem thông tin nhóm.`;
    api.sendMessage(msg, event.threadID, (err, info) => {
      if (err) return;
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        tag: 'locmen',
        thread: event.threadID,
        author: event.userID,
        storage: sort
      });
    });
  } catch (e) {
    // ignore
  }
};