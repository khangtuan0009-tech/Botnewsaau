const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
    name: "autodown",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Toàn Sex",
    description: "Tự động tải media.",
    commandCategory: "Tiện ích",
    usages: "/autodown on | off",
    cooldowns: 5,
  usePrefix: true
};

const cacheDirectory = (() => {
    const dir = path.join(__dirname, "cache");
    fs.existsSync(dir) || fs.mkdirSync(dir);
    return dir;
})();

const dataDirectory = (() => {
    const dir = path.join(__dirname, "data");
    fs.existsSync(dir) || fs.mkdirSync(dir);
    return dir;
})();

const configPath = path.join(dataDirectory, "autodown.json");
if (!fs.existsSync(configPath)) fs.writeJsonSync(configPath, {});

const loadConfig = () => fs.readJsonSync(configPath);
const saveConfig = (data) => fs.writeJsonSync(configPath, data, { spaces: 2 });

const userAgents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0"
];

function getDynamicHeaders(source) {
    let referer = "https://www.google.com/";
    if (source && source.toLowerCase().includes('douyin')) {
        referer = "https://www.douyin.com/";
    }
    return {
        "User-Agent": userAgents[Math.floor(Math.random() * userAgents.length)],
        "Accept": "*/*",
        "Connection": "keep-alive",
        "Referer": referer
    };
}

async function safeAxiosGet(url, options, source, retries = 2) {
    for (let i = 0; i < retries; i++) {
        try {
            return await axios.get(url, { ...options, headers: getDynamicHeaders(source) });
        } catch (err) {
            console.error(`[AUTODOWN] GET Error (Attempt ${i + 1} for ${url}):`, err.message);
            if (i === retries - 1) return null;
        }
    }
    return null;
}

async function safeAxiosPost(url, data, options, retries = 2) {
    for (let i = 0; i < retries; i++) {
        try {
            return await axios.post(url, data, { ...options, headers: getDynamicHeaders() });
        } catch (err) {
            //console.error(`[AUTODOWN] POST Error (Attempt ${i + 1} for ${url}):`, err.message);
            if (i === retries - 1) return null;
        }
    }
    return null;
}

module.exports.run = async function ({ api, event, args }) {
    const { threadID, messageID } = event;
    let config = loadConfig();

    if (!args[0]) {
        const status = config[threadID] !== false ? "on" : "off";
        return api.sendMessage(`Autodown hiện tại đang: ${status}`, threadID, messageID);
    }

    if (args[0].toLowerCase() === "on") {
        config[threadID] = true;
        saveConfig(config);
        return api.sendMessage("✅ Autodown đã bật cho nhóm này", threadID, messageID);
    }

    if (args[0].toLowerCase() === "off") {
        config[threadID] = false;
        saveConfig(config);
        return api.sendMessage("❌ Autodown đã tắt cho nhóm này", threadID, messageID);
    }

    return api.sendMessage("Cách dùng: /autodown on | off", threadID, messageID);
};

module.exports.handleEvent = async function ({ api, event }) {
    const { threadID, messageID, body } = event;
    if (!body) return;

    let config = loadConfig();
    if (config[threadID] === false) return;

    const urls = body.match(/https?:\/\/[\w\d\-._~:/?#[\]@!$&'()*+,;=%]+/g);
    if (!urls) return;
    let url = urls[0];

    const supported = [
        "tiktok.com", "douyin.com", "capcut.com",
        "threads.net", "threads.com", "instagram.com", "facebook.com",
        "espn.com", "pinterest.com", "imdb.com",
        "imgur.com", "ifunny.co", "izlesene.com",
        "reddit.com", "youtube.com", "youtu.be", "twitter.com",
        "vimeo.com", "snapchat.com", "bilibili.com",
        "dailymotion.com", "sharechat.com", "likee.com",
        "linkedin.com", "tumblr.com", "hipi.com",
        "telegram.org", "getstickerpack.com", "bitchute.com",
        "febspot.com", "9gag.com", "oke.ru", "rumble.com",
        "streamable.com", "ted.com", "sohutv.com",
        "xvideos.com", "xnxx.com", "xiaohongshu.com",
        "ixigua.com", "weibo.com", "miaopai.com",
        "meipai.com", "xiaoying.com", "nationalvideo.com",
        "yingke.com", "sina.com", "vk.com", "soundcloud.com",
        "mixcloud.com", "spotify.com", "zingmp3.vn",
        "bandcamp.com"
    ];
    if (!supported.some(domain => url.includes(domain))) return;

    const fetchMedia = async (mediaUrl, ext, source) => {
        const filename = `${Date.now()}_${Math.random().toString(36).substring(2)}.${ext}`;
        const filepath = path.join(cacheDirectory, filename);
        try {
            const res = await safeAxiosGet(mediaUrl, { responseType: "arraybuffer" }, source);
            if (!res || res.data.length < 1024) return null;
            fs.writeFileSync(filepath, res.data);
            return { stream: fs.createReadStream(filepath), path: filepath };
        } catch (err) {
            return null;
        }
    };

    try {
        const response = await safeAxiosPost("https://downr.org/.netlify/functions/download", { url });
        if (!response || !response.data) return;
        const data = response.data;
        if (data.error || !Array.isArray(data.medias)) return;

        const { title = "Không có tiêu đề", author = "Không rõ", source = "Unknown" } = data;
        const header = `[ AUTODOWN ] - ${source.toUpperCase()}`;
        const info = `👤 Tác giả: ${author}\n💬 Tiêu đề: ${title}`;
        const attachments = [];
        const tempPaths = [];
        const videos = data.medias.filter(m => m.type === 'video');
        const images = data.medias.filter(m => m.type === 'image');
        const audios = data.medias.filter(m => m.type === 'audio');

        if (videos.length > 0) {
            const qualityPriority = { "HD No Watermark": 1, "No Watermark": 2 };
            videos.sort((a, b) => (qualityPriority[a.quality] || 3) - (qualityPriority[b.quality] || 3));

            for (const video of videos) {
                const file = await fetchMedia(video.url, video.extension || 'mp4', source);
                if (file) {
                    attachments.push(file.stream);
                    tempPaths.push(file.path);
                    break;
                }
            }
        } else if (images.length > 0) {
            for (const img of images) {
                const file = await fetchMedia(img.url, img.extension || 'jpg', source);
                if (file) attachments.push(file.stream), tempPaths.push(file.path);
            }
        } else if (audios.length > 0) {
            const file = await fetchMedia(audios[0].url, audios[0].extension || 'mp3', source);
            if (file) attachments.push(file.stream), tempPaths.push(file.path);
        }

        if (attachments.length > 0) {
            await api.sendMessage({ body: `${header}\n\n${info}`, attachment: attachments }, threadID, () => {
                for (const file of tempPaths) fs.unlink(file, () => {});
            }, messageID);
        }
    } catch (err) {
        //console.error("❌ Lỗi xử lý autodown:", err.message || err);
    }
};