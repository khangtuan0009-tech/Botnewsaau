module.exports.config = {
  name: "up",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "admin",
  usages: "reply file + .uploadall",
  commandCategory: "utility",
  cooldowns: 3,
  usePrefix: true
};

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

module.exports.run = async ({ api, event }) => {
  try {
    const { messageReply } = event;
    if (!messageReply || !messageReply.attachments || messageReply.attachments.length === 0) {
      return api.sendMessage('⚠️ Vui lòng reply file.', event.threadID, event.messageID);
    }

    const attachment = messageReply.attachments[0];
    const fileUrl = attachment.url || attachment.attachment || attachment.href;
    const filename = attachment.filename || `file_${Date.now()}`;

    if (!fileUrl) {
      return api.sendMessage('❌ Không lấy được link file. File có thể là loại nội bộ không chia sẻ được.', event.threadID, event.messageID);
    }

    // Tải file tạm về server bot
    const tmpDir = path.join(__dirname, 'cache');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
    const tmpPath = path.join(tmpDir, filename.replace(/[^a-zA-Z0-9_.-]/g, '_'));

    const res = await axios.get(fileUrl, { responseType: 'stream' });
    const writer = fs.createWriteStream(tmpPath);
    await new Promise((resolve, reject) => {
      res.data.pipe(writer);
      let error = null;
      writer.on('error', err => { error = err; reject(err); });
      writer.on('close', () => { if (!error) resolve(); });
    });

    // Chuẩn bị form upload
    const form = new FormData();
    form.append('file', fs.createReadStream(tmpPath), filename);

    const UPLOAD_URL = process.env.UPLOAD_API_URL || 'https://nvhz-dz.onrender.com/api/upload';

    const uploadResp = await axios.post(UPLOAD_URL, form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Mirai-bot)'
      },
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      timeout: 180000 // ⏱ timeout 3 phút (180.000 ms)
    });

    const data = uploadResp.data;
    if (!data || !data.ok) {
      try { fs.unlinkSync(tmpPath); } catch (e) {}
      return api.sendMessage(`❌ Upload thất bại.\nResponse: ${JSON.stringify(data)}`, event.threadID, event.messageID);
    }

    const remoteUrl = data.url || data.data?.url || data.filename || JSON.stringify(data);

    await api.sendMessage(
      `✅ Upload thành công!\n\n` +
      `📦 Tên: ${data.filename || filename}\n` +
      `📏 Kích thước: ${data.size ?? 'unknown'}\n` +
      `🧩 MIME: ${data.mime ?? 'unknown'}\n` +
      `🌐 URL: ${remoteUrl}`,
      event.threadID,
      event.messageID
    );

    try { fs.unlinkSync(tmpPath); } catch (e) {}
  } catch (err) {
    console.error(err);
    const msg = err.code === 'ECONNABORTED'
      ? '⚠️ Upload quá thời gian.'
      : '⚠️ Lỗi upload: ' + err.message;
    return api.sendMessage(msg, event.threadID, event.messageID);
  }
};