const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "read",
  version: "2.1.0",
  hasPermssion: 3,
  credits: "lechii",
  description: "Đọc nội dung file .js hoặc link text",
  commandCategory: "Admin",
  usages: "read [tênfile.js hoặc link]",
  cooldowns: 3,
  usePrefix: true
};

module.exports.run = async ({ api, event, args }) => {
  const { threadID, messageID, senderID, messageReply } = event;
  let input = args[0]?.trim();

  if (!input && messageReply && messageReply.body) {
    input = messageReply.body.trim();
  }

  if (!input) {
    return api.sendMessage(
      "📘 Hãy reply tin này bằng:\n- Tên file .js cần đọc (vd: admin.js)\n- Hoặc link raw (vd: https://lechii.online/note/xxxx?raw=true)\nHoặc reply vào tin có link rồi gõ read.",
      threadID,
      (err, info) => {
        if (err) return;
        global.client.handleReply.push({
          name: module.exports.config.name,
          messageID: info.messageID,
          author: senderID,
          type: "read_input"
        });
      },
      messageID
    );
  }

  await readContent(api, event, input);
};

module.exports.handleReply = async ({ api, event, handleReply }) => {
  const { threadID, messageID, senderID, body } = event;
  if (senderID != handleReply.author) return;
  if (!body) return api.sendMessage("⚠️ Vui lòng nhập tên file hoặc link.", threadID, messageID);
  await readContent(api, event, body.trim());
};

async function readContent(api, event, input) {
  const { threadID, messageID } = event;
  try {
    let content;
    if (input.startsWith("http")) {
      const res = await axios.get(input);
      content = res.data;
    } else {
      const filePath = path.join(__dirname, input.endsWith(".js") ? input : input + ".js");
      if (!fs.existsSync(filePath))
        return api.sendMessage("⚠️ File không tồn tại!", threadID, messageID);
      content = fs.readFileSync(filePath, "utf8");
    }

    if (!content || content.length === 0)
      return api.sendMessage("❎ File hoặc link không có nội dung!", threadID, messageID);

    if (content.length > 15000)
      return api.sendMessage("⚠️ Nội dung quá dài, không thể gửi.", threadID, messageID);

    return api.sendMessage(`\`\`\`javascript\n${content}\n\`\`\``, threadID, messageID);
  } catch (err) {
    return api.sendMessage(`❎ Lỗi khi đọc: ${err.message}`, threadID, messageID);
  }
}
