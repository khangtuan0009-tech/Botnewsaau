const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const deletedPath = path.join(__dirname, "data", "deletedThreads.json");
const dbPath = path.join(__dirname, "..", "..", "nvhz", "data.sqlite");

module.exports.config = {
  name: "xoadatabox",
  version: "3.0.0",
  hasPermssion: 2,
  credits: "nvh",
  description: "Lọc nhóm bot đã out",
  commandCategory: "Quản trị viên",
  usages: "[list | restore]",
  cooldowns: 5,
  usePrefix: true
};

// ====== HÀM ĐỌC / GHI FILE JSON ====== //
function readDeleted() {
  if (!fs.existsSync(deletedPath)) return [];
  try {
    return JSON.parse(fs.readFileSync(deletedPath, "utf-8"));
  } catch {
    return [];
  }
}

function saveDeleted(data) {
  fs.writeFileSync(deletedPath, JSON.stringify(data, null, 2));
}

// ====== LỆNH CHÍNH ====== //
module.exports.run = async function ({ api, Threads, event, args }) {
  try {
    const option = args[0];
    const threadID = event.threadID;

    // Xem danh sách nhóm đã xóa
    if (option === "list") {
      const deleted = readDeleted();
      if (!deleted.length)
        return api.sendMessage("📂 Chưa có nhóm nào bị xoá trước đó.", threadID);
      const msg = "📂 Danh sách nhóm đã xoá:\n\n" +
        deleted.map(i => `• ${i.name} | ${i.id}`).join("\n");
      return api.sendMessage(msg, threadID);
    }

    // Khôi phục nhóm đã xóa
    if (option === "restore") {
      const deleted = readDeleted();
      if (!deleted.length)
        return api.sendMessage("📂 Không có dữ liệu nào để khôi phục.", threadID);

      let restored = [];
      for (let g of deleted) {
        try {
          await Threads.setData(g.id, { threadInfo: { threadName: g.name } });
          restored.push(g);
        } catch (e) {
          console.error("Không thể khôi phục:", g.id, e);
        }
      }

      api.sendMessage(
        `♻️ Đã khôi phục ${restored.length} nhóm về database:\n${restored.map(i => `${i.name} | ${i.id}`).join("\n")}`,
        threadID
      );
      return;
    }

    // ====== BẮT ĐẦU LỌC NHÓM BOT ĐÃ OUT ====== //
    api.sendMessage("🔍 Đang quét danh sách nhóm, vui lòng chờ...", threadID);

    const threadList = await api.getThreadList(500, null, ["INBOX", "ARCHIVED"]);
    const toRemove = [];

    for (let thread of threadList) {
      if (!thread.isGroup) continue;
      try {
        await api.getThreadInfo(thread.threadID);
      } catch (err) {
        // Bot đã out thật
        if (
          err?.error === 1545012 ||
          /not a participant|not a member|not allowed/i.test(err.message)
        ) {
          toRemove.push({ name: thread.name || "Không tên", id: thread.threadID });
        }
      }
    }

    if (!toRemove.length)
      return api.sendMessage("✅ Không có nhóm nào cần xoá (bot vẫn còn trong tất cả).", threadID);

    const db = new sqlite3.Database(dbPath);
    const deletedNow = [];

    for (const g of toRemove) {
      try {
        // 1️⃣ Xoá thread thật trên Messenger
        await new Promise((res, rej) => {
          api.deleteThread(g.id, (err) => (err ? rej(err) : res()));
        });

        // 2️⃣ Xoá trong Threads & SQLite
        await Threads.delData(g.id);
        db.run(`DELETE FROM Threads WHERE threadID = ?`, [g.id], function (err) {
          if (err) console.error(`❌ Lỗi khi xóa nhóm ${g.name} (${g.id}) khỏi SQLite:`, err);
          else console.log(`🗑 Đã xoá nhóm ${g.name} (${g.id}) khỏi SQLite`);
        });

        deletedNow.push(g);
      } catch (err) {
        console.error(`⚠️ Lỗi khi xóa nhóm ${g.id}:`, err.message);
      }
    }

    db.close();

    // 3️⃣ Ghi log các nhóm đã xóa
    if (deletedNow.length) {
      const old = readDeleted();
      saveDeleted(old.concat(deletedNow));
    }

    api.sendMessage(
      `🗑 Đã xoá ${deletedNow.length} nhóm thật sự đã out khỏi Messenger + database:\n${deletedNow.map(i => `${i.name} | ${i.id}`).join("\n")}`,
      threadID
    );

  } catch (err) {
    console.error(err);
    api.sendMessage("❌ Đã xảy ra lỗi khi xử lý.", event.threadID);
  }
};