const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  name: "fast",
  version: "1.0.1",
  hasPermssion: 2, // admin
  credits: "nvh",
  description: "Tăng tốc upload video ",
  commandCategory: "Admin",
  usages: "fast <category> <concurrency>",
  cooldowns: 5,
  usePrefix: true
};

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
  "Mozilla/5.0 (Windows NT 11.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
  "Mozilla/5.0 (Linux; Android 14; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (Linux; Android 12; Redmi Note 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
];

function getRandomUserAgent() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

async function fetchStream(url) {
  try {
    const res = await axios({
      url,
      method: 'GET',
      responseType: 'stream',
      timeout: 120000,
      headers: {
        'User-Agent': getRandomUserAgent(),
        'Accept': '*/*',
        'Connection': 'keep-alive'
      },
      validateStatus: s => s >= 200 && s < 400
    });
    return res.data;
  } catch {
    return null;
  }
}

async function uploadUrlToFacebook(url, api) {
  try {
    const stream = await fetchStream(url);
    if (!stream) return null;

    const res = await api.postFormData('https://upload.facebook.com/ajax/mercury/upload.php', {
      upload_1024: stream
    });

    const body = JSON.parse(res.body.replace('for (;;);', ''));
    const metadata = body.payload?.metadata?.[0];
    if (metadata) return Object.entries(metadata)[0];
  } catch {}
  return null;
}

function makeSemaphore(limit) {
  let active = 0;
  const queue = [];
  const next = () => {
    if (queue.length === 0 || active >= limit) return;
    active++;
    const { fn, resolve } = queue.shift();
    fn().then((v) => {
      active--;
      resolve(v);
      next();
    }).catch(() => {
      active--;
      resolve(null);
      next();
    });
  };
  return function run(fn) {
    return new Promise((resolve) => {
      queue.push({ fn, resolve });
      next();
    });
  };
}

module.exports.run = async function ({ event, api, args }) {
  const threadID = event.threadID;

  const category = args[0];
  const concurrency = Math.max(1, Math.min(parseInt(args[1]) || 5, 20));

  if (!category) return api.sendMessage("Vui lòng chỉ định category. Ví dụ: fast vdgai 8", threadID, null);

  const filePath = path.resolve(__dirname, "../../utils/video", `${category}.json`);
  if (!fs.existsSync(filePath)) return api.sendMessage(`Không tìm thấy file ../../utils/video/${category}.json`, threadID, null);

  let urls;
  try {
    urls = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (!Array.isArray(urls) || urls.length === 0) throw new Error("empty");
  } catch {
    return api.sendMessage(`File ../../utils/video/${category}.json không hợp lệ hoặc rỗng.`, threadID, null);
  }

  const tasksCount = Math.min(urls.length, concurrency * 3);

  const chosen = [];
  while (chosen.length < tasksCount) {
    const u = urls[Math.floor(Math.random() * urls.length)];
    if (!chosen.includes(u)) chosen.push(u);
  }

  api.sendMessage(`Bắt đầu upload nhanh: category=${category}, concurrency=${concurrency}, tasks=${chosen.length}`, threadID, null);

  const runWithLimit = makeSemaphore(concurrency);

  const results = await Promise.all(chosen.map(u =>
    runWithLimit(async () => {
      const metadata = await uploadUrlToFacebook(u, api);
      return { url: u, metadata };
    })
  ));

  const globalName = category;
  if (!global[globalName]) global[globalName] = [];

  let success = 0, fail = 0;
  for (const r of results) {
    if (r.metadata) {
      global[globalName].push(r.metadata);
      success++;
    } else fail++;
  }

  api.sendMessage(`Hoàn tất fastupload.\nCategory: ${category}\nConcurrency: ${concurrency}\nTasks: ${chosen.length}\nThành công: ${success}\nThất bại: ${fail}`, threadID, null);
};