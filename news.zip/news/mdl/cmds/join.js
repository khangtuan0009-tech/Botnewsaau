const fs = require("fs");
const path = require("path");

module.exports.config = {
    name: "join",
    version: "1.0.1",
    hasPermssion: 2,
    credits: "nvh",
    description: "Bật/Tắt thông báo khi có người mới vào nhóm",
    commandCategory: "Nhóm",
    usages: "[on/off]",
    cooldowns: 0,
  usePrefix: true
};

module.exports.run = async function ({ api, event, args }) {
    const statusFile = path.join(__dirname, "../../utils/joinstatus.json");

    // Nếu file chưa tồn tại thì tạo file trống {}
    if (!fs.existsSync(statusFile)) {
        fs.writeFileSync(statusFile, JSON.stringify({}, null, 2));
    }

    let data = JSON.parse(fs.readFileSync(statusFile));
    const threadID = event.threadID;

    // Nếu chưa có dữ liệu cho thread này thì set mặc định là false
    if (!data[threadID]) {
        data[threadID] = { status: false };
    }

    if (!args[0]) {
        return api.sendMessage(
            `📢 Trạng thái thông báo nhóm này: ${data[threadID].status ? "✅ BẬT" : "❌ TẮT"}`,
            threadID,
            event.messageID
        );
    }

    const input = args[0].toLowerCase();
    if (input === "on" || input === "bật") {
        data[threadID].status = true;
        fs.writeFileSync(statusFile, JSON.stringify(data, null, 2));
        return api.sendMessage("✅ Đã bật thông báo khi có người mới vào nhóm này", threadID, event.messageID);
    }
    else if (input === "off" || input === "tắt") {
        data[threadID].status = false;
        fs.writeFileSync(statusFile, JSON.stringify(data, null, 2));
        return api.sendMessage("❌ Đã tắt thông báo khi có người mới vào nhóm này", threadID, event.messageID);
    }
    else {
        return api.sendMessage("⚠️ Dùng: join [on/off]", threadID, event.messageID);
    }
};
