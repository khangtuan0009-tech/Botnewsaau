const fs = require("fs");
const path = require("path");

const prefixFile = path.join(__dirname, "cache/prefixData.json");

function loadPrefix() {
  try {
    if (!fs.existsSync(prefixFile)) fs.writeFileSync(prefixFile, "{}");
    return JSON.parse(fs.readFileSync(prefixFile));
  } catch (e) {
    console.error("LOAD PREFIX ERROR:", e);
    return {};
  }
}

function savePrefix(data) {
  try {
    fs.writeFileSync(prefixFile, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error("SAVE PREFIX ERROR:", e);
  }
}

module.exports.config = {
  name: "setname",
  version: "5.3.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Quản lý biệt danh trong nhóm: đổi, check, thêm prefix, xóa người chưa setname",
  commandCategory: "Nhóm",
  usages: "trống/tag/check/all/del/call/add/auto/kytu + name",
  cooldowns: 5,
  usePrefix: true
};

const commandName = module.exports.config.name;

module.exports.run = async ({ api, event, args, Users }) => {
  try {
    let { threadID, messageReply, senderID, mentions = {}, participantIDs = [], type } = event;

    // Lấy info thread
    let threadInfo = {};
    try { threadInfo = await api.getThreadInfo(threadID); } catch (e) { console.warn("getThreadInfo failed:", e && e.message); }

    const nicknames = threadInfo.nicknames || {};
    const objKeys = Object.keys(nicknames);
    const notFoundIds = participantIDs.filter(id => !objKeys.includes(id));

    // Load prefix thread
    let data = loadPrefix();
    let prefixChar = data[threadID]?.prefix || "";

    const isAdmin = Array.isArray(threadInfo.adminIDs) ? threadInfo.adminIDs.some(ad => ad.id === senderID) : false;

    const subcmd = (args[0] || "").toLowerCase();

    switch (subcmd) {
      case "help": {
        const helpText =
`📘 HƯỚNG DẪN LỆNH SETNAME

1️⃣ setname [biệt danh]
→ Đổi biệt danh cho bạn
→ Hoặc reply/tag ai đó để đổi cho họ

2️⃣ setname add [ký tự]
→ Thiết lập ký tự prefix

3️⃣ setname auto
→ Tự động thêm prefix đã thiết lập vào biệt danh tất cả thành viên

4️⃣ setname kytu [ký tự]
→ Liệt kê người chưa có prefix

5️⃣ setname check
→ Xem danh sách người dùng chưa setname (thả react để kick)

6️⃣ setname call
→ Tag người chưa đặt biệt danh để nhắc họ

7️⃣ setname del
→ Xóa người chưa đặt biệt danh khỏi nhóm (chỉ quản trị viên)

8️⃣ setname all [tên]
→ Đổi biệt danh cho toàn bộ thành viên`;
        return api.sendMessage(helpText, threadID);
      }

      case "call": {
        if (notFoundIds.length === 0) return api.sendMessage("✅ Tất cả thành viên đã đặt biệt danh!", threadID);
        const mentionsArr = [];
        let tag = "";
        for (let i = 0; i < notFoundIds.length; i++) {
          const id = notFoundIds[i];
          const name = await Users.getNameUser(id);
          mentionsArr.push({ tag: name, id });
          tag += `${i + 1}. @${name}\n`;
        }
        return api.sendMessage({ body: `📣 Vui lòng setname để mọi người nhận biết bạn dễ dàng hơn\n\n${tag}`, mentions: mentionsArr }, threadID);
      }

      case "del": {
        if (!isAdmin) return api.sendMessage("⚠️ Chỉ quản trị viên mới có thể sử dụng", threadID);
        if (notFoundIds.length === 0) return api.sendMessage("✅ Không có ai để xóa!", threadID);
        let success = 0, fail = 0;
        for (const id of notFoundIds) {
          try { await api.removeUserFromGroup(id, threadID); success++; } catch (e) { fail++; console.warn("removeUser error:", e && e.message); }
        }
        return api.sendMessage(`✅ Đã xóa ${success} thành viên, lỗi: ${fail}`, threadID);
      }

      case "check": {
        if (notFoundIds.length === 0) return api.sendMessage("✅ Tất cả thành viên đã đặt biệt danh!", threadID);
        let msg = "📝 Danh sách người dùng chưa setname:\n";
        let num = 1;
        for (const id of notFoundIds) {
          const name = await Users.getNameUser(id);
          msg += `\n${num++}. ${name}`;
        }
        msg += `\n\n📌 Thả cảm xúc vào tin nhắn này để kick những người không setname ra khỏi nhóm`;
        return api.sendMessage(msg, threadID, (err, info) => {
          if (err) {
            console.error("sendMessage(check) error:", err);
            return;
          }
          global.client = global.client || {};
          global.client.handleReaction = global.client.handleReaction || [];
          global.client.handleReaction.push({
            name: commandName,
            messageID: info.messageID,
            author: senderID,
            abc: notFoundIds
          });
        });
      }

      case "all": {
        if (!isAdmin) return api.sendMessage("⚠️ Chỉ quản trị viên mới được dùng lệnh này!", threadID);
        const nameAll = args.slice(1).join(" ").trim();
        if (!nameAll) return api.sendMessage("❌ Vui lòng nhập tên muốn đặt cho tất cả!", threadID);
        for (const [i, id] of participantIDs.entries()) {
          setTimeout(async () => {
            try { await api.changeNickname(nameAll, threadID, id); } catch (e) { console.warn("changeNickname(all) failed:", e && e.message); }
          }, i * 500);
        }
        return api.sendMessage("✅ Đã đổi biệt danh cho tất cả thành viên", threadID);
      }

      case "add": {
        const newPrefix = args.slice(1).join(" ").trim();
        if (!newPrefix) return api.sendMessage("❌ Vui lòng nhập prefix!", threadID);
        const threadName = threadInfo.threadName || "Tên nhóm chưa đặt";
        data[threadID] = { prefix: newPrefix, threadName };
        savePrefix(data);
        return api.sendMessage(`✅ Đã thiết lập prefix cho nhóm "${threadName}": ${newPrefix}`, threadID);
      }

      case "auto": {
        if (!isAdmin) return api.sendMessage("⚠️ Chỉ quản trị viên mới được dùng lệnh này!", threadID);
        if (!prefixChar) return api.sendMessage("❌ Nhóm chưa có prefix. Dùng: setname add [prefix]", threadID);
        for (const [i, id] of participantIDs.entries()) {
          const currentName = nicknames[id] || await Users.getNameUser(id);
          const newName = `${prefixChar} ${currentName}`;
          setTimeout(async () => {
            try { await api.changeNickname(newName, threadID, id); } catch (e) { console.warn("changeNickname(auto) failed:", e && e.message); }
          }, i * 500);
        }
        return api.sendMessage("✅ Đã tự động thêm prefix cho tất cả thành viên", threadID);
      }

      case "kytu": {
        const charCheck = args.slice(1).join(" ").trim();
        if (!charCheck) return api.sendMessage("❌ Vui lòng nhập ký tự cần kiểm tra", threadID);
        let msg = `📝 Danh sách người chưa có prefix "${charCheck}":\n`;
        let num = 1;
        for (const id of participantIDs) {
          const currentName = nicknames[id] || await Users.getNameUser(id);
          if (!currentName.includes(charCheck)) msg += `\n${num++}. ${currentName}`;
        }
        return api.sendMessage(msg, threadID);
      }

      default: {
        let targetID = senderID;
        let newName = args.join(" ").trim();

        if (type === "message_reply" && messageReply && messageReply.senderID) {
          targetID = messageReply.senderID;
          newName = args.join(" ").trim();
        } 
        else if (mentions && Object.keys(mentions).length > 0) {
          targetID = Object.keys(mentions)[0];
          const mentionText = Object.values(mentions)[0];
          const fullText = args.join(" ");
          // Bỏ hẳn tên tag + icon
          newName = fullText.replace(mentionText, "").trim();
          // Loại bỏ emoji/icon còn sót lại trong phần còn lại
          newName = newName.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "").trim();
        }

        if (!newName) return api.sendMessage("❌ Vui lòng nhập tên muốn đặt.", threadID);

        // Thêm prefix
        if (prefixChar) newName = `${prefixChar} ${newName}`;

        const oldName = await Users.getNameUser(targetID);

        return api.changeNickname(newName, threadID, targetID, (err) => {
          if (!err) {
            api.sendMessage(`✅ Đã đổi tên ${oldName} thành ${newName}`, threadID);
          } else {
            api.sendMessage(`❎ Không thể đổi tên: bot chưa phải admin hoặc nhóm chưa bật quyền`, threadID);
          }
        });
      }
    }

  } catch (error) {
    console.error("RUN ERROR (setname):", error);
    try { api.sendMessage("❌ Đã xảy ra lỗi khi chạy lệnh setname. Kiểm tra console của bot để biết chi tiết.", event.threadID); } catch (e) {}
  }
};

module.exports.handleReaction = async function ({ api, event, handleReaction }) {
  try {
    if (!handleReaction) return;
    if (event.userID != handleReaction.author) return;
    if (Array.isArray(handleReaction.abc) && handleReaction.abc.length > 0) {
      let success = 0, fail = 0;
      for (const id of handleReaction.abc) {
        try { await api.removeUserFromGroup(id, event.threadID); success++; } catch (e) { fail++; console.warn("removeUser in handleReaction failed:", e && e.message); }
      }
      api.sendMessage(`✅ Đã xóa ${success} thành viên, lỗi: ${fail}`, event.threadID);
    } else {
      api.sendMessage(`Không có ai để xóa!`, event.threadID);
    }
  } catch (e) {
    console.error("HANDLE REACTION ERROR:", e);
  }
};