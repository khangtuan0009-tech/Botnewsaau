const axios = require("axios");
const fs = require("fs-extra");
const request = require("request");
const moment = require("moment-timezone");

module.exports.config = {
    name: "tiktok",
    version: "1.2.1",
    hasPermssion: 0,
    credits: "neon team",
    description: "Tải video, nhạc, hoặc xem thông tin từ TikTok",
    commandCategory: "Media",
    usages: "[info|video|music|search|post|trending]",
    cooldowns: 5,
  usePrefix: true,
};

const roof = function(n) { return Math.ceil(n); };
const localeStr = function(n) { return (+n).toLocaleString().replace(/,/g, '.'); };

async function downloadFile(url, path) {
    const writer = fs.createWriteStream(path);
    try {
        const response = await axios({ url: url, method: 'GET', responseType: 'stream' });
        response.data.pipe(writer);
        return new Promise(function(resolve, reject) {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    } catch (e) {
        console.error("Lỗi khi tải file:", e);
        return Promise.reject(e);
    }
}

function cleanup(paths) {
    if (Array.isArray(paths)) {
        paths.forEach(function(path) {
            if (fs.existsSync(path)) fs.unlinkSync(path);
        });
    } else if (typeof paths === 'string' && fs.existsSync(paths)) {
        fs.unlinkSync(paths);
    }
}

// ============================================
//            HANDLE REPLY/REACTION
// ============================================
module.exports.handleReaction = async function({ api, event, handleReaction }) {
    if (event.userID != handleReaction.author) return;
    try {
        switch (handleReaction.type) {
            case 'user_post':
                // Chuyển đổi giữa danh sách video và music
                await runListUserPost({ api: api, event: event, data: handleReaction.data, page: 1, isVideo: !handleReaction.isVideo, author: handleReaction.author });
                break;
        }
    } catch (e) {
        console.error("Lỗi handleReaction TikTok:", e);
    }
};

module.exports.handleReply = async function({ api, event, handleReply }) {
    if (handleReply.author != event.senderID) return;

    const { threadID, messageID, body } = event;
    const args = body.split(" ");

    try {
        switch (handleReply.type) {
            case 'search': {
                const videoIndex = parseInt(body) - 1;
                if (isNaN(videoIndex) || videoIndex < 0 || videoIndex >= handleReply.videoInfo.length) {
                    return api.sendMessage("⚠️ Số thứ tự không hợp lệ.", threadID, messageID);
                }
                
                api.unsendMessage(handleReply.messageID);
                const video = handleReply.videoInfo[videoIndex];
                const videoPath = __dirname + '/cache/tiktok_search_' + Date.now() + '.mp4';
                await downloadFile(video.nowatermark, videoPath);

                const msg = "[ TIKTOK VIDEO ]\n─────────────────\n" +
                            "📝 Tiêu đề: " + video.title + "\n" +
                            "👤 Tác giả: " + video.nickname + " (@" + video.unique_id + ")\n" +
                            "❤️ Lượt tim: " + localeStr(video.digg_count) + "\n" +
                            "⏳ Thời gian: " + video.duration + " giây";
                api.sendMessage({ body: msg, attachment: fs.createReadStream(videoPath) }, threadID, function() { cleanup(videoPath) }, messageID);
                break;
            }
            case 'trending': {
                if (args[0].toLowerCase() === 'trang' && !isNaN(args[1])) {
                    const page = parseInt(args[1]);
                    if (page > 0 && page <= roof(handleReply.data.length / 6)) {
                        await runInfoTrending({ api: api, event: event, data: handleReply.data, page: page, author: handleReply.author });
                    } else {
                        api.sendMessage("⚠️ Trang " + page + " không hợp lệ.", threadID, messageID);
                    }
                    return;
                }

                const trendIndex = parseInt(body) - 1;
                if (isNaN(trendIndex) || trendIndex < 0 || trendIndex >= handleReply.data.length) {
                    return api.sendMessage("⚠️ Số thứ tự không hợp lệ.", threadID, messageID);
                }
                
                const trendVideo = handleReply.data[trendIndex];
                const trendVideoPath = __dirname + '/cache/tiktok_trend_' + Date.now() + '.mp4';
                await downloadFile(trendVideo.play, trendVideoPath);
                
                const trendMsg = "[ VIDEO TRENDING ]\n─────────────────\n" +
                                 "📝 Tiêu đề: " + trendVideo.title + "\n" +
                                 "👤 Tác giả: " + trendVideo.author.nickname + "\n" +
                                 "❤️ Lượt tim: " + localeStr(trendVideo.digg_count);
                api.sendMessage({ body: trendMsg, attachment: fs.createReadStream(trendVideoPath) }, threadID, function() { cleanup(trendVideoPath) }, messageID);
                break;
            }
            case 'user_post': {
                if (args[0].toLowerCase() === 'trang' && !isNaN(args[1])) {
                    const page = parseInt(args[1]);
                    if (page > 0 && page <= roof(handleReply.data.length / 6)) {
                        await runListUserPost({ api: api, event: event, data: handleReply.data, page: page, isVideo: handleReply.isVideo, author: handleReply.author });
                    } else {
                        api.sendMessage("⚠️ Trang " + page + " không hợp lệ.", threadID, messageID);
                    }
                    return;
                }

                const postIndex = parseInt(body) - 1;
                if (isNaN(postIndex) || postIndex < 0 || postIndex >= handleReply.data.length) {
                    return api.sendMessage("⚠️ Số thứ tự không hợp lệ.", threadID, messageID);
                }

                const postData = handleReply.data[postIndex];
                if (handleReply.isVideo) {
                    const postVideoPath = __dirname + '/cache/tiktok_post_' + Date.now() + '.mp4';
                    await downloadFile(postData.play, postVideoPath);
                    const postVideoMsg = "[ VIDEO CỦA NGƯỜI DÙNG ]\n─────────────────\n" +
                                         "📝 Tiêu đề: " + postData.title + "\n" +
                                         "❤️ Lượt tim: " + localeStr(postData.digg_count);
                    api.sendMessage({ body: postVideoMsg, attachment: fs.createReadStream(postVideoPath) }, threadID, function() { cleanup(postVideoPath) }, messageID);
                } else {
                    const postMusicPath = __dirname + '/cache/tiktok_post_' + Date.now() + '.mp3';
                    await downloadFile(postData.music, postMusicPath);
                    const postMusicMsg = "[ ÂM THANH CỦA NGƯỜI DÙNG ]\n─────────────────\n" +
                                         "🎵 Tên bài hát: " + postData.music_info.title + "\n" +
                                         "👤 Nghệ sĩ: " + postData.music_info.author;
                    api.sendMessage({ body: postMusicMsg, attachment: fs.createReadStream(postMusicPath) }, threadID, function() { cleanup(postMusicPath) }, messageID);
                }
                break;
            }
        }
    } catch (error) {
        console.error("Lỗi handleReply TikTok:", error);
        api.sendMessage("❌ Đã có lỗi xảy ra khi xử lý yêu cầu của bạn.", threadID, messageID);
    }
};

// ============================================
//            MAIN RUN FUNCTION
// ============================================
module.exports.run = async function({ api, event, args }) {
    const { threadID, messageID, senderID } = event;
    const command = args[0] ? args[0].toLowerCase() : '';
    const keyword = args.slice(1).join(" ");

    if (!command) {
        const helpMessage = "[ TIKTOK - Hướng Dẫn Sử Dụng ]\n─────────────────\n" +
                            "1. .tiktok info <ID người dùng>: Xem thông tin người dùng.\n" +
                            "2. .tiktok video <link video>: Tải video không logo.\n" +
                            "3. .tiktok music <link video>: Tải âm thanh của video.\n" +
                            "4. .tiktok search <từ khóa>: Tìm kiếm video.\n" +
                            "5. .tiktok post <ID người dùng>: Xem các bài đăng của người dùng.\n" +
                            "6. .tiktok trending: Xem các video thịnh hành tại VN.";
        return api.sendMessage(helpMessage, threadID, messageID);
    }

    const tm = moment.tz('Asia/Ho_Chi_Minh').format('HH:mm:ss | DD/MM/YYYY');

    try {
        switch (command) {
            case "info": {
                if (!keyword) return api.sendMessage("⚠️ Vui lòng nhập ID người dùng (VD: @theanh28entertainment).", threadID, messageID);
                const res = await axios.get("https://www.tikwm.com/api/user/info?unique_id=" + encodeURIComponent(keyword ));
                if (res.data.code !== 0 || !(res.data.data && res.data.data.user)) return api.sendMessage("❌ Không tìm thấy người dùng hoặc API có lỗi.", threadID, messageID);

                const { user, stats } = res.data.data;
                const avatarPath = __dirname + '/cache/tiktok_avatar_' + Date.now() + '.jpg';
                await downloadFile(user.avatarMedium, avatarPath);

                const infoMsg = "[ THÔNG TIN NGƯỜI DÙNG TIKTOK ]\n─────────────────\n" +
                                "👤 Tên: " + user.nickname + "\n" +
                                "🆔 ID: " + user.uniqueId + "\n" +
                                "📝 Tiểu sử: " + (user.signature || 'Không có') + "\n" +
                                "❤️ Lượt theo dõi: " + localeStr(stats.followerCount) + "\n" +
                                "👀 Đang theo dõi: " + localeStr(stats.followingCount) + "\n" +
                                "🎬 Tổng số video: " + localeStr(stats.videoCount) + "\n" +
                                "💖 Tổng lượt tim: " + localeStr(stats.heartCount) + "\n" +
                                "🔗 Link: https://www.tiktok.com/@" + user.uniqueId + "\n─────────────────\n" +
                                "⏰ Thời gian: " + tm;
                api.sendMessage({ body: infoMsg, attachment: fs.createReadStream(avatarPath ) }, threadID, function() { cleanup(avatarPath) }, messageID);
                break;
            }
            case "video": {
                if (!keyword) return api.sendMessage("⚠️ Vui lòng nhập link video TikTok.", threadID, messageID);
                const res = await axios.get("https://www.tikwm.com/api/?url=" + encodeURIComponent(keyword ));
                if (res.data.code !== 0 || !(res.data.data && res.data.data.play)) return api.sendMessage("❌ Không thể tải video từ link này.", threadID, messageID);

                const data = res.data.data;
                const path = __dirname + '/cache/tiktok_video_' + Date.now() + '.mp4';
                await downloadFile(data.play, path);
                const msg = "[ TIKTOK VIDEO ]\n─────────────────\n" +
                            "📝 Tiêu đề: " + data.title + "\n" +
                            "👤 Tác giả: " + data.author.nickname + "\n" +
                            "❤️ Lượt tim: " + localeStr(data.digg_count) + "\n" +
                            "⏳ Thời gian: " + data.duration + " giây";
                api.sendMessage({ body: msg, attachment: fs.createReadStream(path) }, threadID, function() { cleanup(path) }, messageID);
                break;
            }
            case "music": {
                if (!keyword) return api.sendMessage("⚠️ Vui lòng nhập link video TikTok để tải nhạc.", threadID, messageID);
                const res = await axios.get("https://www.tikwm.com/api/?url=" + encodeURIComponent(keyword ));
                if (res.data.code !== 0 || !(res.data.data && res.data.data.music)) return api.sendMessage("❌ Không thể tải âm thanh từ link này.", threadID, messageID);

                const data = res.data.data;
                const path = __dirname + '/cache/tiktok_music_' + Date.now() + '.mp3';
                await downloadFile(data.music, path);
                const msg = "[ TIKTOK MUSIC ]\n─────────────────\n" +
                            "🎵 Tên bài hát: " + data.music_info.title + "\n" +
                            "👤 Nghệ sĩ: " + data.music_info.author + "\n" +
                            "⏳ Thời gian: " + data.music_info.duration + " giây";
                api.sendMessage({ body: msg, attachment: fs.createReadStream(path) }, threadID, function() { cleanup(path) }, messageID);
                break;
            }
            case "search": {
                if (!keyword) return api.sendMessage("⚠️ Vui lòng nhập từ khóa để tìm kiếm.", threadID, messageID);
                const res = await axios.get("https://www.tikwm.com/api/feed/search?keywords=" + encodeURIComponent(keyword ));
                if (res.data.code !== 0 || !(res.data.data && res.data.data.videos && res.data.data.videos.length > 0)) return api.sendMessage("❌ Không tìm thấy kết quả cho từ khóa \"" + keyword + "\".", threadID, messageID);

                const videos = res.data.data.videos;
                let msg = "🔎 Tìm thấy " + videos.length + " kết quả phù hợp:\n\n";
                const videoInfo = [];
                const limit = Math.min(videos.length, 10);

                for (let i = 0; i < limit; i++) {
                    const v = videos[i];
                    msg += (i + 1) + ". " + v.title + "\n   - 👤 Tác giả: " + v.author.nickname + "\n\n";
                    videoInfo.push({
                        title: v.title, nowatermark: v.play, nickname: v.author.nickname,
                        unique_id: v.author.unique_id, digg_count: v.digg_count, duration: v.duration
                    });
                }
                msg += "─────────────────\n📌 Phản hồi tin nhắn này bằng số thứ tự của video bạn muốn tải.";

                api.sendMessage(msg, threadID, function(err, info) {
                    if (err) return console.error(err);
                    global.client.handleReply.push({
                        name: module.exports.config.name, messageID: info.messageID, author: senderID,
                        type: 'search', videoInfo: videoInfo
                    });
                }, messageID);
                break;
            }
            case "post": {
                if (!keyword) return api.sendMessage("⚠️ Vui lòng nhập ID người dùng.", threadID, messageID);
                const res = await axios.get("https://www.tikwm.com/api/user/posts?unique_id=" + encodeURIComponent(keyword ));
                if (res.data.code !== 0 || !(res.data.data && res.data.data.videos && res.data.data.videos.length > 0)) return api.sendMessage("❌ Người dùng này không có bài đăng nào hoặc ID không hợp lệ.", threadID, messageID);
                
                await runListUserPost({ api: api, event: event, data: res.data.data.videos, page: 1, isVideo: true, author: senderID });
                break;
            }
            case "trending": {
                const res = await axios.get("https://www.tikwm.com/api/feed/list?region=VN" );
                if (res.data.code !== 0 || !(res.data.data && res.data.data.length > 0)) return api.sendMessage("❌ Không thể lấy danh sách video thịnh hành.", threadID, messageID);
                
                await runInfoTrending({ api: api, event: event, data: res.data.data, page: 1, author: senderID });
                break;
            }
            default:
                api.sendMessage("⚠️ Lệnh không hợp lệ. Vui lòng dùng `.tiktok` để xem hướng dẫn.", threadID, messageID);
                break;
        }
    } catch (error) {
        const errorMessage = (error.response && error.response.data) ? JSON.stringify(error.response.data) : error.message;
        console.error("Lỗi TikTok:", errorMessage);
        api.sendMessage("❌ Đã có lỗi xảy ra. API có thể đang bảo trì hoặc yêu cầu của bạn không hợp lệ.", threadID, messageID);
    }
};

// ============================================
//            PAGINATION FUNCTIONS
// ============================================
async function runInfoTrending({ api, event, data, page, author }) {
    const { threadID, messageID } = event;
    const itemsPerPage = 6;
    const totalPages = roof(data.length / itemsPerPage);
    const start = (page - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const pageData = data.slice(start, end);

    let msg = "[ VIDEO TIKTOK THỊNH HÀNH ]\n─────────────────\n";
    const attachments = [];
    const tempPaths = [];

    for (let i = 0; i < pageData.length; i++) {
        const video = pageData[i];
        msg += (start + i + 1) + ". " + video.title + "\n   - ❤️ " + localeStr(video.digg_count) + " | ⏳ " + video.duration + "s\n\n";
        const imgPath = __dirname + '/cache/tiktok_thumb_' + Date.now() + '_' + i + '.jpg';
        try {
            await downloadFile(video.origin_cover, imgPath);
            attachments.push(fs.createReadStream(imgPath));
            tempPaths.push(imgPath);
        } catch (e) {
            console.log("Không thể tải ảnh thumbnail cho video " + (start + i + 1));
        }
    }

    msg += "─────────────────\nTrang [ " + page + " / " + totalPages + " ]\n" +
           "📌 Phản hồi + STT để tải video.\n" +
           "📌 Phản hồi \"trang + số trang\" để chuyển trang.";

    api.sendMessage({ body: msg, attachment: attachments }, threadID, function(err, info) {
        cleanup(tempPaths);
        if (err) return console.error(err);
        global.client.handleReply.push({
            name: module.exports.config.name,
            messageID: info.messageID,
            author: author,
            type: 'trending',
            data: data
        });
    }, messageID);
}

async function runListUserPost({ api, event, data, page, isVideo, author }) {
    const { threadID, messageID } = event;
    const itemsPerPage = 6;
    const totalPages = roof(data.length / itemsPerPage);
    const start = (page - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const pageData = data.slice(start, end);

    const typeText = isVideo ? "VIDEO" : "ÂM THANH";
    let msg = "[ DANH SÁCH " + typeText + " CỦA NGƯỜI DÙNG ]\n─────────────────\n";
    const attachments = [];
    const tempPaths = [];

    for (let i = 0; i < pageData.length; i++) {
        const item = pageData[i];
        const title = isVideo ? item.title : (item.music_info ? item.music_info.title : "Không có tiêu đề");
        const duration = isVideo ? item.duration : (item.music_info ? item.music_info.duration : "N/A");
        const coverUrl = isVideo ? item.origin_cover : (item.music_info ? item.music_info.cover : null);
        
        msg += (start + i + 1) + ". " + title + " (⏳ " + duration + "s)\n";
        if (coverUrl) {
            const imgPath = __dirname + '/cache/tiktok_thumb_' + Date.now() + '_' + i + '.jpg';
            try {
                await downloadFile(coverUrl, imgPath);
                attachments.push(fs.createReadStream(imgPath));
                tempPaths.push(imgPath);
            } catch (e) {
                console.log("Không thể tải ảnh thumbnail cho mục " + (start + i + 1));
            }
        }
    }

    msg += "\n─────────────────\nTrang [ " + page + " / " + totalPages + " ]\n" +
           "📌 Phản hồi + STT để tải " + (isVideo ? 'video' : 'nhạc') + ".\n" +
           "📌 Phản hồi \"trang + số trang\" để chuyển trang.\n" +
           "❤️ Reaction tin nhắn này để chuyển sang danh sách " + (isVideo ? 'âm thanh' : 'video') + ".";

    api.sendMessage({ body: msg, attachment: attachments }, threadID, function(err, info) {
        cleanup(tempPaths);
        if (err) return console.error(err);
        const replyPayload = {
            name: module.exports.config.name,
            messageID: info.messageID,
            author: author,
            type: 'user_post',
            data: data,
            isVideo: isVideo
        };
        global.client.handleReply.push(replyPayload);
        global.client.handleReaction.push(replyPayload);
    }, messageID);
}
