const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs-extra');
const path = require('path');
const os = require('os');

module.exports.config = {
  name: "c",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Upload nhiều ảnh hoặc video từ reply lên catbox.moe",
  commandCategory: "Khác",
  usages: "[reply media]",
  cooldowns: 5,
  usePrefix: true,
  userPrefix: false,
  aliases: ["cb"],
};

module.exports.run = async function ({ api, event }) {
  const { messageReply, threadID, messageID } = event;

  // Đặt reaction đang xử lý
  api.setMessageReaction("⌛", messageID, () => {}, true);

  if (!messageReply || !messageReply.attachments || messageReply.attachments.length === 0) {
    return api.sendMessage("⚠️ Vui lòng reply ảnh hoặc video để upload lên Catbox.", threadID, messageID);
  }

  // Xử lý song song
  const uploadTasks = messageReply.attachments.map(async (attachment) => {
    const url = attachment.url;
    const ext = path.extname(url.split("?")[0]) || ".jpg";
    const tempPath = path.join(os.tmpdir(), `catbox_upload_${Date.now()}_${Math.floor(Math.random() * 9999)}${ext}`);

    try {
      // Tải file tạm
      const response = await axios.get(url, { responseType: 'stream' });
      const writer = fs.createWriteStream(tempPath);
      response.data.pipe(writer);

      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });

      // Upload lên Catbox
      const form = new FormData();
      form.append('reqtype', 'fileupload');
      form.append('fileToUpload', fs.createReadStream(tempPath));

      const uploadRes = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders()
      });

      return uploadRes.data.trim();

    } catch (err) {
      console.error("Catbox Upload Error:", err);
      return "❌ Lỗi upload: " + url;
    } finally {
      if (fs.existsSync(tempPath)) fs.unlink(tempPath, () => {});
    }
  });

  // Chờ tất cả hoàn thành
  try {
    const results = await Promise.all(uploadTasks);
    api.sendMessage("✅ Upload xong:\n" + results.join("\n"), threadID, () => {
      api.setMessageReaction("✅", messageID, () => {}, true);
    });
  } catch (err) {
    api.sendMessage("❌ Có lỗi khi upload.", threadID, messageID);
    api.setMessageReaction("❌", messageID, () => {}, true);
  }
};