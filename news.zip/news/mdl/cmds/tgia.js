module.exports.config = {
  name: "tgia",
  version: "2.0.0",
  hasPermssion: 2,
  credits: "nvh",
  description: "Thêm người vào nhiều nhóm mà bot đang ở",
  commandCategory: "Admin",
  usages: "thamgia",
  cooldowns: 0,
  usePrefix: true
};

module.exports.handleReply = async function({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID, mentions } = event;
  const { step, author, threadList, chosenThreads } = handleReply;
  if (senderID !== author) return api.sendMessage("⚠️ Chỉ người gọi lệnh mới được thao tác.", threadID, messageID);

  switch (step) {
    case 1: {
      const numbers = body.split(" ").map(num => parseInt(num)).filter(n => !isNaN(n));
      if (numbers.length === 0) return api.sendMessage("⚠️ Vui lòng nhập số thứ tự hợp lệ.", threadID, messageID);

      const validThreads = numbers.map(n => threadList[n - 1]).filter(Boolean);
      if (validThreads.length === 0) return api.sendMessage("⚠️ Không có nhóm nào hợp lệ.", threadID, messageID);

      const names = validThreads.map(t => `• ${t.name}`).join("\n");
      return api.sendMessage(
        `✅ Bạn đã chọn ${validThreads.length} nhóm:\n${names}\n\n👉 Bây giờ hãy reply tin nhắn này kèm **ID hoặc tag người cần thêm**.`,
        threadID,
        (err, info) => {
          global.client.handleReply.push({
            name: module.exports.config.name,
            messageID: info.messageID,
            author: senderID,
            step: 2,
            chosenThreads: validThreads
          });
        },
        messageID
      );
    }

    // Bước 2: thêm người
    case 2: {
      let targetIDs = [];
      if (Object.keys(mentions).length > 0) {
        targetIDs = Object.keys(mentions);
      } else {
        const ids = body.match(/\d{5,}/g);
        if (ids) targetIDs = ids;
      }

      if (targetIDs.length === 0)
        return api.sendMessage("⚠️ Vui lòng reply kèm ID hoặc tag người cần thêm.", threadID, messageID);

      let success = 0, fail = 0;
      for (const thr of chosenThreads) {
        for (const uid of targetIDs) {
          try {
            await api.addUserToGroup(uid, thr.threadID);
            success++;
          } catch (e) {
            fail++;
          }
        }
      }

      return api.sendMessage(
        `✅ Đã xử lý yêu cầu:\n🟢 Thành công: ${success}\n🔴 Thất bại: ${fail}\n👥 Tổng nhóm: ${chosenThreads.length}\n🆔 Người được thêm: ${targetIDs.length}`,
        threadID,
        messageID
      );
    }
  }
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID, senderID } = event;
  const commandName = this.config.name;

  try {
    const threads = (await api.getThreadList(100, null, ["INBOX"])).filter(g => g.isGroup && g.isSubscribed);
    if (threads.length === 0)
      return api.sendMessage("❌ Không tìm thấy nhóm nào mà bot đang ở.", threadID, messageID);

    let msg = "📜 𝗗𝗔𝗡𝗛 𝗦𝗔́𝗖𝗛 𝗡𝗛𝗢́𝗠 𝗕𝗢𝗧 Đ𝗔𝗡𝗚 𝗢̛̉\n━━━━━━━━━━━━━━━\n";
    threads.forEach((t, i) => {
      msg += `${i + 1}. ${t.name}\n`;
    });

    msg += `\n👉 Reply tin nhắn này kèm **số thứ tự** (có thể chọn nhiều, cách nhau bằng khoảng trắng).\nVí dụ: 1 3 5`;

    return api.sendMessage(msg, threadID, (err, info) => {
      if (err) return;
      global.client.handleReply.push({
        name: commandName,
        messageID: info.messageID,
        author: senderID,
        step: 1,
        threadList: threads
      });
    }, messageID);

  } catch (e) {
    return api.sendMessage(`❌ Lỗi khi lấy danh sách nhóm:\n${e.message}`, threadID, messageID);
  }
};