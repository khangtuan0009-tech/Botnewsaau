const axios = require("axios");
const fs = require("fs");
const ts = require("typescript");
const { v4: uuidv4 } = require("uuid");

module.exports.config = {
  name: "r",
  version: "1.3.0",
  hasPermssion: 3,
  credits: "nvh",
  description: "Chạy code Typscript",
  commandCategory: "Hệ thống",
  usages: "<code TypeScript>",
  cooldowns: 0,
  usePrefix: true,
  aliases: ["eval"]
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID: tid, messageID: mid, senderID: sid } = event;

  const send = async (output) => {
    const text = typeof output === "object"
      ? JSON.stringify(output, null, 2)
      : String(output);

    // Nếu nội dung dài thì upload lên note
    if (text.length > 500) {
      const uuid = uuidv4();
      const noteURL = `https://nvhzxz.onrender.com/note/${uuid}`;

      try {
        // Gửi nội dung bằng text/plain
        await axios.put(noteURL, text, {
          headers: { "content-type": "text/plain; charset=utf-8" },
          timeout: 10000
        });

        // Tạo link raw
        const rawUrl = new URL(noteURL);
        rawUrl.searchParams.append("raw", "true");

        return api.sendMessage(
          `📄 Kết quả quá dài, xem tại:\n${rawUrl.href}`,
          tid,
          mid
        );
      } catch (err) {
        return api.sendMessage(
          `❌ Lỗi khi upload note: ${err.message}`,
          tid,
          mid
        );
      }
    }

    // Gửi trực tiếp nếu ngắn
    return api.sendMessage(text, tid, mid);
  };

  // ====== CHẠY CODE TYPESCRIPT ======
  const tsCode = args.join(" ");
  if (!tsCode) return send("⚠️ Bạn cần nhập code TypeScript để chạy.");

  try {
    // Biên dịch sang JS
    const jsCode = ts.transpile(tsCode, {
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2020,
    });

    // Context để eval
    const context = {
      api,
      event,
      args,
      axios,
      fs,
      tid,
      mid,
      sid,
      send,
      console,
      log: (...data) => api.sendMessage(data.join(" "), tid),
    };

    // Tạo function async và thực thi
    const asyncFunc = new Function(
      ...Object.keys(context),
      `return (async () => { ${jsCode} })();`
    );

    const result = await asyncFunc(...Object.values(context));
    await send(result ?? "✅ Xong");
  } catch (err) {
    await send(`❌ Lỗi: ${err.stack || err.message}`);
  }
};