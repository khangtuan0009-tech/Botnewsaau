module.exports.config = {
  name: "setmoney",
  version: "1.4.0",
  hasPermssion: 2,
  credits: "nvh",
  description: "Cộng thêm số tiền hoặc xóa tiền của người dùng với định dạng tiền tệ",
  commandCategory: "Tiền tệ",
  usages: "[số tiền | clean]",
  cooldowns: 3,
  usePrefix: true
};

module.exports.run = async function ({ api, event, args, Currencies }) {
  const { messageID, threadID, senderID, type, messageReply } = event;

  if (args.length < 1) {
    return api.sendMessage(
      "⚠️ Dùng: setmoney [số tiền | clean]\nVí dụ: 5k, 2m, 1b, 1t",
      threadID,
      messageID
    );
  }

  let targetID = (type === "message_reply") ? messageReply.senderID : senderID;
  const name = (await api.getUserInfo(targetID))[targetID].name;

  try {
    if (args[0].toLowerCase() === "clean") {
      await Currencies.setData(targetID, { money: 0 });
      return api.sendMessage(
        `✅ Đã xóa toàn bộ tiền của ${name}.`,
        threadID,
        messageID
      );
    }

    // Chuyển chuỗi tiền dạng 5k, 2m, 1b, 1t thành số
    const parseMoney = (str) => {
      const match = str.toLowerCase().match(/^(\d+(?:\.\d+)?)([kmbt]?)$/);
      if (!match) return NaN;
      let [ , num, unit ] = match;
      num = parseFloat(num);
      switch (unit) {
        case "k": return num * 1_000;
        case "m": return num * 1_000_000;
        case "b": return num * 100_000_000;
        case "t": return num * 1_000_000_000;
        default: return num;
      }
    };

    // Định dạng số tiền hiển thị
    const formatMoney = (num) => {
      if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(2).replace(/\.00$/, "") + "t$";
      if (num >= 100_000_000) return (num / 100_000_000).toFixed(2).replace(/\.00$/, "") + "b$";
      if (num >= 1_000_000) return (num / 1_000_000).toFixed(2).replace(/\.00$/, "") + "m$";
      if (num >= 1_000) return (num / 1_000).toFixed(2).replace(/\.00$/, "") + "k$";
      return num.toLocaleString() + "$";
    };

    const moneyToAdd = parseMoney(args[0]);
    if (isNaN(moneyToAdd)) {
      return api.sendMessage("⚠️ Số tiền không hợp lệ!", threadID, messageID);
    }

    const userData = await Currencies.getData(targetID);
    const currentMoney = userData.money || 0;
    const newMoney = currentMoney + moneyToAdd;

    await Currencies.setData(targetID, { money: newMoney });

    api.sendMessage(
      `✅ ${name} đã được cộng thêm ${formatMoney(moneyToAdd)}.\nTổng tiền hiện tại: ${formatMoney(newMoney)}`,
      threadID,
      messageID
    );
  } catch (err) {
    console.error(err);
    api.sendMessage("❌ Lỗi khi xử lý tiền!", threadID, messageID);
  }
};