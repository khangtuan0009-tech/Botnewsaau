const fse = require("fs-extra");
const moment = require("moment-timezone");
const path = __dirname + "/../../vh/config.json";
let Cdata = JSON.parse(fse.readFileSync(path, "utf-8"));

module.exports.config = {
    name: "antiname",
    version: "1.4.0",
    hasPermission: 0,
    credits: "nvh",
    description: "Chặn người dùng đổi tên bot và tự đồng bộ nickname chuẩn",
    commandCategory: "Nhóm",
    usages: "[change]",
    cooldowns: 0,
  usePrefix: true,
    envConfig: { status: true },
};

// ====== Auto sync nickname khi bot khởi động ======
module.exports.onLoad = async ({ api, Threads }) => {
    const truc_cti = api.getUserID();
    const prefix = global.config.PREFIX;
    const saveName = `『 ${prefix} 』 ⪼ ${Cdata.BOTNAME}`;

    const allThreads = await api.getThreadList(); // [{ threadID, threadInfo }]
    for (const thread of allThreads) {
        let { threadID, threadInfo } = thread;
        if (!threadInfo.nicknames) threadInfo.nicknames = {};
        const currentNickname = threadInfo.nicknames[truc_cti] || "";

        if (currentNickname !== saveName) {
            threadInfo.nicknames[truc_cti] = saveName;
            await Threads.setData(threadID, { threadInfo });
            global.data.threadInfo.set(threadID, threadInfo);
            await api.changeNickname(saveName, threadID, truc_cti);
            console.log(`✅ Đồng bộ nickname chuẩn cho thread ${threadID}`);
        }
    }
    console.log("✨ Hoàn tất đồng bộ nickname chuẩn cho tất cả thread!");
};

// ====== Handle sự kiện đổi nickname ======
module.exports.handleEvent = async ({ api, event, Threads }) => {
    const { threadID, author, isGroup } = event;
    if (!isGroup) return;

    const truc_cti = api.getCurrentUserID();
    if (author === truc_cti) return; // Bot tự đổi → bỏ qua

    const nameModule = module.exports.config.name;
    let getDataThread = await Threads.getData(threadID) || {};
    const { data, threadInfo } = getDataThread;
    const prefix = data?.PREFIX || global.config.PREFIX;

    const saveName = `『 ${prefix} 』 ⪼ ${Cdata.BOTNAME}`;
    const currentNickname = threadInfo?.nicknames?.[truc_cti] || "";

    // Nếu nickname đã đúng chuẩn → bỏ qua
    if (currentNickname === saveName) return;

    if (Cdata[nameModule]?.status === true) {
        const timeChange = moment().tz("Asia/Ho_Chi_Minh").format("HH:mm:ss DD/MM/YYYY");

        // Người đổi không phải admin → đổi lại nickname chuẩn
        if (!Array.isArray(Cdata.ADMINBOT) || !Cdata.ADMINBOT.includes(author)) {
            if (!threadInfo.nicknames) threadInfo.nicknames = {};
            threadInfo.nicknames[truc_cti] = saveName;
            await Threads.setData(threadID, { threadInfo });
            global.data.threadInfo.set(threadID, threadInfo);
            await api.changeNickname(saveName, threadID, truc_cti);

            const userInfo = await api.getUserInfo(author);
            const nameUser = userInfo?.[author]?.name || author;

            return api.sendMessage(
                `⚠️ Thành viên ${nameUser} vừa cố đổi tên bot lúc ${timeChange}\nĐã tự set lại nickname chuẩn`,
                threadID
            );
        } 
        // Admin đổi → chỉ lưu config
        else {
            Cdata.BOTNAME = currentNickname.replace(/^『.*?』 ⪼\s*/, "").trim();
            fse.writeFileSync(path, JSON.stringify(Cdata, null, 2));
            delete require.cache[require.resolve(global.client.configPath)];
            global.config = require(global.client.configPath);
            Cdata = global.config;

            return api.sendMessage(
                `✅ Admin ${author} đã đổi tên bot thành: ${Cdata.BOTNAME}\n⏰ Thời gian: ${timeChange}`,
                threadID
            );
        }
    }
};

// ====== Lệnh thủ công ======
module.exports.run = function ({ api, event, args }) {
    const { threadID, messageID, senderID } = event;
    const nameModule = module.exports.config.name;
    const spl = args.slice(1);

    if (!Array.isArray(Cdata.ADMINBOT) || !Cdata.ADMINBOT.includes(senderID)) {
        return api.sendMessage("» Bạn không đủ quyền hạn!", threadID, messageID);
    }

    // Lệnh change tên bot
    if (["change", "c"].includes(args[0])) {
        if (!spl.join(" ").trim()) {
            return api.sendMessage("» Bạn chưa nhập tên cho bot", threadID, messageID);
        }
        Cdata.BOTNAME = spl.join(" ").trim();
        fse.writeFileSync(path, JSON.stringify(Cdata, null, 2));
        return api.sendMessage(`» Đã đổi định dạng tên bot thành: ${Cdata.BOTNAME}`, threadID, messageID);
    }

    // Bật/tắt chế độ cấm đổi tên bot
    const newStatus = !Cdata[nameModule]?.status;
    Cdata[nameModule] = { status: newStatus };
    fse.writeFileSync(path, JSON.stringify(Cdata, null, 2));
    api.sendMessage(`» ${newStatus ? "Bật" : "Tắt"} chế độ cấm đổi tên bot`, threadID, messageID);

    delete require.cache[require.resolve(global.client.configPath)];
    global.config = require(global.client.configPath);
    Cdata = global.config;
};