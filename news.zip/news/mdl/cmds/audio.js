const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");
const ytdl = require("ytdl-core-enhanced");

const mediaSavePath = __dirname + "/cache/Youtube/";
if (!fs.existsSync(mediaSavePath)) fs.mkdirSync(mediaSavePath, { recursive: true });

const YT_API_KEY = "AIzaSyAygWrPYHFVzL0zblaZPkRcgIFZkBNAW9g";

module.exports.config = {
  name: "audio",
  version: "6.1.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Tải nhạc từ YouTube",
  commandCategory: "Tiện ích",
  usages: "audio <từ khoá/url>",
  cooldowns: 3,
  usePrefix: true,
  useprefix: false 
};

// ====== DOWNLOAD AUDIO ======
async function downloadAudio(videoID, userID) {
  const filePath = path.join(mediaSavePath, `${Date.now()}_${userID}.m4a`);

  try {
    return await new Promise((resolve, reject) => {
      const stream = ytdl(videoID, {
        quality: "highestaudio",
        filter: "audioonly"
      });

      const writeStream = fs.createWriteStream(filePath);
      stream.pipe(writeStream);

      writeStream.on("finish", () => resolve(filePath));
      stream.on("error", reject);
    });
  } catch (err) {
    // Nếu lỗi -> fallback qua API apinvh
    const apiUrl = `https://apinvh.zzux.com/api/mediadl?url=https://youtu.be/${videoID}`;
    const res = await axios.get(apiUrl);
    if (!res.data || !res.data.data || !res.data.data.audio) throw new Error("API không trả link");

    const audioUrl = res.data.data.audio;
    const response = await axios.get(audioUrl, { responseType: "arraybuffer" });
    fs.writeFileSync(filePath, response.data);
    return filePath;
  }
}

// ====== Format thời lượng video ======
function formatDuration(duration) {
  const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
  const hours = (match[1] || "").replace("H", "") || 0;
  const minutes = (match[2] || "").replace("M", "") || 0;
  const seconds = (match[3] || "").replace("S", "") || 0;
  return `${hours > 0 ? hours + ":" : ""}${minutes.toString().padStart(2, "0")}:${seconds
    .toString()
    .padStart(2, "0")}`;
}

// ====== Xử lý tải và gửi ======
async function handleDownload(api, threadID, messageID, senderID, videoID) {
  try {
    const startTime = Date.now();

    const info = await axios.get(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${videoID}&key=${YT_API_KEY}`
    );
    const video = info.data.items[0];
    const title = video.snippet.title;
    const channel = video.snippet.channelTitle;
    const duration = formatDuration(video.contentDetails.duration);
    const views = Number(video.statistics.viewCount).toLocaleString();

    const filePath = await downloadAudio(videoID, senderID);
    const processingTime = ((Date.now() - startTime) / 1000).toFixed(2);

    const messageText = 
`🎵 Bài hát: ${title}
👤 Ca sĩ: ${channel}
⏱️ Thời lượng: ${duration}
👀 Lượt nghe: ${views}
⏳ Thời gian xử lý: ${processingTime} giây`;

    await api.sendMessage(
      { body: messageText, attachment: fs.createReadStream(filePath) },
      threadID,
      () => fs.unlinkSync(filePath)
    );
  } catch (err) {
    api.sendMessage("❎ Lỗi khi tải bài hát.", threadID, messageID);
  }
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  if (!args[0]) return api.sendMessage("❎ Nhập từ khoá hoặc URL YouTube.", threadID, messageID);

  const input = args.join(" ");
  const urlPattern = /^(https?:\/\/)?(www\.)?(m\.)?(youtube\.com|youtu\.be)\/.+/;
  let videoID;

  if (urlPattern.test(input)) {
    try {
      videoID = ytdl.getURLVideoID(input);
    } catch {}
  } else {
    // Search
    const search = await axios.get(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(
        input
      )}&key=${YT_API_KEY}`
    );
    if (!search.data.items.length) return api.sendMessage("❎ Không tìm thấy kết quả.", threadID, messageID);
    videoID = search.data.items[0].id.videoId;
  }

  if (videoID) {
    await handleDownload(api, threadID, messageID, senderID, videoID);
  }
};