const fs = require('fs');
const fse = require("fs-extra");
const path = require('path');

// ================= Cấu hình =================
const TRASH_EXT = [".mp3", ".wav", ".jpg", ".jpeg", ".png", ".gif", ".mp4", ".webm", ".svg", ".m4a"];

const foldersToClean = [
    path.join(__dirname, '/cache'),
    path.join(__dirname, '/data'),
    path.join(__dirname, '/cache/avt'),
    path.join(__dirname, '/cache/Youtube')
];

const checkttDir = path.join(__dirname, "checktt");

// ============== Hàm dọn file rác ==============
function cleanFolder(folderPath) {
    if (!fs.existsSync(folderPath)) return;
    const files = fs.readdirSync(folderPath);
    for (const file of files) {
        const filePath = path.join(folderPath, file);
        try {
            const stat = fs.lstatSync(filePath);
            if (stat.isDirectory()) continue; // bỏ qua folder
            const ext = path.extname(file).toLowerCase();
            if (TRASH_EXT.includes(ext)) {
                fs.unlinkSync(filePath);
                console.log(`🗑️ Đã xóa: ${filePath}`);
            }
        } catch (err) {
            console.error(`❌ Lỗi khi xóa ${filePath}:`, err);
        }
    }
}

function cleanAllFolders() {
    foldersToClean.forEach(cleanFolder);
}

// ============== Hàm xóa data checktt box out ==============
async function cleanChecktt(api) {
    if (!fs.existsSync(checkttDir)) return 0;

    const files = fs.readdirSync(checkttDir).filter(f => f.endsWith(".json"));
    let threads = await api.getThreadList(100, null, ["INBOX"]);
    let aliveThreadIDs = threads.map(t => t.threadID);

    let deleted = 0;
    for (let file of files) {
        const threadID = file.replace(".json", "");
        if (!aliveThreadIDs.includes(threadID)) {
            fse.unlinkSync(path.join(checkttDir, file));
            deleted++;
        }
    }
    return deleted;
}

// ================= Module command =================
module.exports.config = {
    name: "clean",            
    version: "2.0.0",
    hasPermssion: 2,          
    credits: "nvh",
    description: "Dọn file rác và xoá data checktt box đã out",
    commandCategory: "Admin",
    usages: "clean [trash|data|all]",
    cooldowns: 5,
  usePrefix: true
};

module.exports.run = async ({ event, api, args }) => {
    try {
        if (!args[0] || args[0] === "trash") {
            cleanAllFolders();
            return api.sendMessage("✅ Đã dọn sạch file rác trong cache/data.", event.threadID);
        }

        if (args[0] === "data") {
            let deleted = await cleanChecktt(api);
            return api.sendMessage(`✅ Đã xoá ${deleted} file checktt của box bot đã out.`, event.threadID);
        }

        if (args[0] === "all") {
            cleanAllFolders();
            let deleted = await cleanChecktt(api);
            return api.sendMessage(`✅ Đã dọn rác + xoá ${deleted} file checktt box out.`, event.threadID);
        }

        return api.sendMessage("❌ Sai cú pháp!\n👉 clean [trash|data|all]", event.threadID);

    } catch (err) {
        console.error(err);
        api.sendMessage("❌ Xảy ra lỗi khi dọn dữ liệu!", event.threadID);
    }
};