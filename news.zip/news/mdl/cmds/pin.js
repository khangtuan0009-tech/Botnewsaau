const axios = require("axios");
const fs = require("fs-extra");
const FormData = require("form-data");

// Lấy stream ảnh từ URL
async function getStreamFromURL(url) {
  try {
    const res = await axios({ method: "GET", url, responseType: "stream" });
    return res.data;
  } catch {
    return null;
  }
}

// Gửi ảnh và handle "next"
async function sendImages({ api, threadID, keyword, images, startIndex, authorID, messageID }) {
  const nextImages = images.slice(startIndex, startIndex + 5);
  if (nextImages.length === 0) return api.sendMessage("✅ Hết ảnh rồi!", threadID, messageID);

  const attachments = await Promise.all(nextImages.map(url => getStreamFromURL(url)));
  const validAttach = attachments.filter(Boolean);

  return api.sendMessage({
    body: `📸 Kết quả cho: ${keyword}\nẢnh ${startIndex + 1} → ${startIndex + validAttach.length}/${images.length}\n👉 Reply "next" để xem thêm`,
    attachment: validAttach
  }, threadID, (err, info) => {
    global.client.handleReply.push({
      type: "pin",
      name: "pin",
      author: authorID,
      messageID: info.messageID,
      images,
      index: startIndex + 5,
      keyword
    });
  }, messageID);
}

// Upload ảnh dùng dkupload.site
async function uploadToDkUpload(url) {
  try {
    const res = await axios.get(`https://dkupload.site/api/convert?url=${encodeURIComponent(url)}`);
    if (res.data?.success && res.data?.convertedUrl) return res.data.convertedUrl;
    return null;
  } catch {
    return null;
  }
}

module.exports.config = {
  name: "pin",
  version: "3.4.0",
  hasPermission: 0,
  credits: "nvh",
  description: "Tìm kiếm ảnh trên Pinterest hoặc tìm ảnh tương tự từ ảnh reply",
  commandCategory: "Tiện ích",
  usages: "[từ khóa] hoặc reply 1 ảnh",
  cooldowns: 5,
  usePrefix: true,
  dependencies: {
    axios: ""
  }
};

// Handle reply "next"
module.exports.handleReply = async function ({ api, event, handleReply }) {
  if (event.senderID != handleReply.author) return;
  if (event.body.toLowerCase() === "next") {
    return sendImages({
      api,
      threadID: event.threadID,
      keyword: handleReply.keyword,
      images: handleReply.images,
      startIndex: handleReply.index,
      authorID: event.senderID,
      messageID: event.messageID
    });
  }
};

// Main run
module.exports.run = async function ({ api, event, args }) {
  try {
    // === CASE 1: reply ảnh ===
    if (event.type === "message_reply" && event.messageReply.attachments[0]?.type === "photo" && args.length === 0) {
      const imgURL = event.messageReply.attachments[0].url;
      api.sendMessage("🔍 Đang tìm ảnh tương tự trên Pinterest...", event.threadID, event.messageID);

      const uploadedURL = await uploadToDkUpload(imgURL);
      if (!uploadedURL) return api.sendMessage("❌ Upload ảnh thất bại!", event.threadID, event.messageID);

      try {
        const res = await axios.get(`https://api.satoru.site/api/pinterest/search`, {
          params: { image_url: uploadedURL, limit: 20 }
        });

        const images = res.data?.data?.pins?.map(pin => pin.attachment_url).filter(u => u.startsWith("http")) || [];
        if (images.length === 0) return api.sendMessage("❌ Không tìm thấy ảnh tương tự!", event.threadID, event.messageID);

        return sendImages({
          api,
          threadID: event.threadID,
          keyword: "Ảnh tương tự",
          images,
          startIndex: 0,
          authorID: event.senderID,
          messageID: event.messageID
        });
      } catch {
        return api.sendMessage("❌ Lỗi khi tìm ảnh tương tự!", event.threadID, event.messageID);
      }
    }

    // === CASE 2: tìm theo từ khóa (Pinterest) ===
    const keyword = args.join(" ");
    if (!keyword) return api.sendMessage("⚠️ Nhập từ khóa hoặc reply 1 ảnh!", event.threadID, event.messageID);

    const res = await axios.get(`https://subhatde.id.vn/pinterest?search=${encodeURIComponent(keyword)}`);
    const images = res.data?.data || [];
    if (images.length === 0) return api.sendMessage("❌ Không tìm thấy kết quả nào!", event.threadID, event.messageID);

    return sendImages({
      api,
      threadID: event.threadID,
      keyword,
      images,
      startIndex: 0,
      authorID: event.senderID,
      messageID: event.messageID
    });

  } catch {
    api.sendMessage("❌ Lỗi rồi vợ!", event.threadID, event.messageID);
  }
};