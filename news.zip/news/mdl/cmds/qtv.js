module.exports.config = {
    name: "qtv",
    version: "1.0.0",
    hasPermssion: 1,
    credits: "nvh",
    description: "Thêm hoặc xoá qtv",
    commandCategory: "Nhóm",
    usages: "[add/remove] [tag/reply]",
    cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function ({ event, api, args, Users, Threads }) {
    if (!args[0] || !["add", "remove"].includes(args[0])) 
        return api.sendMessage('⚠️ Lựa chọn: qtv add/remove [tag/reply]', event.threadID);

    let dataThread = (await Threads.getData(event.threadID)).threadInfo;
    const botID = api.getCurrentUserID();

    // Kiểm tra quyền hạn
    if (!dataThread.adminIDs.some(item => item.id == botID) && 
        !dataThread.adminIDs.some(item => item.id == event.senderID))
        return api.sendMessage('❎ Bạn không đủ quyền hạn dùng lệnh này', event.threadID);

    // Xác định UID người được add/remove
    let uid;
    if (event.type == "message_reply") {
        uid = event.messageReply.senderID;
    } else if (Object.keys(event.mentions).length > 0) {
        uid = Object.keys(event.mentions)[0];
    } else {
        uid = event.senderID; // Nếu không reply/tag => lấy bản thân
    }

    api.sendMessage('📌 Thả cảm xúc tin nhắn này để xác nhận', event.threadID, (error, info) => {
        global.client.handleReaction.push({
            name: this.config.name,
            type: args[0],
            messageID: info.messageID,
            author: event.senderID,
            userID: uid
        });
    });
}

module.exports.handleReaction = async function ({ event, api, handleReaction, Users }) {
    if (event.userID != handleReaction.author) return;

    let name = (await Users.getData(handleReaction.userID)).name;

    if (handleReaction.type == 'add') {
        api.changeAdminStatus(event.threadID, handleReaction.userID, true, (err) => {
            if (err) return api.sendMessage("❎ Bot không đủ quyền hạn để thêm quản trị viên", event.threadID, event.messageID);
            return api.sendMessage(`✅ Đã thêm ${name} làm qtv nhóm`, event.threadID, event.messageID);
        });
    }

    if (handleReaction.type == 'remove') {
        api.changeAdminStatus(event.threadID, handleReaction.userID, false, (err) => {
            if (err) return api.sendMessage("❎ Bot không đủ quyền hạn để gỡ quản trị viên", event.threadID, event.messageID);
            return api.sendMessage(`✅ Đã gỡ qtv của ${name}`, event.threadID, event.messageID);
        });
    }
}