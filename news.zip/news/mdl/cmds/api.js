const fs = require("fs");
const path = require("path");
const axios = require("axios");

const pathApi = path.join(__dirname, "../../utils/video/");

module.exports.config = {
  name: "api",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "nvh",
  description: "Check link die và giữ danh sách file",
  commandCategory: "Admin",
  cooldowns: 1,
  usePrefix: true,
};

const CL = (filePath) =>
  fs.readFileSync(filePath, "utf-8").split(/\r\n|\r|\n/).length;

module.exports.run = async ({ api, event }) => {
  try {
    const files = fs.readdirSync(pathApi).filter(f => f.endsWith(".json"));
    if (!files.length) return api.sendMessage("Thư mục rỗng!", event.threadID);

    const fileListArray = files.map((file, index) => ({
      index: index + 1,
      fileName: path.basename(file, ".json"),
      filePath: pathApi + file,
      lineCount: CL(pathApi + file),
    }));

    const fileList = fileListArray
      .map(item => `${item.index}. ${item.fileName} (${item.lineCount} lines)`)
      .join("\n");

    api.setMessageReaction("✅", event.messageID, () => {}, true);

    const messageInfo = await api.sendMessage(
      `➣ Danh sách các file api:\n${fileList}\n\nReply tin nhắn này với: check + stt file`,
      event.threadID
    );

    global.client.handleReply.push({
      name: module.exports.config.name,
      messageID: messageInfo.messageID,
      author: event.senderID,
      fileListArray,
      type: "list",
    });

  } catch (error) {
    console.error(error);
    api.setMessageReaction("❎", event.messageID, () => {}, true);
    api.sendMessage("Đã xảy ra lỗi!", event.threadID);
  }
};

module.exports.handleReply = async ({ api, handleReply, event }) => {
  try {
    const { threadID, body, messageID } = event;
    const { fileListArray } = handleReply;
    const args = body.split(" ");

    if (args[0].toLowerCase() !== "check") return;

    const fileIndices = args.slice(1).map(index => parseInt(index));

    for (const fileIndex of fileIndices) {
      if (fileIndex >= 1 && fileIndex <= fileListArray.length) {
        const selectedFile = fileListArray[fileIndex - 1];
        const filePath = selectedFile.filePath;

        api.setMessageReaction("⌛", messageID, () => {}, true);

        try {
          const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

          const brokenLinks = await Promise.all(data.map(async link => {
            if (!/^https?:\/\//.test(link)) return link;
            try {
              const res = await axios.head(link, { timeout: 5000 });
              if (res.status >= 400) return link;
            } catch {
              return link;
            }
          }));

          const dieLinks = brokenLinks.filter(Boolean);

          api.setMessageReaction("✅", messageID, () => {}, true);
          api.sendMessage(
            `===𝐂𝐡𝐞𝐜𝐤 𝐋𝐢𝐧𝐤===\n➣ File: ${selectedFile.fileName}\n➣ Link die: ${dieLinks.length}\n➣ Link sống: ${data.length - dieLinks.length}\n➣ Thả cảm xúc vào tin nhắn để xóa link die`,
            threadID,
            (error, info) => {
              if (!error && dieLinks.length) {
                global.client.handleReaction.push({
                  name: module.exports.config.name,
                  messageID: info.messageID,
                  author: event.senderID,
                  type: "check",
                  linkk: dieLinks,
                  filePath,
                });
              }
            }
          );

        } catch (error) {
          console.error(`Error reading/parsing JSON file ${selectedFile.fileName}:`, error);
          api.setMessageReaction("❎", messageID, () => {}, true);
          api.sendMessage(`Đã xảy ra lỗi khi đọc file ${selectedFile.fileName}`, threadID);
        }

      } else {
        api.setMessageReaction("❎", messageID, () => {}, true);
        api.sendMessage(`Index ${fileIndex} không hợp lệ`, threadID);
      }
    }

  } catch (error) {
    console.error("Lỗi handleReply:", error);
  }
};

module.exports.handleReaction = async ({ api, event, handleReaction }) => {
  if (event.userID != handleReaction.author) return;
  try {
    const { filePath, linkk } = handleReaction;
    if (filePath && Array.isArray(linkk) && linkk.length) {
      let jsonData = JSON.parse(fs.readFileSync(filePath, "utf-8"));
      const before = jsonData.length;
      jsonData = jsonData.filter(link => !linkk.includes(link));
      fs.writeFileSync(filePath, JSON.stringify(jsonData, null, 2), "utf-8");
      api.sendMessage(`✅ Đã xóa ${before - jsonData.length} link die`, event.threadID);
    }
  } catch (error) {
    console.error(error);
  }
};