const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "ptnews",
  version: "1.3.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Tin tức Play Together VNG + phân trang + xem chi tiết qua reply",
  commandCategory: "Khác",
  usages: "ptnews [số_trang]",
  cooldowns: 5,
  usePrefix: true
};

async function fetchList(page = 1) {
  const LIST_URL = `https://playtogether.vnggames.com/tin-tuc/tin-tuc.${page}.html`;
  const { data: html } = await axios.get(LIST_URL, { timeout: 20000 });
  const $ = cheerio.load(html);

  const items = [];
  $('a[href*="/tin-tuc/tin-tuc/"]').each((i, el) => {
    const url = new URL($(el).attr("href"), LIST_URL).toString();
    const title = $(el).text().trim().replace(/\s+/g, " ");
    if (!title) return;
    let date = $(el).parent().text();
    const m = date.match(/(\d{2}-\d{2}-\d{4}|\d{2}-\d{2}-\d{2})/);
    date = m ? m[1] : "";
    if (!items.find(x => x.url === url)) {
      items.push({ title, date, url });
    }
  });
  return items.slice(0, 8);
}

async function fetchDetail(url) {
  const { data: html } = await axios.get(url, { timeout: 20000 });
  const $ = cheerio.load(html);
  const title = $("h1, h2").first().text().trim() || $("title").text().trim();
  const images = [];
  $("img").each((_, img) => {
    const src = $(img).attr("src") || "";
    if (/img\.zing\.vn\/.+\.(png|jpe?g|webp)$/i.test(src)) {
      images.push(new URL(src, url).toString());
    }
  });
  const uniq = [...new Set(images)].slice(0, 10);
  const desc = ($("p").map((_, p) => $(p).text().trim()).get().find(t => t && t.length > 20)) || "";
  return { title, url, desc, images: uniq };
}

async function downloadImages(imageUrls) {
  const files = [];
  for (const u of imageUrls) {
    try {
      const res = await axios.get(u, { responseType: "arraybuffer", timeout: 25000 });
      const ext = path.extname(new URL(u).pathname) || ".jpg";
      const file = path.join(__dirname, `pt_${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`);
      fs.writeFileSync(file, res.data);
      files.push(file);
    } catch {}
  }
  return files;
}

module.exports.handleReply = async function ({ api, event, handleReply }) {
  try {
    const idx = parseInt(event.body.trim(), 10) - 1;
    if (isNaN(idx) || idx < 0 || idx >= handleReply.list.length) {
      return api.sendMessage("❌ Số bài không hợp lệ.", event.threadID, event.messageID);
    }
    const item = handleReply.list[idx];
    const detail = await fetchDetail(item.url);
    const body = `【Play Together VNG】\n${detail.title}\nNgày: ${item.date || "N/A"}\n${detail.url}\n\n${detail.desc || ""}`;
    const files = await downloadImages(detail.images);
    return api.sendMessage(
      { body, attachment: files.map(f => fs.createReadStream(f)) },
      event.threadID,
      () => files.forEach(f => fs.existsSync(f) && fs.unlinkSync(f)),
      event.messageID
    );
  } catch {
    return api.sendMessage("⚠️ Lỗi khi lấy dữ liệu.", event.threadID, event.messageID);
  }
};

module.exports.run = async function ({ api, event, args }) {
  try {
    const page = args[0] && !isNaN(args[0]) ? parseInt(args[0], 10) : 1;
    const list = await fetchList(page);
    if (list.length === 0) return api.sendMessage("⚠️ Không tìm thấy tin ở trang này.", event.threadID, event.messageID);

    const lines = list.map((it, i) => `${i + 1}. ${it.title} (${it.date || "N/A"})`);
    const guide = [
      `📄 Danh sách tin - Trang ${page}:`,
      ...lines,
      "",
      "💬 Reply số thứ tự bài để xem chi tiết."
    ].join("\n");

    return api.sendMessage(guide, event.threadID, (err, info) => {
      global.client.handleReply.push({
        name: this.config.name,
        messageID: info.messageID,
        list
      });
    });
  } catch {
    return api.sendMessage("⚠️ Lỗi khi lấy dữ liệu.", event.threadID, event.messageID);
  }
};