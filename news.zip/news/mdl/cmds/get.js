const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");
const PQueue = require("p-queue").default;

const pathApi = path.join(__dirname, "../../utils/video/");
const CONCURRENCY = parseInt(process.env.GET_CONCURRENCY || "5");

module.exports.config = {
  name: "get",
  version: "1.6.0",
  hasPermssion: 3,
  credits: "nvh",
  description: "Lấy video TikTok và lưu link catbox",
  commandCategory: "Admin",
  usages: "get <username1> <username2> ... <tên_mục>",
  cooldowns: 5,
  usePrefix: true,
};

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)",
  "Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)",
];

function pickUA() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

// ======= Upload sang Catbox =======
async function uploadViaCatbox(url) {
  try {
    const fileData = await axios.get(url, {
      responseType: "arraybuffer",
      timeout: 30000,
      headers: { "User-Agent": pickUA() },
    });

    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", Buffer.from(fileData.data), {
      filename: "video.mp4",
      contentType: "video/mp4",
    });

    const res = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
      timeout: 60000,
    });

    if (typeof res.data === "string" && res.data.startsWith("https://"))
      return res.data.trim();
    return null;
  } catch (e) {
    return null;
  }
}

// ======= Ghi dữ liệu JSON =======
async function saveLinksJsonAppend(category, newLinks) {
  const folder = pathApi;
  if (!fs.existsSync(folder)) await fsp.mkdir(folder, { recursive: true });
  const filePath = path.join(folder, `${category}.json`);
  let existingLinks = [];
  try {
    if (fs.existsSync(filePath)) {
      const txt = await fsp.readFile(filePath, "utf-8");
      existingLinks = JSON.parse(txt || "[]");
    }
  } catch {
    existingLinks = [];
  }

  const allLinks = [...existingLinks, ...newLinks];
  const tmp = `${filePath}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(allLinks, null, 2), "utf-8");
  await fsp.rename(tmp, filePath);
}

// ==================== Main run =======================
module.exports.run = async function ({ api, event, args }) {
  if (args.length < 2) {
    return api.sendMessage(
      "❌ Dùng: get <username1> <username2> ... <tên_mục>",
      event.threadID,
      event.messageID
    );
  }

  const results = [];
  const errors = [];
  const queue = new PQueue({ concurrency: CONCURRENCY });

  const category = args[args.length - 1];
  const users = args.slice(0, -1);

  api.sendMessage(
    `📥 Đang lấy video TikTok của ${users.length} user...\n🗂 Lưu vào: ${category}.json`,
    event.threadID
  );

  const tasks = users.map((user) =>
    queue.add(async () => {
      try {
        const res = await axios.post(
          "https://www.tikwm.com/api/user/posts",
          new URLSearchParams({ unique_id: user }),
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "User-Agent": pickUA(),
            },
            timeout: 40000,
          }
        );

        if (res.data?.code !== 0) {
          errors.push(`❌ ${user}: API TikTok lỗi (${res.data?.msg || "Không rõ"})`);
          return;
        }

        const videos = res.data?.data?.videos || [];
        if (!videos.length) {
          errors.push(`⚠️ ${user}: Không tìm thấy video.`);
          return;
        }

        for (const v of videos) {
          const uploaded = await uploadViaCatbox(v.play || v.playwm || v.download);
          if (!uploaded) errors.push(`${user}: Upload thất bại`);
          else results.push(uploaded);
        }
      } catch (e) {
        errors.push(`❌ ${user}: ${e.message}`);
      }
    })
  );

  await Promise.all(tasks);

  if (results.length) await saveLinksJsonAppend(category, results);

  api.sendMessage(
    results.length
      ? `🎉 Hoàn tất!\nĐã lưu ${results.length} video vào ${category}.json\n⚠️ ${errors.length} lỗi`
      : `❌ Không tải được video nào.\n${errors.join("\n")}`,
    event.threadID
  );
};
