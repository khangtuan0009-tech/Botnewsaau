const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

module.exports.config = {
  name: "ig",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Instagram",
  commandCategory: "box",
  usages: "<từ khóa>",
  cooldowns: 5
};

let cacheSearch = {}; // Lưu kết quả tìm kiếm tạm thời theo threadID

module.exports.run = async function ({ api, event, args }) {
  try {
    const { threadID, messageID } = event;
    const query = args.join(" ").trim();
    if (!query)
      return api.sendMessage("⚠️ Nhập từ khóa Instagram cần tìm.", threadID, messageID);

    // Gọi API tìm kiếm IG
    const res = await global.api.igsearch.search(query);
    if (!res || !Array.isArray(res) || res.length === 0)
      return api.sendMessage(`❌ Không tìm thấy kết quả cho "${query}".`, threadID, messageID);

    const list = res.slice(0, 10);
    let msg = `🔎 Kết quả cho: ${query}\n\n`;
    list.forEach((u, i) => {
      msg += `${i + 1}. ${u.username} ${u.is_verified ? "✓" : ""}\n`;
      msg += `   ${u.full_name || "—"}${u.is_private ? " 🔒" : ""}\n`;
    });
    msg += `\n📩 Reply số để xem info chi tiết (1–${list.length})`;

    // Lưu tạm kết quả
    cacheSearch[threadID] = list;

    return api.sendMessage(msg, threadID, (err, info) => {
      if (err) console.error(err);
      // Gắn messageID để nhận reply
      cacheSearch[threadID].messageID = info.messageID;
    }, messageID);
  } catch (e) {
    console.error(e);
    api.sendMessage("❗ Lỗi khi tìm Instagram.", event.threadID, event.messageID);
  }
};

module.exports.handleEvent = async function ({ api, event }) {
  try {
    const { threadID, body, messageReply } = event;
    if (!messageReply || !cacheSearch[threadID]) return;
    const data = cacheSearch[threadID];
    if (String(messageReply.messageID) !== String(data.messageID)) return;

    const num = parseInt(body);
    if (isNaN(num) || num < 1 || num > data.length) return;

    const target = data[num - 1];
    const username = target.username;
    const infoRes = await global.api.ifig.infoig(username);

    if (!infoRes?.ok || !infoRes.user)
      return api.sendMessage("❌ Không thể lấy thông tin người dùng.", threadID);

    const u = infoRes.user;
    let msg = `📸 Thông tin Instagram\n\n`;
    msg += `👤 Username: ${u.username}\n`;
    msg += `📛 Tên: ${u.name || "—"}\n`;
    msg += `🆔 ID: ${u.id}\n`;
    msg += `✅ Verified: ${u.verified ? "Có" : "Không"}\n`;
    msg += `🔒 Private: ${u.private ? "Có" : "Không"}\n`;
    msg += `👥 Followers: ${u.followers ?? "—"}\n`;
    msg += `👣 Following: ${u.following ?? "—"}\n`;
    msg += `📷 Bài đăng: ${u.posts ?? 0}\n`;
    msg += `\n📎 https://instagram.com/${u.username}`;

    let attachment = [];
    if (u.avatar) {
      const filePath = path.join(__dirname, "cache", `${u.username}.jpg`);
      const res = await axios.get(u.avatar, { responseType: "arraybuffer" });
      await fs.writeFile(filePath, res.data);
      attachment.push(fs.createReadStream(filePath));
    }

    api.sendMessage({ body: msg, attachment }, threadID);
  } catch (e) {
    console.error("IG reply error:", e);
  }
};