module.exports.config = {
  name: "link",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Lấy link mời group",
  commandCategory: "group",
  usages: "getlink",
  cooldowns: 5,
  usePrefix: true,
};

module.exports.run = async function ({ api, event }) {
  try {
    const threadInfo = await api.getThreadInfo(event.threadID);

    if (threadInfo.inviteLink && threadInfo.inviteLink.enable) {
      api.sendMessage(
        `✅ Link mời của nhóm là:\n${threadInfo.inviteLink.link}`,
        event.threadID,
        event.messageID
      );
    } else {
      api.sendMessage(
        `❌ Nhóm này chưa bật link mời.`,
        event.threadID,
        event.messageID
      );
    }
  } catch (e) {
    console.log(e);
    api.sendMessage(
      `⚠️ Đã xảy ra lỗi khi lấy link mời.`,
      event.threadID,
      event.messageID
    );
  }
};