const axios = require('axios');

module.exports.config = {
  name: "u",
  version: "3.1.0",
  hasPermssion: 0,
  credits: "Dũngkon & nvh",
  description: "Upload media mạnh - hỗ trợ nhiều file cùng lúc",
  commandCategory: "Khác",
  usages: "[up/upload/-up] [link hoặc reply nhiều file]",
  cooldowns: 5
};

module.exports.run = async function({ api, event }) {
  const { threadID, messageID, body, messageReply } = event;

  const isValidMediaUrl = (url) => {
    try {
      const ext = new URL(url).pathname.split('.').pop().toLowerCase();
      return ['jpg','jpeg','png','gif','webp','mp4','mov','avi','mkv'].includes(ext);
    } catch {
      return false;
    }
  };

  const isCmd = body && (body.startsWith("upload") || body.startsWith("up") || body.startsWith("-up"));
  if (!isCmd && !messageReply) {
    return api.sendMessage(`📌 Cách dùng:
➠ Reply file + gõ "up"
➠ Gõ "upload link1 link2..."
➠ Gõ "-up link" (phiên bản rút gọn)`, threadID, messageID);
  }

  try {
    const mediaUrls = [];

    // Reply nhiều file
    if (messageReply?.attachments?.length > 0) {
      for (const file of messageReply.attachments) {
        if (file.url) mediaUrls.push(file.url);
      }
    } 
    // Nhập nhiều link
    else if (body) {
      const text = body.replace(/^(upload|up|-up)/i, "").trim();
      const detectedLinks = text.split(/\s+/).filter(url => isValidMediaUrl(url));
      mediaUrls.push(...detectedLinks);
    }

    if (mediaUrls.length === 0) {
      return api.sendMessage("❌ Không tìm thấy file hợp lệ!", threadID, messageID);
    }

    const startAll = Date.now();

    // Upload từng file
    const results = await Promise.allSettled(mediaUrls.map(async (url) => {
      const startOne = Date.now();
      try {
        // Lấy dung lượng
        let size = "N/A";
        try {
          const head = await axios.head(url, { timeout: 10000 });
          if (head.headers["content-length"]) {
            size = (head.headers["content-length"] / 1024 / 1024).toFixed(2) + " MB";
          }
        } catch {}

        // Upload
        const res = await axios.get(
          `https://dkupload.site/api/convert?url=${encodeURIComponent(url)}`,
          { timeout: 20000 }
        );
        const convertedUrl = res.data?.convertedUrl || null;

        return {
          url,
          size,
          convertedUrl,
          time: ((Date.now() - startOne) / 1000).toFixed(2) + "s"
        };
      } catch {
        return null;
      }
    }));

    const success = results.filter(r => r.status === "fulfilled" && r.value && r.value.convertedUrl).map(r => r.value);

    const totalTime = ((Date.now() - startAll) / 1000).toFixed(2);

    if (success.length === 0) {
      return api.sendMessage("❌ Tất cả upload đều thất bại!", threadID, messageID);
    }

    // Format bảng + link tách riêng
    let table = "📦 KẾT QUẢ UPLOAD\n";
    table += "━━━━━━━━━━━━━━━━━━━━━━━\n";
    table += "# |   Size   |  Time\n";
    table += "━━━━━━━━━━━━━━━━━━━━━━━\n";
    success.forEach((f, i) => {
      table += `${i+1} | ${f.size.padEnd(7)} | ${f.time}\n`;
    });
    table += "━━━━━━━━━━━━━━━━━━━━━━━\n";
    table += `✅ Thành công: ${success.length}/${mediaUrls.length}\n`;
    table += `⏱️ Tổng thời gian: ${totalTime}s\n\n`;

    table += "🔗 Link:\n";
    success.forEach((f, i) => {
      table += `${i+1}. ${f.convertedUrl}\n`;
    });

    await api.sendMessage(table, threadID, messageID);

  } catch (err) {
    console.error("Lỗi hệ thống:", err);
    return api.sendMessage("⚠️ Đã xảy ra lỗi nghiêm trọng, báo admin!", threadID, messageID);
  }
};