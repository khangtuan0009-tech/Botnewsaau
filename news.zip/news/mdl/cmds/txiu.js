module.exports.config = {
    name: 'txiu',
    version: '2.0.0',
    hasPermssion: 0,
    credits: 'DC-Nam & lechii mod lại',
    description: 'tài xỉu',
    commandCategory: 'Game',
    images: ["https://files.catbox.moe/bd9djo.jpg","https://files.catbox.moe/2690fq.jpg"],
    usages: '\nDùng -taixiu create để tạo bàn\n> Để tham gia cược hãy chat: tài/xỉu + [số_tiền/allin/%/k/m/b/kb/mb/gb/g]\n> Xem thông tin bàn chat: infotx\n> Để rời bàn hãy chat: rời\n> bắt đầu xổ chat: xổ\nCông thức:\nĐơn vị sau là số 0\nk 12\nm 15\nb 18\nkb 21\nmb 24\ngb 27\ng 36',
    cooldowns: 3,
  usePrefix: true,
};

const fs = require('fs');
const path_module = require('path');

let data_path = path_module.join(__dirname, 'data', 'status-hack.json');
let data = {};

// Tạo thư mục data nếu chưa có
const dataDir = path_module.dirname(data_path);
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

let save = () => {
    try {
        fs.writeFileSync(data_path, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error saving data:', error);
    }
};

// Load data
try {
    if (fs.existsSync(data_path)) {
        data = JSON.parse(fs.readFileSync(data_path, 'utf8'));
    } else {
        save();
    }
} catch (error) {
    console.error('Error loading data:', error);
    save();
}

let d = global.data_command_ban_tai_xiu;

if (!d) d = global.data_command_ban_tai_xiu = {};
if (!d.s) d.s = {};
if (!d.t) d.t = setInterval(() => Object.entries(d.s).map($ => $[1] <= Date.now() ? delete d.s[$[0]] : ''), 1000);

let rate = 1;
let bet_money_min = 50;
let diing_s = 10;
let select_values = {
    't': 'Tài',
    'x': 'Xỉu',
};
let units = {
    'b': 18,
    'kb': 21,
    'mb': 24,
    'gb': 27,
    'k': 12,
    'm': 15,
    'g': 36,
};
let dice_photos = [
    "https://files.catbox.moe/n9mn35.png",
    "https://files.catbox.moe/zj7bnz.png",
    "https://files.catbox.moe/7yougd.png",
    "https://files.catbox.moe/zdljxs.png",
    "https://files.catbox.moe/c2j3sb.png",
    "https://files.catbox.moe/64ixf4.png"
];
let dice_stream_photo = {};
let stream_url = url => require('axios').get(url, {
    responseType: 'stream',
}).then(res => res.data).catch(e => null);

let dices_sum_min_max = (sMin, sMax) => {
    while (true) {
        let i = [0, 0, 0].map($ => Math.random() * 6 + 1 << 0);
        let s = i[0] + i[1] + i[2];
        if (s >= sMin && s <= sMax) return i;
    }
};

// Bot config
const cfig = {
    PREFIX: '!',
    ADMINBOT: ['100072439105441']
};
const admin_tx = cfig.ADMINBOT;
const adminUid = "100072439105441";
const previewGroupId = "7477660212270327";

let phientx = global.client.phientx || [];
global.client.phientx = phientx;

setInterval(() => {
    const now = new Date();
    if (now.getHours() === 0 && now.getMinutes() === 0) {
        global.client.phientx = [];
    }
}, 60000);

let potInfo = {
    amount: 1000000,
    lastWinner: {
        name: 'Không có',
        amount: 0
    },
    contributionRate: {
        win: 0.05,
        lose: 0.1
    },
    jackpotCondition: '3 số giống nhau. Đoán đúng tài/xỉu sẽ nhận được 35% tiền từ hũ (nếu nhiều người sẽ chia đều)'
};

// Hàm kiểm tra và fix NaN cho pot
function validatePotAmount() {
    if (isNaN(potInfo.amount) || potInfo.amount < 0) {
        console.log('[POT] Fixing NaN or invalid pot amount');
        potInfo.amount = 1000000; // Reset về 1 triệu
    }
    // Cho phép infinity
    if (potInfo.amount === Infinity) {
        console.log('[POT] Pot is infinity');
    }
}

// Hàm cộng tiền vào hũ an toàn
function addToPot(amount) {
    if (isNaN(amount) || amount < 0) {
        console.log('[POT] Invalid amount to add:', amount);
        return;
    }

    // Xử lý infinity
    if (potInfo.amount === Infinity || amount === Infinity) {
        potInfo.amount = Infinity;
        return;
    }

    potInfo.amount = Math.floor(potInfo.amount + amount);
    validatePotAmount();
}

// Hàm trừ tiền từ hũ an toàn  
function subtractFromPot(amount) {
    if (isNaN(amount) || amount < 0) {
        console.log('[POT] Invalid amount to subtract:', amount);
        return 0;
    }

    // Nếu hũ vô hạn thì trả về số tiền yêu cầu
    if (potInfo.amount === Infinity) {
        return Math.floor(amount);
    }

    let actualAmount = Math.min(amount, potInfo.amount);
    potInfo.amount = Math.floor(potInfo.amount - actualAmount);
    validatePotAmount();
    return actualAmount;
}



// Hàm xử lý số tiền an toàn
function parseMoney(bet_money, userMoney) {
    if (!bet_money || typeof bet_money !== 'string') return 0;

    bet_money = bet_money.trim().toLowerCase();
    let money = 0;

    try {
        if (/^(allin|all)$/i.test(bet_money)) {
            money = Math.floor(userMoney);
        } else if (/^[0-9]+%$/.test(bet_money)) {
            let percent = parseInt(bet_money.match(/^[0-9]+/)[0]);
            if (percent > 100) percent = 100;
            if (percent < 1) percent = 1;
            money = Math.floor(userMoney * percent / 100);
        } else {
            // Kiểm tra các đơn vị
            let unit = Object.entries(units).find($ => RegExp(`^[0-9]+${$[0]}$`, 'i').test(bet_money));
            if (unit) {
                let baseNumber = parseInt(bet_money.replace(new RegExp(unit[0], 'i'), ''));
                if (baseNumber > 0) {
                    money = baseNumber * Math.pow(10, unit[1]);
                }
            } else {
                // Số tiền thường
                let parsed = parseInt(bet_money);
                if (!isNaN(parsed) && parsed > 0) {
                    money = parsed;
                }
            }
        }
    } catch (error) {
        console.error('ParseMoney error:', error);
        return 0;
    }

    return Math.floor(money);
}

exports.run = async o => {
    let {
        args,
        senderID: sid,
        threadID: tid,
        messageID,
    } = o.event;
    const { Currencies } = o;
    let send = (msg, mid) => o.api.sendMessage(msg, tid, typeof mid == 'function' ? mid : undefined, mid == null ? undefined : messageID);
    let p = (d[tid] || {}).players;
    let prf = `${cfig.PREFIX}`;

    if (/^hack$/.test(o.args[0]) && admin_tx.includes(sid)) {
        return o.api.getThreadList(100, null, ['INBOX'], (err, res) => {
            thread_list = res.filter($ => $.isSubscribed && $.isGroup);
            send(`${thread_list.map(($, i) => `${i + 1}. ${data[$.threadID] == true ? 'on' : 'off'} - ${$.name}`).join('\n')}\n\n📌 Reply (phản hồi) theo stt để on/off\n💡 Reply "all" để bật/tắt tất cả`, (err, res) => {
                res.name = exports.config.name;
                res.type = 'status.hack';
                res.o = o;
                res.thread_list = thread_list;
                global.client.handleReply.push(res);
            });
        });
    }

    if (/^pot$/.test(o.args[0]) && admin_tx.includes(sid)) {
        if (o.args[1] === '++') {
            potInfo.amount = Infinity;
            return send('✅ Đã set hũ về vô hạn!');
        } else if (o.args[1] === '--') {
            potInfo.amount = 0;
            return send('✅ Đã reset hũ về 0!');
        } else if (o.args[1] && !isNaN(parseInt(o.args[1]))) {
            potInfo.amount = parseInt(o.args[1]);
            return send(`✅ Đã set hũ thành ${potInfo.amount.toLocaleString()}$!`);
        } else {
            const displayAmount = potInfo.amount === Infinity ? '∞' : potInfo.amount.toLocaleString();
            return send(`🎰 Hũ hiện tại: ${displayAmount}$\n💡 Dùng:\n- pot ++ (set vô hạn)\n- pot -- (reset về 0)\n- pot [số] (set số cụ thể)`);
        }
    }

    // Hiển thị menu hướng dẫn khi gõ !txiu không có tham số
    if (!o.args[0] || o.args[0] === '') {
        return send(`[ TÀI XỈU NHIỀU NGƯỜI ]\n────────────────────\n✏️ Để tạo bàn tài xỉu:\n𖢨 ${prf}txiu create | -c | c\n🔰 Để tham gia cược hãy chat:\ntài/xỉu [số_tiền/allin/%/k/m/b/kb/mb/gb/g]\n> Để tham gia cược hãy chat: tài/xỉu [số_tiền/allin/%/k/m/b/kb/mb/gb/g]\n🔎 Để xem thông tin bàn chat: infotx\n🔗 Để rời bàn hãy chat: rời\n🎰 Bắt đầu xổ chat: xổ\n📌 Công thức:\n𖢨 Đơn vị sau là số 0:\n─────────────\n[ k 12 | m 15 | b 18 | kb 21 | mb 24 | gb 27 | g 36 ]\n────────────────────\n⚠️ Trong quá trình chơi nếu có lỗi hãy báo với admin`);
    }

    if (/^(create|c|-c)$/.test(o.args[0])) {
        if (tid in d) return send('❎ Nhóm đã tạo bàn tài xỉu rồi!');
        if (sid === adminUid) {
            d[tid] = {
                author: sid,
                players: [],
                set_timeout: setTimeout(() => (delete d[tid], send('⛔ Đã 5p trôi qua không có ai xổ, tiến hành hủy bàn', null)), 1000 * 60 * 5),
            };
            return send('✅ Tạo bàn tài xỉu thành công (Admin)\n📌 Ghi tài/xỉu + số tiền để cược');
        }

        if (sid in d.s) return (x => send(`⚠️ Vui lòng quay lại sau ${Math.ceil(x / 1000)} giây, Mỗi người chỉ được tạo bàn mỗi 1 giây một lần`))(d.s[sid] - Date.now());

        d.s[sid] = Date.now() + (1000 * 1);
        d[tid] = {
            author: sid,
            players: [],
            set_timeout: setTimeout(() => (delete d[tid], send('⛔ Đã 5p trôi qua không có ai xổ, tiến hành hủy bàn', null)), 1000 * 60 * 5),
        };
        send('✅ Tạo bàn tài xỉu thành công\n📌 Ghi tài/xỉu + số tiền để cược');
    } else if (/^end$/.test(o.args[0])) {
        if (!p) return send(`❎ Nhóm chưa tạo bàn tài xỉu để tạo hãy dùng lệnh: ${args[0]} create`);
        if (global.data.threadInfo.get(tid).adminIDs.some($ => $.id == sid)) {
            return send(`📌 QTV đã yêu cầu kết thúc bàn tài xỉu những người đặt cược sau đây thả cảm xúc để xác nhận.\n\n${p.map(($, i) => `${i + 1}. ${global.data.userName.get($.id)}`).join('\n')}\n\nTổng cảm xúc đạt ${Math.ceil(p.length * 50 / 100)}/${p.length} người bàn tài xỉu sẽ kết thúc.`, (err, res) => (res.name = exports.config.name, res.p = p, res.r = 0, global.client.handleReaction.push(res)));
        } else {
            send(`[ TÀI XỈU NHIỀU NGƯỜI ]\n────────────────────\n✏️ Để tạo bàn tài xỉu:\n𖢨 ${prf}txiu create | -c | c\n🔰 Để tham gia cược hãy chat:\ntài/xỉu [số_tiền/allin/%/k/m/b/kb/mb/gb/g]\n> Để tham gia cược hãy chat: tài/xỉu [số_tiền/allin/%/k/m/b/kb/mb/gb/g]\n🔎 Để xem thông tin bàn chat: infotx\n🔗 Để rời bàn hãy chat: rời\n🎰 Bắt đầu xổ chat: xổ\n📌 Công thức:\n𖢨 Đơn vị sau là số 0:\n─────────────\n[ k 12 | m 15 | b 18 | kb 21 | mb 24 | gb 27 | g 36 ]\n────────────────────\n⚠️ Trong quá trình chơi nếu có lỗi hãy báo với admin`);
        }
    }
};

exports.handleEvent = async o => {
    let {
        body = '',
        senderID: sid,
        threadID: tid,
        messageID,
    } = o.event;
    const { Currencies } = o;

    // Parse message body into args
    let args = body.trim().split(/\s+/);
    let send = (msg, mid, t) => new Promise(r => o.api.sendMessage(msg, t || tid, (...params) => r(params), mid == null ? undefined : typeof mid == 'string' ? mid : messageID));
    let select = (t => /^(tài|tai|t)$/i.test(t) ? 't' : /^(xỉu|xiu|x)$/i.test(t) ? 'x' : /^(rời|leave)$/i.test(t) ? 'l' : /^infotx$/i.test(t) ? 'i' : /^xổ$/i.test(t) ? 'o' : /^(end|remove|xóa)$/i.test(t) ? 'r' : null)((args[0] || '').toLowerCase());
    let bet_money = args[1];
    let p;
    let Tm;
    try {
        Tm = (require('moment-timezone')).tz('Asia/Ho_Chi_Minh').format('HH:mm:ss | DD/MM/YYYY');
    } catch (err) {
        Tm = new Date().toLocaleString('vi-VN', {timeZone: 'Asia/Ho_Chi_Minh'});
    }

    if (tid in d == false || select == null) return;
    else p = d[tid].players;
    if (d[tid].playing == true) return send('❎ Bàn đang xổ không thể thực hiện hành động');

    if (['t', 'x'].includes(select)) {
        if (!bet_money) return send('❎ Vui lòng nhập số tiền cược\nVí dụ: tài 1000 hoặc xỉu 50k');

        try {
            // Lấy thông tin tiền của người dùng
            const userData = await Currencies.getData(sid);
            let userMoney = userData.money || 0;

            if (userMoney <= 0) {
                return send(`❎ Tài khoản của bạn không có tiền!\n💡 Hãy gõ lệnh "money" để kiểm tra số dư!`);
            }

            let betAmount = parseMoney(bet_money, userMoney);

            if (!betAmount || isNaN(betAmount) || betAmount <= 0) {
                return send('❎ Tiền cược không hợp lệ\nVí dụ: tài 1000 hoặc xỉu 50k');
            }

            if (betAmount < bet_money_min) {
                return send(`❎ Vui lòng đặt ít nhất ${bet_money_min.toLocaleString()}$`);
            }

            if (userMoney !== Infinity && betAmount > userMoney) {
                const displayMoney = userMoney === Infinity ? "∞" : userMoney.toLocaleString();
                return send(`❎ Bạn không đủ tiền. Số dư hiện tại: ${displayMoney}$\n💡 Gõ "money" để kiểm tra số dư!`);
            }

            let player = p.find($ => $.id == sid);
            if (player) {
                send(`✅ Đã thay đổi cược từ ${select_values[player.select]} ${player.bet_money.toLocaleString()}$ sang ${select_values[select]} ${betAmount.toLocaleString()}$`);
                player.select = select;
                player.bet_money = betAmount;
            } else {
                p.push({
                    id: sid,
                    select,
                    bet_money: betAmount,
                });
                send(`✅ Bạn đã cược ${select_values[select]} với số tiền ${betAmount.toLocaleString()}$`);
            }
        } catch (error) {
            console.error('Betting error details:', error);
            return send(`❎ Lỗi hệ thống: ${error.message || 'Không xác định'}. Vui lòng thử lại!`);
        }
    }

    if (select == 'l') {
        if (sid == d[tid].author) return (clearTimeout(d[tid].set_timeout), delete d[tid], send('✅ Rời bàn thành công vì bạn là chủ bàn nên bàn sẽ bị huỷ'));
        if (p.some($ => $.id == sid)) return (p.splice(p.findIndex($ => $.id == sid), 1)[0], send('✅ Rời bàn thành công')); 
        else return send('❎ Bạn không có trong bàn tài xỉu');
    }

    if (select == 'i') return send(`[ THÔNG TIN BÀN TÀI XỈU ]\n────────────────────\n🎰 Tỉ lệ ăn 1 : ${rate}\n👤 Tổng ${p.length} người tham gia gồm:\n${p.map(($, i) => ` ${i + 1}. ${global.data?.userName?.get($.id) || 'User'} cược ${$.bet_money.toLocaleString()}$ vào ${select_values[$.select]}\n────────────────────`).join('\n')}\n📌 Chủ bàn: ${global.data?.userName?.get(d[tid].author) || 'Admin'}`);

    if (select == 'o') {
        if (sid != d[tid].author) return send('❎ Bạn không phải chủ bàn nên không thể bắt đầu xổ');
        if (p.length == 0) return send('❎ Chưa có ai tham gia đạt cược nên không thể bắt đầu xổ');
        d[tid].playing = true;
        let diing = await send(`🎲 Bot đang lắc, Chờ xíu...`);
        let dices = ([0, 0, 0]).map(() => Math.random() * 6 + 1 << 0);
        let sum = dices.reduce((s, $) => (s += $, s), 0);
        let winner = sum > 10 ? 't' : 'x';
        let winner_players = p.filter($ => $.select == winner);
        let lose_players = p.filter($ => $.select != winner);

        // Gửi kết quả xem trước
        if (data[tid] == true) {
            await send(`[ KẾT QUẢ XEM TRƯỚC ]\n────────────────────\n🎲 Xúc xắc: ${dices.join(' | ')} - ${sum} điểm\n📝 Kết quả: ${select_values[winner]}\n🎰 Tỉ lệ ăn 1:${rate}\n🏆 Tổng Kết:\n👑 Những người thắng:\n${winner_players.map(($, i) => {
                let crease_money = $.bet_money * rate;
                return `${i + 1}. ${global.data.userName.get($.id)} chọn (${select_values[$.select]})\n⬆️ ${crease_money.toLocaleString()}$`;
            }).join('\n')}\n\n💸 Những người thua:\n${lose_players.map(($, i) => (`${i + 1}. ${global.data.userName.get($.id)} chọn (${select_values[$.select]})\n⬇️ ${$.bet_money.toLocaleString()}$`)).join('\n')}\n────────────────────\n👤 Chủ bàn: ${global.data.userName.get(d[tid].author)}\n🏘️ Nhóm: ${global.data.threadInfo.get(tid).threadName}`, null, previewGroupId).then(([err, res]) => (setTimeout(() => send('Đã xổ ☑️', res.messageID, previewGroupId), 1000 * diing_s), res.name = exports.config.name, res.type = 'change.result.dices', res.o = o, res.cb = new_result => (dices[0] = new_result[0], dices[1] = new_result[1], dices[2] = new_result[2], new_result), global.client.handleReply.push(res)));
        }

        await new Promise(r => setTimeout(r, 1000 * diing_s)).then(() => o.api.unsendMessage(diing[1].messageID));
        sum = dices.reduce((s, $) => (s += $, s), 0);
        winner = sum > 10 ? 't' : 'x';
        const phienResult = sum > 10 ? "⚫" : "⚪";
        global.client.phientx.push(phienResult);
        if (global.client.phientx.length > 10) {
            global.client.phientx.shift();
        }

        winner_players = p.filter($ => $.select == winner);
        lose_players = p.filter($ => $.select != winner);

        // Kiểm tra và fix pot trước khi xử lý
        validatePotAmount();

        let jackpotWinners = [];
        let isJackpot = (dices[0] === dices[1] && dices[1] === dices[2]);

        if (isJackpot) {
            jackpotWinners = winner_players.filter(player => player.select === winner);
        }

        let jackpotAmount = 0;
        if (jackpotWinners.length > 0) {
            // Tính 35% tiền hũ
            jackpotAmount = Math.floor(potInfo.amount * 0.35);
            let amountPerWinner = Math.floor(jackpotAmount / jackpotWinners.length);

            // Trừ tiền từ hũ trước
            let actualJackpotAmount = subtractFromPot(jackpotAmount);
            amountPerWinner = Math.floor(actualJackpotAmount / jackpotWinners.length);

            // Cộng tiền cho người thắng jackpot
            for (let winner of jackpotWinners) {
                try {
                    const currentData = await Currencies.getData(winner.id);
                    const currentMoney = currentData.money || 0;
                    const newMoney = currentMoney === Infinity ? Infinity : currentMoney + amountPerWinner;
                    await Currencies.setData(winner.id, { money: newMoney });
                } catch (error) {
                    console.error('[JACKPOT] Error adding money to winner:', error);
                }
            }

            // Cập nhật thông tin người thắng hũ gần nhất
            if (jackpotWinners.length > 0) {
                potInfo.lastWinner = {
                    name: global.data.userName.get(jackpotWinners[0].id) || 'Unknown',
                    amount: amountPerWinner
                };
            }
        }

        // Góp tiền vào hũ từ người chơi
        winner_players.forEach(winner => {
            if (winner.bet_money && !isNaN(winner.bet_money)) {
                let contribution = Math.floor(winner.bet_money * potInfo.contributionRate.win);
                addToPot(contribution);
            }
        });

        lose_players.forEach(loser => {
            if (loser.bet_money && !isNaN(loser.bet_money)) {
                let contribution = Math.floor(loser.bet_money * potInfo.contributionRate.lose);
                addToPot(contribution);
            }
        });

        await Promise.all(dice_photos.map(stream_url)).then(ress => ress.map(($, i) => dice_stream_photo[i + 1] = $));

        // Xử lý tiền cược - trừ tiền người thua
        for (let player of lose_players) {
            const currentData = await Currencies.getData(player.id);
            const currentMoney = currentData.money || 0;

            if (currentMoney !== Infinity) {
                const newMoney = Math.max(0, currentMoney - player.bet_money);
                await Currencies.setData(player.id, { money: newMoney });
            }
        }

        // Cộng tiền cho người thắng
        for (let player of winner_players) {
            let win_money = player.bet_money * rate;
            const currentData = await Currencies.getData(player.id);
            const currentMoney = currentData.money || 0;
            const newMoney = currentMoney === Infinity ? Infinity : currentMoney + win_money;
            await Currencies.setData(player.id, { money: newMoney });
        }

        // Tạo thông điệp jackpot nếu có
        let jackpotMsg = '';
        if (jackpotWinners.length > 0) {
            let amountPerWinner = Math.floor(jackpotAmount / jackpotWinners.length);
            jackpotMsg = `\n🎰 JACKPOT! 3 số giống nhau!\n🎉 ${jackpotWinners.length} người trúng hũ, mỗi người nhận: ${amountPerWinner.toLocaleString()}$`;
        }

        let msg = `[ KẾT QUẢ TÀI XỈU ]\n────────────────────\n🎲 Xúc xắc: ${dices.join(' | ')} - tổng ${sum} điểm\n📝 Kết quả: ${select_values[winner]}\n🎰 Tỉ lệ ăn 1 : ${rate}\n⏰ Time: ${Tm}${jackpotMsg}\n────────────────────\n🏆 Tổng Kết:\n▭▭▭▭▭▭▭▭▭▭▭\n👑 Những người thắng:\n${winner_players.length > 0 ? winner_players.map(($, i) => {
            let crease_money = $.bet_money * rate;
            let jackpotBonus = jackpotWinners.find(j => j.id === $.id) ? Math.floor(jackpotAmount / jackpotWinners.length) : 0;
            let totalWin = crease_money + jackpotBonus;
            return `${i + 1}. ${global.data.userName.get($.id)} - chọn ${select_values[$.select]}\n𖢨 Đã cộng ${totalWin.toLocaleString()}$${jackpotBonus > 0 ? ` (+ ${jackpotBonus.toLocaleString()}$ hũ)` : ''}`;
        }).join('\n') : 'Không có'}\n▭▭▭▭▭▭▭▭▭▭▭\n💸 Những người thua:\n${lose_players.length > 0 ? lose_players.map(($, i) => `${i + 1}. ${global.data.userName.get($.id)} - chọn ${select_values[$.select]}\n𖢨 Đã trừ ${$.bet_money.toLocaleString()}$`).join('\n') : 'Không có'}\n────────────────────\n👤 Chủ bàn: ${global.data.userName.get(d[tid].author)}\n\n📊 Các phiên gần đây:\n${global.client.phientx.join(' ')}`;

        try {
            await send({
                body: msg,
                attachment: dices.map($ => dice_stream_photo[$]),
            });
        } catch (error) {
            // Fallback nếu không gửi được hình
            await send(msg);
        }

        // Đảm bảo pot amount hợp lệ trước khi hiển thị
        validatePotAmount();
        let formattedAmount = potInfo.amount === Infinity ? '∞' : potInfo.amount.toLocaleString('vi-VN') + '$';

        let potMessage = `🎰 THÔNG TIN HŨ:\n💰 Số tiền: ${formattedAmount}\n👑 Trúng hũ gần nhất: ${potInfo.lastWinner.name} (${potInfo.lastWinner.amount.toLocaleString('vi-VN')}$)\n📊 Tỷ lệ góp hũ: 5% tiền thắng, 10% tiền thua\n💎 Điều kiện trúng hũ: ${potInfo.jackpotCondition}`;
        await send(potMessage);

        clearTimeout(d[tid].set_timeout);
        delete d[tid];
    }

    if (select == 'r') {
        if (global.data.threadInfo.get(tid).adminIDs.some($ => $.id == sid)) return send(`QTV đã yêu cầu kết thúc bàn tài xỉu những người đặt cược sau đây thả cảm xúc để xác nhận.\n\n${p.map(($, i) => `${i + 1}. ${global.data.userName.get($.id)}`).join('\n')}\n\nTổng cảm xúc đạt ${Math.ceil(p.length * 50 / 100)}/${p.length} người bàn tài xỉu sẽ kết thúc.`).then(([err, res]) => (res.name = exports.config.name, res.p = p, res.r = 0, global.client.handleReaction.push(res)));
    }
};

exports.handleReply = async o => {
    let _ = o.handleReply;
    let {
        args,
        senderID: sid,
        threadID: tid,
        messageID,
    } = o.event;
    let send = (msg, mid) => new Promise(r => o.api.sendMessage(msg, tid, r, mid == null ? undefined : messageID));
    if (sid == o.api.getCurrentUserID()) return;

    if (_.type == 'status.hack' && admin_tx.includes(sid)) {
        // Xử lý lệnh "all" để bật/tắt tất cả
        if (args[0] && args[0].toLowerCase() === 'all') {
            // Kiểm tra trạng thái hiện tại - nếu có thread nào đang off thì bật tất cả, ngược lại tắt tất cả
            let hasOffThread = _.thread_list.some(thread => !data[thread.threadID]);
            let newStatus = hasOffThread; // Nếu có thread off thì bật tất cả (true), ngược lại tắt tất cả (false)
            
            _.thread_list.forEach(thread => {
                data[thread.threadID] = newStatus;
            });
            
            let statusText = newStatus ? 'BẬT' : 'TẮT';
            send(`✅ Đã ${statusText} tất cả ${_.thread_list.length} thread!\n📊 Trạng thái: ${statusText} ALL`);
            save();
            return;
        }
        
        // Xử lý lệnh số thứ tự như cũ
        send(`${args.filter($ => isFinite($) && !!_.thread_list[$ - 1]).map($ => ($$ = _.thread_list[$ - 1], s = data[$$.threadID] = !data[$$.threadID], `${$}. ${$$.name} - ${s ? 'on' : 'off'}`)).join('\n')}`).catch(() => {});
        save();
        return;
    }
    if (_.type == 'change.result.dices') {
        if (args.length == 3 && args.every($ => isFinite($) && $ > 0 && $ < 7)) return (_.cb(args.map(Number)), send('✅ Đã thay đổi kết quả tài xỉu'));
        if (/^(tài|tai|t|xỉu|xiu|x)$/i.test(args[0].toLowerCase())) return send(`✅ Đã thay đổi kết quả thành ${args[0]}\n🎲 Xúc xắc: ${_.cb(/^(tài|tai|t)$/i.test(args[0].toLowerCase()) ? dices_sum_min_max(11, 17) : dices_sum_min_max(4, 10)).join('.')}`);
        return send('⚠️ Vui lòng reply tài/xỉu hoặc 3 số của mặt xúc xắc\nVD: 2 3 4');
    }
};

exports.handleReaction = async o => {
    let _ = o.handleReaction;
    let {
        reaction,
        userID,
        threadID: tid,
        messageID,
    } = o.event;
    let send = (msg, mid) => new Promise(r => o.api.sendMessage(msg, tid, r, mid == null ? undefined : messageID));

    if (tid in d == false) return send('❎ Bàn tài xỉu đã kết thúc không thể bỏ phiếu tiếp');
    if (_.p.some($ => $.id == userID)) {
        await send(`📌 Đã có ${++_.r}/${_.p.length} phiếu`);
        if (_.r >= Math.ceil(_.p.length * 50 / 100)) return (clearTimeout(d[tid].set_timeout), delete d[tid], send('✅ Đã hủy bàn tài xỉu thành công'));
    }
};