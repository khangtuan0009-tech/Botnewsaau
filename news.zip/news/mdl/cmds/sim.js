const axios = require('axios');
const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, 'data', 'bot.json');
let data = {};
const save = () => fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

if (!fs.existsSync(path.dirname(dataPath))) fs.mkdirSync(path.dirname(dataPath));
if (!fs.existsSync(dataPath)) save();

try {
  data = JSON.parse(fs.readFileSync(dataPath));
} catch {
  data = {};
  save();
}

module.exports = {
  config: {
    name: "sim",
    version: "2.3.0",
    hasPermssion: 1,
    credits: "L.V. Bằng & nvh",
    description: "Sim AI riêng có thể dạy kèm ảnh/video",
    commandCategory: "Tiện ích",
    usages: "sim | sim teach <hỏi>|<trả lời>",
    cooldowns: 1,
  usePrefix: true,
  },

  run: async ({ event, api, args }) => {
    const t = event.threadID;

    // === DẠY SIM ===
    if (args[0] === "teach") {
      const input = args.slice(1).join(" ");
      if (!input.includes("|"))
        return api.sendMessage("⚠️ Cú pháp: sim teach <câu hỏi>|<câu trả lời>", t, event.messageID);

      const [ask, ansRaw] = input.split("|").map(s => s.trim());
      if (!ask || !ansRaw)
        return api.sendMessage("⚠️ Vui lòng nhập đủ cả hỏi và trả lời!", t, event.messageID);

      // Tách phần media (nếu có link ảnh/video)
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      const urls = ansRaw.match(urlRegex);
      const ans = ansRaw.replace(urlRegex, "").trim();
      const media = urls && urls.length > 0 ? urls[0] : null;

      try {
        const res = await axios.get("https://apinvh.zzux.com/api/teach", {
          params: { ask, ans: ans + (media ? `|${media}` : "") },
          timeout: 10000,
        });

        if (res.data?.msg) {
          api.sendMessage(`✅ ${res.data.msg}\n📚 ${ask} → ${ans}${media ? "\n🎬 Có kèm media" : ""}`, t, event.messageID);
        } else {
          api.sendMessage("❌ Không thể dạy sim, API không trả về phản hồi hợp lệ.", t, event.messageID);
        }
      } catch (err) {
        console.error(err);
        api.sendMessage("⚠️ Lỗi khi kết nối tới API teach sim.", t, event.messageID);
      }
      return;
    }

    // === BẬT / TẮT SIM ===
    if (args[0] === "on") data[t] = true;
    else if (args[0] === "off") data[t] = false;
    else data[t] = data[t] === undefined ? true : !data[t];

    save();
    api.sendMessage(`✅ Sim đã ${data[t] ? "bật" : "tắt"} trong nhóm này.`, t);
  },

  // === GỌI API SIM ===
  sim: async function (text) {
    try {
      const res = await axios.get("https://apinvh.zzux.com/api/ask", {
        params: { query: text },
        timeout: 10000,
      });

      let answer = res.data?.answer || "Tớ chưa hiểu ý bạn 🥲";
      let media = null;

      // Nếu phần trả lời có link ảnh/video
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      const urls = answer.match(urlRegex);
      if (urls && urls.length > 0) {
        media = urls[0];
        answer = answer.replace(urlRegex, "").trim(); // xóa link khỏi text
      }

      return { answer, media };

    } catch (err) {
      console.error("Sim API Error:", err.message);
      return { answer: "Hiện tại sim hơi mệt, nói lại sau nha 🥲", media: null };
    }
  },

  // === XỬ LÝ EVENT ===
  handleEvent: async function ({ event, api }) {
    if (event.senderID == api.getCurrentUserID()) return;
    const t = event.threadID;

    if (data[t] === undefined) {
      data[t] = false;
      save();
    }
    if (!data[t]) return;

    const body = event.body?.toLowerCase() || "";
    if (body.includes("thư") && !event.messageReply) {
      const { answer, media } = await this.sim(event.body);
      await sendSim(api, event, answer, media, this.config.name);
    }
  },

  // === XỬ LÝ REPLY ===
  handleReply: async function ({ event, api }) {
    if (event.senderID == api.getCurrentUserID()) return;
    const t = event.threadID;
    if (data[t] === undefined) {
      data[t] = false;
      save();
    }
    if (!data[t]) return;

    if (event.messageReply) {
      const { answer, media } = await this.sim(event.body);
      await sendSim(api, event, answer, media, this.config.name);
    }
  },
};

// === GỬI TIN NHẮN SIM CÓ MEDIA ===
async function sendSim(api, event, answer, media, name) {
  try {
    const msg = { body: answer };

    // Nếu có media (ảnh hoặc video)
    if (media && media.startsWith("http")) {
      const ext = path.extname(media).split("?")[0];
      const fileName = `sim_media_${Date.now()}${ext}`;
      const filePath = path.join(__dirname, "cache", fileName);

      const res = await axios.get(media, { responseType: "arraybuffer" });
      fs.writeFileSync(filePath, Buffer.from(res.data));
      msg.attachment = fs.createReadStream(filePath);
    }

    api.sendMessage(
      msg,
      event.threadID,
      (err, info) => {
        if (err) return console.error(err);
        global.client.handleReply.push({
          name,
          messageID: info.messageID,
          author: event.senderID,
        });
      },
      event.messageID
    );
  } catch (err) {
    console.error("Sim Send Error:", err);
  }
}