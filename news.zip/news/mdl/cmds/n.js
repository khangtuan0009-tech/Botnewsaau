const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  config: {
    name: 'n',
    version: '1.2.0',
    hasPermssion: 3,
    usePrefix: true,
    credits: 'nvh',
    description: 'Ghi nội dung trực tiếp lên API note và trả raw URL',
    commandCategory: 'Admin',
    usages: 'n <nội dung>',
    cooldowns: 0,
  },

  run: async function({ api, event, args }) {
    const send = msg => new Promise(r => api.sendMessage(msg, event.threadID, (err, res) => r(res), event.messageID));

    const content = args.join(' ').trim();
    if (!content) return send(`❌ Vui lòng nhập nội dung!\n\n📝 Cách dùng:\n• note Hello world\n• note nvh`);

    try {
      const uuid = uuidv4();
      const url_base = `https://nvhzxz.onrender.com/note/${uuid}`;

      // Upload content với text/plain
      await axios.put(url_base, content, {
        headers: { 'content-type': 'text/plain; charset=utf-8' }
      });

      // Tạo raw URL
      const rawUrl = new URL(url_base);
      rawUrl.searchParams.append('raw', 'true');

      return send(`✅ Nội dung đã được ghi thành công!\n\n📝 Raw URL: ${rawUrl.href}`);
    } catch (e) {
      console.error('Note module error:', e);
      return send(`❌ Lỗi khi ghi nội dung: ${e.message}`);
    }
  }
};