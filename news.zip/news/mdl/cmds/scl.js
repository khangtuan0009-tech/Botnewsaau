const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs-extra");
const moment = require("moment-timezone");
const path = require("path");

// --- CƠ CHẾ TỰ ĐỘNG LẤY CLIENT_ID (Vẫn cần cho việc tìm kiếm và lấy info) ---
const CLIENT_ID_CACHE_PATH = __dirname + "/cache/scl_client_id.json";
let CLIENT_ID = null;

async function getClientID() {
    if (CLIENT_ID) return CLIENT_ID;
    try {
        if (fs.existsSync(CLIENT_ID_CACHE_PATH)) {
            const cache = JSON.parse(fs.readFileSync(CLIENT_ID_CACHE_PATH));
            if (cache.clientId && (Date.now() - cache.timestamp < 6 * 60 * 60 * 1000)) {
                CLIENT_ID = cache.clientId;
                return CLIENT_ID;
            }
        }
    } catch (e) { /* Bỏ qua lỗi cache */ }

    try {
        console.log("SCL: Đang lấy Client ID mới từ SoundCloud...");
        const { data: mainPage } = await axios.get("https://soundcloud.com", { headers: { "User-Agent": "Mozilla/5.0" } });
        const scriptUrl = mainPage.match(/<script.*?src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[a-z0-9-]+\.js)".*?><\/script>/g).pop().match(/src="(.*?)"/)[1];
        const { data: scriptContent } = await axios.get(scriptUrl);
        const newClientId = scriptContent.match(/client_id:"([a-zA-Z0-9]{32})"/)[1];
        if (!newClientId) throw new Error("Không tìm thấy Client ID trong script.");
        CLIENT_ID = newClientId;
        fs.writeFileSync(CLIENT_ID_CACHE_PATH, JSON.stringify({ clientId: CLIENT_ID, timestamp: Date.now() }));
        console.log("SCL: Đã lấy và lưu Client ID mới:", CLIENT_ID);
        return CLIENT_ID;
    } catch (error) {
        console.error("SCL: Không thể lấy Client ID mới, sử dụng ID dự phòng.", error.message);
        return "aFFdsz1yEw4N1aVWe4C74WjsYJ82KAnY"; // ID dự phòng
    }
}

// --- CÁC HÀM GỐC (ĐÃ CẬP NHẬT ĐỂ DÙNG CLIENT_ID MỚI) ---

async function getAdvancedSoundCloudInfo(trackUrl) {
  const clientId = await getClientID();
  try {
    const resolveUrl = `https://api-v2.soundcloud.com/resolve?url=${encodeURIComponent(trackUrl)}&client_id=${clientId}`;
    const { data: track } = await axios.get(resolveUrl);
    if (track && track.kind === "track") {
      return {
        id: track.id,
        title: track.title,
        artist: track.user?.username || track.user?.full_name || "Unknown",
        duration: track.duration || 0,
        plays: track.playback_count || 0,
        likes: track.likes_count || 0,
        reposts: track.reposts_count || 0,
        comments: track.comment_count || 0,
        genre: track.genre || "Unknown",
        tags: track.tag_list ? track.tag_list.split(" ").filter(Boolean) : [],
        created_at: track.created_at,
        description: track.description || "",
        artwork: track.artwork_url ? track.artwork_url.replace("-large", "-t500x500") : null,
        permalink: track.permalink_url,
        downloadable: track.downloadable,
        streamable: track.streamable
      };
    }
  } catch (error) {
    console.log("SCL: getAdvancedSoundCloudInfo thất bại.", error.message);
  }
  return null;
}

async function searchSoundCloudAdvanced(query, limit = 10) {
  const clientId = await getClientID();
  try {
    const apiUrl = `https://api-v2.soundcloud.com/search/tracks?q=${encodeURIComponent(query)}&client_id=${clientId}&limit=${limit}&offset=0`;
    const { data } = await axios.get(apiUrl, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (data && data.collection) {
      return data.collection.map(track => ({
        id: track.id,
        title: track.title,
        url: track.permalink_url,
        thumb: track.artwork_url ? track.artwork_url.replace("-large", "-t500x500") : null,
        artist: track.user?.username || track.user?.full_name || "Unknown Artist",
        views: track.playback_count?.toString() || "0",
        likes: track.likes_count || 0,
        reposts: track.reposts_count || 0,
        comments: track.comment_count || 0,
        release: track.created_at ? new Date(track.created_at).toLocaleDateString("vi-VN") : "Unknown",
        timestamp: track.duration || "0",
        genre: track.genre || "Unknown",
        tags: track.tag_list ? track.tag_list.split(" ").slice(0, 3) : [],
        description: track.description || "",
      }));
    }
    return await searchSoundCloudFallback(query, limit);
  } catch (error) {
    console.log("SCL: Lỗi tìm kiếm API, chuyển sang fallback.", error.message);
    return await searchSoundCloudFallback(query, limit);
  }
}

async function searchSoundCloudFallback(query, limit = 10) {
  try {
    const { data } = await axios.get(`https://m.soundcloud.com/search?q=${encodeURIComponent(query)}`, { headers: { "User-Agent": "Mozilla/5.0" } });
    const $ = cheerio.load(data);
    const results = [];
    $("div > ul > li > div").each(function (index, element) {
      if (index < limit) {
        const title = $(element).find("a").attr("aria-label")?.trim() || "";
        const url = "https://soundcloud.com" + ($(element).find("a").attr("href") || "").trim();
        if (title && url && url !== "https://soundcloud.com") {
          results.push({
            title, url,
            thumb: $(element).find("a > div > div > div > picture > img").attr("src")?.trim() || "",
            artist: $(element).find("a > div > div > div").eq(1).text()?.trim() || "",
            views: $(element).find("a > div > div > div > div > div").eq(0).text()?.trim() || "0",
            timestamp: "0", release: $(element).find("a > div > div > div > div > div").eq(2).text()?.trim() || "",
            likes: 0, reposts: 0, comments: 0, genre: "Unknown", tags: [], description: ""
          });
        }
      }
    });
    return results;
  } catch (error) {
    throw new Error(`Lỗi tìm kiếm fallback: ${error.message}`);
  }
}

async function downloadImage(url) {
  try {
    if (!url) return null;
    const { data } = await axios.get(url, { responseType: "stream", timeout: 10000 });
    return data;
  } catch (error) { return null; }
}

function formatDuration(ms) {
    if (!ms || isNaN(ms)) return "0:00";
    const totalSeconds = Math.floor(parseInt(ms) / 1000);
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
}

function formatNumber(num) {
  if (!num || num === "0") return "0";
  const number = parseInt(num.toString().replace(/[^\d]/g, ""));
  if (isNaN(number)) return num;
  if (number >= 1000000) return `${(number / 1000000).toFixed(1)}M`;
  if (number >= 1000) return `${(number / 1000).toFixed(1)}K`;
  return number.toLocaleString();
}

function parseSearchQuery(query) {
  const filters = { genre: null, sort: "relevance", artist: null, limit: 8, general: query };
  const patterns = {
    genre: /-genre\s+([^-]+)/i,
    sort: /-sort\s+(relevance|date|plays|likes)/i,
    artist: /-artist\s+([^-]+)/i,
    limit: /-limit\s+(\d+)/i
  };
  Object.keys(patterns).forEach(key => {
    const match = query.match(patterns[key]);
    if (match) {
      filters[key] = key === "limit" ? Math.min(parseInt(match[1]), 20) : match[1].trim();
      query = query.replace(match[0], "").trim();
    }
  });
  filters.general = query || filters.artist || "";
  return filters;
}

// --- HÀM TẢI NHẠC BẰNG API NIIO-TEAM ---
async function downloadWithnvhAPI(soundcloudUrl) {
  try {
    const apiUrl = `https://apinvh.zzux.com/api/mediadl?url=${encodeURIComponent(soundcloudUrl)}`;
    const { data } = await axios.get(apiUrl, { timeout: 30000 });
    
    if (data.error) {
      throw new Error(data.message || "API trả về lỗi");
    }
    
    if (!data.medias || data.medias.length === 0) {
      throw new Error("Không tìm thấy link tải");
    }
    
    const audioMedia = data.medias.find(m => m.type === "audio") || data.medias[0];
    if (!audioMedia.url) {
      throw new Error("Không tìm thấy URL audio");
    }
    
    return {
      title: data.title || "Unknown",
      artist: data.author || "Unknown",
      thumbnail: data.thumbnail,
      duration: data.duration || "0:00",
      audioUrl: audioMedia.url
    };
  } catch (error) {
    throw new Error(`Lỗi API nvh-media: ${error.message}`);
  }
}

// Hàm mới để tải file audio và lưu vào bộ nhớ tạm
async function downloadAudioFileToTemp(audioUrl, filename) {
  const tempFilePath = path.join(__dirname, "cache", filename);
  try {
    const response = await axios({
      method: "get",
      url: audioUrl,
      responseType: "stream",
      timeout: 60000,
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    const writer = fs.createWriteStream(tempFilePath);
    response.data.pipe(writer);

    return new Promise((resolve, reject) => {
      writer.on("finish", () => resolve(tempFilePath));
      writer.on("error", reject);
    });
  } catch (error) {
    throw new Error(`Lỗi tải và lưu file audio: ${error.message}`);
  }
}

// --- HÀM TẢI VÀ GỬI NHẠC (ĐÃ SỬA ĐỂ TÁCH THÀNH 2 TIN NHẮN) ---
async function downloadAndSendTrack(api, threadID, track, originalMessageID) {
    const loadingMsgId = (await api.sendMessage("⏳ Đang tải nhạc...", threadID)).messageID;
    let tempAudioFilePath = null;
    
    try {
        // Bước 1: Lấy thông tin từ API niio-team
        const downloadInfo = await downloadWithnvhAPI(track.url);
        
        // Bước 2: Tải file audio và lưu vào file tạm thời
        tempAudioFilePath = await downloadAudioFileToTemp(downloadInfo.audioUrl, `${downloadInfo.title.replace(/[^a-zA-Z0-9]/g, ".")}.mp3`);
        
        // Bước 3: Tải ảnh thumbnail (nếu có)
        let thumbnailStream = null;
        if (downloadInfo.thumbnail) {
            thumbnailStream = await downloadImage(downloadInfo.thumbnail);
        }
        
        // Bước 4: GỬI TIN NHẮN ĐẦU TIÊN - Chỉ thông tin và ảnh (sau khi đã tải xong audio)
        const infoMessage = `🎵 [ SOUNDCLOUD DOWNLOAD ]\n📝 ${downloadInfo.title}\n👤 ${downloadInfo.artist}\n⏳ ${downloadInfo.duration}`;
        
        const firstMessageAttachments = thumbnailStream ? [thumbnailStream] : [];
        
        await api.sendMessage({
            body: infoMessage,
            attachment: firstMessageAttachments
        }, threadID);
        
        // Bước 5: GỬI TIN NHẮN THỨ HAI - Chỉ file audio từ đường dẫn tạm thời
        await api.sendMessage({
            body: `🎵 ${downloadInfo.title} - ${downloadInfo.artist}`,
            attachment: [fs.createReadStream(tempAudioFilePath)]
        }, threadID, originalMessageID);

        api.unsendMessage(loadingMsgId);

    } catch (error) {
        api.unsendMessage(loadingMsgId);
        console.error(`Lỗi khi tải bài hát: ${track.title}`, error);
        api.sendMessage(`❌ Rất tiếc, đã xảy ra lỗi khi tải bài hát "${track.title}":\n${error.message}`, threadID, originalMessageID);
    } finally {
        // Đảm bảo xóa file tạm thời sau khi gửi hoặc khi có lỗi
        if (tempAudioFilePath && fs.existsSync(tempAudioFilePath)) {
            fs.unlinkSync(tempAudioFilePath);
        }
    }
}

async function batchDownload(api, threadID, tracks, indices) {
    const batchMsg = await api.sendMessage(`📦 Bắt đầu tải ${tracks.length} bài hát...`, threadID);
    
    for (let i = 0; i < tracks.length; i++) {
        const track = tracks[i];
        const trackNumber = indices ? indices[i] : i + 1;
        
        try {
            await api.sendMessage(`📥 [${i + 1}/${tracks.length}] Đang tải: ${track.title}`, threadID);
            await downloadAndSendTrack(api, threadID, track);
            
            // Delay giữa các bài để tránh spam
            if (i < tracks.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
        } catch (error) {
            console.error(`Lỗi tải bài ${track.title}:`, error);
            await api.sendMessage(`❌ Lỗi tải bài ${trackNumber}: ${track.title}`, threadID);
        }
    }
    
    api.unsendMessage(batchMsg.messageID);
    api.sendMessage(`✅ Hoàn thành tải ${tracks.length} bài hát!`, threadID);
}

async function getLyrics(title, artist) {
    try {
        const query = `${title} ${artist} lyrics`;
        const { data } = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`);
        if (data.lyrics) {
            return { lyrics: data.lyrics.trim(), source: "lyrics.ovh" };
        }
    } catch (error) {
        console.log("SCL: Không tìm thấy lời bài hát từ lyrics.ovh");
    }
    return null;
}

async function getTrackStats(track) {
    try {
        const info = await getAdvancedSoundCloudInfo(track.url);
        if (!info) return null;
        
        return {
            basic: { plays: formatNumber(info.plays), likes: formatNumber(info.likes), reposts: formatNumber(info.reposts), comments: formatNumber(info.comments) },
            engagement: {
                likeRate: ((info.likes / info.plays) * 100).toFixed(2),
                commentRate: ((info.comments / info.plays) * 100).toFixed(2),
                repostRate: ((info.reposts / info.plays) * 100).toFixed(2)
            }
        };
    } catch (error) {
        return null;
    }
}

module.exports.config = {
  name: "scl",
  version: "3.0.4", // Cập nhật version
  hasPermssion: 0,
  credits: "Tiên - Pro Edition (Fixed by vanhung)",
  description: "SoundCloud promax",
  commandCategory: "Khác",
  usages: "[từ khóa] | -genre [thể loại] | -artist [nghệ sĩ] | -sort [relevance/date/plays/likes] | -limit [số]",
  cooldowns: 5,
  usePrefix: true,
};

module.exports.run = async function ({ api, event, args }) {
  const rawQuery = args.join(" ").trim();
  const { threadID, messageID } = event;

  if (!rawQuery) {
    const helpText = `🎵 [ SOUNDCLOUD PRO - HƯỚCNG DẪN ]\n═══════════════════════════════\n📝 Tìm kiếm cơ bản:\n• scl [từ khóa]\n\n🎯 Tìm kiếm nâng cao:\n• scl -genre electronic\n• scl -artist Skrillex\n• scl -sort plays\n• scl -limit 15\n\n🔧 Kết hợp filters:\n• scl dubstep -genre electronic -sort likes`;
    return api.sendMessage(helpText, threadID, messageID);
  }

  const filters = parseSearchQuery(rawQuery);
  if (!filters.general) return api.sendMessage("⚠️ Vui lòng nhập từ khóa tìm kiếm", threadID, messageID);

  const searchingMsg = await api.sendMessage(`🔍 Đang tìm kiếm "${filters.general}"...`, threadID);

  try {
    let searchResults = await searchSoundCloudAdvanced(filters.general, 20); // Lấy nhiều để sort
    
    if (filters.genre) searchResults = searchResults.filter(t => t.genre.toLowerCase().includes(t.genre.toLowerCase()) || t.tags.some(tag => tag.toLowerCase().includes(filters.genre.toLowerCase())));
    if (filters.artist) searchResults = searchResults.filter(t => t.artist.toLowerCase().includes(filters.artist.toLowerCase()));

    switch (filters.sort) {
      case "date": searchResults.sort((a, b) => new Date(b.release) - new Date(a.release)); break;
      case "plays": searchResults.sort((a, b) => parseInt(b.views) - parseInt(a.views)); break;
      case "likes": searchResults.sort((a, b) => b.likes - a.likes); break;
    }
    
    searchResults = searchResults.slice(0, filters.limit);

    api.unsendMessage(searchingMsg.messageID);
    if (searchResults.length === 0) return api.sendMessage(`❎ Không tìm thấy kết quả cho "${filters.general}" với các filters đã chọn`, threadID, messageID);

    const images = [];
    for (const result of searchResults) {
        if (result.thumb) {
            const imageStream = await downloadImage(result.thumb);
            if (imageStream) images.push(imageStream);
        }
    }

    const messages = searchResults.map((item, index) => {
      const duration = formatDuration(item.timestamp);
      const views = formatNumber(item.views);
      const likes = formatNumber(item.likes);
      return `\n${index + 1}. 🎵 ${item.title}\n👤 ${item.artist}\n⏳ ${duration} | 👁️ ${views} | ❤️ ${likes}`;
    });

    const listMessage = {
      body: `🎵 [ SOUNDCLOUD PRO - RESULTS ]\n${messages.join("\n─────────────────────────")}\n\n💡 Reply số để tải MP3\n📥 Reply "batch [số1,số2]" để tải nhiều bài\n📥 Reply "all" để tải tất cả\n🎯 Reply "info [số]" để xem chi tiết`,
      attachment: images
    };

    api.sendMessage(listMessage, threadID, (error, info) => {
      if (!error) global.client.handleReply.push({ type: "advanced_choose", name: this.config.name, author: event.senderID, messageID: info.messageID, searchResults });
    });

  } catch (error) {
    api.unsendMessage(searchingMsg.messageID);
    console.error("SCL Lỗi Run:", error);
    api.sendMessage(`❎ Lỗi tìm kiếm: ${error.message}`, threadID, messageID);
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (senderID !== handleReply.author) return;

  const handlers = {
    "advanced_choose": handleAdvancedChoose,
    "track_info": handleTrackInfo,
    "post_download": handlePostDownload,
    "full_lyrics": handleFullLyrics
  };

  if (handlers[handleReply.type]) {
    await handlers[handleReply.type]({ event, api, handleReply });
  }
};

async function handleAdvancedChoose({ event, api, handleReply }) {
    const { threadID, messageID, body } = event;
    try {
        const input = body.toLowerCase().trim();
        api.unsendMessage(handleReply.messageID);

        if (input.startsWith("info ")) {
            const choice = parseInt(input.replace("info ", ""));
            if (isNaN(choice) || choice < 1 || choice > handleReply.searchResults.length) return;
            await showTrackInfo(api, threadID, handleReply.searchResults[choice - 1], choice);
            return;
        }

        if (input.startsWith("batch ")) {
            const indices = input.replace("batch ", "").split(",").map(s => parseInt(s.trim())).filter(n => !isNaN(n) && n > 0 && n <= handleReply.searchResults.length);
            if (indices.length === 0) return;
            const tracksToDownload = indices.map(i => handleReply.searchResults[i - 1]);
            await batchDownload(api, threadID, tracksToDownload, indices);
            return;
        }

        if (input === "all") {
            const tracksToDownload = handleReply.searchResults.slice(0, 10);
            await batchDownload(api, threadID, tracksToDownload);
            return;
        }

        const choice = parseInt(input);
        if (isNaN(choice) || choice < 1 || choice > handleReply.searchResults.length) return;
        await downloadAndSendTrack(api, threadID, handleReply.searchResults[choice - 1], choice);

    } catch (error) {
        console.error("SCL HandleReply error:", error);
        api.sendMessage(`❌ Lỗi: ${error.message}`, threadID);
    }
}

async function handleTrackInfo({ event, api, handleReply }) {
    if (event.body.toLowerCase() === "download" || event.body.toLowerCase() === "dl") {
        api.unsendMessage(handleReply.messageID);
        await downloadAndSendTrack(api, event.threadID, handleReply.track);
    }
}

async function handlePostDownload({ event, api, handleReply }) {
    const { threadID, messageID, body, senderID } = event;
    const input = body.toLowerCase().trim();
    
    if (input === "y") {
        api.unsendMessage(handleReply.messageID);
        const loadingMsg = await api.sendMessage("🔍 Đang tìm lời bài hát...", threadID);
        const lyricsData = await getLyrics(handleReply.track.title, handleReply.track.artist);
        api.unsendMessage(loadingMsg.messageID);
        
        if (lyricsData) {
            const lyricsPreview = lyricsData.lyrics.length > 1500 ? lyricsData.lyrics.substring(0, 1500) + "..." : lyricsData.lyrics;
            api.sendMessage(`🎵 [ LYRICS FOUND ]\n📝 ${handleReply.track.title}\n📊 Source: ${lyricsData.source}\n\n${lyricsPreview}\n\n${lyricsData.lyrics.length > 1500 ? "💡 Reply \"FULL\" để xem toàn bộ lời bài hát" : ""}`, threadID, (err, info) => {
                if (!err && lyricsData.lyrics.length > 1500) {
                    global.client.handleReply.push({ type: "full_lyrics", name: module.exports.config.name, author: senderID, messageID: info.messageID, fullLyrics: lyricsData.lyrics, track: handleReply.track, source: lyricsData.source });
                }
            });
        } else {
            api.sendMessage(`❌ Không tìm thấy lời bài hát cho: "${handleReply.track.title}"`, threadID);
        }
    } else if (input === "stats") {
        api.unsendMessage(handleReply.messageID);
        const loadingMsg = await api.sendMessage("📊 Đang lấy thống kê chi tiết...", threadID);
        const stats = await getTrackStats(handleReply.track);
        api.unsendMessage(loadingMsg.messageID);
        
        if (stats) {
            const statsMessage = `📊 [ DETAILED STATISTICS ]\n📝 Track: ${handleReply.track.title}\n\n📈 PERFORMANCE:\n▶️ Plays: ${stats.basic.plays}\n❤️ Likes: ${stats.basic.likes}\n🔄 Reposts: ${stats.basic.reposts}\n💬 Comments: ${stats.basic.comments}\n\n📊 ENGAGEMENT (% of plays):\n❤️ Like Rate: ${stats.engagement.likeRate}%\n💬 Comment Rate: ${stats.engagement.commentRate}%\n🔄 Repost Rate: ${stats.engagement.repostRate}%`;
            api.sendMessage(statsMessage, threadID);
        } else {
            api.sendMessage("❌ Không thể lấy thống kê chi tiết.", threadID);
        }
    }
}

async function handleFullLyrics({ event, api, handleReply }) {
    if (event.body.toLowerCase() === "full") {
        api.unsendMessage(handleReply.messageID);
        const fullLyrics = handleReply.fullLyrics;
        const chunkSize = 1800;
        for (let i = 0; i < fullLyrics.length; i += chunkSize) {
            const header = i === 0 ? `🎵 [ FULL LYRICS ]\n📝 ${handleReply.track.title}\n\n` : `🎵 [ CONTINUED ]\n\n`;
            await api.sendMessage(header + fullLyrics.substring(i, i + chunkSize), event.threadID);
            if (i + chunkSize < fullLyrics.length) await new Promise(resolve => setTimeout(resolve, 1500));
        }
    }
}

async function showTrackInfo(api, threadID, track, trackNumber) {
  try {
    const info = await getAdvancedSoundCloudInfo(track.url) || track;
    const duration = formatDuration(info.duration);
    const description = info.description ? (info.description.length > 200 ? info.description.substring(0, 200) + "..." : info.description) : "Không có mô tả.";
    const thumbnail = info.artwork ? [await downloadImage(info.artwork)] : [];

    const infoText = `🎵 [ TRACK INFO - ${trackNumber || ""} ]\n═══════════════════════════════\n📝 Tiêu đề: ${info.title}\n👤 Nghệ sĩ: ${info.artist}\n⏳ Thời lượng: ${duration}\n👁️ Lượt nghe: ${formatNumber(info.plays)}\n❤️ Lượt thích: ${formatNumber(info.likes)}\n🔄 Reposts: ${formatNumber(info.reposts)}\n💬 Comments: ${formatNumber(info.comments)}\n🎭 Thể loại: ${info.genre}\n📅 Ngày tạo: ${info.release}\n\n📄 Mô tả:\n${description}\n\n💡 Reply "download" hoặc "dl" để tải nhạc`;

    api.sendMessage({
      body: infoText,
      attachment: thumbnail
    }, threadID, (error, info) => {
      if (!error) {
        global.client.handleReply.push({
          type: "track_info",
          name: module.exports.config.name,
          author: event.senderID,
          messageID: info.messageID,
          track: track
        });
      }
    });

  } catch (error) {
    console.error("SCL showTrackInfo error:", error);
    api.sendMessage(`❌ Lỗi hiển thị thông tin: ${error.message}`, threadID);
  }
}