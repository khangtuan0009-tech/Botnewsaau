const axios = require("axios");
const qs = require("querystring");

module.exports.config = {
  name: "lbh",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "Dongdev & nvh",
  description: "Tìm kiếm và hiển thị toàn bộ lời bài hát (LyricFind)",
  commandCategory: "Tiện ích",
  usages: "[tên bài hát]",
  cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function({ api, event, args }) {
  const query = args.join(" ").trim();
  if (!query)
    return api.sendMessage("⚠️ Vui lòng nhập tên bài hát cần tìm!", event.threadID, event.messageID);

  api.sendMessage(`🔍 Đang tìm lời bài hát "${query}"...`, event.threadID, async (err, info) => {
    const res = await lfSearch(query, 1, 25);
    if (!res || res.response?.code !== 100)
      return api.sendMessage("❌ Không thể truy vấn dữ liệu từ LyricFind.", event.threadID, event.messageID);

    const tracks = Array.isArray(res.tracks) ? res.tracks : [];
    if (!tracks.length)
      return api.sendMessage("❗ Không tìm thấy kết quả phù hợp.", event.threadID, event.messageID);

    const best = pickBest(sortNewest(tracks));
    const link =
      best.url ||
      best.track_url ||
      (best.artist && best.title
        ? `https://lyrics.lyricfind.com/lyrics/${encodeURIComponent(
            `${best.artist.name}-${best.title}`.replace(/\s+/g, "-").toLowerCase()
          )}`
        : null);

    let fullLyrics = null;
    if (link) fullLyrics = await fetchFullLyrics(link);

    const content = fullLyrics
      ? fullLyrics
      : cleanContext(best.context || best.snippet || "Không có dữ liệu lyrics.");

    const msg = `🎵 | ${best.title || "Không rõ tiêu đề"} - ${
      best.artist?.name || "Không rõ ca sĩ"
    }\n━━━━━━━━━━━━━━\n${content.trim().slice(0, 19000)}`;

    return api.sendMessage(msg, event.threadID, event.messageID);
  });
};

//================= CORE FUNCTION =================//

async function lfSearch(query, page, limit) {
  try {
    const { data } = await axios.get(
      `https://lyrics.lyricfind.com/api/v1/search?${qs.stringify({
        reqtype: "default",
        territory: "VN",
        searchtype: "track",
        all: query,
        alltracks: "no",
        limit: String(limit || 25),
        output: "json",
        page: String(Math.max(1, page || 1))
      })}`,
      {
        headers: {
          Accept: "application/json, text/plain, */*",
          "Accept-Language": "vi,en-US;q=0.9",
          "Cache-Control": "no-cache",
          Pragma: "no-cache",
          Referer: "https://lyrics.lyricfind.com/",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139 Safari/537.36"
        },
        timeout: 15000
      }
    );
    return data;
  } catch {
    return null;
  }
}

async function fetchFullLyrics(url) {
  try {
    const { data } = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139 Safari/537.36"
      },
      timeout: 15000
    });

    const jsonMatch = data.match(
      /<script id="__NEXT_DATA__" type="application\/json">(.+?)<\/script>/
    );
    if (!jsonMatch) return null;

    const json = JSON.parse(jsonMatch[1]);
    const lines = json.props?.pageProps?.lyrics?.lines;
    if (!lines || !lines.length) return null;

    return lines.map(l => l.words).join("\n");
  } catch {
    return null;
  }
}

function sortNewest(arr) {
  return [...arr].sort((a, b) => {
    const da = parseDate(a.last_update) || fromApple(a.apple) || 0;
    const db = parseDate(b.last_update) || fromApple(b.apple) || 0;
    return db - da;
  });
}

function pickBest(arr) {
  let best = arr[0];
  let bestScore = rank(arr[0]);
  for (let i = 1; i < arr.length; i++) {
    const r = rank(arr[i]);
    if (r > bestScore) {
      best = arr[i];
      bestScore = r;
    }
  }
  return best;
}

function rank(t) {
  const rec = (parseDate(t.last_update) || fromApple(t.apple) || 0) / 1e12;
  const sc = Number(t.score || 0) / 100;
  const lrc = t.has_lrc ? 0.05 : 0;
  return rec * 0.7 + sc * 0.25 + lrc;
}

function parseDate(s) {
  if (!s) return 0;
  const t = Date.parse(String(s).replace(" ", "T") + "Z");
  return Number.isFinite(t) ? t : 0;
}

function fromApple(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  if (n > 1e12) return n;
  if (n > 1e9) return n * 1000;
  return 0;
}

function cleanContext(s) {
  let x = String(s).replace(/<[^>]*>/g, " ");
  x = x
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
  x = x.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  x = x.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n");
  return x.trim();
}