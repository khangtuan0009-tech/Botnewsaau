const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { createCanvas } = require("canvas");
const { v4: uuidv4 } = require("uuid");

// 🔍 Hàm tìm file trong project
function findFile(filename, startDir = process.cwd()) {
  const results = [];
  const skip = new Set(["node_modules", ".git", ".next", "dist", "build", ".replit-cache"]);

  function search(dir, depth = 0) {
    if (depth > 8) return;
    try {
      for (const item of fs.readdirSync(dir)) {
        if (skip.has(item)) continue;
        const full = path.join(dir, item);
        const stat = fs.statSync(full);
        if (stat.isFile() && (item === filename || path.parse(item).name === path.parse(filename).name)) {
          results.push({ path: full, isInModules: full.includes("modules") });
        } else if (stat.isDirectory()) {
          search(full, depth + 1);
        }
      }
    } catch { }
  }

  search(startDir);
  return results
    .sort((a, b) => b.isInModules - a.isInModules)
    .map(f => f.path);
}

// 🖼️ Hàm tạo ảnh code
function createCodeImages(code, fileName, sourceUrl) {
  const raw = code.replace(/\r\n/g, "\n").split("\n");
  const rowsPer = 35, lineH = 22, pad = 30, fsz = 16, head = 80, left = 70, w = 1200;

  const ctxM = createCanvas(10, 10).getContext("2d");
  ctxM.font = `${fsz}px Consolas`;

  const wrap = text => {
    let cur = "", rows = [];
    for (const ch of text) {
      if (ctxM.measureText(cur + ch).width <= w - pad * 2 - left) cur += ch;
      else {
        rows.push(cur);
        cur = ch === " " ? "" : ch;
      }
    }
    rows.push(cur);
    return rows.filter(Boolean);
  };

  const color = line => {
    if (/^\/\//.test(line.trim()) || /^\/\*/.test(line.trim())) return "#6a9955";
    if (/const|let|var|function/.test(line)) return "#569cd6";
    if (/['"`]/.test(line)) return "#ce9178";
    return "#d4d4d4";
  };

  const rows = [];
  raw.forEach((l, i) =>
    wrap(l.replace(/\t/g, "  ")).forEach((p, j) =>
      rows.push({ text: p, lineNo: j ? null : i + 1, color: color(l) })
    )
  );

  const parts = Math.ceil(rows.length / rowsPer);
  const images = [];

  for (let p = 0; p < parts; p++) {
    const slice = rows.slice(p * rowsPer, (p + 1) * rowsPer);
    const c = createCanvas(w, rowsPer * lineH + pad * 2 + head);
    const ctx = c.getContext("2d");

    // nền
    ctx.fillStyle = "#1e1e1e";
    ctx.fillRect(0, 0, w, c.height);
    ctx.fillStyle = "#2d2d30";
    ctx.fillRect(0, 0, w, head);

    // tiêu đề
    ctx.font = `bold ${fsz + 2}px Consolas`;
    ctx.fillStyle = "#569cd6";
    ctx.fillText(`📄 ${fileName}`, pad, pad + 20);

    ctx.font = `${fsz - 2}px Consolas`;
    ctx.fillStyle = "#9cdcfe";
    ctx.fillText(parts > 1 ? `Part ${p + 1}/${parts}` : `${raw.length} lines`, pad, pad + 45);

    if (sourceUrl) {
      ctx.fillStyle = "#4ec9b0";
      ctx.fillText(`🔗 ${sourceUrl.slice(0, 100)}`, pad, pad + 65);
    }

    ctx.font = `${fsz}px Consolas`;

    slice.forEach((r, i) => {
      const y = head + pad + i * lineH;
      ctx.fillStyle = "#2d2d30";
      ctx.fillRect(0, y - lineH + 5, 60, lineH);
      ctx.fillStyle = "#858585";
      ctx.fillText(r.lineNo ? String(r.lineNo).padStart(3, " ") : "   ", 10, y);
      ctx.fillStyle = r.color;
      ctx.fillText(r.text, left, y);
    });

    images.push(c.toBuffer("image/png"));
  }

  return images;
}

// 🌐 Upload code lên paste server
async function uploadRaw(content) {
  try {
    const id = uuidv4();
    const base = `https://nvhzxz.onrender.com/note/${id}`;
    await axios.put(base, content, { headers: { "content-type": "text/plain; charset=utf-8" } });
    return `${base}?raw=true`;
  } catch {
    return null;
  }
}

async function sendImages(o, filePath, data) {
  const cacheDir = path.join(__dirname, "cache");
  if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });

  const rawUrl = await uploadRaw(data);
  const imgs = createCodeImages(data, path.basename(filePath), rawUrl);
  const temps = imgs.map((b, i) => {
    const p = path.join(cacheDir, `temp_${Date.now()}_${i}.png`);
    fs.writeFileSync(p, b);
    return p;
  });

  const fileSizeKB = (Buffer.byteLength(data, "utf-8") / 1024).toFixed(2);
  const msg = `✅ Code: ${path.relative(process.cwd(), filePath)}\n📊 ${data.split("\n").length} dòng | 💾 ${fileSizeKB} KB${rawUrl ? `\n🔗 ${rawUrl}` : ""}`;

  await new Promise((res, rej) =>
    o.api.sendMessage(
      { body: msg, attachment: temps.map(p => fs.createReadStream(p)) },
      o.event.threadID,
      (e, r) => (e ? rej(e) : res(r)),
      o.event.messageID
    )
  );

  // 🧹 Xoá file sau khi gửi
  temps.forEach(p => fs.existsSync(p) && fs.unlinkSync(p));
}

module.exports = {
  config: {
    name: "adc",
    version: "1.3.1",
    hasPermssion: 3,
    credits: "lechii & nvh",
    description: "Render code ra ảnh hoặc tải code raw",
    commandCategory: "Admin",
    usages: "adc <filename> [line|url]",
    usePrefix: true,
    cooldowns: 0
  },

  // 🏃‍♂️ Lệnh chính
  run: async function (o) {
    const send = m => new Promise(r => o.api.sendMessage(m, o.event.threadID, (e, res) => r(res), o.event.messageID));
    const filename = o.args[0];
    const mode = o.args[1];
    const text = o.event?.type === "message_reply" ? o.event.messageReply.body : "";

    if (!filename && !text) return send("❎ Reply link hoặc ghi tên file!");

    // Nếu có filename nhưng không có reply text
    if (filename && !text) {
      const files = findFile(filename);
      if (!files.length) return send(`❎ Không tìm thấy ${filename}`);
      if (files.length > 1) {
        let s = `🔎 Có ${files.length} file:\n` +
          files.map((f, i) => `${i + 1}. ${path.relative(process.cwd(), f)}`).join("\n");
        s += `\n💡 Reply số để chọn`;
        return send(s).then(res => {
          global.client.handleReply.push({
            name: this.config.name,
            messageID: res.messageID,
            author: o.event.senderID,
            action: mode || "default",
            files,
            o
          });
        });
      }

      const data = fs.readFileSync(files[0], "utf-8");
      const fileSizeKB = (Buffer.byteLength(data, "utf-8") / 1024).toFixed(2);
      if (mode === "line")
        return send(`📄 File: ${path.relative(process.cwd(), files[0])}\n📊 Tổng số dòng: ${data.split("\n").length} | 💾 ${fileSizeKB} KB`);
      return sendImages(o, files[0], data);
    }

    // Nếu có reply link hoặc nhập link trực tiếp
    const url = (text.match(/https?:\/\/\S+/) || [])[0] || (mode && mode.startsWith("http") ? mode : null);
    if (!url) return send("❎ URL không hợp lệ!");
    if (!filename) return send("❎ Nhập tên file!");

    const processed = url.includes("raw=true") ? url : url + (url.includes("?") ? "&" : "?") + "raw=true";
    const files = findFile(`${filename}.js`);

    if (files.length) {
      let s = `🔎 File trùng tên:\n` +
        files.map((f, i) => `${i + 1}. ${path.relative(process.cwd(), f)}`).join("\n");
      s += `\n${files.length + 1}. Tạo file mới`;
      return send(s).then(res => {
        global.client.handleReply.push({
          name: this.config.name,
          messageID: res.messageID,
          author: o.event.senderID,
          action: "download",
          files: [...files, path.join(process.cwd(), `${filename}.js`)],
          url: processed,
          o
        });
      });
    }

    try {
      const { data } = await axios.get(processed);
      fs.writeFileSync(path.join(process.cwd(), `${filename}.js`), data, "utf-8");
      return send(`✅ Lưu code vào ${filename}.js`);
    } catch (e) {
      return send(`⚠️ ${e.message}`);
    }
  },

  // 📩 Xử lý reply
  handleReply: async function (o) {
    const _ = o.handleReply;
    const send = m => o.api.sendMessage(m, o.event.threadID, () => { }, o.event.messageID);
    if (o.event.senderID !== _.author) return;

    const idx = parseInt(o.event.body) - 1;
    if (isNaN(idx) || idx < 0 || idx >= _.files.length) return send(`❌ Chọn 1-${_.files.length}`);

    const file = _.files[idx];

    if (_.action === "line") {
      const data = fs.readFileSync(file, "utf-8");
      const fileSizeKB = (Buffer.byteLength(data, "utf-8") / 1024).toFixed(2);
      return send(`📄 File: ${path.relative(process.cwd(), file)}\n📊 Tổng số dòng: ${data.split("\n").length} | 💾 ${fileSizeKB} KB`);
    }

    if (_.action === "download") {
      try {
        const { data } = await axios.get(_.url);
        fs.writeFileSync(file, data, "utf-8");
        return send(`✅ Code đã lưu vào ${file}`);
      } catch (e) {
        return send(`⚠️ ${e.message}`);
      }
    }

    if (_.action === "default")
      return sendImages(o, file, fs.readFileSync(file, "utf-8"));
  }
};