const axios = require("axios");
const moment = require("moment");

module.exports.config = {
  name: "site",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "uptime web",
  commandCategory: "admin",
  usages: "site help | site add <url> [name] | site addsites <url1> [name1] | <url2> [name2] | ... | site status | site remove <url>",
  cooldowns: 5
};

const API_BASE = "http://46.247.108.191:30287";

function extractDomain(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, "");
  } catch (e) {
    return null;
  }
}

function parseEntries(input) {
  return input.split("|").map(s => {
    const parts = s.trim().split(/\s+/);
    const url = parts.shift();
    const name = parts.join(" ").trim();
    return { url, name: name || null };
  }).filter(e => e.url);
}

module.exports.run = async ({ api, event, args }) => {
  const send = (msg) => api.sendMessage(msg, event.threadID, event.messageID);

  if (!args || args.length === 0) {
    return send(getHelp());
  }

  const sub = args[0].toLowerCase();

  // HELP
  if (sub === "help") return send(getHelp());

  // STATUS: GET /api/status
  if (sub === "status") {
    try {
      const res = await axios.get(`${API_BASE}/api/status`, {
        headers: {
          "User-Agent": "MiraiBot/1.0",
          "Referer": `${API_BASE}/`
        },
        timeout: 15000,
        // allow self-signed if server uses -k in curl (axios ignores by default in Node)
      });
      const d = res.data || {};
      const lines = [];
      lines.push("📡 Monitor server status:");
      if (d.clientIP) lines.push(`• Client IP: ${d.clientIP}`);
      if (d.serverUptime !== undefined) lines.push(`• Server Uptime: ${d.serverUptime} s`);
      if (d.ipUptime !== undefined) lines.push(`• IP Uptime: ${d.ipUptime} s`);
      lines.push(`• Total websites: ${d.totalWebsites || 0}`);
      lines.push(`• Up: ${d.upWebsites || 0} | Down: ${d.downWebsites || 0}`);
      lines.push(`• Total checks: ${d.totalChecks || 0}`);
      if (d.lastSave) lines.push(`• Last save: ${moment(d.lastSave).format("YYYY-MM-DD HH:mm:ss")}`);
      // optionally show raw websites if present
      if (Array.isArray(d.websites) && d.websites.length) {
        lines.push("");
        lines.push("Websites (sample):");
        d.websites.slice(0, 10).forEach(w => {
          lines.push(`- ${w.name || w.url} | ${w.status || "—"} | ${w.statusCode || "—"} | ${w.responseTime !== undefined ? w.responseTime + "ms" : "—"}`);
        });
      }
      return send(lines.join("\n"));
    } catch (err) {
      return send(formatError("Lỗi khi lấy status", err));
    }
  }

  // ADD single: site add <url> [name]
  if (sub === "add") {
    const rest = args.slice(1).join(" ").trim();
    if (!rest) return send("❌ Cách dùng: site add <url> [name]");
    const parts = rest.split(/\s+/);
    const url = parts.shift();
    if (!/^https?:\/\//i.test(url)) return send("❌ URL phải bắt đầu bằng http:// hoặc https://");
    const name = parts.join(" ").trim() || extractDomain(url) || "Website";
    try {
      const res = await axios.post(`${API_BASE}/api/add-website`, { url, name }, {
        headers: {
          "User-Agent": "MiraiBot/1.0",
          "Content-Type": "application/json",
          "Referer": `${API_BASE}/`
        },
        timeout: 20000
      });
      const d = res.data && res.data.data ? res.data.data : res.data;
      const lines = [];
      lines.push("✅ Thêm website thành công!");
      lines.push(`• URL: ${d.url || url}`);
      lines.push(`• Name: ${d.name || name}`);
      lines.push(`• Status: ${d.status || (res.data && res.data.message) || "—"}`);
      if (d.statusCode !== undefined) lines.push(`• StatusCode: ${d.statusCode}`);
      if (d.responseTime !== undefined) lines.push(`• ResponseTime: ${d.responseTime} ms`);
      if (d.lastChecked) lines.push(`• LastChecked: ${moment(d.lastChecked).format("YYYY-MM-DD HH:mm:ss")}`);
      return send(lines.join("\n"));
    } catch (err) {
      return send(formatError("Lỗi khi thêm website", err));
    }
  }

  // ADDSITES: site addsites <url1> [name1] | <url2> [name2] | ...
  if (sub === "addsites") {
    const text = args.slice(1).join(" ").trim();
    if (!text) return send("❌ Cách dùng: site addsites <url1> [name1] | <url2> [name2] | ...");
    const entries = parseEntries(text);
    if (!entries.length) return send("❌ Không tìm thấy URL hợp lệ trong input.");
    const results = [];
    const loading = await api.sendMessage(`⏳ Đang thêm ${entries.length} website...`, event.threadID);
    for (const e of entries) {
      const url = e.url.trim();
      if (!/^https?:\/\//i.test(url)) {
        results.push({ url, ok: false, error: "URL phải bắt đầu bằng http:// hoặc https://" });
        continue;
      }
      const name = e.name || extractDomain(url) || "Website";
      try {
        const res = await axios.post(`${API_BASE}/api/add-website`, { url, name }, {
          headers: {
            "User-Agent": "MiraiBot/1.0",
            "Content-Type": "application/json",
            "Referer": `${API_BASE}/`
          },
          timeout: 20000
        });
        const d = res.data && res.data.data ? res.data.data : res.data;
        results.push({ url, ok: true, data: d });
      } catch (err) {
        let info = err.message;
        if (err.response && err.response.data) info = JSON.stringify(err.response.data);
        results.push({ url, ok: false, error: info });
      }
    }
    try { await api.unsendMessage(loading.messageID); } catch (e) {}
    // build reply
    const lines = [`✅ Hoàn tất xử lý ${results.length} site:\n`];
    results.forEach(r => {
      if (r.ok) {
        const d = r.data || {};
        lines.push(`● ${r.url}`);
        lines.push(`  → Name: ${d.name || "—"}`);
        lines.push(`  → Status: ${d.status || (d.message || "—")}`);
        if (d.statusCode !== undefined) lines.push(`  → StatusCode: ${d.statusCode}`);
        if (d.responseTime !== undefined) lines.push(`  → ResponseTime: ${d.responseTime} ms`);
        if (d.lastChecked) lines.push(`  → LastChecked: ${moment(d.lastChecked).format("YYYY-MM-DD HH:mm:ss")}`);
      } else {
        lines.push(`● ${r.url}`);
        lines.push(`  ❌ Lỗi: ${r.error}`);
      }
      lines.push("");
    });
    return send(lines.join("\n"));
  }

  // REMOVE: site remove <url>
  if (sub === "remove") {
    const rest = args.slice(1).join(" ").trim();
    if (!rest) return send("❌ Cách dùng: site remove <url>");
    const url = rest.split(/\s+/)[0];
    if (!/^https?:\/\//i.test(url)) return send("❌ URL phải bắt đầu bằng http:// hoặc https://");
    try {
      const encoded = encodeURIComponent(url);
      const res = await axios.delete(`${API_BASE}/api/remove-website/${encoded}`, {
        headers: {
          "User-Agent": "MiraiBot/1.0",
          "Origin": `${API_BASE}`,
          "Referer": `${API_BASE}/`
        },
        timeout: 15000
      });
      const d = res.data || {};
      if (d.success) {
        return send(`✅ Xóa thành công:\n• URL: ${url}\n• Message: ${d.message || "—"}`);
      } else {
        return send(`❌ Server trả về lỗi khi xóa:\n${JSON.stringify(d)}`);
      }
    } catch (err) {
      return send(formatError("Lỗi khi xóa website", err));
    }
  }

  // fallback
  return send(getHelp());
};

// helpers
function getHelp() {
  return [
    "📘 Hướng dẫn lệnh site:",
    "• site help — Hiện hướng dẫn",
    "• site status — Lấy status server (GET /api/status)",
    "• site add <url> [name] — Thêm 1 website",
    "• site addsites <url1> [name1] | <url2> [name2] | ... — Thêm nhiều website",
    "• site remove <url> — Xóa website",
    "",
    "Ví dụ:",
    "site add https://nvhzxz.onrender.com/ Note",
    "site addsites https://a.com A | https://b.com B",
    "site remove https://nvhzxz.onrender.com/"
  ].join("\n");
}

function formatError(title, err) {
  let msg = `❌ ${title}.`;
  if (err && err.response && err.response.data) {
    msg += `\nServer trả về: ${JSON.stringify(err.response.data)}`;
  } else if (err && err.code === "ECONNABORTED") {
    msg += `\nLỗi: Request timeout.`;
  } else if (err && err.message) {
    msg += `\nChi tiết: ${err.message}`;
  } else {
    msg += `\nKhông rõ lỗi.`;
  }
  return msg;
}