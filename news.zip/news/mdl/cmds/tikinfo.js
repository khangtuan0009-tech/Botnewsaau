const a = require("axios")
const f = require("fs")
const p = require("path")
const { createCanvas, loadImage } = require("canvas")
const q = require("qrcode")

module.exports.config = {
  name: "tikinfo",
  version: "1.6",
  hasPermssion: 0,
  credits: "nvh | lechii",
  description: "TikTok Info",
  commandCategory: "media",
  usages: "tikinfo <username>",
  cooldowns: 3,
  usePrefix: true
}

const UA = "Mozilla/5.0"
const C = p.join(__dirname, "cache")
f.mkdirSync(C, { recursive: true })

const num = n => {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + "B"
  if (n >= 1e6) return (n / 1e6).toFixed(1) + "M"
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "K"
  return n.toString()
}

const getId = i => {
  const m = i.match(/tiktok\.com\/@([^/?\s]+)/i)
  return m ? m[1] : i.replace(/^@/, "")
}

const rect = (x, a, b, w, h, r) => {
  x.beginPath()
  x.moveTo(a + r, b)
  x.lineTo(a + w - r, b)
  x.quadraticCurveTo(a + w, b, a + w, b + r)
  x.lineTo(a + w, b + h - r)
  x.quadraticCurveTo(a + w, b + h, a + w - r, b + h)
  x.lineTo(a + r, b + h)
  x.quadraticCurveTo(a, b + h, a, b + h - r)
  x.lineTo(a, b + r)
  x.quadraticCurveTo(a, b, a + r, b)
  x.closePath()
}

async function getAvatar(u) {
  const k = p.join(C, `ava_${Date.now()}.jpg`)
  const r = await a.get(`https://images.weserv.nl/?url=${encodeURIComponent(u)}&output=jpg`, { responseType: "arraybuffer" })
  f.writeFileSync(k, Buffer.from(r.data))
  return k
}

async function fetchUser(u) {
  const { data } = await a.get(`https://www.tikwm.com/api/user/info?unique_id=${encodeURIComponent(u)}`, { headers: { "user-agent": UA } })
  if (data.code !== 0) throw new Error("Không tìm thấy user")
  const d = data.data.user
  const s = data.data.stats
  return {
    uid: d.uniqueId,
    name: d.nickname,
    ava: d.avatarLarger || d.avatarMedium,
    fl: s.followerCount,
    fg: s.followingCount,
    heart: s.heartCount
  }
}

async function makeCard(u, A) {
  const w = 1300, h = 700
  const c = createCanvas(w, h)
  const x = c.getContext("2d")
  const s = (Math.sin(Date.now() / 800) + 1) / 2

  const g = x.createLinearGradient(0, 0, w, h)
  g.addColorStop(0, "#10001c")
  g.addColorStop(1, "#240042")
  x.fillStyle = g
  x.fillRect(0, 0, w, h)

  const L = [
    { cx: 150, cy: 130, color: `hsla(${200 + s * 40},100%,60%,0.25)` },
    { cx: w - 150, cy: 130, color: `hsla(${280 + s * 30},100%,65%,0.25)` },
    { cx: 150, cy: h - 130, color: `hsla(${330 + s * 40},100%,70%,0.25)` },
    { cx: w - 150, cy: h - 130, color: `hsla(${190 + s * 30},100%,65%,0.25)` }
  ]
  for (const l of L) {
    const g = x.createRadialGradient(l.cx, l.cy, 0, l.cx, l.cy, 220)
    g.addColorStop(0, l.color)
    g.addColorStop(1, "transparent")
    x.fillStyle = g
    x.fillRect(l.cx - 220, l.cy - 220, 440, 440)
  }

  const t = x.createLinearGradient(0, 0, w, 0)
  t.addColorStop(0, `hsl(${280 + s * 30},100%,70%)`)
  t.addColorStop(0.5, `hsl(${320 + s * 40},100%,70%)`)
  t.addColorStop(1, `hsl(${180 + s * 60},100%,70%)`)
  x.shadowColor = "#b26cff"
  x.shadowBlur = 10
  x.font = "bold 60px sans-serif"
  x.fillStyle = t
  x.textAlign = "center"
  x.fillText("Profile Card TikTok", w / 2, 90)
  x.shadowBlur = 0

  const a = await loadImage(A)
  const r = 150, cx = 270, cy = 320
  const gl = x.createRadialGradient(cx, cy, 60, cx, cy, 220)
  gl.addColorStop(0, "#00ffff33")
  gl.addColorStop(1, "transparent")
  x.fillStyle = gl
  x.fillRect(cx - 220, cy - 220, 440, 440)
  x.save()
  x.beginPath()
  x.arc(cx, cy, r, 0, Math.PI * 2)
  x.clip()
  x.drawImage(a, cx - r, cy - r, r * 2, r * 2)
  x.restore()

  const av = x.createLinearGradient(cx - r, cy - r, cx + r, cy + r)
  av.addColorStop(0, "#00ccff")
  av.addColorStop(0.5, "#9966ff")
  av.addColorStop(1, "#ff66cc")
  x.lineWidth = 5
  x.strokeStyle = av
  x.beginPath()
  x.arc(cx, cy, r, 0, Math.PI * 2)
  x.stroke()

  const gr = x.createLinearGradient(400, 240, 900, 260)
  gr.addColorStop(0, "#00ccff")
  gr.addColorStop(0.5, "#9966ff")
  gr.addColorStop(1, "#ff66cc")
  x.shadowColor = "#9966ff"
  x.shadowBlur = 10
  x.fillStyle = gr
  x.font = "bold 64px sans-serif"
  x.textAlign = "left"
  x.fillText("@" + u.uid, 440, 280)
  x.shadowBlur = 0
  x.font = "30px sans-serif"
  x.fillStyle = "#aaa"
  x.fillText("TikTok User", 440, 325)

  const S = [
    { v: num(u.fl), t: "Followers" },
    { v: num(u.fg), t: "Following" },
    { v: num(u.heart), t: "Hearts" }
  ]
  const bw = 240, bh = 110, gp = 130
  const tw = S.length * bw + (S.length - 1) * gp
  const sx = (w - tw) / 2
  const y = 480

  for (const s of S) {
    const i = S.indexOf(s)
    const bx = sx + i * (bw + gp)
    rect(x, bx, y, bw, bh, 20)
    x.fillStyle = "rgba(255,255,255,0.06)"
    x.fill()

    const lg = x.createLinearGradient(bx, y, bx + bw, y + bh)
    lg.addColorStop(0, "#00ccff")
    lg.addColorStop(0.5, "#9966ff")
    lg.addColorStop(1, "#ff66cc")
    x.strokeStyle = lg
    x.lineWidth = 1.8
    x.stroke()

    x.font = "bold 42px sans-serif"
    x.fillStyle = "#fff"
    x.textAlign = "left"
    x.fillText(s.v, bx + 25, y + 58)
    x.font = "26px sans-serif"
    x.fillStyle = "#aaa"
    x.fillText(s.t, bx + 25, y + 90)
  }

  const qrD = await q.toDataURL(`https://www.tiktok.com/@${u.uid}`)
  const Q = await loadImage(qrD)
  const qx = w - 310, qy = 160
  const qrG = x.createLinearGradient(qx - 10, qy - 10, qx + 180, qy + 180)
  qrG.addColorStop(0, `hsl(${280 + s * 30},100%,70%)`)
  qrG.addColorStop(0.5, `hsl(${320 + s * 40},100%,70%)`)
  qrG.addColorStop(1, `hsl(${180 + s * 60},100%,70%)`)
  x.lineWidth = 4
  x.strokeStyle = qrG
  rect(x, qx - 10, qy - 10, 180, 180, 18)
  x.stroke()
  x.fillStyle = "#101014"
  rect(x, qx - 10, qy - 10, 180, 180, 18)
  x.fill()
  x.drawImage(Q, qx, qy, 160, 160)

  const fG = x.createLinearGradient(w - 200, h - 50, w - 60, h - 20)
  fG.addColorStop(0, "#00ccff")
  fG.addColorStop(0.5, "#9966ff")
  fG.addColorStop(1, "#ff66cc")
  const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 500)
  x.shadowColor = `rgba(153,102,255,${pulse})`
  x.shadowBlur = 10
  x.font = "22px sans-serif"
  x.fillStyle = fG
  x.textAlign = "right"
  x.fillText("lechii", w - 50, h - 25)

  const out = p.join(C, `tiktok_${Date.now()}.png`)
  f.writeFileSync(out, c.toBuffer())
  return out
}

module.exports.run = async ({ api, event, args }) => {
  const { threadID: t, messageID: m } = event
  const u = args.join(" ").trim()
  if (!u) return api.sendMessage("⚠️ Dùng: tikinfo <username>", t, m)
  try {
    const i = await fetchUser(getId(u))
    const A = await getAvatar(i.ava)
    const o = await makeCard(i, A)
    api.sendMessage({ body: `${i.name} (@${i.uid})`, attachment: f.createReadStream(o) }, t, () => {
      f.unlinkSync(A)
      f.unlinkSync(o)
    }, m)
  } catch (e) {
    api.sendMessage("❎ Lỗi: " + e.message, t, m)
  }
}
