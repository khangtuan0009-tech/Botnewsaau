const moment = require("moment-timezone");

module.exports.config = {
  name: "setunsend",
  version: "1.0.3",
  hasPermssion: 1,
  credits: "nvh",
  description: "Đặt lại icon unsend cho nhóm",
  commandCategory: "Nhóm",
  usages: "[icon/reset]",
  cooldowns: 5,
  usePrefix: true
};

module.exports.languages = {
  "vi": {
    "successChange": "☑️ Đã thay đổi icon unsend của nhóm thành: %1",
    "missingInput": "⚠️ Vui lòng nhập icon mới để thay đổi icon unsend của nhóm",
    "resetIcon": "☑️ Đã reset icon unsend về mặc định: %1",
    "confirmChange": "📝 Bạn đang yêu cầu set icon unsend mới: %1\n👉 Reaction tin nhắn này để xác nhận",
    "disabled": "⚙️ Tính năng icon unsend hiện đang bị tắt trong config!"
  }
};

module.exports.handleEvent = async function ({ api, event }) {
  const { threadID, body } = event;
  if (typeof body !== 'string') return;

  const cfg = global.config.iconUnsend || {};
  if (!cfg.status) return; // tính năng bị tắt

  const gio = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || DD/MM/YYYY");
  const defaultIcon = cfg.icon || "👍";
  const icon = global.data.threadData.get(threadID)?.ICON_UNSEND || defaultIcon;

  if (
    body.toLowerCase() === "iconunsend" ||
    body.toLowerCase() === "icon unsend là gì" ||
    body.toLowerCase() === "icon unsend bot" ||
    body.toLowerCase() === "icon unsend?"
  ) {
    const msg = `🗑️ Icon unsend hiện tại của nhóm: ${icon}\n📎 Icon mặc định: ${defaultIcon}\n⏰ Time: ${gio}`;
    api.sendMessage(msg, threadID, event.messageID);
  }
};

module.exports.handleReaction = async function ({ api, event, Threads, handleReaction, getText }) {
  try {
    if (event.userID !== handleReaction.author) return;
    const { threadID } = event;

    const cfg = global.config.iconUnsend || {};
    if (!cfg.status) return api.sendMessage(getText("disabled"), threadID);

    let data = (await Threads.getData(String(threadID))).data || {};
    data["ICON_UNSEND"] = handleReaction.ICON_UNSEND;
    await Threads.setData(threadID, { data });
    await global.data.threadData.set(String(threadID), data);

    return api.sendMessage(getText("successChange", handleReaction.ICON_UNSEND), threadID);
  } catch (e) {
    console.log(e);
  }
};

module.exports.run = async ({ api, event, args, Threads, getText }) => {
  const cfg = global.config.iconUnsend || {};
  const defaultIcon = cfg.icon || "👍";

  if (!cfg.status)
    return api.sendMessage(getText("disabled"), event.threadID, event.messageID);

  if (typeof args[0] === "undefined")
    return api.sendMessage(getText("missingInput"), event.threadID, event.messageID);

  const icon = args[0].trim();
  if (!icon)
    return api.sendMessage(getText("missingInput"), event.threadID, event.messageID);

  if (icon === "-r") {
    let data = (await Threads.getData(event.threadID)).data || {};
    data["ICON_UNSEND"] = defaultIcon;
    await Threads.setData(event.threadID, { data });
    await global.data.threadData.set(String(event.threadID), data);

    return api.sendMessage(getText("resetIcon", defaultIcon), event.threadID, event.messageID);
  } else {
    return api.sendMessage(getText("confirmChange", icon), event.threadID, (err, info) => {
      global.client.handleReaction.push({
        name: "setunsend",
        messageID: info.messageID,
        author: event.senderID,
        ICON_UNSEND: icon
      });
    });
  }
};