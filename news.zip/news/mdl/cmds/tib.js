/**
 * testib.js
 * Gửi tin nhắn riêng (inbox) tới người dùng gọi lệnh.
 *
 * Cách dùng:
 *  - Trong nhóm:  .testib [nội dung]  -> bot sẽ gửi nội dung vào inbox của người dùng gọi lệnh
 *  - Trong PM với bot: .testib [nội dung] -> bot trả lời trong chính thread PM
 *
 * Nếu không truyền [nội dung], bot sẽ gửi nội dung mặc định.
 */

module.exports.config = {
  name: "test",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "GPT-5 Thinking mini & bạn",
  description: "Test gửi tin nhắn riêng (inbox) tới người gọi lệnh",
  commandCategory: "Box",
  usages: "[nội dung tùy chọn]",
  cooldowns: 3,
  usePrefix: true
};

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID, senderID, isGroup } = event;
  const text = args.join(" ").trim() || "Đây là tin nhắn test inbox từ bot.";

  // Nếu đang ở trong group -> gửi inbox tới sender
  if (isGroup) {
    try {
      // Gửi tin nhắn vào inbox user (to = senderID)
      await api.sendMessage({
        body: `📮 TEST IB\n\nNội dung: ${text}\n\n(Được gửi bởi bot tại request từ group ${threadID})`
      }, senderID);

      // Thông báo lại trong group rằng đã gửi thành công (không tiết lộ nội dung inbox)
      return api.sendMessage(`✅ Đã gửi tin nhắn riêng tới bạn. Kiểm tra hộp thư (inbox) nhé.`, threadID, messageID);
    } catch (err) {
      // Thường lỗi xảy ra khi user chặn bot hoặc không cho phép nhận tin
      console.error("Lỗi gửi inbox:", err);
      return api.sendMessage(`❌ Không thể gửi tin nhắn riêng. Có thể người dùng đã chặn bot hoặc bot không có quyền gửi tin nhắn riêng.`, threadID, messageID);
    }
  } else {
    // Nếu đang ở PM (không phải group) -> trả lời ngay trong thread
    return api.sendMessage(`📮 TEST PM\n\nNội dung: ${text}`, threadID, messageID);
  }
};