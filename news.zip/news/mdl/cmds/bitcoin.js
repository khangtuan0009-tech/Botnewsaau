const fs = require("fs-extra");
const axios = require("axios");

module.exports.config = {
    name: "bitcoin",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Kaori Waguri",
    description: "Bitcoin ảo với AI quản lý giá và biểu đồ thời gian thực",
    commandCategory: "Khác",
    usages: "bitcoin [mua/ban/gia/bieu-do/vi/lich-su/tin-tuc]",
    cooldowns: 5,
  usePrefix: true,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
};

// Cấu hình API Cohere
const COHERE_API_KEY = "D0O5lqckf50p3kdODOUMNL333dn0mPYYyqAXuMTd";
const COHERE_API_URL = "https://api.cohere.ai/v1/generate";

// Hàm làm sạch text
function cleanText(text) {
    if (!text) return "";
    return text
        .replace(/[^\w\s.,!?-]/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

// Hàm gọi Cohere AI để quản lý giá Bitcoin
async function getCoherePrice() {
    try {
        console.log("Đang gọi Cohere API...");

        const response = await axios.post(COHERE_API_URL, {
            model: "command",
            prompt: "Tạo giá Bitcoin hiện tại trong khoảng 45000-75000 USD. Chỉ trả về số tiền, không có text khác. Ví dụ: 52847.23",
            max_tokens: 20,
            temperature: 0.8,
            stop_sequences: ["\n"]
        }, {
            headers: {
                'Authorization': `Bearer ${COHERE_API_KEY}`,
                'Content-Type': 'application/json'
            },
            timeout: 15000
        });

        console.log("Cohere response:", response.data);

        const priceText = response.data.generations[0].text.trim();
        const price = parseFloat(priceText.replace(/[^0-9.]/g, ""));

        const finalPrice = isNaN(price) ? (Math.random() * 30000 + 45000) : price;
        console.log("Final price:", finalPrice);
        return finalPrice;

    } catch (error) {
        console.log("Lỗi Cohere API:", error.message);
        // Fallback price
        return Math.random() * 30000 + 45000;
    }
}

// Hàm tạo tin tức Bitcoin bằng Cohere
async function getBitcoinNews() {
    try {
        const response = await axios.post(COHERE_API_URL, {
            model: "command",
            prompt: "Tạo tin tức Bitcoin ngắn gọn trong ngày hôm nay (2-3 câu). Nội dung tích cực hoặc tiêu cực ngẫu nhiên về thị trường crypto.",
            max_tokens: 100,
            temperature: 0.9
        }, {
            headers: {
                'Authorization': `Bearer ${COHERE_API_KEY}`,
                'Content-Type': 'application/json'
            },
            timeout: 15000
        });

        return cleanText(response.data.generations[0].text.trim());
    } catch (error) {
        console.log("Lỗi tin tức:", error.message);
        return "Thị trường Bitcoin đang có những biến động thú vị trong ngày hôm nay!";
    }
}

// Hàm lưu/đọc dữ liệu Bitcoin
function getBitcoinData() {
    const dataPath = __dirname + "/cache/bitcoin_data.json";
    try {
        if (!fs.existsSync(__dirname + "/cache")) {
            fs.mkdirSync(__dirname + "/cache");
        }

        if (!fs.existsSync(dataPath)) {
            const initialData = {
                prices: [],
                userWallets: {},
                lastUpdate: Date.now()
            };
            fs.writeFileSync(dataPath, JSON.stringify(initialData, null, 2));
            return initialData;
        }
        return JSON.parse(fs.readFileSync(dataPath));
    } catch (error) {
        console.log("Lỗi đọc data:", error.message);
        return {
            prices: [],
            userWallets: {},
            lastUpdate: Date.now()
        };
    }
}

function saveBitcoinData(data) {
    const dataPath = __dirname + "/cache/bitcoin_data.json";
    try {
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.log("Lỗi lưu data:", error.message);
        return false;
    }
}

// Hàm cập nhật giá Bitcoin
async function updateBitcoinPrice() {
    try {
        const data = getBitcoinData();
        const newPrice = await getCoherePrice();
        const timestamp = Date.now();

        data.prices.push({
            price: newPrice,
            timestamp: timestamp,
            time: new Date().toLocaleString("vi-VN")
        });

        // Giữ lại 50 giá gần nhất
        if (data.prices.length > 50) {
            data.prices = data.prices.slice(-50);
        }

        data.lastUpdate = timestamp;
        saveBitcoinData(data);
        return newPrice;
    } catch (error) {
        console.log("Lỗi cập nhật giá:", error.message);
        return 50000; // Giá mặc định
    }
}

// Hàm tạo biểu đồ đơn giản (text-based)
async function createSimpleChart() {
    try {
        const data = getBitcoinData();
        let prices = data.prices.slice(-10); // 10 điểm gần nhất

        if (prices.length < 5) {
            // Tạo dữ liệu mẫu nếu chưa có đủ
            for (let i = 0; i < 10; i++) {
                const price = await getCoherePrice();
                prices.push({
                    price: price,
                    timestamp: Date.now() - (10 - i) * 3600000,
                    time: new Date(Date.now() - (10 - i) * 3600000).toLocaleString("vi-VN")
                });
            }
            data.prices = prices;
            saveBitcoinData(data);
        }

        let chart = "📈 BIỂU ĐỒ BITCOIN (10 điểm gần nhất)\n";
        chart += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

        for (let i = 0; i < prices.length; i++) {
            const price = prices[i].price;
            const trend = i > 0 ? (price > prices[i-1].price ? "📈" : "📉") : "➡️";
            chart += `${trend} $${price.toFixed(2)} - ${prices[i].time.split(' ')[1]}\n`;
        }

        return chart;
    } catch (error) {
        console.log("Lỗi tạo biểu đồ:", error.message);
        return "📈 Không thể tạo biểu đồ lúc này";
    }
}

module.exports.run = async ({ event, api, args, Currencies }) => {
    const { threadID, senderID, messageID } = event;
    const command = args[0] || "gia";

    console.log(`Bitcoin command: ${command}, User: ${senderID}`);

    try {
        // Kiểm tra Currencies module
        if (!Currencies) {
            return api.sendMessage("❌ Hệ thống tiền tệ chưa sẵn sàng! Vui lòng thử lại sau.", threadID, messageID);
        }

        switch (command.toLowerCase()) {
            case "gia":
            case "price": {
                console.log("Xử lý lệnh giá...");
                api.sendMessage("💰 Đang cập nhật giá Bitcoin...", threadID, messageID);

                const currentPrice = await updateBitcoinPrice();
                const data = getBitcoinData();
                const prices = data.prices;

                let changeText = "";
                if (prices.length > 1) {
                    const prevPrice = prices[prices.length - 2].price;
                    const change = ((currentPrice - prevPrice) / prevPrice) * 100;
                    const emoji = change >= 0 ? "📈" : "📉";
                    changeText = `\n${emoji} Thay đổi: ${change >= 0 ? '+' : ''}${change.toFixed(2)}%`;
                }

                const message = `
╭─────────────────────╮
│    🪙 GIÁ BITCOIN HIỆN TẠI 🪙    │
╰─────────────────────╯

💰 Giá: $${currentPrice.toFixed(2)}
⏰ Cập nhật: ${new Date().toLocaleString("vi-VN")}${changeText}

🎯 Lệnh khả dụng:
• !bitcoin mua [số lượng] - Mua Bitcoin
• !bitcoin ban [số lượng] - Bán Bitcoin  
• !bitcoin vi - Xem ví Bitcoin
• !bitcoin bieu-do - Xem biểu đồ
• !bitcoin tin-tuc - Tin tức Bitcoin
`;

                return api.sendMessage(message, threadID, messageID);
            }

            case "mua":
            case "buy": {
                const amount = parseFloat(args[1]);
                if (!amount || amount <= 0) {
                    return api.sendMessage("❌ Vui lòng nhập số lượng Bitcoin hợp lệ!\nVí dụ: !bitcoin mua 0.1", threadID, messageID);
                }

                const currentPrice = await updateBitcoinPrice();
                const totalCost = amount * currentPrice;

                try {
                    const userData = await Currencies.getData(senderID);
                    if (!userData || userData.money < totalCost) {
                        return api.sendMessage(`❌ Bạn không đủ tiền để mua ${amount} Bitcoin!\n💰 Cần: $${totalCost.toFixed(2)}\n💳 Có: $${userData ? userData.money : 0}`, threadID, messageID);
                    }

                    // Trừ tiền và cập nhật ví Bitcoin
                    await Currencies.decreaseMoney(senderID, Math.floor(totalCost));

                    const bitcoinData = getBitcoinData();
                    if (!bitcoinData.userWallets[senderID]) {
                        bitcoinData.userWallets[senderID] = {
                            bitcoin: 0,
                            totalInvested: 0,
                            transactions: []
                        };
                    }

                    bitcoinData.userWallets[senderID].bitcoin += amount;
                    bitcoinData.userWallets[senderID].totalInvested += totalCost;
                    bitcoinData.userWallets[senderID].transactions.push({
                        type: "mua",
                        amount: amount,
                        price: currentPrice,
                        total: totalCost,
                        time: new Date().toLocaleString("vi-VN")
                    });

                    saveBitcoinData(bitcoinData);

                    const message = `
╭─────────────────────╮
│    ✅ MUA BITCOIN THÀNH CÔNG    │
╰─────────────────────╯

🪙 Đã mua: ${amount} BTC
💰 Giá: $${currentPrice.toFixed(2)}/BTC
💸 Tổng chi phí: $${totalCost.toFixed(2)}
📊 Bitcoin hiện có: ${bitcoinData.userWallets[senderID].bitcoin.toFixed(6)} BTC
⏰ ${new Date().toLocaleString("vi-VN")}
`;

                    return api.sendMessage(message, threadID, messageID);

                } catch (error) {
                    console.log("Lỗi mua Bitcoin:", error.message);
                    return api.sendMessage("❌ Có lỗi xảy ra khi mua Bitcoin. Vui lòng thử lại!", threadID, messageID);
                }
            }

            case "ban":
            case "sell": {
                const amount = parseFloat(args[1]);
                if (!amount || amount <= 0) {
                    return api.sendMessage("❌ Vui lòng nhập số lượng Bitcoin hợp lệ!\nVí dụ: !bitcoin ban 0.1", threadID, messageID);
                }

                const bitcoinData = getBitcoinData();
                const userWallet = bitcoinData.userWallets[senderID];

                if (!userWallet || userWallet.bitcoin < amount) {
                    return api.sendMessage(`❌ Bạn không đủ Bitcoin để bán!\n🪙 Cần: ${amount} BTC\n📊 Có: ${userWallet ? userWallet.bitcoin.toFixed(6) : 0} BTC`, threadID, messageID);
                }

                try {
                    const currentPrice = await updateBitcoinPrice();
                    const totalEarn = amount * currentPrice;

                    // Cộng tiền và trừ Bitcoin
                    await Currencies.increaseMoney(senderID, Math.floor(totalEarn));

                    userWallet.bitcoin -= amount;
                    userWallet.transactions.push({
                        type: "ban",
                        amount: amount,
                        price: currentPrice,
                        total: totalEarn,
                        time: new Date().toLocaleString("vi-VN")
                    });

                    saveBitcoinData(bitcoinData);

                    const message = `
╭─────────────────────╮
│    ✅ BÁN BITCOIN THÀNH CÔNG    │
╰─────────────────────╯

🪙 Đã bán: ${amount} BTC
💰 Giá: $${currentPrice.toFixed(2)}/BTC
💸 Tổng thu được: $${totalEarn.toFixed(2)}
📊 Bitcoin còn lại: ${userWallet.bitcoin.toFixed(6)} BTC
⏰ ${new Date().toLocaleString("vi-VN")}
`;

                    return api.sendMessage(message, threadID, messageID);

                } catch (error) {
                    console.log("Lỗi bán Bitcoin:", error.message);
                    return api.sendMessage("❌ Có lỗi xảy ra khi bán Bitcoin. Vui lòng thử lại!", threadID, messageID);
                }
            }

            case "vi":
            case "wallet": {
                const bitcoinData = getBitcoinData();
                const userWallet = bitcoinData.userWallets[senderID];
                const currentPrice = await updateBitcoinPrice();

                if (!userWallet || userWallet.bitcoin === 0) {
                    return api.sendMessage("📊 Ví Bitcoin của bạn đang trống!\nSử dụng !bitcoin mua [số lượng] để mua Bitcoin", threadID, messageID);
                }

                const currentValue = userWallet.bitcoin * currentPrice;
                const profit = currentValue - userWallet.totalInvested;
                const profitPercent = (profit / userWallet.totalInvested) * 100;

                const message = `
╭─────────────────────╮
│    📊 VÍ BITCOIN CỦA BẠN    │
╰─────────────────────╯

🪙 Bitcoin: ${userWallet.bitcoin.toFixed(6)} BTC
💰 Giá trị hiện tại: $${currentValue.toFixed(2)}
💸 Tổng đầu tư: $${userWallet.totalInvested.toFixed(2)}
📈 Lãi/Lỗ: $${profit.toFixed(2)} (${profitPercent.toFixed(2)}%)
⏰ Cập nhật: ${new Date().toLocaleString("vi-VN")}

📝 Giao dịch: ${userWallet.transactions.length} lần
`;

                return api.sendMessage(message, threadID, messageID);
            }

            case "bieu-do":
            case "chart": {
                api.sendMessage("📊 Đang tạo biểu đồ Bitcoin...", threadID, messageID);

                const chart = await createSimpleChart();
                return api.sendMessage(chart, threadID, messageID);
            }

            case "tin-tuc":
            case "news": {
                api.sendMessage("📰 Đang tải tin tức Bitcoin...", threadID, messageID);

                const news = await getBitcoinNews();
                const currentPrice = await updateBitcoinPrice();

                const message = `
╭─────────────────────╮
│    📰 TIN TỨC BITCOIN    │
╰─────────────────────╯

${news}

💰 Giá hiện tại: $${currentPrice.toFixed(2)}
⏰ ${new Date().toLocaleString("vi-VN")}

💡 Sử dụng !bitcoin gia để xem chi tiết!
`;

                return api.sendMessage(message, threadID, messageID);
            }

            case "lich-su":
            case "history": {
                const bitcoinData = getBitcoinData();
                const userWallet = bitcoinData.userWallets[senderID];

                if (!userWallet || userWallet.transactions.length === 0) {
                    return api.sendMessage("📝 Bạn chưa có giao dịch Bitcoin nào!", threadID, messageID);
                }

                let message = `
╭─────────────────────╮
│    📝 LỊCH SỬ GIAO DỊCH    │
╰─────────────────────╯\n\n`;

                const recentTransactions = userWallet.transactions.slice(-10).reverse();

                for (const tx of recentTransactions) {
                    const emoji = tx.type === "mua" ? "🛒" : "💰";
                    message += `${emoji} ${tx.type.toUpperCase()}: ${tx.amount} BTC\n`;
                    message += `   💵 $${tx.price.toFixed(2)}/BTC = $${tx.total.toFixed(2)}\n`;
                    message += `   ⏰ ${tx.time}\n\n`;
                }

                return api.sendMessage(message, threadID, messageID);
            }

            default: {
                const helpMessage = `
╭─────────────────────╮
│    🪙 BITCOIN VIP PREMIUM    │
╰─────────────────────╯

📋 LỆNH SỬ DỤNG:

💰 !bitcoin gia - Xem giá hiện tại
🛒 !bitcoin mua [số lượng] - Mua Bitcoin
💸 !bitcoin ban [số lượng] - Bán Bitcoin
📊 !bitcoin vi - Xem ví Bitcoin
📈 !bitcoin bieu-do - Biểu đồ giá
📰 !bitcoin tin-tuc - Tin tức Bitcoin
📝 !bitcoin lich-su - Lịch sử giao dịch

🎯 Ví dụ: !bitcoin mua 0.5
🤖 AI quản lý giá bởi Cohere
`;

                return api.sendMessage(helpMessage, threadID, messageID);
            }
        }

    } catch (error) {
        console.log("Lỗi chính Bitcoin module:", error);
        return api.sendMessage(`❌ Có lỗi xảy ra: ${error.message}\nVui lòng thử lại sau!`, threadID, messageID);
    }
};