const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "setpr",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "nvh",
  description: "Bật/tắt usePrefix cho 1 hoặc tất cả lệnh",
  commandCategory: "Admin",
  usages: "[tên lệnh/all] [true/false]",
  cooldowns: 5,
  usePrefix: false
};

module.exports.run = async ({ api, event, args, models }) => {
  const { threadID: a, messageID: b } = event;
  if (!args[0])
    return api.sendMessage("📘 Dùng: setpr [tên lệnh/all] [true/false]", a, b);

  const c = args[0].toLowerCase();
  const d = args[1]?.toLowerCase();
  const e = path.join(__dirname, "..");

  const findFile = g => {
    for (const i of fs.readdirSync(g)) {
      const j = path.join(g, i);
      const k = fs.statSync(j);
      if (k.isDirectory()) {
        const l = findFile(j);
        if (l) return l;
      } else if (i === `${c}.js`) return j;
    }
    return null;
  };

  const getAllFiles = g => {
    let h = [];
    for (const i of fs.readdirSync(g)) {
      const j = path.join(g, i);
      const k = fs.statSync(j);
      if (k.isDirectory()) h = h.concat(getAllFiles(j));
      else if (i.endsWith(".js") && !i.startsWith("setpr")) h.push(j);
    }
    return h;
  };

  if (!args[1]) {
    const f = findFile(e);
    if (!f) return api.sendMessage(`❌ Không tìm thấy lệnh "${c}".`, a, b);
    const g = fs.readFileSync(f, "utf8").match(/usePrefix\s*:\s*(true|false)/);
    return api.sendMessage(
      g
        ? `📍 Lệnh "${c}" đang có usePrefix: ${g[1]}`
        : `⚠️ Lệnh "${c}" chưa có usePrefix.`,
      a,
      b
    );
  }

  if (!["true", "false"].includes(d))
    return api.sendMessage("⚠️ Nhập true hoặc false.", a, b);

  const f = d === "true";
  const list = c === "all" ? getAllFiles(e) : [findFile(e)];
  if (!list[0])
    return api.sendMessage(`❌ Không tìm thấy "${c}".`, a, b);

  let edited = 0;
  for (const i of list) {
    let j = fs.readFileSync(i, "utf8");
    let k = false;
    if (/usePrefix\s*:/.test(j)) {
      j = j.replace(/usePrefix\s*:\s*(true|false)/g, `usePrefix: ${f}`);
      k = true;
    } else if (/cooldowns\s*:\s*\d+/.test(j)) {
      j = j.replace(/(cooldowns\s*:\s*\d+)/, `$1,\n  usePrefix: ${f}`);
      k = true;
    } else if (/module\.exports\.config\s*=\s*{/.test(j)) {
      j = j.replace(/module\.exports\.config\s*=\s*{/, m => `${m}\n  usePrefix: ${f},`);
      k = true;
    }
    if (k) fs.writeFileSync(i, j, "utf8"), edited++;
  }

  if (!edited)
    return api.sendMessage("⚠️ Không có file nào thay đổi.", a, b);

  try {
    const load = require(path.join(__dirname, "load.js"));
    load.run({ api, event: { threadID: a, messageID: b }, args: [c], models, silent: !0 });
    api.sendMessage(`✅ Đã sửa usePrefix=${f} cho lệnh "${c}"\n🔄 Load thành công "${c}"`, a, b);
  } catch (err) {
    api.sendMessage(`✅ Đã sửa usePrefix=${f} cho lệnh "${c}"\n⚠️ Nhưng lỗi reload: ${err.message}`, a, b);
  }
};
