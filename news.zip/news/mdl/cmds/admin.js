const axios = require('axios');
const path = require("path");
const fs = require("fs-extra");
const moment = require("moment-timezone");
const cron = require('node-cron');

module.exports.config = {
  name: "admin",
  version: "1.0.5",
  hasPermssion: 0,
  credits: "Mirai Team",
  description: "Bật tắt chế độ quản lý admin/ndh/qtv",
  commandCategory: "Admin",
  usages: "",
  usePrefix: true,
  cooldowns: 5,
  dependencies: {
    "fs-extra": "",
    "moment-timezone": "",
    "axios": "",
    "node-cron": ""
  }
};

module.exports.languages = {
  "vi": {
    "addedNewNDH": 'Đã thêm thành công %1 người dùng trở thành Người hỗ trợ\n\n%2',
    "listAdmin": `[ Danh Sách Admin ]\n────────────────\n\n%1\n\n\n[ Người điều hành ]\n────────────────\n\n%2`,
    "notHavePermssion": 'Bạn không đủ quyền hạn để có thể sử dụng chức năng "%1"',
    "addedNewAdmin": '[ ADD NEW ADMIN ]\n───────────────\n📝 Thêm thành công %1 người dùng trở thành admin bot\n\n%2\n───────────────\n[⏰] → Time: %3',
    "removedAdmin": '[ REMOVE ADMIN ]\n───────────────\n📝 Gỡ thành công %1 người dùng trở lại làm thành viên\n\n%2\n───────────────\n[⏰] → Time: %3',
    "removedNDH": 'MODE - Đã gỡ thành công vai trò Người hỗ trợ %1 người dùng trở lại làm thành viên\n\n%2'
  },
  "en": {
    "listAdmin": '[Admin] Admin list: \n\n%1',
    "notHavePermssion": '[Admin] You have no permission to use "%1"',
    "addedNewAdmin": '[Admin] Added %1 Admin :\n\n%2',
    "removedAdmin": '[Admin] Remove %1 Admin:\n\n%2'
  }
};

const expPath = path.join(__dirname, "data", "adminlist.json")
if (!fs.existsSync(expPath)) fs.writeFileSync(expPath, JSON.stringify({}, null, 2))

function calcExpire(date) {
  if (date === "Vĩnh viễn") return { status: "👑 Vĩnh viễn", hours: null };
  const now = moment().tz("Asia/Ho_Chi_Minh");
  const end = moment(date, ["DD/MM/YYYY HH:mm:ss", "DD/MM/YYYY"]);
  if (!end.isValid()) return { status: "❌ Không hợp lệ", hours: null };

  const diffMs = end.diff(now);
  if (diffMs <= 0) return { status: "📌 Hết hạn", hours: 0 };

  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffHours < 1) {
    return { status: `✅ Còn ${diffMinutes} phút`, hours: diffHours };
  } else if (diffHours < 24) {
    const h = diffHours;
    const m = diffMinutes % 60;
    return { status: `✅ Còn ${h} giờ ${m} phút`, hours: diffHours };
  } else {
    const d = diffDays;
    const h = diffHours % 24;
    return { status: `✅ Còn ${d} ngày ${h} giờ`, hours: diffHours };
  }
}

function saveExpire(id, role, expire) {
  const d = fs.existsSync(expPath)?JSON.parse(fs.readFileSync(expPath)):{}
  d[id] = {role, expire}
  fs.writeFileSync(expPath, JSON.stringify(d,null,2))
}

function getExpire(id) {
  const d = fs.existsSync(expPath)?JSON.parse(fs.readFileSync(expPath)):{}
  return d[id]?.expire || "Vĩnh viễn"
}

function parseExpire(arg) {
  if (!arg) return "Vĩnh viễn";
  arg = arg.toLowerCase().trim();
  if (["vv", "vĩnhviễn", "vĩnh viễn"].includes(arg)) return "Vĩnh viễn";
  const now = moment().tz("Asia/Ho_Chi_Minh");
  const n = parseInt(arg);
  if (isNaN(n)) return "Vĩnh viễn";
  if (arg.endsWith("h")) return now.add(n, "hours").format("DD/MM/YYYY HH:mm:ss");
  if (arg.endsWith("d")) return now.add(n, "days").format("DD/MM/YYYY HH:mm:ss");
  if (arg.endsWith("m")) return now.add(n, "months").format("DD/MM/YYYY HH:mm:ss");
  if (arg.endsWith("y")) return now.add(n, "years").format("DD/MM/YYYY HH:mm:ss");
  return now.add(n, "hours").format("DD/MM/YYYY HH:mm:ss"); // nếu chỉ số => giờ
}


async function sendFriendRequest(api, botID, targetUID) {
  try {
    const response = JSON.parse(await api.httpPost('https://www.facebook.com/api/graphql/', {
      av: botID, fb_api_caller_class: "RelayModern", fb_api_req_friendly_name: "FriendingCometFriendRequestSendMutation", doc_id: "5090693304332268",
      variables: JSON.stringify({ input: { friend_requestee_ids: [targetUID], refs: ["PROFILE_PLUS_FRIEND_BUTTON"], source: "profile_button", warn_ack_for_ids: [], actor_id: botID, client_mutation_id: Math.round(Math.random() * 19).toString() }, scale: 1.5 })
    }));
    return !!(response.data?.friending_comet_friend_request_send);
  } catch {
    return false;
  }
}

async function createPrivateGroupForUser(api, botID, userID, groupName) {
  return new Promise(resolve => api.createNewGroup([botID, userID], groupName, (err, newThreadID) => resolve(err ? null : newThreadID)));
}

async function removeUserFromSpecificGroup(api, userID, threadID) {
  try {
    await new Promise(r => setTimeout(r, 1500));
    await api.removeUserFromGroup(userID, threadID);
    return true;
  } catch {
    return false;
  }
}

module.exports.run = async ({ api, event, args, Users, permssion, getText }) => {
  const { senderID, threadID, messageID, messageReply, mentions, type } = event;
  const { configPath } = global.client;
  const { writeFileSync } = require('fs-extra');

  if (!global.config.ADMINBOT) global.config.ADMINBOT = [];
  if (!global.config.NDH) global.config.NDH = [];
  if (!global.config.run) global.config.run = [];

  const { ADMINBOT, NDH, run } = global.config;
  const mention = Object.keys(mentions);
  const content = args.slice(1);
  const gio = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY - HH:mm:ss");

  delete require.cache[require.resolve(configPath)];
  var config = require(configPath);

  const isMainAdmin = () => senderID == 100073639420918;
  const checkPermission = (level) => permssion >= level;

  if (args.length == 0) {
    return api.sendMessage(`[ ADMIN CONFIG SETTING ]
────────────────
${global.config.PREFIX}admin add → Thêm Admin
${global.config.PREFIX}admin remove → Gỡ Admin
${global.config.PREFIX}admin addndh → Thêm NDH
${global.config.PREFIX}admin removendh → Gỡ NDH
${global.config.PREFIX}admin list → Xem danh sách Admin/NDH
${global.config.PREFIX}admin qtvonly → Bật/tắt chỉ QTV dùng Bot
${global.config.PREFIX}admin ndhonly → Bật/tắt chỉ NDH dùng Bot
${global.config.PREFIX}admin only → Bật/tắt chỉ Admin dùng Bot
${global.config.PREFIX}admin reload [time] → Khởi động lại bot
${global.config.PREFIX}admin echo [text] → Nhắn văn bản
${global.config.PREFIX}admin rename [mdl] [new] → Đổi tên modules
${global.config.PREFIX}admin del [mdl] → Xoá module
${global.config.PREFIX}admin ship [mdl] + [tag/reply] → Ship module`,
      threadID, messageID);
    }

  switch (args[0]) {
    case 'ghichu': {
      if (!isMainAdmin()) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, threadID, messageID);
      if (args[1] && args[1].endsWith(".js")) {
        fs.readFile(`${__dirname}/${args[1]}`, "utf-8", async (err, data) => {
          if (err) return api.sendMessage(`Lệnh ${args[1]} không tồn tại!.`, threadID, messageID);
          try {
            const uuid = require('uuid').v4();
            const url_base = new URL(`https://lechii.online/note/${uuid}`);
            
            await axios(url_base.href, {
              method: "PUT",
              headers: {
                'content-type': 'text/plain; charset=utf-8'
              },
              data: data
            });
            
            const rawUrl = new URL(url_base.href);
            rawUrl.searchParams.append('raw', 'true');

            return api.sendMessage(`✅ Upload thành công!\n🔗 Raw: ${rawUrl.href}`, threadID, messageID);
          } catch (error) {
            return api.sendMessage(`⚠️ Lỗi khi upload lên lechii.online: ${error.message}`, threadID, messageID);
          }
        });
      } else if (args[1]) {
        try {
          const uuid = require('uuid').v4();
          const url_base = new URL(`https://lechii.online/note/${uuid}`);

          await axios(url_base.href, {
            method: "PUT",
            headers: {
              'content-type': 'text/plain; charset=utf-8'
            },
            data: args.slice(1).join(' ')
          });

          const rawUrl = new URL(url_base.href);
          rawUrl.searchParams.append('raw', 'true');

          return api.sendMessage(`✅ Upload thành công!\n🔗 Raw: ${rawUrl.href}`, threadID, messageID);
        } catch (error) {
          return api.sendMessage(`⚠️ Lỗi khi upload lên lechii.online: ${error.message}`, threadID, messageID);
        }
      } else {
        return api.sendMessage("Vui lòng nhập nội dung hoặc tên file .js cần upload!", threadID, messageID);
      }
    } break

    case 'del': {
      if (!isMainAdmin()) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, threadID, messageID);
      if (!args[1]) return api.sendMessage("Vui lòng nhập tên file!", threadID, messageID);
      try {
        fs.unlinkSync(`${__dirname}/${args[1]}.js`);
        return api.sendMessage(`Đã xoá file có tên "${args[1]}.js".`, threadID, messageID);
      } catch (error) {
        return api.sendMessage(`Lỗi khi xóa file: ${error.message}`, threadID, messageID);
      }
    } break
    case "off": {
      if (!isMainAdmin()) 
        return api.sendMessage("⚠️ Lệnh này chỉ admin chính mới dùng được!", threadID, messageID);

      const offPath = path.join(__dirname, "cache", "onoff.json");
      fs.ensureDirSync(path.join(__dirname, "cache"));

      fs.writeFileSync(offPath, JSON.stringify({ status: true, time: Date.now() }, null, 2));
      return api.sendMessage("🛑 Bot đã tạm dừng nhận lệnh. Chỉ admin chính có thể bật lại bằng lệnh: admin on", threadID, messageID);
    } break

    case "on": {
      if (!isMainAdmin()) 
        return api.sendMessage("⚠️ Lệnh này chỉ admin chính mới dùng được!", threadID, messageID);

      const offPath = path.join(__dirname, "cache", "onoff.json");
      if (!fs.existsSync(offPath))
        return api.sendMessage("✅ Bot đang hoạt động bình thường, không cần bật lại.", threadID, messageID);

      fs.writeFileSync(offPath, JSON.stringify({ status: false }, null, 2));
      return api.sendMessage("🚀 Bot đã được bật lại và hoạt động bình thường!", threadID, messageID);
    } break

    case 'ship': {
  if (!isMainAdmin()) return api.sendMessage(`⚠️ Cần quyền Admin để thực hiện lệnh này.`, threadID, messageID);

  const fileName = content[0];
  if (!fileName) return api.sendMessage("Vui lòng nhập tên module cần gửi.", threadID, messageID);

  let targetUID;
  if (type === "message_reply") targetUID = messageReply.senderID;
  else if (Object.keys(mentions).length > 0) targetUID = Object.keys(mentions)[0];
  else return api.sendMessage("Vui lòng tag hoặc reply người bạn muốn ship module cho họ.", threadID, messageID);

  const botID = api.getCurrentUserID();
  if (targetUID === botID) return api.sendMessage("Không thể gửi code cho chính bot.", threadID, messageID);
  if (targetUID === senderID) return api.sendMessage("Không thể tự ship code cho chính mình.", threadID, messageID);

  const filePath = path.join(__dirname, `${fileName}.js`);
  if (!fs.existsSync(filePath)) return api.sendMessage(`⚠️ Module "${fileName}.js" không tồn tại.`, threadID, messageID);

  const targetUserName = await Users.getNameUser(targetUID);
  let finalMessage = "";

  api.sendMessage(`🚀 Đang ship module "${fileName}.js" đến ${targetUserName}...`, threadID, messageID);

  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    await sendFriendRequest(api, botID, targetUID);

    const groupName = `📦 Ship Code - ${fileName}.js cho ${targetUserName}`;
    const privateThreadID = await createPrivateGroupForUser(api, botID, targetUID, groupName);
    if (!privateThreadID) throw new Error(`Không thể tạo nhóm riêng với ${targetUserName}.`);

    await api.sendMessage(
      `😀 Nào bú đi em:\n\`\`\`javascript\n${fileContent}\n\`\`\``,
      privateThreadID
    );

    try {
      const uuid = require('uuid').v4();
      const url_base = new URL(`https://lechii.online/note/${uuid}`);
      await axios(url_base.href, {
        method: "PUT",
        headers: { 'content-type': 'text/plain; charset=utf-8' },
        data: fileContent
      });
      const rawUrl = new URL(url_base.href);
      rawUrl.searchParams.append('raw', 'true');
      await api.sendMessage(
        `📦 File đã được upload lên lechii.online\n🔗 Link: ${url_base.href}\n🧩 Raw: ${rawUrl.href}`,
        privateThreadID
      );
    } catch (e) {
      await api.sendMessage(`⚠️ Không thể upload file lên lechii.online: ${e.message}`, privateThreadID);
    }

    await new Promise(r => setTimeout(r, 2000));
    await removeUserFromSpecificGroup(api, targetUID, privateThreadID);
    await removeUserFromSpecificGroup(api, botID, privateThreadID);

    finalMessage = `✅ Đã ship module "${fileName}.js" thành công cho ${targetUserName}!`;
  } catch (e) {
    finalMessage = `📌 Lỗi khi ship code: ${e.message}`;
  } finally {
    api.sendMessage(finalMessage, threadID, messageID);
  }
}
break

    case "read": {
      if (!isMainAdmin()) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, threadID, messageID);
      if (!args[1]) return api.sendMessage("Vui lòng nhập tên file!", threadID, messageID);
      fs.readFile(`${__dirname}/${args[1]}.js`, "utf-8", (err, data) => {
        if (err) return api.sendMessage(`Đã xảy ra lỗi khi đọc lệnh "${args[1]}.js".`, threadID, messageID);
        api.sendMessage(data, threadID, messageID);
      });
    } break

    case 'echo': {
      const echoContent = content.join(" ");

      if (!echoContent) {
        return api.sendMessage("Vui lòng nhập nội dung cần echo!", threadID, messageID);
      }

      if (Object.keys(mentions).length > 0) {
        let mentionsArray = [];

        for (const mentionID in mentions) {
          const tagName = mentions[mentionID].replace("@", "");
          mentionsArray.push({
            tag: tagName,
            id: mentionID,
            fromIndex: echoContent.indexOf(tagName)
          });
        }

        return api.sendMessage({
          body: echoContent,
          mentions: mentionsArray
        }, threadID, messageID);

      } else {
        return api.sendMessage(echoContent, threadID, messageID);
      }
    } break

    case "reload": {
      if (!isMainAdmin()) return api.sendMessage(`Xin lỗi! lệnh này chỉ admin mới dùng được`, threadID, messageID);
      if (!args[1] || isNaN(args[1])) return api.sendMessage("Vui lòng nhập thời gian hợp lệ (số giây)!", threadID, messageID);

      const reloadTime = parseInt(args[1]);
      api.sendMessage(`Sẽ bật Bot trở lại sau: ${reloadTime} giây nữa!`, threadID, () => process.exit(2 + reloadTime));
    } break;

case 'list':
case 'all': {
  const expPath = path.join(__dirname, "data", "adminlist.json");
  if (!fs.existsSync(expPath)) fs.writeFileSync(expPath, JSON.stringify({}, null, 2));
  const expData = JSON.parse(fs.readFileSync(expPath));

  const listAdmin = ADMINBOT || config.ADMINBOT || [];
  const listNDH = NDH || config.NDH || [];

  if (listAdmin.length == 0 && listNDH.length == 0)
    return api.sendMessage("❎ Chưa có ADMIN hoặc NDH nào trong hệ thống!", threadID, messageID);

  let merged = [];
  let stt = 1;
  let changed = false;

  for (const id of listAdmin) {
    const user = await Users.getData(id);
    const name = user?.name || "Không rõ tên";
    const isNDH = listNDH.includes(id);
    const exp = expData[id]?.expire || "Vĩnh viễn";
    const s = calcExpire(exp);
    if (s.status.includes("Hết hạn")) {
      delete expData[id];
      ADMINBOT.splice(ADMINBOT.indexOf(id), 1);
      config.ADMINBOT = ADMINBOT;
      changed = true;
      continue;
    }
    merged.push({
      stt,
      id,
      name,
      tag: isNDH ? "(Admin Bot + NDH)" : "(Admin Bot)",
      fb: `https://www.facebook.com/profile.php?id=${id}`,
      expire: s.status
    });
    stt++;
  }

  for (const id of listNDH) {
    if (listAdmin.includes(id)) continue;
    const user = await Users.getData(id);
    const name = user?.name || "Không rõ tên";
    const exp = expData[id]?.expire || "Vĩnh viễn";
    const s = calcExpire(exp);
    if (s.status.includes("Hết hạn")) {
      delete expData[id];
      NDH.splice(NDH.indexOf(id), 1);
      config.NDH = NDH;
      changed = true;
      continue;
    }
    merged.push({
      stt,
      id,
      name,
      tag: "(NDH)",
      fb: `https://www.facebook.com/profile.php?id=${id}`,
      expire: s.status
    });
    stt++;
  }

  if (changed) {
    fs.writeFileSync(expPath, JSON.stringify(expData, null, 2));
    fs.writeFileSync(configPath, JSON.stringify(config, null, 4));
  }

  let msg = "📋 DANH SÁCH ADMIN / NDH \n────────────────\n";
  msg += merged
    .map(u => `${u.stt}. ${u.name} ${u.tag}
🔗 ${u.fb}
⏰ ${u.expire}`)
    .join("\n\n");

  return api.sendMessage(msg, threadID, (err, info) => {
    if (err) return;
    global.client.handleReply.push({
      name: this.config.name,
      messageID: info.messageID,
      author: senderID,
      type: "remove_admin_ndh",
      list: merged
    });
  }, messageID);
}
break;

case 'add': {
  if (!checkPermission(3)) 
    return api.sendMessage(getText("notHavePermssion", "add"), threadID, messageID);

  const expPath = path.join(__dirname, "data", "adminlist.json");
  if (!fs.existsSync(expPath)) fs.writeFileSync(expPath, JSON.stringify({}, null, 2));
  
  const saveExpire = (id, role, expire) => {
    const d = JSON.parse(fs.readFileSync(expPath));
    d[id] = { role, expire };
    fs.writeFileSync(expPath, JSON.stringify(d, null, 2));
  };

  if (event.type == "message_reply") {
    const targetId = messageReply.senderID;
    const expireArg = content[0];
    const expireDate = parseExpire(expireArg);
    if (!ADMINBOT.includes(targetId)) {
      ADMINBOT.push(targetId);
      config.ADMINBOT.push(targetId);
    }
    const name = (await Users.getData(targetId)).name;
    saveExpire(targetId, "Admin", expireDate);
    writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
    return api.sendMessage(
      getText("addedNewAdmin", 1, `[👤] → Name: ${name}\n[🔰] → Uid: ${targetId}\n[🕒] → Hết hạn: ${expireDate}`, gio),
      threadID
    );
  }

  else if (mention.length && isNaN(content[0])) {
    const listAdd = [];
    const expireArg = content[content.length - 1];
    const expireDate = parseExpire(expireArg);
    for (const id of mention) {
      if (!ADMINBOT.includes(id)) {
        ADMINBOT.push(id);
        config.ADMINBOT.push(id);
      }
      listAdd.push(`[👤] → Name: ${event.mentions[id]}\n[🔰] → Uid: ${id}`);
      saveExpire(id, "Admin", expireDate);
    }
    writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
    return api.sendMessage(
      getText("addedNewAdmin", mention.length, listAdd.join("\n") + `\n[🕒] → Hết hạn: ${expireDate}`, gio),
      threadID
    );
  }

  else if (content.length && !isNaN(content[0])) {
    const id = content[0];
    const expireArg = content[1];
    const expireDate = parseExpire(expireArg);
    ADMINBOT.push(id);
    config.ADMINBOT.push(id);
    const name = (await Users.getData(id)).name;
    saveExpire(id, "Admin", expireDate);
    writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
    return api.sendMessage(
      getText("addedNewAdmin", 1, `[👤] → Name: ${name}\n[🔰] → Uid: ${id}\n[🕒] → Hết hạn: ${expireDate}`, gio),
      threadID
    );
  }

  return api.sendMessage("Vui lòng tag người dùng hoặc nhập UID!", threadID, messageID);
}
break;


    case 'remove':
    case 'rm': {
      if (!isMainAdmin()) return api.sendMessage(`⚠️ Cần quyền Admin để thực hiện lệnh`, threadID, messageID);
      if (!checkPermission(3)) return api.sendMessage(getText("notHavePermssion", "removeAdmin"), threadID, messageID);

      if (event.type == "message_reply") {
        const targetId = messageReply.senderID;
        const index = config.ADMINBOT.findIndex(item => item.toString() == targetId);
        if (index > -1) {
          ADMINBOT.splice(index, 1);
          config.ADMINBOT.splice(index, 1);
        }
        const name = (await Users.getData(targetId)).name;
        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(getText("removedAdmin", 1, `[👤] → Name: ${name}\n[🔰] → Uid: ${targetId}`, gio), threadID, messageID);
      }
      else if (mention.length && isNaN(content[0])) {
        const listAdd = [];
        for (const id of mention) {
          const index = config.ADMINBOT.findIndex(item => item == id);
          if (index > -1) {
            ADMINBOT.splice(index, 1);
            config.ADMINBOT.splice(index, 1);
          }
          listAdd.push(`[👤] → Name: ${event.mentions[id]}\n[🔰] → Uid: ${id}`);
        }

        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(getText("removedAdmin", mention.length, listAdd.join("\n"), gio), threadID, messageID);
      }
      else if (content.length && !isNaN(content[0])) {
        const index = config.ADMINBOT.findIndex(item => item.toString() == content[0]);
        if (index > -1) {
          ADMINBOT.splice(index, 1);
          config.ADMINBOT.splice(index, 1);
        }
        const name = (await Users.getData(content[0])).name;
        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(getText("removedAdmin", 1, `[👤] → Name: ${name}\n[🔰] → Uid: ${content[0]}`, gio), threadID, messageID);
      }
      return api.sendMessage("Vui lòng tag người dùng hoặc nhập UID!", threadID, messageID);
    }

     case 'qtvonly': {
      if (!checkPermission(1)) 
        return api.sendMessage("❎ Cần quyền Quản trị viên trở lên để dùng lệnh này.", threadID, messageID);

      const dataPath = path.join(__dirname, "data", "dataAdbox.json");
      if (!fs.existsSync(dataPath)) 
        fs.writeFileSync(dataPath, JSON.stringify({ qtvOnly: {}, adminOnly: {}, ndhOnly: {} }, null, 4));

      const dataAdbox = JSON.parse(fs.readFileSync(dataPath, "utf8"));
      dataAdbox.qtvOnly[threadID] = !dataAdbox.qtvOnly[threadID];
      fs.writeFileSync(dataPath, JSON.stringify(dataAdbox, null, 4));

      return api.sendMessage(
        dataAdbox.qtvOnly[threadID]
          ? "✅ Đã bật chế độ **QTV-only** — chỉ Quản Trị Viên, NDH, ADMIN BOT mới được dùng bot trong box này."
          : "✅ Đã tắt chế độ **QTV-only** — tất cả thành viên đều có thể dùng bot.",
        threadID,
        messageID
      );
    }

    case 'only': {
      if (!checkPermission(2)) 
        return api.sendMessage("❎ Cần quyền ADMIN BOT trở lên để dùng lệnh này.", threadID, messageID);

      const dataPath = path.join(__dirname, "data", "data.json");
      if (!fs.existsSync(dataPath)) 
        fs.writeFileSync(dataPath, JSON.stringify({ qtvOnly: {}, adminOnly: {}, ndhOnly: {} }, null, 4));

      const dataAdbox = JSON.parse(fs.readFileSync(dataPath, "utf8"));
      dataAdbox.adminOnly[threadID] = !dataAdbox.adminOnly[threadID];
      fs.writeFileSync(dataPath, JSON.stringify(dataAdbox, null, 4));

      return api.sendMessage(
        dataAdbox.adminOnly[threadID]
          ? "☑️ Đã bật chế độ **ADMIN-only** — chỉ ADMIN BOT hoặc NDH mới được dùng bot trong box này."
          : "☑️ Đã tắt chế độ **ADMIN-only** — tất cả thành viên đều có thể dùng bot.",
        threadID,
        messageID
      );
    }

    case 'ndhonly': {
      if (!checkPermission(3)) 
        return api.sendMessage("❎ Cần quyền NDH (Người Điều Hành) để dùng lệnh này.", threadID, messageID);

      const dataPath = path.join(__dirname, "data", "data.json");
      if (!fs.existsSync(dataPath)) 
        fs.writeFileSync(dataPath, JSON.stringify({ qtvOnly: {}, adminOnly: {}, ndhOnly: {} }, null, 4));

      const dataAdbox = JSON.parse(fs.readFileSync(dataPath, "utf8"));
      dataAdbox.ndhOnly[threadID] = !dataAdbox.ndhOnly[threadID];
      fs.writeFileSync(dataPath, JSON.stringify(dataAdbox, null, 4));

      return api.sendMessage(
        dataAdbox.ndhOnly[threadID]
          ? "☑️ Đã bật chế độ **NDH-only** — chỉ NDH được phép dùng bot trong box này."
          : "☑️ Đã tắt chế độ **NDH-only** — ai cũng có thể dùng bot.",
        threadID,
        messageID
      );
    }

  case "addndh": {
  if (!isMainAdmin()) 
    return api.sendMessage(`Cần quyền Admin chính để thực hiện lệnh`, threadID, messageID);
  if (!checkPermission(3)) 
    return api.sendMessage(getText("notHavePermssion", "addndh"), threadID, messageID);

  const expPath = path.join(__dirname, "data", "adminlist.json");
  if (!fs.existsSync(expPath)) fs.writeFileSync(expPath, JSON.stringify({}, null, 2));

  const saveExpire = (id, role, expire) => {
    const d = JSON.parse(fs.readFileSync(expPath));
    d[id] = { role, expire };
    fs.writeFileSync(expPath, JSON.stringify(d, null, 2));
  };

  if (event.type == "message_reply") {
    const targetId = messageReply.senderID;
    const expireArg = content[0];
    const expireDate = parseExpire(expireArg);
    if (!NDH.includes(targetId)) {
      NDH.push(targetId);
      config.NDH.push(targetId);
    }
    const name = (await Users.getData(targetId)).name;
    saveExpire(targetId, "NDH", expireDate);
    writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
    return api.sendMessage(
      getText("addedNewNDH", 1, `Người Hỗ Trợ → ${name}\n[🔰] Uid: ${targetId}\n[🕒] Hết hạn: ${expireDate}`),
      threadID, messageID
    );
  }

  else if (mention.length && isNaN(content[0])) {
    const listAdd = [];
    const expireArg = content[content.length - 1];
    const expireDate = parseExpire(expireArg);
    for (const id of mention) {
      if (!NDH.includes(id)) {
        NDH.push(id);
        config.NDH.push(id);
      }
      listAdd.push(`${id} - ${event.mentions[id]}`);
      saveExpire(id, "NDH", expireDate);
    }
    writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
    return api.sendMessage(
      getText("addedNewNDH", mention.length, listAdd.join("\n").replace(/\@/g, "") + `\n[🕒] Hết hạn: ${expireDate}`),
      threadID, messageID
    );
  }

  else if (content.length && !isNaN(content[0])) {
    const id = content[0];
    const expireArg = content[1];
    const expireDate = parseExpire(expireArg);
    if (!NDH.includes(id)) {
      NDH.push(id);
      config.NDH.push(id);
    }
    const name = (await Users.getData(id)).name;
    saveExpire(id, "NDH", expireDate);
    writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
    return api.sendMessage(
      getText("addedNewNDH", 1, `Người Hỗ Trợ → ${name}\n[🔰] Uid: ${id}\n[🕒] Hết hạn: ${expireDate}`),
      threadID, messageID
    );
  }
  return api.sendMessage("Vui lòng tag người dùng hoặc nhập UID!", threadID, messageID);
}
break;



    case "removendh": {
      if (!isMainAdmin()) return api.sendMessage(`Cần quyền Admin để thực hiện`, threadID, messageID)
      if (!checkPermission(3)) return api.sendMessage(getText("notHavePermssion", "removendh"), threadID, messageID);

      if (event.type == "message_reply") {
        const targetId = messageReply.senderID;
        const index = config.NDH.findIndex(item => item.toString() == targetId);
        if (index > -1) {
          NDH.splice(index, 1);
          config.NDH.splice(index, 1);
        }
        const name = (await Users.getData(targetId)).name;
        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(getText("removedNDH", 1, `${targetId} - ${name}`), threadID, messageID);
      }
      else if (mention.length != 0 && isNaN(content[0])) {
        var listAdd = [];

        for (const id of mention) {
          const index = config.NDH.findIndex(item => item == id);
          if (index > -1) {
            NDH.splice(index, 1);
            config.NDH.splice(index, 1);
          }
          listAdd.push(`${id} - ${event.mentions[id]}`);
        };

        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(getText("removedNDH", mention.length, listAdd.join("\n").replace(/\@/g, "")), threadID, messageID);
      }
      else if (content.length != 0 && !isNaN(content[0])) {
        const index = config.NDH.findIndex(item => item.toString() == content[0]);
        if (index > -1) {
          NDH.splice(index, 1);
          config.NDH.splice(index, 1);
        }
        const name = (await Users.getData(content[0])).name
        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(getText("removedNDH", 1, `${content[0]} - ${name}`), threadID, messageID);
      }
      else return api.sendMessage("Vui lòng tag người dùng hoặc nhập UID!", threadID, messageID);
    } break

    case "run": {
      if (!isMainAdmin()) return api.sendMessage(`Cần quyền Admin chính để thực hiện lệnh`, threadID, messageID)
      if (event.type == "message_reply") { content[0] = messageReply.senderID }
      if (mention.length != 0 && isNaN(content[0])) {
        var listAdd = [];
        for (const id of mention) {
          if (!run.includes(id)) {
            run.push(id);
            config.run.push(id);
          }
          listAdd.push(`${id} - ${event.mentions[id]}`);
        };

        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        api.sendMessage(`Đã thêm ${listAdd.join("\n").replace(/\@/g, "")} vào danh sách`, threadID, messageID);
      }
      else if (content.length != 0 && !isNaN(content[0])) {
        run.push(content[0]);
        config.run.push(content[0]);
        const name = (await Users.getData(content[0])).name
        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(`Đã thêm ${name} (${content[0]})\nVào danh sách dùng run!`, threadID, messageID);
      }
      else return api.sendMessage("Vui lòng tag người dùng hoặc nhập UID!", threadID, messageID);
    } break

    case "rundel": {
      if (!isMainAdmin()) return api.sendMessage(`Cần quyền Admin để thực hiện`, threadID, messageID)

      if (event.type == "message_reply") { content[0] = messageReply.senderID }
      if (mention.length != 0 && isNaN(content[0])) {
        var listAdd = [];

        for (const id of mention) {
          const index = config.run.findIndex(item => item == id);
          if (index > -1) {
            run.splice(index, 1);
            config.run.splice(index, 1);
          }
          listAdd.push(`${id} - ${event.mentions[id]}`);
        };

        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(`Đã xoá ${listAdd.join("\n").replace(/\@/g, "")} khỏi danh sách`, threadID, messageID);
      }
      else if (content.length != 0 && !isNaN(content[0])) {
        const index = config.run.findIndex(item => item.toString() == content[0]);
        run.splice(index, 1);
        config.run.splice(index, 1);
        const name = (await Users.getData(content[0])).name
        writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
        return api.sendMessage(`Đã xóa khỏi danh sách:\n ${content[0]} - ${name}`, threadID, messageID);
      }
      else return api.sendMessage("Vui lòng tag người dùng hoặc nhập UID!", threadID, messageID);
    } break

    default: {
      return api.sendMessage("Lệnh không hợp lệ! Sử dụng !admin để xem danh sách lệnh.", threadID, messageID);
    }
  };
}
module.exports.handleReply = async ({ api, event, handleReply, Users }) => {
  const { senderID, threadID, body, messageID } = event;
  const { author, list } = handleReply;
  const isMainAdmin = () => senderID == 100073639420918;

  if (senderID != author)
    return api.sendMessage("⚠️ Bạn không phải người mở danh sách này!", threadID, messageID);

  if (!isMainAdmin())
    return api.sendMessage("🚫 Chỉ Admin chính mới có quyền gỡ người trong danh sách!", threadID, messageID);

  const indexes = body.split(/\s+/).map(n => parseInt(n)).filter(n => !isNaN(n));
  if (indexes.length === 0)
    return api.sendMessage("⚠️ Vui lòng nhập số thứ tự hợp lệ!", threadID, messageID);

  const { writeFileSync } = require("fs-extra");
  let removed = [];

  for (const stt of indexes) {
    const target = list.find(u => u.stt === stt);
    if (!target) continue;

    const { id, name } = target;
    let removedType = "";

    if (global.config.ADMINBOT.includes(id)) {
      global.config.ADMINBOT = global.config.ADMINBOT.filter(e => e !== id);
      removedType += "Admin ";
    }

    if (global.config.NDH.includes(id)) {
      global.config.NDH = global.config.NDH.filter(e => e !== id);
      removedType += "NDH";
    }

    removed.push(`${stt}. ${name} (${removedType.trim() || "Không xác định"})`);
  }

  writeFileSync(global.client.configPath, JSON.stringify(global.config, null, 4), "utf8");

  return api.sendMessage(
    removed.length
      ? `🗑️ Đã gỡ thành công:\n${removed.join("\n")}`
      : "❎ Không có ai bị gỡ!",
    threadID,
    messageID
  );
};

module.exports.onLoad = function({ api }) {
  const path = require("path")
  const fs = require("fs-extra")
  const moment = require("moment-timezone")
  const cron = require("node-cron")

  const boxNoti = global.config.BOXNOTI
  const configPath = global.client.configPath
  const expPath = path.join(__dirname, "data", "adminlist.json")

  setTimeout(() => {
    cron.schedule("*/15 * * * *", async () => {
      try {
        if (!fs.existsSync(configPath) || !fs.existsSync(expPath)) return
        const config = JSON.parse(fs.readFileSync(configPath))
        const expData = JSON.parse(fs.readFileSync(expPath))
        const now = moment().tz("Asia/Ho_Chi_Minh")
        let changed = false
        for (const [uid, info] of Object.entries(expData)) {
          if (!info.expire || info.expire === "Vĩnh viễn") continue
          const end = moment(info.expire, "DD/MM/YYYY HH:mm:ss")
          if (!end.isValid()) continue
          const diffHours = end.diff(now, "hours")
          const diffMinutes = end.diff(now, "minutes")
          const name = (await global.controllers.Users.getData(uid))?.name || uid
          const alerts = {
            24: "⚠️ Admin/NDH còn ~1 ngày sẽ hết hạn!",
            12: "⚠️ Admin/NDH còn ~12 giờ sẽ hết hạn!",
            1: "⚠️ Admin/NDH còn ~1 giờ sẽ hết hạn!"
          }
          if (alerts[diffHours])
            await api.sendMessage(`${alerts[diffHours]}\n👤 ${name}\n🔰 UID: ${uid}\n⏰ Hết hạn: ${info.expire}`, boxNoti)
          if (diffMinutes <= 0) {
            if (info.role === "Admin" && config.ADMINBOT.includes(uid))
              config.ADMINBOT = config.ADMINBOT.filter(e => e !== uid)
            if (info.role === "NDH" && config.NDH.includes(uid))
              config.NDH = config.NDH.filter(e => e !== uid)
            delete expData[uid]
            changed = true
            await api.sendMessage(`📌 ${info.role} hết hạn và đã bị gỡ:\n👤 ${name}\n🔰 UID: ${uid}\n🕒 ${end.format("HH:mm:ss DD/MM/YYYY")}`, boxNoti)
          }
        }
        if (changed) {
          fs.writeFileSync(configPath, JSON.stringify(config, null, 4))
          fs.writeFileSync(expPath, JSON.stringify(expData, null, 2))
        }
      } catch (e) {}
    }, { scheduled: true, timezone: "Asia/Ho_Chi_Minh" })
  }, 15000)
}