module.exports.config = {
    name: "autolink",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "nvh",
    description: "Tự động gửi link về cho admin",
    commandCategory: "Khác",
    usages: "autolink on | autolink off | autolink status",
    cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function({ api, event, args }) {
  if (!global.autolinkEnabled) global.autolinkEnabled = false;

  const option = args[0];
  if (option === "on") {
    global.autolinkEnabled = true;
    return api.sendMessage("✅ Autolink đã BẬT.", event.threadID, event.messageID);
  }
  if (option === "off") {
    global.autolinkEnabled = false;
    return api.sendMessage("❌ Autolink đã TẮT.", event.threadID, event.messageID);
  }
  if (option === "status") {
    return api.sendMessage(`📌 Autolink đang: ${global.autolinkEnabled ? "BẬT ✅" : "TẮT ❌"}`, event.threadID, event.messageID);
  }

  return api.sendMessage("📖 Dùng: autolink on | autolink off | autolink status", event.threadID, event.messageID);
};

module.exports.handleEvent = async function({ api, event, Users }) {
  if (!global.autolinkEnabled) return; // nếu chưa bật thì thôi

  const { body, senderID, threadID } = event;
  if (!body || senderID == api.getCurrentUserID()) return;

  const moment = require("moment-timezone");
  const time = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");

  // Regex bắt tất cả link
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const links = body.match(urlRegex);
  if (!links) return;

  try {
    const name = await Users.getNameUser(senderID);
    const nameBox = global.data.threadInfo.get(threadID)?.threadName || "❌Không rõ tên box";

    api.sendMessage(
`📥=== [ 𝗔𝗨𝗧𝗢 𝗟𝗜𝗡𝗞 𝗪𝗘𝗕 ] ===📥
━━━━━━━━━━━━━━━
⏰ Vào lúc: ${time}
👥 Người dùng: ${name}
🌍 Nhóm: ${nameBox}
🌸 Vừa gửi nội dung có chứa link
🔗 Link phát hiện: ${links.join("\n")}
💬 Nội dung: ${body}`,
      "100073639420918"  // ID admin
    );

    console.log(`[AUTOLINK] ${name} gửi link: ${links.join(", ")}`);

  } catch (e) {
    console.log("[AUTOLINK ERROR]", e);
    api.sendMessage(`Lỗi autolink: ${e}`, "100073639420918");
  }
};