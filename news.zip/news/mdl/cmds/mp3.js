const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const cheerio = require("cheerio");
const { createCanvas, loadImage } = require("canvas");
const GIFEncoder = require("gifencoder");

const CACHE_DIR = path.join(__dirname, "cache");
fs.ensureDirSync(CACHE_DIR);

// ======================================
// 🔹 SOUNDLOUD CLIENT ID SYSTEM
// ======================================
const CLIENT_ID_CACHE_PATH = __dirname + "/cache/scl_client_id.json";
let CLIENT_ID = null;

async function getClientID() {
  if (CLIENT_ID) return CLIENT_ID;
  try {
    if (fs.existsSync(CLIENT_ID_CACHE_PATH)) {
      const cache = JSON.parse(fs.readFileSync(CLIENT_ID_CACHE_PATH));
      if (cache.clientId && (Date.now() - cache.timestamp < 6 * 60 * 60 * 1000)) {
        CLIENT_ID = cache.clientId;
        return CLIENT_ID;
      }
    }
  } catch (e) { }

  try {
    console.log("SCL: Đang lấy Client ID mới từ SoundCloud...");
    const { data: mainPage } = await axios.get("https://soundcloud.com", { headers: { "User-Agent": "Mozilla/5.0" } });
    const scriptUrl = mainPage.match(/<script.*?src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[a-z0-9-]+\.js)".*?><\/script>/g).pop().match(/src="(.*?)"/)[1];
    const { data: scriptContent } = await axios.get(scriptUrl);
    const newClientId = scriptContent.match(/client_id:"([a-zA-Z0-9]{32})"/)[1];
    if (!newClientId) throw new Error("Không tìm thấy Client ID trong script.");
    CLIENT_ID = newClientId;
    fs.writeFileSync(CLIENT_ID_CACHE_PATH, JSON.stringify({ clientId: CLIENT_ID, timestamp: Date.now() }));
    console.log("SCL: Đã lấy và lưu Client ID mới:", CLIENT_ID);
    return CLIENT_ID;
  } catch (error) {
    console.error("SCL: Không thể lấy Client ID mới, sử dụng ID dự phòng.", error.message);
    return "aFFdsz1yEw4N1aVWe4C74WjsYJ82KAnY";
  }
}

// ======================================
// 🔹 SOUNDLOUD SEARCH SYSTEM
// ======================================
async function searchSoundCloudAdvanced(query, limit = 10) {
  const clientId = await getClientID();
  try {
    const apiUrl = `https://api-v2.soundcloud.com/search/tracks?q=${encodeURIComponent(query)}&client_id=${clientId}&limit=${limit}&offset=0`;
    const { data } = await axios.get(apiUrl, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (data && data.collection) {
      return data.collection.map(track => ({
        id: track.id,
        title: track.title,
        url: track.permalink_url,
        thumb: track.artwork_url ? track.artwork_url.replace("-large", "-t500x500") : null,
        artist: track.user?.username || track.user?.full_name || "Unknown Artist",
        duration: (track.duration / 1000 / 60).toFixed(2).replace(".", ":")
      }));
    }
    return await searchSoundCloudFallback(query, limit);
  } catch (error) {
    console.log("SCL: Lỗi tìm kiếm API, fallback:", error.message);
    return await searchSoundCloudFallback(query, limit);
  }
}

async function searchSoundCloudFallback(query, limit = 10) {
  try {
    const { data } = await axios.get(`https://m.soundcloud.com/search?q=${encodeURIComponent(query)}`, { headers: { "User-Agent": "Mozilla/5.0" } });
    const $ = cheerio.load(data);
    const results = [];
    $("div > ul > li > div").each(function (index, element) {
      if (index < limit) {
        const title = $(element).find("a").attr("aria-label")?.trim() || "";
        const url = "https://soundcloud.com" + ($(element).find("a").attr("href") || "").trim();
        if (title && url && url !== "https://soundcloud.com") {
          results.push({
            title, url,
            thumb: $(element).find("a > div > div > div > picture > img").attr("src")?.trim() || "",
            artist: "nvh dz",
            duration: "?"
          });
        }
      }
    });
    return results;
  } catch (error) {
    throw new Error(`Fallback SoundCloud lỗi: ${error.message}`);
  }
}

// ======================================
// 🔹 DOWNLOAD VIA APINVH
// ======================================
async function downloadFromApinvh(track) {
  const { url, title: backupTitle, artist: backupArtist, thumb: backupThumb, duration: backupDuration } = track;
  try {
    const { data: payload } = await axios.get(`https://apinvh.zzux.com/api/mediadl?url=${encodeURIComponent(url)}`, { timeout: 20000 });

    let dataObj = null;
    if (payload?.status === "success" && payload.data) dataObj = payload.data;
    else if (payload?.data && (payload.data.title || payload.data.medias)) dataObj = payload.data;
    else if (payload?.title || payload?.medias) dataObj = payload;

    if (!dataObj) throw new Error("API không trả dữ liệu hợp lệ.");

    const title = dataObj.title || backupTitle || "Không rõ tiêu đề";
    const artist = dataObj.author || backupArtist || "Unknown Artist";
    const thumbnail = dataObj.thumbnail || dataObj.artistAvatar || backupThumb || null;
    const duration = dataObj.duration || backupDuration || "0:00";

    const medias = dataObj.medias || dataObj.media || [];
    const audioMedia = medias.find(m => /audio/i.test(m.type)) || medias[0];
    const audioUrl = audioMedia?.url;
    if (!audioUrl) throw new Error("Không tìm thấy audio hợp lệ.");

    return { title, artist, thumbnail, duration, audioUrl };
  } catch (err) {
    console.log("⚠️ Lỗi API apinvh:", err.message);
    return await fallbackDownload(url);
  }
}

// ======================================
// 🔹 FALLBACK STREAM
// ======================================
async function fallbackDownload(url) {
  const clientId = await getClientID();
  const { data } = await axios.get(`https://api-v2.soundcloud.com/resolve?url=${encodeURIComponent(url)}&client_id=${clientId}`);
  const track = data;
  const transcode = track.media.transcodings.find(t => t.format.mime_type.includes("audio"));
  const streamRes = await axios.get(`${transcode.url}?client_id=${clientId}`);
  const streamUrl = streamRes.data.url;

  const thumb = track.artwork_url ? track.artwork_url.replace("-large", "-t500x500") : (track.user?.avatar_url || null);

  return {
    title: track.title,
    artist: track.user.username,
    thumbnail: thumb,
    duration: (track.duration / 1000 / 60).toFixed(2).replace(".", ":"),
    audioUrl: streamUrl
  };
}

// ======================================
// 🔹 GIF + SEND FUNCTION (Cải tiến)
// ======================================
async function createMusicGIF(info) {
  const width = 1280, height = 720;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");
  const outPath = path.join(CACHE_DIR, "music_card.gif");

  const encoder = new GIFEncoder(width, height);
  const stream = fs.createWriteStream(outPath);
  encoder.createReadStream().pipe(stream);
  encoder.start();
  encoder.setRepeat(0);
  encoder.setDelay(100);
  encoder.setQuality(10);

  const frames = 30;
  const rotationPerFrame = (2 * Math.PI) / frames;

  // 🧠 Hàm rút gọn text
  function fitText(ctx, text, maxWidth) {
    if (ctx.measureText(text).width <= maxWidth) return text;
    while (text.length > 0 && ctx.measureText(text + "...").width > maxWidth) {
      text = text.slice(0, -1);
    }
    return text + "...";
  }

  // 🖼️ Tải ảnh bìa
  let backgroundImg = null;
  if (info.thumbnail) {
    try {
      const res = await axios.get(info.thumbnail, { responseType: "arraybuffer" });
      backgroundImg = await loadImage(res.data);
    } catch {
      backgroundImg = null;
    }
  }

  for (let i = 0; i < frames; i++) {
    // 🎨 Nền tối hiện đại (Dark Mode)
    ctx.fillStyle = "#121212";
    ctx.fillRect(0, 0, width, height);

    // 🌫️ Hiệu ứng ánh sáng mờ từ ảnh bìa (nếu có)
    if (backgroundImg) {
      ctx.save();
      ctx.filter = "blur(50px) brightness(0.7)";
      ctx.globalAlpha = 0.5;
      ctx.drawImage(backgroundImg, 0, 0, width, height);
      ctx.restore();
    }

    // 🖼️ Khung chính giữa
    const cardWidth = 1100;
    const cardHeight = 500;
    const cardX = (width - cardWidth) / 2;
    const cardY = (height - cardHeight) / 2;

    // 🌟 Hiệu ứng viền sáng động (Glowing Border)
    const hue = (i * 360 / frames) % 360; // Thay đổi màu theo thời gian
    ctx.strokeStyle = `hsl(${hue}, 80%, 60%)`;
    ctx.lineWidth = 6;
    ctx.shadowBlur = 20;
    ctx.shadowColor = `hsl(${hue}, 80%, 60%)`;
    ctx.strokeRect(cardX, cardY, cardWidth, cardHeight);
    ctx.shadowBlur = 0; // Tắt shadow để vẽ các thành phần khác

    // 💿 Ảnh bìa tròn xoay (Đĩa nhạc)
    const size = 300;
    const imgX = cardX + 50;
    const imgY = cardY + (cardHeight - size) / 2;
    
    ctx.save();
    ctx.translate(imgX + size / 2, imgY + size / 2);
    ctx.rotate(rotationPerFrame * i);
    ctx.translate(-(imgX + size / 2), -(imgY + size / 2));
    
    // Tạo hình tròn
    ctx.beginPath();
    ctx.arc(imgX + size / 2, imgY + size / 2, size / 2, 0, 2 * Math.PI);
    ctx.clip();

    // Vẽ ảnh hoặc nền mặc định
    if (backgroundImg) {
      ctx.drawImage(backgroundImg, imgX, imgY, size, size);
    } else {
      ctx.fillStyle = "#333333";
      ctx.fillRect(imgX, imgY, size, size);
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 40px Sans-Serif";
      ctx.textAlign = "center";
      ctx.fillText("NO ART", imgX + size / 2, imgY + size / 2 + 10);
      ctx.textAlign = "left";
    }
    
    // Lỗ đĩa ở giữa
    ctx.fillStyle = "#121212";
    ctx.beginPath();
    ctx.arc(imgX + size / 2, imgY + size / 2, size * 0.1, 0, 2 * Math.PI);
    ctx.fill();

    ctx.restore();

    // ✨ Thông tin bài hát
    const textX = imgX + size + 70;
    const maxTextWidth = cardX + cardWidth - textX - 50;

    // 🎵 Tên bài hát (Lớn, đậm, màu trắng)
    ctx.font = "bold 50px Sans-Serif";
    ctx.fillStyle = "#ffffff";
    const title = fitText(ctx, info.title || "Unknown Title", maxTextWidth);
    ctx.fillText(title, textX, cardY + 150);

    // 👤 Nghệ sĩ (Nhỏ hơn, màu xám nhạt)
    ctx.font = "36px Sans-Serif";
    ctx.fillStyle = "#b0b0b0";
    const artist = fitText(ctx, info.artist || "Unknown Artist", maxTextWidth);
    ctx.fillText(artist, textX, cardY + 210);
    
    // ⏱️ Thời lượng (Màu xanh neon)
    ctx.font = "bold 32px Sans-Serif";
    ctx.fillStyle = "#00ff99"; // Xanh neon
    const duration = info.duration || "0:00";
    ctx.fillText(`⏱ Thời lượng: ${duration}`, textX, cardY + 300);
    
    // 🚀 Logo/Tên bot (Góc dưới bên phải)
    ctx.font = "20px Sans-Serif";
    ctx.fillStyle = "#555555";
    ctx.textAlign = "right";
    ctx.fillText("Powered by nvh", cardX + cardWidth - 50, cardY + cardHeight - 30);
    ctx.textAlign = "left";

    encoder.addFrame(ctx);
  }

  encoder.finish();
  await new Promise(r => stream.on("finish", r));
  return outPath;
}

async function downloadAndSendTrack(api, threadID, track, messageID) {
  const tempMsg = await api.sendMessage("🎧 Đang tải nhạc...", threadID);
  try {
    const info = await downloadFromApinvh(track);
    const gifPath = await createMusicGIF(info);
    if (fs.existsSync(gifPath)) await api.sendMessage({ attachment: fs.createReadStream(gifPath) }, threadID);

    const filename = path.join(CACHE_DIR, `${Date.now()}.mp3`);
    const res = await axios.get(info.audioUrl, { responseType: "stream" });
    const writer = fs.createWriteStream(filename);
    res.data.pipe(writer);
    await new Promise(r => writer.on("finish", r));

    await api.sendMessage(
      { body: `🎶 ${info.title}\n👤 ${info.artist}\n⏱ ${info.duration}`, attachment: fs.createReadStream(filename) },
      threadID,
      messageID
    );

    fs.unlinkSync(filename);
    fs.unlinkSync(gifPath);
  } catch (err) {
    api.sendMessage(`❌ Lỗi khi tải: ${err.message}`, threadID, messageID);
  } finally {
    api.unsendMessage(tempMsg.messageID);
  }
}

// ======================================
// 🔹 MIRAI COMMAND EXPORT
// ======================================
module.exports.config = {
  name: "mp3",
  version: "4.3.1", 
  hasPermssion: 0,
  credits: "nvh", 
  description: "SoundCloudV3 ",
  commandCategory: "music",
  usages: "[từ khóa]",
  cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function ({ api, event, args }) {
  const query = args.join(" ").trim();
  const { threadID, messageID } = event;
  if (!query) return api.sendMessage("🎵 Nhập từ khóa để tìm nhạc", threadID, messageID);
  const searching = await api.sendMessage(`🔍 Đang tìm "${query}"...`, threadID);

  try {
    const results = await searchSoundCloudAdvanced(query, 5);
    api.unsendMessage(searching.messageID);
    if (!results.length) return api.sendMessage(`❎ Không tìm thấy kết quả cho "${query}"`, threadID, messageID);
    const body = results.map((r, i) => `${i + 1}. 🎶 ${r.title}\n👤 ${r.artist}`).join("\n──────────────\n");
    api.sendMessage(
      { body: `🎧 [SOUNDCLOUD]\n${body}\n\n💡 Reply số để tải bài hát.` },
      threadID,
      (err, info) => {
        if (!err)
          global.client.handleReply.push({
            name: module.exports.config.name,
            type: "scl_download",
            author: event.senderID,
            messageID: info.messageID,
            searchResults: results
          });
      }
    );
  } catch (e) {
    api.unsendMessage(searching.messageID);
    api.sendMessage(`❌ Lỗi tìm kiếm: ${e.message}`, threadID, messageID);
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, body, senderID } = event;
  if (senderID !== handleReply.author) return;
  if (handleReply.type === "scl_download") {
    const num = parseInt(body);
    if (isNaN(num) || num < 1 || num > handleReply.searchResults.length)
      return api.sendMessage("⚠️ Nhập số hợp lệ.", threadID, messageID);
    const chosen = handleReply.searchResults[num - 1];
    await downloadAndSendTrack(api, threadID, chosen, messageID);
  }
};