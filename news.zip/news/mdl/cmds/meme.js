const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "meme",
    version: "1.3.0",
    hasPermission: 0,
    credits: "nvh",
    description: "Tạo meme ",
    commandCategory: "Box",
    usages: "[template | reply ảnh] [top text | bottom text] hoặc 'list' để xem template",
    cooldowns: 3,
    usePrefix: true
  },

  onStart: async function ({ api, event, args }) {
    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);

    // 🧾 Nếu người dùng gọi "memegen list"
    if (args[0] && args[0].toLowerCase() === "list") {
      return await sendTemplateList(api, event);
    }

    // ❌ Nếu không có tham số và không reply ảnh
    if (args.length < 1 && !event.messageReply) {
      return api.sendMessage(
        "⚠️ Cách dùng:\n• memegen drake top | bottom\n• Reply một ảnh: memegen top | bottom\n• Xem danh sách template: memegen list",
        event.threadID,
        event.messageID
      );
    }

    const texts = args.join(" ").split("|").map(t => t.trim());
    const topText = encodeURIComponent(texts[0] || "-");
    const bottomText = encodeURIComponent(texts[1] || "-");
    const imgPath = path.join(cacheDir, `meme_${Date.now()}.png`);

    let imageUrl;

    // 📷 Nếu reply ảnh
    if (event.messageReply && event.messageReply.attachments?.length > 0) {
      const attachment = event.messageReply.attachments[0];
      if (attachment.type === "photo") {
        imageUrl = `https://api.memegen.link/images/custom/${topText}/${bottomText}.png?background=${encodeURIComponent(attachment.url)}`;
      } else {
        return api.sendMessage("❌ Vui lòng reply một ảnh hợp lệ.", event.threadID, event.messageID);
      }
    } 
    // 🧩 Nếu nhập template
    else {
      const template = args[0];
      if (!template) return api.sendMessage("⚠️ Bạn cần nhập tên template hoặc reply ảnh.", event.threadID, event.messageID);
      imageUrl = `https://api.memegen.link/images/${template}/${topText}/${bottomText}.png`;
    }

    try {
      const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
      fs.writeFileSync(imgPath, response.data);

      api.sendMessage(
        {
          body: "🖼 Meme của bạn đây!",
          attachment: fs.createReadStream(imgPath)
        },
        event.threadID,
        () => fs.unlinkSync(imgPath),
        event.messageID
      );
    } catch (err) {
      console.error(err);
      api.sendMessage("❌ Không thể tạo meme. Template có thể sai hoặc API lỗi.", event.threadID, event.messageID);
    }
  }
};

// 📜 HÀM PHỤ: Lấy danh sách template từ API
async function sendTemplateList(api, event) {
  try {
    const res = await axios.get("https://api.memegen.link/templates/");
    const templates = res.data;

    if (!templates || templates.length === 0) {
      return api.sendMessage("⚠️ Không lấy được danh sách template.", event.threadID, event.messageID);
    }

    // Chỉ lấy tên template
    const names = templates.map(t => t.id).filter(Boolean);
    const content = `📜 DANH SÁCH TEMPLATE CÓ SẴN (${names.length}):\n\n${names.join(", ")}\n\n🧠 Dùng ví dụ:\nmemegen drake trên | dưới`;

    // Ghi file để tránh tin nhắn quá dài
    const filePath = path.join(__dirname, "cache", `template_list_${Date.now()}.txt`);
    fs.writeFileSync(filePath, content);

    api.sendMessage(
      {
        body: "📂 Danh sách template (file đính kèm):",
        attachment: fs.createReadStream(filePath)
      },
      event.threadID,
      () => fs.unlinkSync(filePath),
      event.messageID
    );
  } catch (err) {
    console.error(err);
    api.sendMessage("❌ Không thể lấy danh sách template từ API.", event.threadID, event.messageID);
  }
}