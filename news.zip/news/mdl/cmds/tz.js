const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const axios = require("axios");
const { createCanvas, loadImage } = require("canvas");

// ================= CONFIG =================
this.config = {
	name: "tx",
	alias: ["taixiu"],
	version: "3.0.0",
	role: 1,
	author: "lechii & nvh",
	info: "Game Tài Xỉu full (jackpot, cầu, hũ, auto stop, canvas xúc xắc)",
	category: "Game",
	cd: 0,
	prefix: true
};

// ================= PATHS & CONSTANTS =================
const BASE = path.join(process.cwd(), "core", "data", "taixiu");
const CHECK_FILE = path.join(BASE, "status.json");
const IMG_PATH = path.join(BASE, "img");

const XU_XAC_URL = {
	1: "https://files.catbox.moe/4327xu.jpg",
	2: "https://files.catbox.moe/wkqb94.jpg",
	3: "https://files.catbox.moe/4fdeeb.jpg",
	4: "https://files.catbox.moe/rn49o9.jpg",
	5: "https://files.catbox.moe/m15zci.jpg",
	6: "https://files.catbox.moe/vhyr10.jpg"
};

const TILE = 1.95;
const MIN_MONEY = 50;
const SELECT = { t: "Tài", x: "Xỉu" };

const INFO_DEFAULT = {
	amount: 1_000_000,
	lastWinner: { name: "Không có", amount: 0 },
	contributionRate: { win: 0.05, lose: 0.1 },
	jackpotCondition: "3 xúc xắc giống nhau. Người đoán đúng nhận 35% hũ (chia đều)."
};

// ================= UTILITIES =================
async function ensureDir(dir) {
	await fsp.mkdir(dir, { recursive: true }).catch(() => {});
}
async function readJson(file, def = []) {
	try {
		const data = await fsp.readFile(file, "utf8");
		return JSON.parse(data);
	} catch {
		return def;
	}
}
async function writeJson(file, data) {
	const tmp = `${file}.tmp`;
	await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
	await fsp.rename(tmp, file);
}
function rollDice() {
	return Math.floor(Math.random() * 6) + 1;
}
function formatNum(n) {
	return new Intl.NumberFormat("vi-VN").format(n);
}
async function downloadFile(url, filePath) {
	if (fs.existsSync(filePath)) return;
	const res = await axios.get(url, { responseType: "arraybuffer" });
	await fsp.writeFile(filePath, res.data);
}
function parseMoney(str, userMoney) {
	if (!str) return 0;
	str = str.trim().toLowerCase();
	if (["all", "allin"].includes(str)) return userMoney;
	if (str.endsWith("%")) return Math.floor(userMoney * (parseInt(str) / 100));
	const match = str.match(/^(\d+)(k|m|g)?$/i);
	if (!match) return parseInt(str) || 0;
	const num = parseInt(match[1]);
	const unit = match[2]?.toLowerCase();
	const mult = unit === "k" ? 1e3 : unit === "m" ? 1e6 : unit === "g" ? 1e9 : 1;
	return num * mult;
}

// ================= PATH MANAGER =================
function getPaths(threadID) {
	const root = path.join(BASE, "threads", threadID);
	const data = path.join(root, "data");
	const betHistory = path.join(data, "history");
	return {
		root,
		data,
		betHistory,
		phien: path.join(root, "phien.json"),
		hu: path.join(root, "hu.json"),
		detail: path.join(root, "detail.json")
	};
}

// ================= CANVAS: CREATE BRIDGE (CẦU) =================
async function createBridgeImage(threadID, count = 15) {
	const paths = getPaths(threadID);
	const detail = await readJson(paths.detail, []);
	if (!detail.length) return null;

	const recent = detail.slice(-count);
	const w = 900,
		h = 600;
	const cv = createCanvas(w, h);
	const ctx = cv.getContext("2d");

	ctx.fillStyle = "#000";
	ctx.fillRect(0, 0, w, h);

	ctx.fillStyle = "#FFD700";
	ctx.font = "bold 20px Arial";
	ctx.textAlign = "center";
	ctx.fillText("THỐNG KÊ CẦU TÀI XỈU", w / 2, 30);

	const gridX = 60,
		gridY = 60,
		gridW = w - 120,
		gridH = 400,
		rows = 16,
		cols = Math.max(recent.length + 2, 15),
		cw = gridW / cols,
		ch = gridH / rows;

	ctx.strokeStyle = "#2c3e50";
	for (let i = 0; i <= rows; i++) {
		ctx.beginPath();
		ctx.moveTo(gridX, gridY + i * ch);
		ctx.lineTo(gridX + gridW, gridY + i * ch);
		ctx.stroke();
	}
	for (let i = 0; i <= cols; i++) {
		ctx.beginPath();
		ctx.moveTo(gridX + i * cw, gridY);
		ctx.lineTo(gridX + i * cw, gridY + gridH);
		ctx.stroke();
	}

	const points = recent.map((r, i) => ({
		x: gridX + (i + 1) * cw,
		y: gridY + (18 - r.total) * ch,
		total: r.total,
		result: r.result
	}));

	ctx.strokeStyle = "#f39c12";
	ctx.lineWidth = 2;
	ctx.beginPath();
	for (let i = 0; i < points.length; i++) {
		const p = points[i];
		if (i === 0) ctx.moveTo(p.x, p.y);
		else ctx.lineTo(p.x, p.y);
	}
	ctx.stroke();

	points.forEach(p => {
		ctx.beginPath();
		ctx.arc(p.x, p.y, 10, 0, 2 * Math.PI);
		ctx.fillStyle = p.result === "t" ? "#e74c3c" : "#3498db";
		ctx.fill();
		ctx.strokeStyle = "#fff";
		ctx.stroke();
		ctx.fillStyle = "#fff";
		ctx.font = "bold 10px Arial";
		ctx.textAlign = "center";
		ctx.fillText(p.total, p.x, p.y + 3);
	});

	const out = path.join(BASE, `bridge_${Date.now()}.png`);
	await fsp.writeFile(out, cv.toBuffer("image/png"));
	return out;
}

// ================= INIT =================
this.onLoad = async function () {
	await ensureDir(BASE);
	await ensureDir(IMG_PATH);
	if (!fs.existsSync(CHECK_FILE)) await writeJson(CHECK_FILE, []);
	for (const [num, url] of Object.entries(XU_XAC_URL)) {
		const f = path.join(IMG_PATH, `${num}.jpg`);
		if (!fs.existsSync(f)) await downloadFile(url, f);
	}
	global.txStates ??= {};
	global.noPlayerSessions ??= {};
};

// ================= MAIN FUNCTION =================
this.onCall = async function ({ api, event, args, Users, Currencies, Threads, msg }) {
	const { threadID, senderID } = event;
	const paths = getPaths(threadID);
	await ensureDir(paths.betHistory);
	const check = await readJson(CHECK_FILE);
	const tData = await Threads.getData(threadID);
	const isAdmin =
		tData.threadInfo.adminIDs.some(a => a.id === senderID) ||
		global.config.ADMINBOT?.includes(senderID);
	const state = (global.txStates[threadID] ??= { time: 0, phien: 1 });

	switch ((args[0] || "").toLowerCase()) {
		case "on":
			if (!isAdmin) return msg.reply("❌ Bạn không có quyền bật game.");
			if (check.includes(threadID)) return msg.reply("⚠️ Game đã bật.");
			check.push(threadID);
			await writeJson(CHECK_FILE, check);
			msg.reply("✅ Đã bật game Tài Xỉu!");
			break;

		case "off":
			if (!isAdmin) return msg.reply("❌ Bạn không có quyền tắt game.");
			await writeJson(
				CHECK_FILE,
				check.filter(x => x !== threadID)
			);
			delete global.txStates[threadID];
			msg.reply("❎ Game Tài Xỉu đã tắt!");
			break;

		case "check": {
			const img = await createBridgeImage(threadID, 15);
			if (!img) return msg.reply("❎ Chưa có dữ liệu để vẽ cầu.");
			await api.sendMessage({ body: "📊 CẦU TÀI XỈU:", attachment: fs.createReadStream(img) }, threadID);
			setTimeout(() => fs.unlink(img, () => {}), 6000);
			break;
		}

		default: {
			if (!check.includes(threadID)) return msg.reply("⚠️ Game chưa bật.");
			const type = /^(tài|tai|t)$/i.test(args[0])
				? "t"
				: /^(xỉu|xiu|x)$/i.test(args[0])
				? "x"
				: null;
			if (!type) return msg.reply("❎ Dùng: tài [tiền] hoặc xỉu [tiền]");

			const moneyData = await Currencies.getData(senderID);
			const userMoney = moneyData.money || 0;
			const bet = parseMoney(args[1], userMoney);
			if (bet < MIN_MONEY) return msg.reply(`⚠️ Cược tối thiểu ${formatNum(MIN_MONEY)} VND`);
			if (userMoney < bet) return msg.reply("💸 Bạn không đủ tiền!");

			await Currencies.decreaseMoney(senderID, bet);
			const betFile = path.join(paths.betHistory, `${senderID}.json`);
			const betList = await readJson(betFile, []);
			betList.push({ senderID, choice: type, amount: bet, phien: state.phien });
			await writeJson(betFile, betList);
			msg.reply(`✅ Cược ${SELECT[type]} ${formatNum(bet)} VND (phiên #${state.phien})`);

			if (!state.timer) {
				state.timer = true;
				setTimeout(async () => {
					const d1 = rollDice(),
						d2 = rollDice(),
						d3 = rollDice();
					const total = d1 + d2 + d3;
					const result = total >= 11 ? "t" : "x";
					const jackpot = d1 === d2 && d2 === d3;

					const allFiles = await fsp.readdir(paths.betHistory);
					let winners = [],
						losers = [];
					for (const file of allFiles) {
						const data = await readJson(path.join(paths.betHistory, file), []);
						for (const b of data.filter(b => b.phien === state.phien)) {
							if (b.choice === result) {
								const win = Math.floor(b.amount * TILE);
								await Currencies.increaseMoney(b.senderID, win);
								winners.push({ ...b, win });
							} else losers.push(b);
						}
					}

					const record = { d1, d2, d3, total, result, jackpot };
					await writeJson(paths.detail, [...(await readJson(paths.detail, [])), record]);

					const diceImgs = [
						path.join(IMG_PATH, `${d1}.jpg`),
						path.join(IMG_PATH, `${d2}.jpg`),
						path.join(IMG_PATH, `${d3}.jpg`)
					];
					const imgs = await Promise.all(diceImgs.map(loadImage));
					const cw = imgs[0].width,
						ch = imgs[0].height;
					const cv = createCanvas(cw * 3, ch);
					const ctx = cv.getContext("2d");
					imgs.forEach((img, i) => ctx.drawImage(img, i * cw, 0, cw, ch));
					const tmp = path.join(BASE, `dice_${Date.now()}.png`);
					await fsp.writeFile(tmp, cv.toBuffer("image/png"));

					const text = `🎲 PHIÊN #${state.phien}\n🎲 ${d1}-${d2}-${d3} (${total}) → ${SELECT[result]}${
						jackpot ? " + JACKPOT 🎉" : ""
					}\n──────────────\n👑 Thắng: ${
						winners.length
							? winners.map(w => `${await Users.getNameUser(w.senderID)} (+${formatNum(w.win)})`).join("\n")
							: "Không có"
					}\n💸 Thua: ${
						losers.length
							? losers.map(l => await Users.getNameUser(l.senderID)).join(", ")
							: "Không có"
					}`;

					await api.sendMessage({ body: text, attachment: fs.createReadStream(tmp) }, threadID);
					setTimeout(() => fs.unlink(tmp, () => {}), 6000);

					state.phien++;
					state.timer = false;

					global.noPlayerSessions[threadID] = (global.noPlayerSessions[threadID] || 0) + 1;
					if (global.noPlayerSessions[threadID] >= 2 && (!winners.length && !losers.length)) {
						const checkNow = await readJson(CHECK_FILE);
						await writeJson(CHECK_FILE, checkNow.filter(id => id !== threadID));
						delete global.txStates[threadID];
						msg.reply("⚠️ Không có người chơi trong 2 phiên → game tự động tắt.");
					}
				}, 60000);
			}
		}
	}
};
