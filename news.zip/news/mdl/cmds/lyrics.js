const axios = require("axios");

module.exports.config = {
  name: "lyrics",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Tìm lời bài hát",
  commandCategory: "music",
  usages: "lyrics <tên bài hát>",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
  if (!args[0]) return api.sendMessage("❌ Vui lòng nhập tên bài hát", event.threadID, event.messageID);
  const query = encodeURIComponent(args.join(" "));

  try {
    const res = await axios.get(`https://lrclib.net/api/search?q=${query}`);
    if (!res.data || res.data.length === 0) 
      return api.sendMessage("⚠️ Không tìm thấy lời bài hát nào!", event.threadID, event.messageID);

    const results = res.data.slice(0, 10); // tối đa 10 bài
    let msg = `🎵 Có ${results.length} kết quả tìm thấy:\n\n`;
    results.forEach((s, i) => {
      msg += `${i+1}. ${s.trackName} - ${s.artistName}\n`;
    });
    msg += `\n👉 Reply số thứ tự để xem lyrics.`;

    return api.sendMessage(msg, event.threadID, (err, info) => {
      if (err) return;
      global.client.handleReply.push({
        name: module.exports.config.name,
        messageID: info.messageID,
        author: event.senderID,
        type: "chooseSong",
        results
      });
    }, event.messageID);

  } catch (err) {
    console.error(err);
    api.sendMessage("❌ Đã xảy ra lỗi khi tìm lyric.", event.threadID, event.messageID);
  }
};

module.exports.handleReply = async function({ api, event, handleReply }) {
  if (event.senderID != handleReply.author) return;
  const choice = parseInt(event.body);
  if (isNaN(choice) || choice < 1 || choice > handleReply.results.length) {
    return api.sendMessage("⚠️ Vui lòng chọn số hợp lệ.", event.threadID, event.messageID);
  }

  const song = handleReply.results[choice-1];
  let msg = `🎶 ${song.trackName} - ${song.artistName}\n\n`;

  let lyrics = "";
  if (song.plainLyrics) {
    lyrics = song.plainLyrics;
  } else if (song.syncedLyrics) {
    // Xóa timestamp [mm:ss.xx] và khoảng trắng thừa
    lyrics = song.syncedLyrics
      .replace(/\[.*?\]/g, "")    // bỏ tag [02:48.48]
      .replace(/^\s*$/gm, "")     // bỏ dòng trống
      .trim();
  } else {
    lyrics = "❌ Không có lyric cho bài này!";
  }

  msg += lyrics;

  return api.sendMessage(msg, event.threadID, event.messageID);
};
