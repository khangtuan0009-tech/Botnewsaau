const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "list",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Liệt kê các lệnh theo từng credits",
  commandCategory: "admin",
  usages: "[credits hoặc để trống]",
  cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function ({ api, event, args }) {
  try {
    const commandDir = path.join(__dirname);
    const files = fs.readdirSync(commandDir).filter(f => f.endsWith(".js"));
    const target = args.join(" ").trim().toLowerCase();
    const commands = [];

    // Đọc toàn bộ file trong thư mục
    for (const file of files) {
      try {
        const command = require(path.join(commandDir, file));
        if (command.config && command.config.name) {
          const name = command.config.name;
          const credits = (command.config.credits || "Không rõ").trim().toUpperCase();
          commands.push({ name, credits });
        }
      } catch {}
    }

    if (!commands.length)
      return api.sendMessage("⚠️ Không tìm thấy lệnh nào.", event.threadID, event.messageID);

    // Gom nhóm theo credits
    const grouped = {};
    for (const cmd of commands) {
      if (!grouped[cmd.credits]) grouped[cmd.credits] = [];
      grouped[cmd.credits].push(cmd.name);
    }

    // Nếu có tìm credits cụ thể
    if (target) {
      const found = Object.keys(grouped).find(c => c.toLowerCase().includes(target));
      if (!found)
        return api.sendMessage(`❌ Không tìm thấy nhóm credits "${target}".`, event.threadID, event.messageID);

      const list = grouped[found].sort((a, b) => a.localeCompare(b));
      const msg = `[ ${found} ]\n📝 Tổng lệnh: ${list.length} lệnh\n${list.join(", ")}`;
      return api.sendMessage(msg, event.threadID, event.messageID);
    }

    // Nếu không có args → hiển thị tất cả credits
    let msg = "";
    const sortedCredits = Object.keys(grouped).sort(); // sắp xếp theo tên credits
    for (const credit of sortedCredits) {
      const list = grouped[credit].sort((a, b) => a.localeCompare(b));
      msg += `[ ${credit} ]\n📝 Tổng lệnh: ${list.length} lệnh\n${list.join(", ")}\n\n`;
    }

    return api.sendMessage(msg.trim(), event.threadID, event.messageID);
  } catch (err) {
    console.error(err);
    return api.sendMessage("⚠️ Đã xảy ra lỗi khi liệt kê lệnh.", event.threadID, event.messageID);
  }
};