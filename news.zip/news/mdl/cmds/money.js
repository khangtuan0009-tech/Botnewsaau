module.exports.config = {
  name: "money",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Xem số dư hiện tại của bạn hoặc người khác khi reply",
  commandCategory: "Tiền tệ",
  usages: "[money] hoặc reply tin nhắn",
  cooldowns: 5
,
  usePrefix: true
};

// Hàm định dạng tiền kiểu Việt Nam
function formatCurrencyVietnamese(amount) {
  if (amount >= 1000000000) {
    return (amount / 1000000000).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + ' tỷ';
  } else if (amount >= 1000000) {
    return (amount / 1000000).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + ' triệu';
  } else if (amount >= 1000) {
    return (amount / 1000).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + ' nghìn';
  } else {
    return amount.toLocaleString('vi-VN');
  }
}

module.exports.run = async function ({ api, event, Currencies, Users }) {
  const { senderID, threadID, messageID, messageReply } = event;

  try {
    // Nếu reply vào tin nhắn, lấy ID người được reply
    const targetID = messageReply ? messageReply.senderID : senderID;

    const data = await Currencies.getData(targetID);
    if (!data) {
      return api.sendMessage("❌ Không tìm thấy dữ liệu người dùng!", threadID, messageID);
    }

    const money = data.money || 0;

    // Lấy tên người dùng nếu là reply
    const name = messageReply ? await Users.getNameUser(targetID) : "Bạn";

    return api.sendMessage(
      `💰 Số dư hiện tại của ${name} là: ${formatCurrencyVietnamese(money)} VND`,
      threadID,
      messageID
    );
  } catch (err) {
    console.error(err);
    return api.sendMessage("❌ Đã xảy ra lỗi khi lấy thông tin tiền!", threadID, messageID);
  }
};