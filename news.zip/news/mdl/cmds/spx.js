const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "spx",
  version: "1.3.1",
  hasPermssion: 0,
  credits: "Dũngkon",
  description: "Kiểm tra và theo dõi đơn hàng SPX",
  commandCategory: "Tiện ích",
  usages: "spx <mã> | spx add <mã> | spx remove <mã> | spx list",
  cooldowns: 5
};

const TRACK_FILE = path.resolve(__dirname, "..", "..", "data", "spx_trackings.json");
fs.ensureFileSync(TRACK_FILE);

function loadTrackings() {
  try {
    return fs.readJSONSync(TRACK_FILE, { throws: false }) || [];
  } catch {
    return [];
  }
}
function saveTrackings(list) {
  fs.writeJSONSync(TRACK_FILE, list, { spaces: 2 });
}
function fmtTimestamp(timestamp) {
  if (!timestamp) return "Không có";
  try {
    const d = new Date(timestamp * 1000);
    return d.toLocaleString("vi-VN", { hour12: false, timeZone: "Asia/Ho_Chi_Minh" });
  } catch {
    return "Không có";
  }
}
function getStatusColor(milestoneCode) {
  const colors = { 1: "🟡", 5: "🔵", 6: "🟢", 10: "🔴" };
  return colors[milestoneCode] || "⚪";
}
function isFinalStatus(record) {
  if (!record) return false;
  const text = [
    record.buyer_description,
    record.seller_description,
    record.description,
    record.tracking_name,
    record.milestone_name,
    record.reason_desc
  ].filter(Boolean).join(" ").toLowerCase();

  const keywords = [
    "giao hàng thành công",
    "đã giao",
    "delivered",
    "delivery successful",
    "deliver successful",
    "trả hàng thành công",
    "returned to sender",
    "returned",
    "hoàn trả",
    "return successful",
    "returned successfully"
  ];

  return keywords.some(k => text.includes(k));
}

function translateStatus(status) {
  const statusMap = {
    "Manifested": "Đã tạo đơn",
    "SLSTN Created": "Đã tạo mã vận đơn",
    "Pickup From Domestic Seller": "Đã lấy hàng từ người bán",
    "Enter Domestic First Mile Hub": "Đã đến kho đầu tiên",
    "Packed in First Mile Hub": "Đã đóng gói tại kho đầu tiên",
    "Loaded to Truck in First Mile Hub": "Đã xếp lên xe tại kho đầu tiên",
    "Left Domestic First Mile Hub": "Đã rời kho đầu tiên",
    "Enter Domestic Sorting Center": "Đã đến trung tâm phân loại",
    "Packed in Domestic Sorting Centre": "Đã đóng gói tại trung tâm phân loại",
    "Loaded to Truck in Sorting Centre": "Đã xếp lên xe tại trung tâm phân loại",
    "Left Domestic Sorting Center": "Đã rời trung tâm phân loại",
    "Domestic Line Haul End": "Kết thúc vận chuyển đường dài",
    "Enter Last Mile Hub": "Đã đến kho cuối cùng",
    "Delivery Driver Assigned": "Đã phân công tài xế giao hàng",
    "Out For Delivery": "Đang giao hàng",
    "Delivery Attempt Failed": "Giao hàng không thành công",
    "Return Initiated": "Bắt đầu hoàn trả",
    "Enter RTS Sorting Centre": "Đã đến kho hoàn trả",
    "RTS Line Haul Transportation": "Đang vận chuyển hoàn trả",
    "Return Attempt Started": "Bắt đầu thử hoàn trả",
    "Returned to Sender": "Đã hoàn trả người gửi",
    
    "Preparing to ship": "Chuẩn bị giao hàng",
    "In transit": "Đang vận chuyển",
    "Out for delivery": "Đang giao hàng",
    "Delivery Unsuccessful": "Giao hàng không thành công"
  };
  
  return statusMap[status] || status;
}

function formatHistoryDetail(record, index) {
  let detail = "";
  
  if (index === 0) {
    detail += "📍 ";
  } else {
    detail += "📌 ";
  }
  
  detail += `${fmtTimestamp(record.actual_time)}\n`;
  
  detail += `   🏷️ Trạng thái: ${translateStatus(record.tracking_name)}`;
  if (record.milestone_name && record.milestone_name !== record.tracking_name) {
    detail += ` (${translateStatus(record.milestone_name)})`;
  }
  detail += `\n`;
  
  if (record.buyer_description) {
    detail += `   📝 Mô tả: ${record.buyer_description}\n`;
  } else if (record.description) {
    detail += `   📝 Mô tả: ${record.description}\n`;
  }
  
  if (record.reason_desc && record.reason_desc !== "R00") {
    detail += `   ❗ Lý do: ${record.reason_desc}\n`;
  }
  
  if (record.current_location && record.current_location.location_name) {
    detail += `   📍 Địa điểm: ${record.current_location.location_name}\n`;
    if (record.current_location.full_address) {
      const shortAddress = record.current_location.full_address.split(',').slice(-3).join(',');
      detail += `   🏠 Địa chỉ: ${shortAddress}\n`;
    }
  }
  
  if (record.next_location && record.next_location.location_name) {
    detail += `   ➡️ Điểm đến: ${record.next_location.location_name}\n`;
  }
  
  return detail + "\n";
}

async function trackSPX(trackingNumber) {
  try {
    const response = await axios.get(`https://adidaphat.site/spx`, {
      params: { billcode: trackingNumber },
      timeout: 15000
    });
    
    const data = response.data;
    
    if (!data || data.raw_response?.retcode !== 0) {
      throw new Error("Không tìm thấy thông tin đơn hàng");
    }
    
    return data;
  } catch (error) {
    console.error("API Error:", error.message);
    if (error.response) {
      console.error("Response data:", error.response.data);
      console.error("Response status:", error.response.status);
    }
    throw error;
  }
}

module.exports.run = async function({ api, event, args, Users }) { 
  if (!global.api) global.api = api;
  global.lastSPXCheck = Date.now();

  const { threadID, senderID } = event;
  const out = msg => api.sendMessage(msg, threadID);
  args = args || [];

  if (args.length >= 2 && args[0].toLowerCase() === "add") {
    const code = args.slice(1).join(" ").trim();
    if (!code) return out("⚠️ Vui lòng nhập mã vận đơn: spx add <mã>");

    try {
      const userName = (await Users.getData(senderID)).name;

      const data = await trackSPX(code);
      const records = data.raw_response?.data?.sls_tracking_info?.records || [];
      const latest = records[0] || null;
      const latestTime = latest?.actual_time || 0;

      if (isFinalStatus(latest)) {
        let note = `📣 Đơn ${code} đã hoàn tất:\n`;
        note += `• Trạng thái: ${translateStatus(latest.milestone_name || latest.tracking_name || "")}\n`;
        note += `• Mô tả: ${latest.buyer_description || latest.description || ""}\n`;
        note += `• Cập nhật: ${fmtTimestamp(latestTime)}\n`;
        
        const msg = {
          body: note,
          mentions: [{ tag: userName, id: senderID }]
        };
        await api.sendMessage(msg, threadID);
        return out("✅ Đơn này đã hoàn tất, không cần theo dõi.");
      }

      const list = loadTrackings();
      if (list.find(x => x.tracking === code && x.threadID === threadID))
        return out("⚠️ Mã này đã được theo dõi.");

      list.push({ 
        tracking: code, 
        threadID, 
        addedBy: senderID,
        adderName: userName, 
        lastTime: latestTime 
      });
      saveTrackings(list);

      const msg = {
        body: `✅ Đã thêm theo dõi: ${code}\n👤 Người thêm: ${userName}\n⏰ Mốc thời gian: ${fmtTimestamp(latestTime)}`,
        mentions: [{ tag: userName, id: senderID }]
      };
      return api.sendMessage(msg, threadID);
    } catch (e) {
      console.error("spx add error:", e.message);
      return out("❌ Lỗi khi thêm theo dõi: " + e.message);
    }
  }

  if (args.length >= 2 && args[0].toLowerCase() === "remove") {
    const code = args.slice(1).join(" ").trim();
    if (!code) return out("⚠️ Vui lòng nhập mã: spx remove <mã>");
    const list = loadTrackings();
    const idx = list.findIndex(x => x.tracking === code && x.threadID === threadID);
    if (idx === -1) return out("❌ Không tìm thấy mã trong danh sách.");
    list.splice(idx, 1);
    saveTrackings(list);
    return out(`🗑️ Đã xóa theo dõi: ${code}`);
  }

  if (args.length >= 1 && args[0].toLowerCase() === "list") {
    const list = loadTrackings().filter(x => x.threadID === threadID);
    if (list.length === 0) return out("📭 Bạn chưa theo dõi đơn nào.");
    let msg = "📋 Danh sách theo dõi:\n";
    for (const it of list) {
      msg += `• ${it.tracking} — lần cuối: ${fmtTimestamp(it.lastTime)}\n`;
    }
    return out(msg);
  }

  let trackingNumber = args.join(" ").trim();
  if (!trackingNumber && event.type === "message_reply") {
    trackingNumber = event.messageReply.body?.trim();
  }
  if (!trackingNumber) return out("⚠️ Dùng: spx <mã_vận_đơn>");

  try {
    out(`🔎 Đang kiểm tra: ${trackingNumber} ...`);
    const data = await trackSPX(trackingNumber);
    
    const trackingInfo = data.raw_response?.data?.sls_tracking_info;
    const records = trackingInfo?.records || [];
    if (records.length === 0) return out("Không có dữ liệu theo dõi.");

    const currentStatus = records[0];
    
    let msg = `=== SHOPEE EXPRESS ===\n\n`;
    
    msg += `📦 THÔNG TIN HIỆN TẠI:\n`;
    msg += `🔸 Mã vận đơn: ${trackingInfo.sls_tn || data.requested_tn}\n`;
    msg += `🔸 Trạng thái: ${translateStatus(currentStatus.milestone_name || currentStatus.tracking_name)}\n`;
    msg += `🔸 Mô tả: ${currentStatus.buyer_description || currentStatus.description || "Không có mô tả"}\n`;
    
    if (currentStatus.reason_desc && currentStatus.reason_desc !== "R00") {
      msg += `🔸 Lý do: ${currentStatus.reason_desc}\n`;
    }
    
    if (currentStatus.current_location && currentStatus.current_location.location_name) {
      msg += `🔸 Địa điểm: ${currentStatus.current_location.location_name}\n`;
    }
    
    msg += `🔸 Thời gian: ${fmtTimestamp(currentStatus.actual_time)}\n\n`;
    
    msg += `📜 LỊCH SỬ CHI TIẾT:\n\n`;
    
    for (let i = 0; i < Math.min(records.length, 15); i++) {
      msg += formatHistoryDetail(records[i], i);
    }
    
    if (records.length > 15) {
      msg += `... và ${records.length - 15} cập nhật khác\n`;
    }

    if (isFinalStatus(currentStatus)) {
      msg = `✅ ĐƠN HÀNG ĐÃ HOÀN TẤT\n\n` + msg;
    }
    
    return out(msg);
  } catch (err) {
    console.error("spx command error:", err.message);
    return out("❌ Đã xảy ra lỗi khi tra cứu SPX: " + err.message);
  }
};

const CHECK_INTERVAL = 10 * 60 * 1000; 

async function autoCheckSPX(api) {
  const list = loadTrackings();
  if (!list || list.length === 0) return;

  console.log(`[AUTO-SPX] Bắt đầu kiểm tra ${list.length} đơn...`);
  let hasChanges = false;

  for (const item of [...list]) {
    try {
      const data = await trackSPX(item.tracking);
      const records = data.raw_response?.data?.sls_tracking_info?.records || [];
      if (!records.length) continue;

      const latest = records[0];
      const latestTime = latest.actual_time || 0;

      if (isFinalStatus(latest)) {
        const finalMsg = {
          body: `✅ Đơn ${item.tracking} đã ${latest.buyer_description || "hoàn tất"}.\n👤 Người theo dõi: ${item.adderName}`,
          mentions: [{ tag: item.adderName, id: item.addedBy }]
        };
        await api.sendMessage(finalMsg, item.threadID);
        
        const idx = list.findIndex(x => x.tracking === item.tracking && x.threadID === item.threadID);
        if (idx !== -1) {
          list.splice(idx, 1);
          hasChanges = true;
          console.log(`[AUTO-SPX] Đã xóa đơn hoàn tất: ${item.tracking}`);
        }
        continue; 
      }

      if (latestTime > item.lastTime) {
        let msgBody = `📦 CẬP NHẬT MỚI CHO ĐƠN ${item.tracking}:\n`;
        msgBody += `👤 Người theo dõi: ${item.adderName}\n`;
        msgBody += `🔸 Trạng thái: ${translateStatus(latest.milestone_name || latest.tracking_name)}\n`;
        msgBody += `🔸 Mô tả: ${latest.buyer_description || latest.description || "Không có mô tả"}\n`;
        
        if (latest.reason_desc && latest.reason_desc !== "R00") {
          msgBody += `🔸 Lý do: ${latest.reason_desc}\n`;
        }
        
        if (latest.current_location && latest.current_location.location_name) {
          msgBody += `🔸 Địa điểm: ${latest.current_location.location_name}\n`;
        }
        
        msgBody += `🔸 Thời gian: ${fmtTimestamp(latestTime)}\n`;

        const msg = {
          body: msgBody,
          mentions: [{ tag: item.adderName, id: item.addedBy }]
        };

        await api.sendMessage(msg, item.threadID);
        item.lastTime = latestTime;
        hasChanges = true;
      }
    } catch (err) {
      console.error(`[AUTO-SPX] Lỗi kiểm tra ${item.tracking}:`, err.message);
    }
  }

  if (hasChanges) {
    saveTrackings(list);
    console.log(`[AUTO-SPX] Đã cập nhật file theo dõi, còn ${list.length} đơn`);
  }
}

setInterval(() => {
  if (global.api) autoCheckSPX(global.api);
  else console.warn("[AUTO-SPX] Chưa có global.api, đợi lần chạy lệnh đầu tiên...");
}, CHECK_INTERVAL);