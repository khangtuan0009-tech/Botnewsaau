const axios = require("axios");
const fs = require("fs");
const path = require("path");

// ==== CONFIG MODULE ====
module.exports.config = {
  name: "nct",
  version: "2.2.1",
  hasPermssion: 0,
  credits: "nvh",
  description: "Nghe, tải nhạc từ NhacCuaTui",
  commandCategory: "Tiện ích",
  usages: "nct search/play/info/lyric <từ khóa>",
  cooldowns: 5,
  usePrefix: true
};

// ==== HELPERS ====
async function searchNCT(keyword) {
  const url = "https://graph.nhaccuatui.com/api/v1/search/all";
  const res = await axios.get(url, { params: { keyword, page: 1, pageSize: 6 } });
  return res.data?.data || {};
}

async function getNCTDetail(key) {
  const url = `https://graph.nhaccuatui.com/api/v1/song/detail/${encodeURIComponent(key)}`;
  const res = await axios.get(url, { params: { key, timestamp: Date.now() } });
  return res.data?.data || null;
}

async function downloadStream(url, filepath) {
  const writer = fs.createWriteStream(filepath);
  const res = await axios({ url, method: "GET", responseType: "stream" });
  res.data.pipe(writer);
  return new Promise((resolve, reject) => {
    writer.on("finish", () => resolve(filepath));
    writer.on("error", reject);
  });
}

function formatArtists(artists) {
  return (artists || []).map(a => a.name).join(", ");
}

// ==== MAIN RUN ====
module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID } = event;
  const type = args[0];
  const keyword = args.slice(1).join(" ");

  if (!type)
    return api.sendMessage(
      "📌 Dùng:\n- nct search <từ khóa>\n- nct play <từ khóa>\n- nct lyric <từ khóa>\n- nct info <từ khóa>",
      threadID,
      messageID
    );

  if (!keyword)
    return api.sendMessage("⚠️ Vui lòng nhập từ khóa.", threadID, messageID);

  try {
    const data = await searchNCT(keyword);
    const songs = data.songs ? data.songs.slice(0, 6) : [];
    if (!songs.length)
      return api.sendMessage("❌ Không tìm thấy bài hát.", threadID, messageID);

    // === SEARCH ===
    if (type === "search") {
      let menu = "🎵 Kết quả tìm kiếm:\n";
      songs.forEach((s, i) => {
        menu += `📌 ${i + 1}. ${s.name} - ${s.artistName || formatArtists(s.artists)}\n`;
      });
      menu += "\n👉 Reply số để tải hoặc xem info";

      return api.sendMessage(menu, threadID, (err, info) => {
        global.client.handleReply.push({
          name: module.exports.config.name,
          type: "chooseSong",
          messageID: info.messageID,
          author: event.senderID,
          songs
        });
      }, messageID);
    }

    // === PLAY / INFO / LYRIC ===
    const song = songs[0];
    const detail = await getNCTDetail(song.key);
    if (!detail)
      return api.sendMessage("❌ Không lấy được thông tin bài hát.", threadID, messageID);

    // === PLAY ===
    if (type === "play") {
      if (!detail.streamURL?.length)
        return api.sendMessage("❌ Không tải được bài hát.", threadID, messageID);

      const best = detail.streamURL.find(a => a.value === 320) || detail.streamURL[0];
      const fileName = detail.name.replace(/[\\/:*?"<>|]/g, "_") + ".mp3";
      const mp3Path = path.join(__dirname, "cache", fileName);

      // 🔄 thông báo đang tải
      await api.sendMessage(`⏳ Đang tải bài hát “${detail.name}”...`, threadID, messageID);

      // tải nhạc về cache
      await downloadStream(best.stream || best.download, mp3Path);

      if (!fs.existsSync(mp3Path))
        return api.sendMessage("❌ Lỗi: File chưa được tải xong.", threadID, messageID);

      const min = Math.floor(detail.duration / 60);
      const sec = detail.duration % 60;
      const msg = `🎶 ${detail.name}\n👤 ${detail.artistName || formatArtists(detail.artists)}\n⏱ ${min}:${("0" + sec).slice(-2)}\n💽 Album: ${detail.album ? detail.album.title : "Không có"}\n🔗 ${detail.linkShare || detail.shareUrl}`;

      // ✅ Gửi nhạc sau khi tải hoàn tất
      return api.sendMessage({ body: msg, attachment: fs.createReadStream(mp3Path) }, threadID, () => {
        setTimeout(() => {
          try { fs.unlinkSync(mp3Path); } catch { }
        }, 3000);
      });
    }

    // === LYRIC ===
    if (type === "lyric") {
      const lyric = detail.lyric ? detail.lyric.replace(/<[^>]+>/g, "") : "❌ Không có lời bài hát.";
      return api.sendMessage(`📖 Lời bài hát: ${detail.name}\n\n${lyric}`, threadID, messageID);
    }

    // === INFO ===
    if (type === "info") {
      const min = Math.floor(detail.duration / 60);
      const sec = detail.duration % 60;
      return api.sendMessage(
        `📌 Thông tin bài hát:\n\n🎶 Tên: ${detail.name}\n👤 Ca sĩ: ${detail.artistName || formatArtists(detail.artists)}\n💽 Album: ${detail.album ? detail.album.title : "Không có"}\n⏱ Thời lượng: ${min}:${("0" + sec).slice(-2)}\n🔗 Link: ${detail.linkShare || detail.shareUrl}`,
        threadID,
        messageID
      );
    }

  } catch (e) {
    return api.sendMessage("❌ Lỗi: " + e.message, threadID, messageID);
  }
};

// ==== HANDLE REPLY ====
module.exports.handleReply = async function({ api, event, handleReply }) {
  const { threadID, messageID, senderID, body } = event;

  if (handleReply.type === "chooseSong" && handleReply.author === senderID) {
    const choice = parseInt(body.trim());
    if (isNaN(choice) || choice < 1 || choice > handleReply.songs.length)
      return api.sendMessage("⚠️ Chọn số hợp lệ.", threadID, messageID);

    const song = handleReply.songs[choice - 1];
    try {
      const detail = await getNCTDetail(song.key);
      if (!detail?.streamURL?.length)
        return api.sendMessage("❌ Không tải được bài hát.", threadID, messageID);

      const best = detail.streamURL.find(a => a.value === 320) || detail.streamURL[0];
      const fileName = detail.name.replace(/[\\/:*?"<>|]/g, "_") + ".mp3";
      const mp3Path = path.join(__dirname, "cache", fileName);

      // 🔄 Thông báo đang tải
      await api.sendMessage(`⏳ Đang tải bài hát “${detail.name}”...`, threadID, messageID);

      await downloadStream(best.stream || best.download, mp3Path);

      if (!fs.existsSync(mp3Path))
        return api.sendMessage("❌ Lỗi khi tải file.", threadID, messageID);

      const min = Math.floor(detail.duration / 60);
      const sec = detail.duration % 60;
      const msg = `🎶 ${detail.name}\n👤 ${detail.artistName || formatArtists(detail.artists)}\n⏱ ${min}:${("0" + sec).slice(-2)}\n💽 Album: ${detail.album ? detail.album.title : "Không có"}\n🔗 ${detail.linkShare || detail.shareUrl}`;

      await api.sendMessage({ body: msg, attachment: fs.createReadStream(mp3Path) }, threadID, () => {
        setTimeout(() => {
          try { fs.unlinkSync(mp3Path); } catch { }
        }, 3000);
      });

      // ✅ Thu hồi menu + reply
      try { await api.unsendMessage(handleReply.messageID); } catch { }
      try { await api.unsendMessage(messageID); } catch { }

    } catch (e) {
      return api.sendMessage("❌ Lỗi tải: " + e.message, threadID, messageID);
    }
  }
};