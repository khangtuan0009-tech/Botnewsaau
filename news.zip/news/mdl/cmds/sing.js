const fs = require('fs-extra');
const axios = require('axios');
const Youtube = require('youtube-search-api');

this.config = {
    name: "sing",
    aliases: ["music"],
    version: "2.3.0",
    role: 0,
    credits: "lechii",
    description: "Phát nhạc qua từ khoá",
    commandCategory: "Tiện ích",
    usages: "sing [từ khoá]",
    cd: 0,
    hasPrefix: true,
    images: [],
};

async function getLunarAudio(link, savePath) {
    const apiUrl = `https://api.lunarkrystal.site/ytmp3?url=${encodeURIComponent(link)}`;
    const res = await axios.get(apiUrl);
    const data = res.data;

    if (!data || data.status !== "ok" || !data.link)
        throw new Error("API Lunarkrystal không trả về link hợp lệ.");

    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
    };

    let attempt = 0;
    while (attempt < 3) {
        try {
            const response = await axios.get(data.link, {
                responseType: 'arraybuffer',
                headers
            });
            fs.writeFileSync(savePath, response.data);
            break;
        } catch (err) {
            attempt++;
            if (attempt >= 3) throw new Error(`Lỗi tải file (${err.message})`);
        }
    }

    return {
        title: data.title || "Không rõ tiêu đề",
        size: data.filesize || 0
    };
}

this.handleReply = async function ({ api, event, handleReply }) {
    if (event.senderID !== handleReply.author) {
        api.sendMessage("Người khác đang chọn bài mà cứ xí vào, vô duyên vcl!", event.threadID, event.messageID);
        return api.setMessageReaction("🖕", event.messageID, () => {}, true);
    }

    try {
        const startTime = Date.now();
        const id = handleReply.link[event.body - 1];
        if (!id) {
            api.sendMessage("Mày chọn cái đéo gì vậy?", event.threadID, event.messageID);
            return api.setMessageReaction("🖕", event.messageID, () => {}, true);
        }
        api.setMessageReaction("⌛", event.messageID, () => {}, true);

        const savePath = `${__dirname}/cache/Youtube/sing-${event.senderID}.mp3`;

        try {
            const info = await getLunarAudio(`https://www.youtube.com/watch?v=${id}`, savePath);

            if (fs.statSync(savePath).size > 25 * 1024 * 1024) {
                fs.unlinkSync(savePath);
                return api.sendMessage('❎ File quá lớn, vui lòng chọn bài khác!', event.threadID, event.messageID);
            }

            api.unsendMessage(handleReply.messageID);
            api.sendMessage({
                body: `🎬 Tiêu đề: ${info.title}\n⏳ Tốc độ xử lý: ${Math.floor((Date.now() - startTime) / 1000)} giây.`,
                attachment: fs.createReadStream(savePath)
            }, event.threadID, (err) => {
                if (!err) fs.unlinkSync(savePath);
                api.setMessageReaction(err ? "❎" : "✅", event.messageID, () => {}, true);
            }, event.messageID);

        } catch (err) {
            console.error(err);
            api.sendMessage(`❎ Lỗi tải nhạc: ${err.message}`, event.threadID, event.messageID);
        }
    } catch (e) {
        console.error(e);
    }
};

this.run = async function ({ api, event, args }) {
    if (args.length === 0)
        return api.sendMessage('❎ Phần tìm kiếm không được để trống!', event.threadID, event.messageID);

    const keyword = args.join(" ");
    const path = `${__dirname}/cache/Youtube/sing-${event.senderID}.mp3`;
    if (fs.existsSync(path)) fs.unlinkSync(path);

    try {
        const data = await Youtube.GetListByKeyword(keyword, false, 8);
        const items = data.items || [];

        if (!items.length)
            return api.sendMessage('❎ Không tìm thấy kết quả nào!', event.threadID, event.messageID);

        const links = [];
        const msg = items.map((v, i) => {
            links.push(v.id);
            const len = v.length?.simpleText || "Không rõ";
            return `${i + 1}. ${v.title}\n🗣️ Kênh: ${v.channelTitle || "Không rõ"}\n⏰ Thời lượng: ${len}\n──────────────────`;
        }).join("\n");

        api.sendMessage(`🎵 Có ${links.length} kết quả với từ khóa “${keyword}”:\n──────────────────\n${msg}\n\n📌 Reply (phản hồi) STT tương ứng để tải nhạc mp3.`,
            event.threadID,
            (err, info) => {
                if (!err)
                    global.client.handleReply.push({
                        type: 'reply',
                        name: this.config.name,
                        messageID: info.messageID,
                        author: event.senderID,
                        link: links
                    });
            },
            event.messageID
        );
    } catch (e) {
        console.error(e);
        api.sendMessage('❎ Đã xảy ra lỗi, vui lòng thử lại sau!\n' + e.message, event.threadID, event.messageID);
    }
};