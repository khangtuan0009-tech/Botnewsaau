module.exports.config = {
  name: 'bank',
  version: '1.0.0',
  hasPermssion: 0,
  credits: 'Neon Team',
  description: 'Ngân hàng',
  commandCategory: 'Tiện ích',
  usages: 'bank <lệnh>',
  cooldowns: 3,
  usePrefix: true
};

const fs = require('fs-extra');
const path = require('path');
const moment = require('moment-timezone');

const Mpath = path.join(__dirname, 'cache', 'bank.json');
const LAIXUAT = 1;
const INTERVAL_MINUTES = 20;

if (!fs.existsSync(Mpath)) {
  fs.ensureDirSync(path.dirname(Mpath));
  fs.writeFileSync(Mpath, JSON.stringify([], null, 2));
}

const loadData = () => {
  try {
    const raw = fs.readFileSync(Mpath);
    return JSON.parse(raw);
  } catch (e) {
    console.error('Lỗi load bank data:', e);
    return [];
  }
};
const saveData = (data) => {
  try {
    fs.writeFileSync(Mpath, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('Lỗi save bank data:', e);
  }
};

setInterval(() => {
  try {
    const data = loadData();
    if (!Array.isArray(data)) return;
    for (const acc of data) {
      if (typeof acc.money === 'number' && acc.money > 0) {
        acc.money = Math.ceil(acc.money * (1 + LAIXUAT / 100));
      }
    }
    saveData(data);
  } catch (e) {
    console.error('Lỗi job lãi:', e);
  }
}, INTERVAL_MINUTES * 60 * 1000);

const parseArgsFromEvent = (event) => {
  const body = (event && event.body) ? String(event.body) : '';
  return body.trim().split(/\s+/).filter(Boolean);
};

module.exports.run = async function({ api, event, args, Users, Currencies }) {
  try {
    const { threadID, messageID, senderID } = event;
    const data = loadData();
    const cmdRaw = args && args.length ? String(args[0]).toLowerCase() : '';
    const cmdMap = {
      'đk': 'dangky', 'dk': 'dangky', 'dangky': 'dangky', 'đăng ký': 'dangky',
      'register': 'dangky', '-r': 'dangky',
      'tt': 'thongtin', 'thongtin': 'thongtin', 'thông tin': 'thongtin', 'info': 'thongtin', '-i': 'thongtin',
      'ck': 'chuyenkhoan', 'chuyenkhoan': 'chuyenkhoan', 'chuyển khoản': 'chuyenkhoan', 'send': 'chuyenkhoan', '-s': 'chuyenkhoan',
      'nap': 'nap', 'gửi': 'nap', 'gui': 'nap', 'napvao': 'nap', 'deposit': 'nap',
      'rut': 'rut', 'rút': 'rut', 'withdraw': 'rut', '-b': 'rut',
      'vay': 'vay', 'loan': 'vay', '-v': 'vay',
      'dm': 'doimatkhau', 'doimatkhau': 'doimatkhau', 'đổi': 'doimatkhau', 'change': 'doimatkhau', '-c': 'doimatkhau'
    };
    const mapped = cmdMap[cmdRaw] || cmdRaw;

    if (!cmdRaw) {
      const help = `[ NGÂN HÀNG ]\n` +
        `- Sử dụng lệnh ngân hàng theo hướng dẫn dưới đây:\n` +
        `---------\n` +
        `• đk / dangky <mật khẩu>: Tạo tài khoản mới.\n` +
        `• tt / thongtin: Xem thông tin tài khoản.\n` +
        `• ck / chuyenkhoan <id/người> <số tiền>: Chuyển tiền cho người khác (trong hệ thống bank).\n` +
        `• nap / gửi <số tiền>: Nạp (chuyển) tiền từ ví Currencies vào tài khoản bank.\n` +
        `• rut / rút <số tiền>: Rút tiền từ tài khoản bank về ví Currencies.\n` +
        `• vay <số tiền>: Vay tiền từ ngân hàng (tăng loans và tiền mặt trong tài khoản).\n` +
        `• trả <số tiền>: Trả nợ (sử dụng tiền trong ví Currencies để trả).\n` +
        `• dm / doimatkhau <mật khẩu mới>: Đổi mật khẩu tài khoản.\n` +
        `---------\n` +
        `Lãi suất: Nhận ${LAIXUAT}% mỗi ${INTERVAL_MINUTES} phút\n`;
      return api.sendMessage(help, threadID, messageID);
    }

    const findU = data.find(i => i.senderID === senderID);

    switch (mapped) {
      case 'dangky': {
        if (findU) return api.sendMessage('❌ Bạn đã có tài khoản ngân hàng rồi. Dùng "tt" để xem thông tin.', threadID, messageID);
        const password = args[1] ? String(args[1]) : Math.random().toString(36).slice(2, 8);
        const newAcc = {
          senderID: senderID,
          password: password,
          money: 100,
          loans: 0,
          timeStart: Date.now()
        };
        data.push(newAcc);
        saveData(data);
        return api.sendMessage(`✅ Đăng ký thành công!\nMật khẩu của bạn: ${password}\nSố dư khởi tạo: ${newAcc.money} coin`, threadID, messageID);
      }

      case 'thongtin': {
        if (!findU) return api.sendMessage('❌ Bạn chưa có tài khoản. Dùng "đk <mật khẩu>" để tạo.', threadID, messageID);
        return api.sendMessage('📥 Hãy trả lời tin nhắn này và nhập mật khẩu để xem thông tin.', threadID, (err, info) => {
          global.client.handleReply.push({
            name: this.config.name,
            author: senderID,
            messageID: info.messageID,
            data: { senderID: findU.senderID },
            type: 'enter-password',
            theme: 'info'
          });
        }, messageID);
      }

      case 'nap': {
        if (!findU) return api.sendMessage('❌ Bạn chưa có tài khoản. Dùng "đk <mật khẩu>" để tạo.', threadID, messageID);
        return api.sendMessage('📥 Hãy trả lời tin nhắn này và nhập số tiền muốn nạp từ ví của bạn (Currencies).', threadID, (err, info) => {
          global.client.handleReply.push({
            name: this.config.name,
            author: senderID,
            messageID: info.messageID,
            data: { senderID: findU.senderID },
            type: 'enter-password',
            theme: 'nap'
          });
        }, messageID);
      }

      case 'rut': {
        if (!findU) return api.sendMessage('❌ Bạn chưa có tài khoản. Dùng "đk <mật khẩu>" để tạo.', threadID, messageID);
        return api.sendMessage('📥 Hãy trả lời tin nhắn này và nhập mật khẩu để tiếp tục rút tiền.', threadID, (err, info) => {
          global.client.handleReply.push({
            name: this.config.name,
            author: senderID,
            messageID: info.messageID,
            data: { senderID: findU.senderID },
            type: 'enter-password',
            theme: 'rut'
          });
        }, messageID);
      }

      case 'chuyenkhoan': {
        if (!findU) return api.sendMessage('❌ Bạn chưa có tài khoản. Dùng "đk <mật khẩu>" để tạo.', threadID, messageID);
        return api.sendMessage('📥 Hãy trả lời tin nhắn này và nhập mật khẩu để tiếp tục chuyển khoản.', threadID, (err, info) => {
          global.client.handleReply.push({
            name: this.config.name,
            author: senderID,
            messageID: info.messageID,
            data: { senderID: findU.senderID },
            type: 'enter-password',
            theme: 'chuyenkhoan'
          });
        }, messageID);
      }

      case 'vay': {
        if (!findU) return api.sendMessage('❌ Bạn chưa có tài khoản. Dùng "đk <mật khẩu>" để tạo.', threadID, messageID);
        return api.sendMessage('📥 Hãy trả lời tin nhắn này và nhập mật khẩu để chọn vay/trả nợ.', threadID, (err, info) => {
          global.client.handleReply.push({
            name: this.config.name,
            author: senderID,
            messageID: info.messageID,
            data: { senderID: findU.senderID },
            type: 'enter-password',
            theme: 'vay'
          });
        }, messageID);
      }

      case 'doimatkhau': {
        if (!findU) return api.sendMessage('❌ Bạn chưa có tài khoản. Dùng "đk <mật khẩu>" để tạo.', threadID, messageID);
        return api.sendMessage('📥 Hãy trả lời tin nhắn này và nhập mật khẩu hiện tại để tiếp tục đổi mật khẩu.', threadID, (err, info) => {
          global.client.handleReply.push({
            name: this.config.name,
            author: senderID,
            messageID: info.messageID,
            data: { senderID: findU.senderID },
            type: 'enter-password',
            theme: 'doimatkhau'
          });
        }, messageID);
      }

      default:
        return api.sendMessage('❌ Lệnh không hợp lệ. Gõ "bank" để xem hướng dẫn.', threadID, messageID);
    }
  } catch (error) {
    console.error('Run error bank:', error);
  }
};

module.exports.handleReply = async function({ api, event, handleReply: H, Users, Currencies }) {
  try {
    const { threadID, messageID, senderID } = event;
    const args = parseArgsFromEvent(event);
    const data = loadData();

    if (senderID != H.author) return api.sendMessage('❌ Chỉ người chạy lệnh mới được thao tác.', threadID, messageID);

    const account = data.find(i => i.senderID === (H.data && H.data.senderID ? H.data.senderID : H.author));
    if (!account) return api.sendMessage('❌ Không tìm thấy tài khoản (có thể đã bị xóa).', threadID, messageID);

    switch (H.type) {
      case 'enter-password': {
        const input = args.join(' ');
        if (!input) return api.sendMessage('❌ Vui lòng trả lời kèm mật khẩu.', threadID, messageID);
        if (input !== account.password) return api.sendMessage('❌ Mật khẩu không chính xác.', threadID, messageID);

        switch (H.theme) {
          case 'info': {
            const name = await Users.getNameUser(account.senderID);
            const created = moment(account.timeStart).tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY HH:mm:ss');
            const days = Math.ceil((Date.now() - account.timeStart) / (24*60*60*1000));
            return api.sendMessage(
              `💳 [ Thông tin tài khoản ]\n` +
              `Tên: ${name}\n` +
              `ID: ${account.senderID}\n` +
              `Số dư: ${account.money} coin\n` +
              `Nợ: ${account.loans} coin\n` +
              `Mật khẩu: ${account.password}\n` +
              `Ngày tạo: ${created} (${days} ngày)`,
              threadID, messageID
            );
          }

          case 'nap': {
            return api.sendMessage('📥 Trả lời tin nhắn này và nhập số tiền muốn nạp từ ví Currencies vào tài khoản bank.', threadID, (err, info) => {
              global.client.handleReply.push({
                name: this.config.name,
                author: H.author,
                messageID: info.messageID,
                data: { senderID: account.senderID },
                type: 'nap-amount'
              });
            }, messageID);
          }

          case 'rut': {
            return api.sendMessage('📥 Trả lời và nhập số tiền muốn rút từ tài khoản bank về ví Currencies.', threadID, (err, info) => {
              global.client.handleReply.push({
                name: this.config.name,
                author: H.author,
                messageID: info.messageID,
                data: { senderID: account.senderID },
                type: 'rut-amount'
              });
            }, messageID);
          }

          case 'chuyenkhoan': {
            return api.sendMessage('📥 Trả lời và nhập theo định dạng: {id_đích} {số_tiền}\nVí dụ: 123456789 5000', threadID, (err, info) => {
              global.client.handleReply.push({
                name: this.config.name,
                author: H.author,
                messageID: info.messageID,
                data: { senderID: account.senderID },
                type: 'chuyenkhoan-action'
              });
            }, messageID);
          }

          case 'vay': {
            return api.sendMessage('[ VAY / TRẢ ]\n1: Vay tiền\n2: Trả tiền\n\nTrả lời 1 hoặc 2 để chọn.', threadID, (err, info) => {
              global.client.handleReply.push({
                name: this.config.name,
                author: H.author,
                messageID: info.messageID,
                data: { senderID: account.senderID },
                type: 'vay-action'
              });
            }, messageID);
          }

          case 'doimatkhau': {
            return api.sendMessage('📥 Trả lời và nhập mật khẩu mới bạn muốn đổi.', threadID, (err, info) => {
              global.client.handleReply.push({
                name: this.config.name,
                author: H.author,
                messageID: info.messageID,
                data: { senderID: account.senderID },
                type: 'doimatkhau-action'
              });
            }, messageID);
          }

          default:
            return api.sendMessage('✅ Xác thực thành công.', threadID, messageID);
        }
      }

      case 'nap-amount': {
        const amount = parseInt(args[0]);
        if (isNaN(amount) || amount <= 0) return api.sendMessage('❌ Số tiền không hợp lệ.', threadID, messageID);
        const acc = data.find(i => i.senderID === H.data.senderID);
        if (!acc) return api.sendMessage('❌ Tài khoản không tồn tại.', threadID, messageID);

        const dataU = await Currencies.getData(H.author);
        if (!dataU || dataU.money < amount) return api.sendMessage('❌ Ví cá nhân (Currencies) không đủ tiền.', threadID, messageID);

        let finalDeposit = amount;
        if (acc.loans && acc.loans > 0) {
          const pay = Math.min(acc.loans, amount);
          acc.loans -= pay;
          finalDeposit = amount - pay;
          if (finalDeposit < 0) finalDeposit = 0;
        }
        acc.money = (acc.money || 0) + finalDeposit;
        await Currencies.decreaseMoney(H.author, amount);
        saveData(data);

        return api.sendMessage(`✅ Nạp thành công ${amount} coin.\n(Đã chuyển ${finalDeposit} vào tài khoản)`, threadID, messageID);
      }

      case 'rut-amount': {
        const amount = parseInt(args[0]);
        if (isNaN(amount) || amount <= 0) return api.sendMessage('❌ Số tiền không hợp lệ.', threadID, messageID);
        const acc = data.find(i => i.senderID === H.data.senderID);
        if (!acc) return api.sendMessage('❌ Tài khoản không tồn tại.', threadID, messageID);
        if (acc.money < amount) return api.sendMessage('❌ Số dư tài khoản không đủ để rút.', threadID, messageID);

        acc.money -= amount;
        await Currencies.increaseMoney(H.author, amount);
        saveData(data);

        return api.sendMessage(`✅ Rút thành công ${amount} coin về ví.`, threadID, messageID);
      }

      case 'chuyenkhoan-action': {
        const id = args[0];
        const amount = parseInt(args[1]);
        if (!id || isNaN(amount) || amount <= 0) return api.sendMessage('❌ Định dạng sai. Vui lòng nhập: {id_đích} {số_tiền}', threadID, messageID);
        const fromAcc = data.find(i => i.senderID === H.data.senderID);
        if (!fromAcc) return api.sendMessage('❌ Tài khoản gửi không tồn tại.', threadID, messageID);
        const toAcc = data.find(i => i.senderID === id);
        if (!toAcc) return api.sendMessage('❌ Tài khoản đích không tồn tại trong hệ thống bank.', threadID, messageID);
        if (fromAcc.money < amount) return api.sendMessage('❌ Số dư không đủ để chuyển.', threadID, messageID);

        fromAcc.money -= amount;
        toAcc.money += amount;
        saveData(data);

        const nameTo = await Users.getNameUser(id).catch(()=>id);
        return api.sendMessage(`✅ Chuyển thành công ${amount} coin cho ${nameTo} (ID: ${id}).`, threadID, messageID);
      }

      case 'vay-action': {
        const choice = args[0];
        if (!choice) return api.sendMessage('❌ Vui lòng trả lời 1 hoặc 2.', threadID, messageID);

        if (choice === '1') {
          return api.sendMessage('📥 Trả lời và nhập số tiền bạn muốn vay.', threadID, (err, info) => {
            global.client.handleReply.push({
              name: this.config.name,
              author: H.author,
              messageID: info.messageID,
              data: { senderID: H.data.senderID },
              type: 'vay-amount',
              theme: 'borrow'
            });
          }, messageID);
        } else if (choice === '2') {
          return api.sendMessage('📥 Trả lời và nhập số tiền bạn muốn trả (sẽ trừ từ ví Currencies).', threadID, (err, info) => {
            global.client.handleReply.push({
              name: this.config.name,
              author: H.author,
              messageID: info.messageID,
              data: { senderID: H.data.senderID },
              type: 'vay-amount',
              theme: 'pay'
            });
          }, messageID);
        } else {
          return api.sendMessage('❌ Lựa chọn không hợp lệ. Chỉ chọn 1 hoặc 2.', threadID, messageID);
        }
      }

      case 'vay-amount': {
        const amount = parseInt(args[0]);
        if (isNaN(amount) || amount <= 0) return api.sendMessage('❌ Số tiền không hợp lệ.', threadID, messageID);
        const acc = data.find(i => i.senderID === H.data.senderID);
        if (!acc) return api.sendMessage('❌ Tài khoản không tồn tại.', threadID, messageID);

        if (H.theme === 'borrow') {
          acc.loans = (acc.loans || 0) + amount;
          acc.money = (acc.money || 0) + amount;
          saveData(data);
          return api.sendMessage(`✅ Vay thành công ${amount} coin. Tổng nợ hiện tại: ${acc.loans} coin.`, threadID, messageID);
        } else if (H.theme === 'pay') {
          const dataU = await Currencies.getData(H.author);
          if (!dataU || dataU.money < amount) return api.sendMessage('❌ Ví Currencies không đủ để trả nợ.', threadID, messageID);
          if ((acc.loans || 0) < amount) return api.sendMessage(`❌ Số tiền trả lớn hơn nợ hiện tại (${acc.loans}).`, threadID, messageID);

          acc.loans -= amount;
          await Currencies.decreaseMoney(H.author, amount);
          saveData(data);
          return api.sendMessage(`✅ Trả nợ thành công ${amount} coin. Nợ còn lại: ${acc.loans} coin.`, threadID, messageID);
        } else {
          return api.sendMessage('❌ Lỗi theme vay.', threadID, messageID);
        }
      }

      case 'doimatkhau-action': {
        const newPass = args.join(' ');
        if (!newPass) return api.sendMessage('❌ Vui lòng nhập mật khẩu mới.', threadID, messageID);
        const acc = data.find(i => i.senderID === H.data.senderID);
        if (!acc) return api.sendMessage('❌ Tài khoản không tồn tại.', threadID, messageID);
        if (acc.password === newPass) return api.sendMessage('❌ Mật khẩu mới giống mật khẩu cũ.', threadID, messageID);

        const old = acc.password;
        acc.password = newPass;
        saveData(data);
        return api.sendMessage(`✅ Đổi mật khẩu thành công.\nMật khẩu cũ: ${old}\nMật khẩu mới: ${newPass}`, threadID, messageID);
      }

      default:
        return api.sendMessage('❌ Xử lý không hợp lệ hoặc đã hết thời gian thao tác.', threadID, messageID);
    }
  } catch (error) {
    console.error('handleReply error bank:', error);
  }
};