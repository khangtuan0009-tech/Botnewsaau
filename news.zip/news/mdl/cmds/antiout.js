const fs = require("fs");
const path = require("path");

module.exports.config = {
    name: "antiout",
    version: "1.0.1",
    hasPermssion: 1,
    credits: "nvh",
    description: "Bật/Tắt chế độ chống out cho nhóm",
    commandCategory: "Nhóm",
    usages: "antiout on/off",
    cooldowns: 5,
  usePrefix: true,
    dependencies: {}
};

const statusFile = path.join(__dirname, "../../utils/antiout.json");

// Đảm bảo file config tồn tại
function ensureFile() {
    if (!fs.existsSync(statusFile)) {
        fs.writeFileSync(statusFile, JSON.stringify({}, null, 2));
    }
}

module.exports.run = async function ({ api, event, args }) {
    ensureFile();
    let data = JSON.parse(fs.readFileSync(statusFile, "utf8"));
    const { threadID, messageID } = event;

    if (!data[threadID]) {
        data[threadID] = { status: false };
    }

    if (args[0] === "on") {
        data[threadID].status = true;
        fs.writeFileSync(statusFile, JSON.stringify(data, null, 2));
        return api.sendMessage("✅ Antiout đã được BẬT cho nhóm này.", threadID, messageID);
    }

    if (args[0] === "off") {
        data[threadID].status = false;
        fs.writeFileSync(statusFile, JSON.stringify(data, null, 2));
        return api.sendMessage("❎ Antiout đã được TẮT cho nhóm này.", threadID, messageID);
    }

    return api.sendMessage("⚙️ Dùng: antiout on/off", threadID, messageID);
};

// Phần sự kiện
module.exports.handleEvent = async function ({ api, event }) {
    ensureFile();
    let data = JSON.parse(fs.readFileSync(statusFile, "utf8"));
    const { threadID, logMessageData, author } = event;

    if (!data[threadID] || !data[threadID].status) return;
    if (event.logMessageType !== "log:unsubscribe") return;

    const { leftParticipantFbId } = logMessageData;

    // Nếu bot bị kick thì bỏ qua
    if (leftParticipantFbId == api.getCurrentUserID()) return;

    // Nếu admin kick thì bỏ qua (chỉ chặn tự ý out)
    if (author !== leftParticipantFbId) return;

    try {
        await api.addUserToGroup(leftParticipantFbId, threadID);
        const userInfo = await api.getUserInfo(leftParticipantFbId);
        const name = userInfo[leftParticipantFbId]?.name || "Người dùng";
        api.sendMessage(`${name} định trốn nhóm nhưng đã bị bot lôi lại 🤭`, threadID);
    } catch (e) {
        api.sendMessage(
            `❗ Không thể add lại người dùng ${leftParticipantFbId} (có thể đã chặn bot hoặc không kết bạn).`,
            threadID
        );
    }
};