const fs = require("fs");
const axios = require("axios");
const path = require("path");

module.exports.config = {
  name: "sendmsg",
  version: "2.0.0",
  hasPermssion: 3,
  credits: "manhG & nvh",
  description: "Gửi tin nhắn hàng loạt đến box đã chọn",
  commandCategory: "Admin",
  usages: "Của tao sài cl",
  cooldowns: 5,
  usePrefix: true,
  useprefix: false
};

module.exports.run = async function({ api, event }) {
  const permission = ["100073639420918"];
  if (!permission.includes(event.senderID))
    return api.sendMessage("⚠️ Bạn không có quyền dùng lệnh này", event.threadID, event.messageID);

  const allThreads = await api.getThreadList(100, null, ["INBOX"]);
  const list = allThreads.filter(t => t.isGroup);
  if (list.length === 0)
    return api.sendMessage("⚠️ Bot hiện không ở trong nhóm nào!", event.threadID, event.messageID);

  let msg = "📋 Danh sách nhóm bot đang tham gia:\n";
  let i = 1;
  for (const group of list) {
    msg += `${i++}. ${group.name} (${group.threadID})\n`;
  }
  msg += "\n➡️ Reply số thứ tự (cách nhau bằng dấu cách) để chọn nhóm cần gửi thông báo.";

  api.sendMessage(msg, event.threadID, (err, info) => {
    global.client.handleReply.push({
      name: module.exports.config.name,
      messageID: info.messageID,
      author: event.senderID,
      type: "chooseBox",
      list
    });
  });
};

module.exports.handleReply = async function({ api, event, handleReply }) {
  const { author, type, list } = handleReply;
  if (event.senderID !== author) return;

  switch (type) {
    case "chooseBox": {
      const chosen = event.body.split(" ").map(n => parseInt(n)).filter(n => !isNaN(n) && n > 0 && n <= list.length);
      if (chosen.length === 0)
        return api.sendMessage("⚠️ Không hợp lệ! Vui lòng nhập số thứ tự hợp lệ.", event.threadID, event.messageID);

      const chosenBoxes = chosen.map(i => list[i - 1]);
      let msg = "✅ Đã chọn các nhóm:\n";
      chosenBoxes.forEach((box, idx) => msg += `${idx + 1}. ${box.name}\n`);
      msg += "\n➡️ Reply tin nhắn bạn muốn gửi (có thể kèm ảnh/video).";

      api.sendMessage(msg, event.threadID, (err, info) => {
        global.client.handleReply.push({
          name: module.exports.config.name,
          messageID: info.messageID,
          author,
          type: "inputMessage",
          chosenBoxes
        });
      });
      break;
    }

    case "inputMessage": {
      const { chosenBoxes } = handleReply;
      let attachments = [];

      if (event.messageReply && event.messageReply.attachments.length > 0) {
        const file = event.messageReply.attachments[0];
        const url = file.url;
        const ext = path.extname(url).split("?")[0];
        const filePath = path.join(__dirname, `cache`, `noti${ext}`);
        const data = (await axios.get(url, { responseType: "arraybuffer" })).data;
        fs.writeFileSync(filePath, Buffer.from(data, "utf-8"));
        attachments.push(fs.createReadStream(filePath));
      }

      const content = event.body || (event.messageReply && event.messageReply.body);
      if (!content)
        return api.sendMessage("⚠️ Bạn chưa nhập nội dung cần gửi!", event.threadID, event.messageID);

      for (const box of chosenBoxes) {
        api.sendMessage(
          {
            body: `📢 Thông báo từ admin:\n\n${content}`,
            attachment: attachments.length > 0 ? attachments : undefined
          },
          box.threadID
        );
      }

      api.sendMessage(`✅ Đã gửi tin nhắn đến ${chosenBoxes.length} nhóm!`, event.threadID);
      break;
    }
  }
};