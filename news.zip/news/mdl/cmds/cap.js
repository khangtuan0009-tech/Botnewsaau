const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer");

module.exports.config = {
  name: "cap",
  version: "6.2.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Chụp màn hình",
  commandCategory: "Tiện ích",
  usages: "[link | reply] [--full]",
  cooldowns: 10,
  usePrefix: true
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, messageReply, senderID } = event;
  const isFullPage = args.includes("--full");
  const filteredArgs = args.filter(arg => arg !== "--full");

  let target;
  if (filteredArgs.length > 0 && (filteredArgs[0].startsWith("http") || filteredArgs[0].startsWith("www"))) {
    target = filteredArgs[0];
  } else if (messageReply) {
    const linkInReply = messageReply.body?.match(/https?:\/\/[^\s]+/g)?.[0];
    target = linkInReply || messageReply.senderID;
  } else {
    target = senderID;
  }

  const rawUrl = String(target).startsWith("http") ? target : `https://www.facebook.com/${target}`;

  let finalUrl;
  try {
    const parsed = new URL(rawUrl);
    if (parsed.hostname.startsWith("m.")) parsed.hostname = "www.facebook.com";
    parsed.searchParams.delete("--full");
    finalUrl = parsed.toString();
  } catch (err) {
    return api.sendMessage("❎ URL hoặc ID không hợp lệ.", threadID, messageID);
  }

  const filePath = path.join(__dirname, "cache", `screenshot_${Date.now()}.png`);
  api.sendMessage(`🕓 Đang chụp ảnh${isFullPage ? " (toàn trang)" : ""}...`, threadID, messageID);

  // ✅ Đường dẫn Chrome thật trên Windows
  const chromePath = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";

  if (!fs.existsSync(chromePath)) {
    return api.sendMessage("❎ Không tìm thấy Chrome tại:\n" + chromePath, threadID, messageID);
  }

  try {
    // ❌ Không headless, không sandbox
    const browser = await puppeteer.launch({
      executablePath: chromePath,
      headless: false, // ← mở cửa sổ thật để bạn thấy
      defaultViewport: { width: 1920, height: isFullPage ? 3000 : 1080 },
      args: [
        "--disable-gpu",
        "--start-maximized",
        "--disable-dev-shm-usage"
      ]
    });

    const page = await browser.newPage();
    await page.goto(finalUrl, { waitUntil: "networkidle2", timeout: 0 });
    await new Promise(r => setTimeout(r, 3000)); // đợi load

    await page.screenshot({
      path: filePath,
      fullPage: isFullPage
    });

    await browser.close();

    if (fs.existsSync(filePath)) {
      api.sendMessage(
        {
          body: `✅ Chụp ảnh thành công${isFullPage ? " (toàn trang)" : ""}:\n${finalUrl}`,
          attachment: fs.createReadStream(filePath)
        },
        threadID,
        () => fs.unlinkSync(filePath),
        messageID
      );
    } else {
      api.sendMessage("❎ Không tạo được file ảnh.", threadID, messageID);
    }
  } catch (err) {
    api.sendMessage("❎ Lỗi khi chụp ảnh:\n" + err.message, threadID, messageID);
  }
};