const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');
const logger = require('../../utils/log');

const dataDir = path.join(__dirname, 'data');
const dataPath = path.join(dataDir, 'thuebot.json');
const cachePath = path.join(dataDir, 'lastUpdate.txt');

// Tạo folder/data file nếu chưa có
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, '[]');
if (!fs.existsSync(cachePath)) fs.writeFileSync(cachePath, '');

// Load data
let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const saveData = () => fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

let lastUpdatedDate = fs.readFileSync(cachePath, 'utf8').trim();

// Hàm đổi nickname
async function updateNickname(api, targetTids = []) {
    try {
        const allThreads = data.map(g => g.t_id);
        const tids = targetTids.length ? targetTids : allThreads;

        for (const tid of tids) {
            let rentData = data.find(g => g.t_id === tid);
            let threadInfo;
            try {
                threadInfo = await api.getThreadInfo(tid);
            } catch {
                threadInfo = null;
            }

            if (!threadInfo) continue;

            const threadData = global.data.threadData.get(tid) || {};
            const PREFIX_GROUP = threadData.PREFIX || global.config.PREFIX;
            let nickname;

            if (rentData) {
                const newEndDate = moment(rentData.time_end, 'DD/MM/YYYY').format('DD/MM/YYYY');
                const days_left = moment(rentData.time_end, 'DD/MM/YYYY').diff(moment().tz('Asia/Ho_Chi_Minh'), 'days');
                nickname = `『 ${PREFIX_GROUP} 』 ⪼ ${global.config.BOTNAME} | HSD: ${newEndDate} | ${days_left} ngày 🕒`;
            } else {
                nickname = `『 ${PREFIX_GROUP} 』 ⪼ ${global.config.BOTNAME} | HSD: Chưa thuê bot`;
            }

            try {
                await api.changeNickname(nickname, tid, api.getCurrentUserID());
            } catch (err) {
                logger(`Không thể đổi biệt danh nhóm ${tid}: ${err.message}`, '[ RENT ]');
            }
        }
    } catch (err) {
        logger(`Lỗi updateNickname: ${err.message}`, '[ RENT ]');
    }
}

// Hàm tải hình ảnh từ URL
async function streamURL(url, mime = 'jpg') {
    try {
        if (!url.startsWith('http')) throw new Error('URL không hợp lệ');
        const cacheDir = path.join(__dirname, 'cache');
        if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
        const dest = path.join(cacheDir, `${Date.now()}.${mime}`);
        const downloader = require('image-downloader');
        const fse = require('fs-extra');

        await downloader.image({ url, dest });
        if (!fse.existsSync(dest)) throw new Error('Không thể tải hình ảnh');

        setTimeout(() => {
            if (fse.existsSync(dest)) fse.unlinkSync(dest);
        }, 60 * 1000);

        return fse.createReadStream(dest);
    } catch (err) {
        logger(`Lỗi trong streamURL: ${err.message}`, '[ RENT ]');
        throw err;
    }
}

module.exports.config = {
    name: 'rent',
    version: '1.6.0',
    hasPermssion: 1,
    credits: 'DC-Nam & DongDev & Khôi & nvh',
    description: 'Thuê bot + cập nhật nickname hàng ngày + tự xoá nhóm hết hạn',
    commandCategory: 'Admin',
    usages: '[]',
    cooldowns: 1,
    usePrefix: false,
};

// Chuyển DD/MM/YYYY → MM/DD/YYYY
function formatDate(input = '') {
    const [d, m, y] = input.split('/');
    return `${m}/${d}/${y}`;
}

// ✅ Tự động update nickname và xoá nhóm hết hạn mỗi ngày
module.exports.onLoad = ({ api }) => {
    setInterval(async () => {
        const now = moment().tz('Asia/Ho_Chi_Minh');
        const today = now.format('DD/MM/YYYY');

        // 1️⃣ Tự update nickname lúc 0h
        if (now.hours() === 0 && now.minutes() < 5 && lastUpdatedDate !== today) {
            lastUpdatedDate = today;
            fs.writeFileSync(cachePath, today);
            await updateNickname(api);
            logger(`Đã cập nhật biệt danh ngày ${today} lúc ${now.format('HH:mm:ss')}`, '[ RENT ]');
        }

        // 2️⃣ Kiểm tra nhóm hết hạn (chạy mỗi phút)
        const expiredGroups = data.filter(g =>
            moment(g.time_end, 'DD/MM/YYYY').isBefore(now, 'day')
        );

        for (const g of expiredGroups) {
            try {
                await api.sendMessage(
                    `⚠️ Nhóm này đã **hết hạn thuê bot** vào ngày ${g.time_end}!\n` +
                    `🕒 Vui lòng liên hệ admin để gia hạn và tiếp tục sử dụng.\n\nCảm ơn đã đồng hành ❤️`,
                    g.t_id
                );
                await api.changeNickname(
                    `『 ${global.config.PREFIX} 』 ⪼ ${global.config.BOTNAME} | HSD: Hết hạn ❌`,
                    g.t_id,
                    api.getCurrentUserID()
                );
                // Xoá khỏi danh sách
                data = data.filter(x => x.t_id !== g.t_id);
                saveData();
                logger(`Đã xoá nhóm hết hạn: ${g.t_id}`, '[ RENT ]');
            } catch (err) {
                logger(`Lỗi khi xoá nhóm hết hạn ${g.t_id}: ${err.message}`, '[ RENT ]');
            }
        }

    }, 60 * 1000);
};

// Toàn bộ phần lệnh run & handleReply giữ nguyên
module.exports.run = async function ({ api, event, args }) {
    const send = (msg) => api.sendMessage(msg, event.threadID, event.messageID);
    const t_id = event.threadID;
    const senderID = event.senderID;
    const isAdmin = global.config.NDH.includes(senderID);

    switch (args[0]) {
        case 'add': {
            if (!isAdmin) return send('⚠️ Chỉ Admin mới được dùng lệnh này!');
            let targetTid = t_id, targetUid = senderID, days = 30;
            if (args.length === 2) days = parseInt(args[1]);
            else if (args.length === 3) { targetUid = args[1]; days = parseInt(args[2]); }
            else if (args.length >= 4) { targetTid = args[1]; targetUid = args[2]; days = parseInt(args[3]); }

            if (isNaN(days) || days <= 0) return send('❎ Số ngày không hợp lệ!');

            const time_start = moment().tz('Asia/Ho_Chi_Minh').startOf('day').format('DD/MM/YYYY');
            const time_end = moment().tz('Asia/Ho_Chi_Minh').startOf('day').add(days, 'days').format('DD/MM/YYYY');

            let existing = data.find(x => x.t_id == targetTid);
            if (existing) {
                existing.time_end = moment(existing.time_end, 'DD/MM/YYYY').add(days, 'days').format('DD/MM/YYYY');
                send(`✅ Đã gia hạn thêm cho nhóm ${targetTid}\n- Hết hạn: ${existing.time_end}`);
            } else {
                data.push({ t_id: targetTid, id: targetUid, time_start, time_end });
                send(`✅ Đã thêm nhóm ${targetTid} vào danh sách thuê bot\n- Hết hạn: ${time_end}`);
            }

            saveData();
            updateNickname(api, [targetTid]);
            break;
        }

        case 'list': {
            if (!isAdmin) return send('⚠️ Chỉ Admin mới được dùng lệnh này!');
            if (!data.length) return send('❎ Danh sách thuê bot trống.');
            const list = data.map((g, i) => {
                const threadName = global.data.threadInfo.get(g.t_id)?.threadName || 'Không rõ';
                const userName = global.data.userName.get(g.id) || 'Không xác định';
                return `${i + 1}. ${userName} | ${threadName}\nHSD: ${g.time_end}`;
            }).join('\n-------------------\n');

            api.sendMessage(`[ DANH SÁCH THUÊ BOT ]\n-------------------\n${list}\n-------------------\nReply STT để xem thông tin hoặc gõ del/giahan`, t_id, (err, info) => {
                global.client.handleReply.push({ name: this.config.name, messageID: info.messageID, event });
            }, event.messageID);
            break;
        }

        case 'info': {
            const infoData = data.find(x => x.t_id === t_id);
            if (!infoData) return send('❎ Nhóm này không có trong danh sách thuê bot.');

            try {
                const threadInfo = await api.getThreadInfo(t_id);
                const days_left = moment(infoData.time_end, 'DD/MM/YYYY').diff(moment().tz('Asia/Ho_Chi_Minh'), 'days');
                const status = days_left >= 0 ? '✅ Còn hạn' : '❌ Đã hết hạn';
                const userPhoto = `https://graph.facebook.com/${infoData.id}/picture?height=720&width=720&access_token=6628568379%7Cc1e620fa708a1d5696fb991c1bde5662`;
                const groupPhoto = threadInfo.imageSrc;
                const attachments = [];
                if (userPhoto) attachments.push(await streamURL(userPhoto));
                if (groupPhoto) attachments.push(await streamURL(groupPhoto));

                send({
                    body:
                        `[ THÔNG TIN THUÊ BOT ]\n` +
                        `👤 Người thuê: ${global.data.userName.get(infoData.id) || 'Không xác định'}\n` +
                        `🔗 Facebook: https://facebook.com/${infoData.id}\n` +
                        `🏘️ Nhóm: ${threadInfo.threadName || 'Không rõ'}\n` +
                        `🔗 TID: ${t_id}\n` +
                        `📆 Ngày thuê: ${infoData.time_start}\n` +
                        `⏳ Ngày hết hạn: ${infoData.time_end}\n` +
                        `📌 Tình trạng: ${status}\n` +
                        `📎 Còn lại: ${days_left >= 0 ? `${days_left} ngày` : 'Đã hết hạn'}`,
                    attachment: attachments
                });
            } catch (err) {
                logger(`Lỗi info: ${err.message}`, '[ RENT ]');
                send('❎ Lỗi khi lấy thông tin nhóm.');
            }
            break;
        }

        case 'remove': {
            if (!isAdmin) return send('⚠️ Chỉ Admin mới được dùng lệnh này!');
            const tidToRemove = args[1] || t_id;
            const idx = data.findIndex(x => x.t_id === tidToRemove);
            if (idx === -1) return send(`❎ Nhóm ${tidToRemove} không tồn tại trong danh sách thuê bot.`);
            data.splice(idx, 1);
            saveData();
            updateNickname(api, [tidToRemove]);
            send(`✅ Đã xóa nhóm ${tidToRemove} khỏi danh sách thuê bot.`);
            break;
        }

        case 'update': {
            if (!isAdmin) return send('⚠️ Chỉ Admin mới được dùng lệnh này!');
            if (args[1] === 'all') { updateNickname(api); send('✅ Đã cập nhật nickname tất cả nhóm'); }
            else { updateNickname(api, [t_id]); send('✅ Đã cập nhật nickname nhóm hiện tại'); }
            break;
        }

        case 'lọc': {
            if (!isAdmin) return send('⚠️ Chỉ Admin mới được dùng lệnh này!');
            const expired = data.filter(g => new Date(formatDate(g.time_end)).getTime() < Date.now());
            if (!expired.length) return send('✅ Không có nhóm nào hết hạn.');
            expired.forEach(g => data = data.filter(x => x.t_id !== g.t_id));
            saveData();
            expired.forEach(g => api.removeUserFromGroup(api.getCurrentUserID(), g.t_id));
            send(`🗑️ Đã xóa và out ${expired.length} nhóm hết hạn.`);
            break;
        }

        case 'fix': {
            if (!isAdmin) return send('⚠️ Chỉ Admin mới được dùng lệnh này!');
            await updateNickname(api);
            send('✅ Đã kiểm tra và sửa nickname nếu có lỗi.');
            break;
        }

        default:
            send(`⚙️ Lệnh có sẵn:\nadd | remove | list | info | update | lọc | fix`);
    }
};

// handleReply giữ nguyên như cũ
module.exports.handleReply = async function ({ api, event, handleReply }) {
    const send = (msg) => api.sendMessage(msg, event.threadID, event.messageID);
    if (event.senderID !== handleReply.event.senderID) return;

    const args = event.body.split(' ');
    const cmd = args[0].toLowerCase();

    if (cmd === 'del') {
        const indices = args.slice(1).map(i => parseInt(i) - 1).filter(i => !isNaN(i) && i >= 0 && i < data.length).sort((a, b) => b - a);
        if (!indices.length) return send('❎ Không có STT hợp lệ để xóa.');

        const tids = [];
        for (const i of indices) {
            tids.push(data[i].t_id);
            data.splice(i, 1);
        }
        saveData();
        updateNickname(api, tids);
        return send(`✅ Đã xóa ${tids.length} nhóm thành công.`);
    }

    if (cmd === 'giahan') {
        const index = parseInt(args[1]) - 1;
        const days = parseInt(args[2]);
        if (isNaN(index) || !data[index] || isNaN(days) || days <= 0) return send('❌ STT hoặc số ngày không hợp lệ.');
        data[index].time_end = moment(data[index].time_end, 'DD/MM/YYYY').add(days, 'days').format('DD/MM/YYYY');
        saveData();
        updateNickname(api, [data[index].t_id]);
        return send(`✅ Đã gia hạn nhóm thêm ${days} ngày.`);
    }

    if (!isNaN(cmd)) {
        const idx = parseInt(cmd) - 1;
        if (!data[idx]) return send('❎ STT không tồn tại.');
        const g = data[idx];
        const days_left = moment(g.time_end, 'DD/MM/YYYY').diff(moment().tz('Asia/Ho_Chi_Minh'), 'days');
        const status = days_left >= 0 ? '✅ Còn hạn' : '❌ Đã hết hạn';
        send(
            `[ THÔNG TIN THUÊ BOT - Nhóm ${cmd} ]\n` +
            `👤 Người thuê: ${global.data.userName.get(g.id) || 'Không xác định'}\n` +
            `🔗 Facebook: https://facebook.com/${g.id}\n` +
            `🔗 TID: ${g.t_id}\n` +
            `📆 Ngày thuê: ${g.time_start}\n` +
            `⏳ Ngày hết hạn: ${g.time_end}\n` +
            `📌 Tình trạng: ${status}\n` +
            `📎 Còn lại: ${days_left >= 0 ? `${days_left} ngày` : 'Đã hết hạn'}`
        );
    }
};