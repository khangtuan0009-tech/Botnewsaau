const axios = require("axios");
const fs = require("fs");
const Canvas = require("canvas");
const fetch = require("node-fetch");
const path = require("path");

// --- CONFIGURATION ---
module.exports.config = {
    name: "spt",
    version: "3.5.0",
    hasPermssion: 0,
    credits: "nvh",
    description: "Tìm kiếm nhạc Spotify, tải MP3 với cardmusic, xem lyrics.",
    commandCategory: "Tiện ích",
    usages: "[từ khóa] | -lyrics [tên bài hát]",
    cooldowns: 5,
  usePrefix: true,
};

const API_ENDPOINTS = {
    spotify: {
        token: 'https://accounts.spotify.com/api/token',
        search: 'https://api.spotify.com/v1/search',
    },
    lyrics: 'https://api.lyrics.ovh/v1',
};

const API_KEYS = {
    spotify: {
        clientId: 'b9d2557a2dd64105a37f413fa5ffcda4',
        clientSecret: '41bdf804974e4e70bfa0515bb3097fbb'
    }
};

// --- HELPER FUNCTIONS ---
function formatDuration(ms) {
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const seconds = Math.floor((ms / 1000) % 60);
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function parseSearchQuery(query) {
    return {
        lyrics: /-lyrics/i.test(query),
        general: query.replace(/-lyrics/i, '').trim()
    };
}

async function getSpotifyToken() {
    const response = await axios.post(API_ENDPOINTS.spotify.token,
        'grant_type=client_credentials', {
            headers: {
                'Authorization': 'Basic ' + Buffer.from(`${API_KEYS.spotify.clientId}:${API_KEYS.spotify.clientSecret}`).toString('base64'),
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
    return response.data.access_token;
}

async function searchSpotify(query, limit = 8) {
    const token = await getSpotifyToken();
    const response = await axios.get(API_ENDPOINTS.spotify.search, {
        headers: { Authorization: `Bearer ${token}` },
        params: { q: query, type: 'track', limit: limit, market: 'VN' }
    });

    if (!response.data.tracks || response.data.tracks.items.length === 0) return [];

    return response.data.tracks.items.map(item => ({
        id: item.id,
        title: item.name,
        artist: item.artists.map(a => a.name).join(', '),
        duration: item.duration_ms,
        thumbnail: item.album.images[0]?.url,
        album: item.album.name,
    }));
}

async function getTrackLyrics(artist, title) {
    try {
        const response = await axios.get(`${API_ENDPOINTS.lyrics}/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`);
        return response.data.lyrics || null;
    } catch {
        return null;
    }
}

// --- DOWNLOAD DIRECT FROM SPOTIFY (downr.org API với headers đầy đủ) ---
async function downloadFromSpotify(trackInfo) {
    try {
        const trackUrl = `https://open.spotify.com/track/${trackInfo.id}`;
        const data = JSON.stringify({ url: trackUrl });

        const response = await fetch("https://downr.org/.netlify/functions/download", {
            method: "POST",
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36',
                'Content-Type': 'application/json',
                'authority': 'downr.org',
                'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
                'origin': 'https://downr.org',
                'referer': 'https://downr.org/',
                'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                // cookie fake để API trả đủ chất lượng
                'Cookie': '_ga=GA1.1.1562252099.1756313299; _ga_2HS60D2GS7=GS2.1.s1756316739$o2$g1$t1756317044$j59$l0$h0'
            },
            body: data
        });

        const result = await response.json();

        if (result && !result.error && result.medias && result.medias.length > 0) {
            // lọc ra các chất lượng mp3
            const audios = result.medias.filter(m => m.type === "audio" && m.extension === "mp3");

            if (audios.length === 0) throw new Error("Không tìm thấy link MP3");

            // ưu tiên 320kbps -> 160 -> 128
            let media = audios.find(a => /320/.test(a.quality)) 
                      || audios.find(a => /160/.test(a.quality)) 
                      || audios[0];

            const mp3Path = path.join(__dirname, "cache", `${trackInfo.id}.mp3`);
            const writer = fs.createWriteStream(mp3Path);

            const audioResponse = await axios({
                url: media.url,
                method: "GET",
                responseType: "stream"
            });

            await new Promise((resolve, reject) => {
                audioResponse.data.pipe(writer);
                writer.on("finish", resolve);
                writer.on("error", reject);
            });

            return mp3Path;
        }
        throw new Error("API downr.org không trả về link audio.");
    } catch (err) {
        throw new Error("Không tải được MP3 từ Spotify: " + err.message);
    }
}

// --- CANVAS CARD MUSIC ---
async function createCard(track) {
    const canvas = Canvas.createCanvas(800, 400);
    const ctx = canvas.getContext("2d");

    // background mờ
    const bg = await Canvas.loadImage(track.thumbnail);
    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // ảnh album
    ctx.drawImage(bg, 40, 70, 250, 250);

    // text
    ctx.fillStyle = "#fff";
    ctx.font = "bold 32px Arial";
    ctx.fillText(track.title, 320, 150);
    ctx.font = "24px Arial";
    ctx.fillText(track.artist, 320, 200);
    ctx.fillText(`⏳ ${formatDuration(track.duration)}`, 320, 250);

    return canvas.toBuffer();
}

// --- MAIN EXECUTION ---
module.exports.run = async function({ api, event, args }) {
    const rawQuery = args.join(" ");
    if (!rawQuery) {
        return api.sendMessage(`🎵 Vui lòng nhập từ khóa.\n\nHDSD:\n- Tìm kiếm: spt [tên bài hát]\n- Lời bài hát: spt -lyrics [tên bài hát]`, event.threadID, event.messageID);
    }

    const filters = parseSearchQuery(rawQuery);
    const query = filters.general;

    try {
        const searchingMsg = await api.sendMessage(`🔍 Đang tìm kiếm "${query}"...`, event.threadID);
        const tracks = await searchSpotify(query, 8);
        api.unsendMessage(searchingMsg.messageID);

        if (tracks.length === 0) return api.sendMessage(`❌ Không tìm thấy kết quả cho "${query}".`, event.threadID);

        // LYRICS
        if (filters.lyrics) {
            const firstTrack = tracks[0];
            const lyrics = await getTrackLyrics(firstTrack.artist.split(',')[0], firstTrack.title);
            return api.sendMessage(lyrics ? 
                `🎵 Lời bài hát: ${firstTrack.title}\n👤 ${firstTrack.artist}\n\n${lyrics.substring(0, 1500)}` :
                `❌ Không tìm thấy lời cho "${firstTrack.title}".`, event.threadID);
        }

        // SEARCH LIST
        const trackList = tracks.map((t, i) => `\n${i+1}. 🎵 ${t.title}\n   👤 ${t.artist}`).join("\n");
        api.sendMessage(`🎵 Kết quả tìm kiếm cho "${query}":\n${trackList}\n\n💡 Reply số để tải về kèm cardmusic.`, event.threadID, (e, info) => {
            if (e) return;
            global.client.handleReply.push({
                type: "download_choose",
                name: module.exports.config.name,
                author: event.senderID,
                messageID: info.messageID,
                tracks
            });
        });

    } catch (e) {
        console.error(e);
        api.sendMessage(`❌ Lỗi: ${e.message}`, event.threadID);
    }
};

// --- REPLY HANDLING ---
module.exports.handleReply = async function({ api, event, handleReply }) {
    const { tracks, author } = handleReply;
    if (event.senderID !== author) return;

    const choice = parseInt(event.body);
    if (isNaN(choice) || choice < 1 || choice > tracks.length) 
        return api.sendMessage("⚠️ Lựa chọn không hợp lệ.", event.threadID);

    const track = tracks[choice - 1];
    api.unsendMessage(handleReply.messageID);

    try {
        const downloadingMsg = await api.sendMessage(`🔄 Đang tải "${track.title}"...`, event.threadID);

        // tải mp3 trước
        const mp3Path = await downloadFromSpotify(track);

        // dựng card
        const cardBuffer = await createCard(track);
        const cardPath = path.join(__dirname, "cache", "card.png");
        fs.writeFileSync(cardPath, cardBuffer);

        api.unsendMessage(downloadingMsg.messageID);

        // gửi card trước
        await api.sendMessage({
            body: `🎶 Thông tin bài hát\n🎵 ${track.title}\n👤 ${track.artist}`,
            attachment: fs.createReadStream(cardPath)
        }, event.threadID, async (err) => {
            if (err) console.error("Lỗi khi gửi card:", err);
            fs.unlinkSync(cardPath);

            // gửi mp3 ngay sau card
            try {
                await api.sendMessage({
                    body: `📥 "${track.title}"`,
                    attachment: fs.createReadStream(mp3Path)
                }, event.threadID, (err) => {
                    if (err) console.error("Lỗi khi gửi MP3:", err);
                    fs.unlinkSync(mp3Path);
                });
            } catch (mp3Err) {
                console.error("Lỗi khi gửi MP3:", mp3Err);
                api.sendMessage(`❌ Lỗi khi gửi MP3: ${mp3Err.message}`, event.threadID);
                fs.unlinkSync(mp3Path);
            }
        });

    } catch (err) {
        console.error(err);
        api.sendMessage(`❌ Lỗi: ${err.message}`, event.threadID);
    }
};