const axios = require("axios")
async function down(url) {
    return (await axios.get(url, { responseType: "stream" })).data
}
module.exports = class {
    static config = {
        name: "theme",
        version: "0.0.1",
        hasPermission: 2,
        description: "Tạo chủ đề AI",
        credits: "Hải harin",
        commandCategory: "Quản Trị Viên",
        usages: "[ prompt ]",
        cooldowns: 5,
        usePrefix: true
    }
    static async run(o) {
        const { threadID: t, messageID: m, messageReply: mrl, senderID: s } = o.event
        const send = (msg, callback) => o.api.sendMessage(msg, t, callback, m)
        const { args: a } = o
        if(!a[0]) return send("❎ Vui lòng nhập prompt")
        const prompt = a.join(" ")
        send("⏳ Đang tạo chủ đề AI, vui lòng chờ...")
        
        try {
            o.api.changeThreadColorAI(null, null, { prompt }, async (e, i) => {
                if(e) return send("❎ Lỗi không thể đổi chủ đề")
                
                try {
                    const attachments = [await down(i.img.light), await down(i.img.dark)]
                    const messageBody = `[ THEME AI CREATE ]\n\nName: ${prompt}\nID: ${i.themeID}\n\n→ Reply "s" để áp dụng chủ đề này\n→ Reply prompt để bot tạo lại chủ đề`
                    
                    send({ 
                        body: messageBody, 
                        attachment: attachments 
                    }, (error, info) => {
                        if (!error) {
                            global.client.handleReply.push({
                                name: this.config.name,
                                messageID: info.messageID,
                                author: s,
                                themeID: i.themeID,
                            })
                        }
                    })
                } catch (downloadError) {
                    console.error("Download error:", downloadError)
                    send("❎ Lỗi tải hình ảnh chủ đề")
                }
            })
        } catch (error) {
            console.error("Theme creation error:", error)
            send("❎ Có lỗi xảy ra khi tạo chủ đề")
        }
    }
    static async handleReply(o) {
        const { threadID: t, messageID: m, body: b, senderID: s } = o.event
        const { themeID, author } = o.handleReply
        if(s !== author) return o.api.sendMessage("❎ Bạn không có quyền thực hiện lệnh này", t, m)
        const send = (msg, callback) => o.api.sendMessage(msg, t, callback, m)
        if(b.toLowerCase() === "s") {
            try {
                o.api.changeThreadColorAI(t, s, { type: "apply", themeID }, (e) => {
                    if(e) return send("❎ Lỗi không thể áp dụng chủ đề")
                    send("✅ Đã áp dụng chủ đề thành công")
                })
            } catch (error) {
                console.error("Apply theme error:", error)
                send("❎ Lỗi không thể áp dụng chủ đề")
            }
        } else {
            const body = b.trim()
            if(!body) return send("❎ Vui lòng nhập prompt")
            
            try {
                o.api.changeThreadColorAI(null, null, { prompt: body }, async (e, i) => {
                    if(e) return send("❎ Lỗi không thể đổi chủ đề")
                    
                    try {
                        const attachments = [await down(i.img.light), await down(i.img.dark)]
                        const messageBody = `[ THEME AI CREATE ]\n\nName: ${body}\nID: ${i.themeID}\n\n→ Reply "s" để áp dụng chủ đề này\n→ Reply prompt để bot tạo lại chủ đề`
                        
                        send({ 
                            body: messageBody, 
                            attachment: attachments 
                        }, (error, info) => {
                            if (!error) {
                                global.client.handleReply.push({
                                    name: this.config.name,
                                    messageID: info.messageID,
                                    author: s,
                                    themeID: i.themeID,
                                })
                            }
                        })
                    } catch (downloadError) {
                        console.error("Download error:", downloadError)
                        send("❎ Lỗi tải hình ảnh chủ đề")
                    }
                })
            } catch (error) {
                console.error("Theme creation error:", error)
                send("❎ Có lỗi xảy ra khi tạo chủ đề mới")
            }
        }
    }
}