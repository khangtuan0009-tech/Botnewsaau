const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "att",
  eventType: ["log:thread-color"],
  version: "3.4.0",
  hasPermssion: 3,
  credits: "DongDev & nvh",
  description: "Chống đổi màu chủ đề nhóm Messenger",
  commandCategory: "QTV",
  usages: "[bật | tắt]",
  cooldowns: 5,
  usePrefix: true
};

const filePath = path.join(__dirname, "data", "antitheme.json");

module.exports.onLoad = function () {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify({}, null, 2));
};

module.exports.run = async function ({ api, event, Threads }) {
  const { threadID, messageID } = event;
  let data = {};

  try {
    data = JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    data = {};
  }

  let themeID = "";
  try {
    const info = await Threads.getInfo(threadID);
    themeID = info?.threadTheme?.id || "";
  } catch (err) {
    console.error("Lỗi lấy thông tin theme:", err);
  }

  if (!data[threadID]) {
    data[threadID] = {
      themeID,
      enabled: true
    };
  } else {

    data[threadID].enabled = !data[threadID].enabled;
    if (data[threadID].enabled) {
      data[threadID].themeID = themeID;
    }
  }

  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");

  const status = data[threadID].enabled ? "✅ Đã bật" : "🚫 Đã tắt";
  api.sendMessage(`${status} chống đổi màu chủ đề cho nhóm này.`, threadID, messageID);
};

module.exports.handleEvent = async function ({ api, event, Threads }) {
  if (event.logMessageType !== "log:thread-color") return;
  const { threadID, logMessageData, author } = event;

  if (!fs.existsSync(filePath)) return;
  let data;
  try {
    data = JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return;
  }

  const info = data[threadID];
  if (!info || !info.enabled) return;

  const oldTheme = info.themeID;
  const newTheme = logMessageData?.theme_id;

  if (oldTheme && newTheme && oldTheme !== newTheme) {
    try {
      // Khôi phục theme cũ
      await api.changeThreadColor(oldTheme, threadID);

      // Cập nhật lại dữ liệu theme trong Threads (để không bị ghi đè)
      const threadData = await Threads.getData(threadID);
      threadData.threadInfo.threadTheme.themeID = oldTheme;
      await Threads.setData(threadID, { threadInfo: threadData.threadInfo });

      // 🔹 Lấy tên người đổi theme
      let name = "Người lạ";
      try {
        const userInfo = await api.getUserInfo(author);
        name = userInfo?.[author]?.name || "Người lạ";
      } catch {
        name = "Người lạ";
      }

      api.sendMessage(
        `⚠️ ${name} vừa đổi màu chủ đề — đã khôi phục lại màu cũ!`,
        threadID
      );
    } catch (err) {
      console.error("Lỗi khôi phục màu chủ đề:", err);
    }
  }
};