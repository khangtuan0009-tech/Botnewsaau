const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
 name: "sms",
 version: "1.3.0",
 hasPermssion: 0,
 credits: "nvh",
 description: "sms free ",
 commandCategory: "Tiện ích",
 usages: "[get | inbox <số> | premium add/del <uid>]",
 cooldowns: 5,
  usePrefix: true
};

const API_KEY = "NemG_tWsiRRLk"; 
const BASE_URL = "https://api.thenamk3.net/api/sms/sms24";
const DATA_PATH = path.join(__dirname, "cache", "smsUser.json");
const LIMIT_PER_DAY = 5;

// Load data user
function loadData() {
 if (!fs.existsSync(DATA_PATH)) return {};
 return JSON.parse(fs.readFileSync(DATA_PATH));
}

// Save data user
function saveData(data) {
 fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

// Check quota
function checkQuota(senderID) {
 let data = loadData();
 let today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

 if (!data[senderID]) {
 data[senderID] = { date: today, count: 0, premium: false };
 }

 // Nếu là premium → không giới hạn
 if (data[senderID].premium) {
 return { ok: true, premium: true, data };
 }

 // Reset nếu qua ngày mới
 if (data[senderID].date !== today) {
 data[senderID].date = today;
 data[senderID].count = 0;
 }

 if (data[senderID].count >= LIMIT_PER_DAY) {
 return { ok: false, premium: false, data };
 }

 // +1 lượt
 data[senderID].count += 1;
 saveData(data);
 return { ok: true, premium: false, data };
}

module.exports.run = async function({ api, event, args }) {
 const senderID = event.senderID;
 let data = loadData();

 // Admin quản lý premium
 if (args[0] === "premium") {
 if (event.senderID != "100073639420918") { // thay UID admin thật của bạn
 return api.sendMessage("❌ Bạn không có quyền quản lý premium!", event.threadID, event.messageID);
 }

 if (args[1] === "add" && args[2]) {
 let uid = args[2];
 if (!data[uid]) data[uid] = { date: "", count: 0, premium: true };
 else data[uid].premium = true;
 saveData(data);
 return api.sendMessage(`✅ Đã thêm UID ${uid} vào danh sách premium!`, event.threadID, event.messageID);
 }

 if (args[1] === "del" && args[2]) {
 let uid = args[2];
 if (data[uid]) {
 data[uid].premium = false;
 saveData(data);
 }
 return api.sendMessage(`✅ Đã xoá UID ${uid} khỏi danh sách premium!`, event.threadID, event.messageID);
 }

 return api.sendMessage("⚡️Dùng: sms premium add <uid> | sms premium del <uid>", event.threadID, event.messageID);
 }

 if (args.length === 0) {
 return api.sendMessage(
 "⚡️Dùng lệnh:\n" +
 "• sms get → lấy số điện thoại VN\n" +
 "• sms inbox <số> → xem tin nhắn của số đó\n" +
 "• sms premium add/del <uid> (admin)\n" +
 `\n📌 Free: ${LIMIT_PER_DAY} lần/ngày\n📌 Premium: Không giới hạn`,
 event.threadID,
 event.messageID
 );
 }

 // Check quota
 let quota = checkQuota(senderID);
 if (!quota.ok) {
 return api.sendMessage(
 "❌ Bạn đã dùng hết " + LIMIT_PER_DAY + " lượt miễn phí hôm nay!\n" +
 "💳 Muốn thêm lượt vui lòng liên hệ Admin để thuê premium.",
 event.threadID,
 event.messageID
 );
 }

 const type = args[0].toLowerCase();

 // 🟢 Lấy danh sách số
 if (type === "get") {
 try {
 const res = await axios.get(`${BASE_URL}/numbers?country=vn&apikey=${API_KEY}`);
 if (!res.data.ok) return api.sendMessage("❌ API lỗi!", event.threadID, event.messageID);

 let msg = "📱 Danh sách số VN:\n\n";
 res.data.so_dien_thoai.forEach((item, i) => {
 msg += `${i + 1}. ${item.so_dien_thoai}\n`;
 });

 return api.sendMessage(msg, event.threadID, event.messageID);
 } catch (e) {
 return api.sendMessage("❌ Không thể lấy số!\n" + e.message, event.threadID, event.messageID);
 }
 }

 // 🟢 Xem inbox của số
 if (type === "inbox") {
 if (!args[1]) return api.sendMessage("⚡️Vui lòng nhập số! (ví dụ: sms inbox 84965667788)", event.threadID, event.messageID);
 const number = args[1];

 try {
 const res = await axios.get(`${BASE_URL}/messages?number=${number}&apikey=${API_KEY}`);
 if (!res.data.ok || !res.data.tin_nhan || res.data.tin_nhan.length === 0) {
 return api.sendMessage("❌ Không có tin nhắn nào!", event.threadID, event.messageID);
 }

 let msg = `📩 Tin nhắn của số ${number}:\n\n`;
 res.data.tin_nhan.forEach((sms, i) => {
 let otpMatch = sms.noi_dung.match(/\b\d{4,8}\b/);
 let otp = otpMatch ? `🔑 OTP: ${otpMatch[0]}` : "⛔ Không thấy mã OTP";

 msg += `${i + 1}. Từ: ${sms.tu}\n📜 Nội dung: ${sms.noi_dung}\n${otp}\n\n`;
 });

 return api.sendMessage(msg, event.threadID, event.messageID);
 } catch (e) {
 return api.sendMessage("❌ Không thể lấy tin nhắn!\n" + e.message, event.threadID, event.messageID);
 }
 }

 return api.sendMessage("⚡️Sai cú pháp! Dùng: sms get | sms inbox <số>", event.threadID, event.messageID);
};