module.exports.config = {
  name: 'menu',
  version: '3.0.0',
  hasPermssion: 0,
  credits: 'nvh',
  description: 'Xem danh sách nhóm lệnh, thông tin lệnh',
  commandCategory: 'Nhóm',
  usages: '[...name commands|all]',
  cooldowns: 5,
  usePrefix: false,
  images: [],
  envConfig: {
    autoUnsend: {
      status: true,
      timeOut: 60
    }
  }
};

const { autoUnsend = this.config.envConfig.autoUnsend } =
  global.config == undefined ? {} : global.config.menu == undefined ? {} : global.config.menu;
const { findBestMatch } = require('string-similarity');

// === GOM NHÓM TRÙNG NGHĨA ===
const aliasGroups = {
  "👑 Admin": ["admin", "qtv", "quản trị viên", "quản trị", "quản trị viên"],
  "🧰 Tiện ích": ["tiện ích", "utility", "công cụ"],
  "💻 Hệ thống": ["hệ thống", "system"],
  "🎵 Nhạc": ["nhạc", "music", "media"],
  "📦 Box": ["box", "box chat", "nhóm", "group", "quản lí box"],
  "🎮 Game": ["game", "free fire", "tài chính", "money", "coin", "tiền tệ"],
  "💬 Khác": ["khác", "no prefix"]
};

function normalizeCategory(cat) {
  if (!cat) return "💬 Khác";
  cat = cat.toLowerCase().trim();
  for (const [main, aliases] of Object.entries(aliasGroups)) {
    if (aliases.includes(cat)) return main;
  }
  return "📁 " + cat.charAt(0).toUpperCase() + cat.slice(1);
}

function shortDesc(desc) {
  if (!desc) return '';
  return desc.length > 40 ? desc.slice(0, 37) + '...' : desc;
}

module.exports.run = async function ({ api, event, args }) {
  const { sendMessage: send, unsendMessage: un } = api;
  const { threadID: tid, messageID: mid, senderID: sid } = event;
  const cmds = global.client.commands;
  const isAdminOrNDH = global.config.ADMINBOT.includes(sid) || global.config.NDH.includes(sid);

  if (args.length >= 1) {
    // --- Xem info 1 lệnh ---
    if (typeof cmds.get(args.join(' ')) == 'object') {
      const body = infoCmds(cmds.get(args.join(' ')).config);
      return send({ body }, tid, mid);
    }

    // --- Xem tất cả lệnh ---
    if (args[0] == 'all') {
      const data = Array.from(cmds.values()).filter(cmd =>
        isAdminOrNDH || normalizeCategory(cmd.config.commandCategory) !== '👑 Admin'
      );

      let txt = '╭───『📜 DANH SÁCH TOÀN BỘ LỆNH』───╮\n\n';
      let count = 0;
      for (const cmd of data) {
        count++;
        const name = cmd.config.name.padEnd(12, ' ');
        txt += `${count}. ${name} → ${shortDesc(cmd.config.description)}\n`;
      }

      // Dòng admin xuống cuối
      txt += `\n│ Admin Bot: ${global.config.ADMIN_NAME || 'Chưa có'}\n`;
      txt += `│ Facebook Admin: ${global.config.FACEBOOK_ADMIN || 'Chưa có'}\n`;
      txt += `\n📊 Tổng: ${data.length} lệnh`;

      return send({ body: txt }, tid, (err, info) => {
        if (autoUnsend.status) setTimeout(() => un(info.messageID), 1000 * autoUnsend.timeOut);
      }, mid);
    }

    // --- Gợi ý lệnh tương tự ---
    const cmdsValue = Array.from(cmds.values()).filter(cmd =>
      isAdminOrNDH || normalizeCategory(cmd.config.commandCategory) !== '👑 Admin'
    );
    const arrayCmds = cmdsValue.map(cmd => cmd.config.name);
    const similarly = findBestMatch(args.join(' '), arrayCmds);
    if (similarly.bestMatch.rating >= 0.3)
      return send({ body: `🔍 "${args.join(' ')}" có thể là lệnh "${similarly.bestMatch.target}"?` }, tid, mid);
  }

  // --- Hiển thị danh sách nhóm ---
  const data = commandsGroup(isAdminOrNDH);
  let txt = "╭───『📚 DANH MỤC LỆNH 』───╮\n";
  let count = 0;
  for (const { commandCategory, commandsName } of data)
    txt += `│ ${++count}. ${commandCategory} → ${commandsName.length} lệnh\n`;

  // Admin xuống cuối
  txt += `│ Admin Bot: ${global.config.ADMIN_NAME || 'Chưa có'}\n`;
  txt += `│ Facebook Admin: ${global.config.FACEBOOK_ADMIN || 'Chưa có'}\n`;
  txt += `╰──────────────────────────╯\n📊 Tổng cộng: ${data.reduce((a, b) => a + b.commandsName.length, 0)} lệnh\n\n📌 Reply số thứ tự để xem chi tiết nhóm.`;

  send({ body: txt }, tid, (a, b) => {
    global.client.handleReply.push({ name: this.config.name, messageID: b.messageID, author: sid, 'case': 'infoGr', data });
    if (autoUnsend.status) setTimeout(() => un(b.messageID), 1000 * autoUnsend.timeOut);
  }, mid);
};

module.exports.handleReply = async function ({ handleReply: $, api, event }) {
  const { sendMessage: send, unsendMessage: un } = api;
  const { threadID: tid, messageID: mid, senderID: sid, args } = event;

  if (sid != $.author) return send(`⛔ Bạn không có quyền truy cập!`, tid, mid);

  switch ($.case) {
    case 'infoGr': {
      const data = $.data[args[0] - 1];
      if (!data) return send(`❌ Nhập sai số thứ tự nhóm!`, tid, mid);
      un($.messageID);

      let txt = `╭───『 ${data.commandCategory.toUpperCase()} 』───╮\n`;
      let count = 0;
      for (const name of data.commandsName) {
        const cmdInfo = global.client.commands.get(name).config;
        if (cmdInfo)
          txt += `│ ${++count}. ${name} → ${shortDesc(cmdInfo.description)}\n`;
      }

      // Admin xuống cuối
      txt += `│ Admin Bot: ${global.config.ADMIN_NAME || 'Chưa có'}\n`;
      txt += `│ Facebook Admin: ${global.config.FACEBOOK_ADMIN || 'Chưa có'}\n`;
      txt += `╰──────────────────────────╯\n📦 Tổng: ${data.commandsName.length} lệnh\n\n📌 Reply số thứ tự để xem chi tiết từng lệnh.`;

      return send({ body: txt }, tid, (a, b) => {
        global.client.handleReply.push({ name: this.config.name, messageID: b.messageID, author: sid, 'case': 'infoCmds', data: data.commandsName });
        if (autoUnsend.status) setTimeout(() => un(b.messageID), 1000 * autoUnsend.timeOut);
      });
    }

    case 'infoCmds': {
      const cmdData = global.client.commands.get($.data[args[0] - 1]);
      if (!cmdData) return send(`⚠️ Không tìm thấy lệnh "${args[0]}"`, tid, mid);
      const msg = infoCmds(cmdData.config);
      un($.messageID);
      return send({ body: msg }, tid, mid);
    }
  }
};

// === INFO FORMAT ===
function infoCmds(cmd) {
  return (
    `╭───『📖 THÔNG TIN LỆNH 』───╮\n` +
    `│ 🧩 Tên: ${cmd.name}\n` +
    `│ 📦 Nhóm: ${normalizeCategory(cmd.commandCategory)}\n` +
    `│ ⚙️ Phiên bản: ${cmd.version}\n` +
    `│ 👑 Quyền hạn: ${permissionText(cmd.hasPermssion)}\n` +
    `│ ✍️ Tác giả: ${cmd.credits}\n` +
    `│ 📝 Mô tả: ${cmd.description}\n` +
    `│ ⏱️ Cooldown: ${cmd.cooldowns}s\n` +
    `╰──────────────────────────╯`
  );
}

function permissionText(perm) {
  switch (perm) {
    case 0: return 'Thành viên';
    case 1: return 'Quản trị viên nhóm';
    case 2: return 'Admin bot';
    case 3: return 'Người điều hành bot';
    default: return 'Không xác định';
  }
}

function commandsGroup(isAdminOrNDH) {
  const groups = [];
  const cmds = global.client.commands.values();
  for (const cmd of cmds) {
    const { name } = cmd.config;
    const category = normalizeCategory(cmd.config.commandCategory || "💬 Khác");
    if (isAdminOrNDH || category !== '👑 Admin') {
      const group = groups.find(g => g.commandCategory === category);
      if (group) group.commandsName.push(name);
      else groups.push({ commandCategory: category, commandsName: [name] });
    }
  }
  groups.sort((a, b) => a.commandCategory.localeCompare(b.commandCategory));
  return groups;
}