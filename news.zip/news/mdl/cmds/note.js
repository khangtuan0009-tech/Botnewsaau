const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
 config: {
 name: 'note',
 version: '1.0.0',
 hasPermssion: 3,
 usePrefix: false,
 credits: 'lechii',
 description: 'Chỉnh sửa nội dung code với tìm kiếm file thông minh',
 commandCategory: 'Admin',
 images: ["https://files.catbox.moe/yw2sq3.jpg"],
 usages: 'note <filename> [url] - Tự động tìm file trong project',
 cooldowns: 0,
 },

 // Hàm tìm file tối ưu - chỉ exact và name match để tránh kết quả rác
 findFile: function(filename, startDir = process.cwd()) {
 const exactMatches = [];
 const nameMatches = [];
 const skipDirs = new Set(['node_modules', '.git', '.next', 'dist', 'build', '.replit-cache']);
 
 function searchRecursive(dir, depth = 0) {
 if (depth > 8) return; // Giảm độ sâu để tăng hiệu suất
 
 try {
 const items = fs.readdirSync(dir);
 
 for (const item of items) {
 if (skipDirs.has(item)) continue;
 
 const fullPath = path.join(dir, item);
 let stat;
 
 try {
 stat = fs.statSync(fullPath);
 } catch (e) {
 continue; // Skip file lỗi quyền truy cập
 }
 
 if (stat.isFile()) {
 const isInModules = fullPath.includes('modules');
 const fileInfo = { 
 path: fullPath, 
 isInModules,
 fileName: item
 };
 
 // 1. Exact match - ưu tiên cao nhất
 if (item === filename) {
 exactMatches.push(fileInfo);
 if (isInModules) return; // Tìm thấy trong modules thì dừng ngay
 }
 // 2. Name match - cùng tên nhưng khác extension
 else if (path.parse(item).name === path.parse(filename).name) {
 nameMatches.push(fileInfo);
 }
 } else if (stat.isDirectory()) {
 searchRecursive(fullPath, depth + 1);
 }
 }
 } catch (error) {
 // Bỏ qua lỗi đọc thư mục
 }
 }
 
 searchRecursive(startDir);
 
 // Sắp xếp ưu tiên modules trước
 const sortByPriority = arr => arr.sort((a, b) => b.isInModules - a.isInModules);
 
 // Chỉ trả về exact và name match - loại bỏ partial để tránh kết quả rác
 return [
 ...sortByPriority(exactMatches).map(f => f.path),
 ...sortByPriority(nameMatches).map(f => f.path)
 ];
 },

 run: async function(o) {
 const name = module.exports.config.name;
 const url = o.event?.messageReply?.args?.[0] || o.args[1];
 const filename = o.args[0];
 const send = msg => new Promise(r => o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res), o.event.messageID));

 if (!filename) {
 return send(`❌ Vui lòng nhập tên file!\n\n📝 Cách dùng:\n• note config.json\n• note check.js\n• note note.js\n\n✨ Sẽ tự động tìm file trong project!`);
 }

 try {
 if (/^https:\/\//.test(url)) {
 // Tìm file trước khi replace
 const foundFiles = this.findFile(filename);
 
 if (foundFiles.length === 0) {
 return send(`❌ Không tìm thấy file: ${filename}\n\n🔍 Đã tìm kiếm trong toàn bộ project!`);
 }
 
 // Nếu có nhiều file, yêu cầu chọn
 if (foundFiles.length > 1) {
 let fileList = `🔍 Tìm thấy ${foundFiles.length} file khớp:\n\n`;
 foundFiles.forEach((file, index) => {
 const relativePath = path.relative(process.cwd(), file);
 const isInModules = file.includes('/modules/') || file.includes('\\modules\\');
 fileList += `${index + 1}. ${relativePath}${isInModules ? ' 📁' : ''}\n`;
 });
 fileList += `\n💡 Reply số để chọn file (ví dụ: 1, 2, 3...)`;
 
 return send(fileList).then(res => {
 res = {
 ...res,
 name,
 foundFiles,
 o,
 url,
 action: 'select_file_for_replace',
 };
 global.client.handleReply.push(res);
 });
 }
 
 let filePath = foundFiles[0];
 
 // Xử lý URL với ?raw=true hoặc &raw=true
 let processedUrl = url;
 if (url.includes('?raw=true') || url.includes('&raw=true')) {
 // Lấy content từ URL raw
 processedUrl = url;
 } else {
 // Thêm ?raw=true nếu chưa có
 processedUrl = url + (url.includes('?') ? '&raw=true' : '?raw=true');
 }
 
 return send(`🔗 File: ${path.relative(process.cwd(), filePath)}\n📁 Tìm thấy: ${filename}\n🌐 URL: ${processedUrl}\n\n💾 Thả cảm xúc để xác nhận thay thế nội dung file`).then(res => {
 res = {
 ...res,
 name,
 path: filePath,
 o,
 url: processedUrl,
 action: 'confirm_replace_content',
 };
 global.client.handleReaction.push(res);
 });
 } else {
 // Tìm file để export
 const foundFiles = this.findFile(filename);
 
 if (foundFiles.length === 0) {
 return send(`❌ Không tìm thấy file: ${filename}\n\n🔍 Đã tìm kiếm trong:\n• modules/ (ưu tiên)\n• utils/\n• Thư mục gốc\n• Tất cả thư mục con\n\n💡 Kiểm tra lại tên file!`);
 }
 
 // Nếu có nhiều file, yêu cầu chọn
 if (foundFiles.length > 1) {
 let fileList = `🔍 Tìm thấy ${foundFiles.length} file khớp:\n\n`;
 foundFiles.forEach((file, index) => {
 const relativePath = path.relative(process.cwd(), file);
 const isInModules = file.includes('/modules/') || file.includes('\\modules\\');
 fileList += `${index + 1}. ${relativePath}${isInModules ? ' 📁' : ''}\n`;
 });
 fileList += `\n💡 Reply số để chọn file (ví dụ: 1, 2, 3...)`;
 
 return send(fileList).then(res => {
 res = {
 ...res,
 name,
 foundFiles,
 o,
 action: 'select_file_for_export',
 };
 global.client.handleReply.push(res);
 });
 }
 
 let filePath = foundFiles[0];
 
 if (!fs.existsSync(filePath)) {
 return send(`❌ File không tồn tại: ${filePath}`);
 }

 const uuid = require('uuid').v4();
 const url_base = new URL(`https://nvhzxz.onrender.com/note/${uuid}`);
 
 const fileContent = fs.readFileSync(filePath, "utf-8");
 
 // Upload content với text/plain để đảm bảo raw hiển thị đúng
 await axios(url_base.href, {
 method: "PUT",
 headers: {
 'content-type': 'text/plain; charset=utf-8'
 },
 data: fileContent
 });
 
 // Tạo URL raw và edit từ cùng một base URL
 const rawUrl = new URL(url_base.href);
 rawUrl.searchParams.append('raw', 'true');
 
 const editUrl = url_base;

 const relativePath = path.relative(process.cwd(), filePath);
 const fileSize = fs.statSync(filePath).size;
 const lines = fs.readFileSync(filePath, 'utf-8').split('\n').length;

 return send(`📝 Raw: ${rawUrl.href}\n\n✏️ Edit: ${editUrl.href}\n────────────────\n📁 File: ${relativePath}\n\n💾 Thả cảm xúc để upload code`).then(res => {
 res = {
 ...res,
 name,
 path: filePath,
 o,
 url: rawUrl.href,
 action: 'confirm_replace_content',
 };
 global.client.handleReaction.push(res);
 });
 }
 } catch (e) {
 console.error('Note module error:', e);
 send(`❌ Lỗi: ${e.message}\n\n🔧 Debug info đã ghi vào console`);
 }
 },

 handleReaction: async function(o) {
 const _ = o.handleReaction;
 const send = msg => new Promise(r => o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res), o.event.messageID));

 try {
 if (o.event.userID != _.o.event.senderID) return;

 switch (_.action) {
 case 'confirm_replace_content': {
 const content = (await axios.get(_.url, {
 responseType: 'text',
 headers: {
 'User-Agent': 'Mozilla/5.0 (compatible; Replit-Bot/1.0)'
 }
 })).data;

 fs.writeFileSync(_.path, content);
 const relativePath = path.relative(process.cwd(), _.path);
 const newSize = fs.statSync(_.path).size;
 const newLines = content.split('\n').length;
 
 send(`✅ Đã cập nhật code thành công!\n\n📁 File: ${relativePath}\n⏰ Updated: ${new Date().toLocaleString('vi-VN')}`).then(res => {
 res = {
 ..._,
 ...res,
 };
 global.client.handleReaction.push(res);
 });
 }
 break;
 default:
 break;
 }
 } catch (e) {
 console.error('HandleReaction error:', e);
 send(`❌ Lỗi khi xử lý: ${e.message}\n\n🔧 Chi tiết: ${e.response?.status || 'Network error'}`);
 }
 },

 handleReply: async function(o) {
 const _ = o.handleReply;
 const send = msg => new Promise(r => o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res), o.event.messageID));

 try {
 if (o.event.senderID != _.o.event.senderID) return;

 const selectedIndex = parseInt(o.event.body) - 1;
 
 if (isNaN(selectedIndex) || selectedIndex < 0 || selectedIndex >= _.foundFiles.length) {
 return send(`❌ Số không hợp lệ! Vui lòng chọn từ 1 đến ${_.foundFiles.length}`);
 }

 const selectedFile = _.foundFiles[selectedIndex];
 const relativePath = path.relative(process.cwd(), selectedFile);

 switch (_.action) {
 case 'select_file_for_replace': {
 // Xử lý URL với ?raw=true hoặc &raw=true
 let processedUrl = _.url;
 if (_.url.includes('?raw=true') || _.url.includes('&raw=true')) {
 processedUrl = _.url;
 } else {
 processedUrl = _.url + (_.url.includes('?') ? '&raw=true' : '?raw=true');
 }
 
 return send(`🔗 File đã chọn: ${relativePath}\n🌐 URL: ${processedUrl}\n📁 Sẵn sàng thay thế nội dung\n\n💾 Thả cảm xúc để xác nhận thay thế`).then(res => {
 res = {
 ...res,
 name: _.name,
 path: selectedFile,
 o: _.o,
 url: processedUrl,
 action: 'confirm_replace_content',
 };
 global.client.handleReaction.push(res);
 });
 }
 case 'select_file_for_export': {
 if (!fs.existsSync(selectedFile)) {
 return send(`❌ File không tồn tại: ${selectedFile}`);
 }

 const uuid = require('uuid').v4();
 const url_base = new URL(`https://nvhzxz.onrender.com/note/${uuid}`);
 
 const fileContent = fs.readFileSync(selectedFile, "utf-8");
 
 // Upload content với text/plain để đảm bảo raw hiển thị đúng
 await axios(url_base.href, {
 method: "PUT",
 headers: {
 'content-type': 'text/plain; charset=utf-8'
 },
 data: fileContent
 });
 
 // Tạo URL raw và edit từ cùng một base URL
 const rawUrl = new URL(url_base.href);
 rawUrl.searchParams.append('raw', 'true');
 
 const editUrl = url_base;

 const fileSize = fs.statSync(selectedFile).size;
 const lines = fs.readFileSync(selectedFile, 'utf-8').split('\n').length;

 return send(`📝 Raw: ${rawUrl.href}\n\n✏️ Edit: ${editUrl.href}\n────────────────\n📁 File: ${relativePath}\n\n💾 Thả cảm xúc để upload code`).then(res => {
 res = {
 ...res,
 name: _.name,
 path: selectedFile,
 o: _.o,
 url: rawUrl.href,
 action: 'confirm_replace_content',
 };
 global.client.handleReaction.push(res);
 });
 }
 default:
 break;
 }
 } catch (e) {
 console.error('HandleReply error:', e);
 send(`❌ Lỗi khi xử lý: ${e.message}`);
 }
 }
}