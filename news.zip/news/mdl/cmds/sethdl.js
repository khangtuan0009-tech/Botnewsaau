const fs = require("fs");
const path = require("path");

this.config = {
    name: "sethdl",
    version: "1.0.1",
    hasPermission: 2,
    credits: "nvh",
    description: "sethdl",
    commandCategory: "system",
    usages: "[cos/gai/trai/nhac/chill/sad]",
    cooldowns: 3,
  usePrefix: true
};

this.run = async function({ api, event, args }) {
    const type = args[0];
    if (!type) {
        return api.sendMessage("⚠️ Vui lòng nhập vd muốn đổi", event.threadID, event.messageID);
    }

    const map = {
        vdcos: "vdcos",
        vdgai: "vdgai",
        vdtrai: "vdtrai",
        vdnhac: "vdnhac",
        vdchill: "vdchill",
        vdsad: "vdsad",
        vdanime: "vdanime"
    };

    if (!map[type]) {
        return api.sendMessage("Ngu", event.threadID, event.messageID);
    }

    const filePath = path.join(__dirname, "sailenh.js"); // file gốc
    let content = fs.readFileSync(filePath, "utf8");

    // Replace dòng attachment
    content = content.replace(
        /attachment:\s*.*?\.splice\(0,\s*1\)/,
        `attachment: ${map[type]}.splice(0, 1)`
    );

    fs.writeFileSync(filePath, content, "utf8");

    // Reload module
    try {
        delete require.cache[require.resolve(filePath)];
        const newCmd = require(filePath);
        global.client.commands.set(newCmd.config.name, newCmd);

        return api.sendMessage(`✅ Đã đổi sang ${map[type]} `, event.threadID, event.messageID);
    } catch (e) {
        return api.sendMessage(`❌ Lỗi khi reload module: ${e.message}`, event.threadID, event.messageID);
    }
};