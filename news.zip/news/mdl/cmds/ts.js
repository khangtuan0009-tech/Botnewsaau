const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");
const { createCanvas, loadImage } = require("canvas");

const mediaSavePath = path.join(__dirname, "cache/Youtube");
if (!fs.existsSync(mediaSavePath)) fs.mkdirSync(mediaSavePath, { recursive: true });

const YT_API_KEY = "AIzaSyAygWrPYHFVzL0zblaZPkRcgIFZkBNAW9g";

module.exports.config = {
  name: "ts",
  version: "6.7.2",
  hasPermssion: 0,
  credits: "nvh",
  description: "Tải nhạc từ YouTube",
  commandCategory: "Tiện ích",
  usages: "ts <từ khóa hoặc URL>",
  cooldowns: 3,
  usePrefix: true,
  useprefix: false
};

// === FORMAT DURATION ===
function formatDuration(duration) {
  const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  const h = parseInt(match?.[1] || 0);
  const m = parseInt(match?.[2] || 0);
  const s = parseInt(match?.[3] || 0);
  return [h, m, s]
    .map((x, i) => (i === 0 && h === 0 ? "" : x.toString().padStart(2, "0")))
    .filter(x => x !== "")
    .join(":");
}

// === DOWNLOAD AUDIO ===
async function downloadAudio(videoID, userID) {
  const mp3Path = path.join(mediaSavePath, `${Date.now()}_${userID}.mp3`);
  try {
    const apiUrl = `https://nvhdz.onrender.com/api/mediadl?url=https://youtu.be/${videoID}`;
    const res = await axios.get(apiUrl, { headers: { "User-Agent": "Mozilla/5.0" }, timeout: 20000 });
    const data = res.data;

    if (!data || !data.medias) throw new Error("API không trả về dữ liệu hợp lệ");

    const bestAudio =
      data.medias.find(i => i.formatId === "251") ||
      data.medias.find(i => i.formatId === "140") ||
      data.medias.find(i => i.audioOnly || i.mimeType?.includes("audio")) ||
      data.medias[0];

    if (!bestAudio?.url) throw new Error("Không tìm thấy link audio phù hợp");

    const audio = await axios.get(bestAudio.url, { responseType: "arraybuffer" });
    fs.writeFileSync(mp3Path, audio.data);
    return mp3Path;
  } catch (err) {
    console.error("❌ Lỗi tải audio:", err.message);
    throw new Error("Tải nhạc thất bại hoặc link lỗi.");
  }
}

// === DRAW MENU CANVAS ===
async function drawMenu(videos) {
  const width = 1280, height = 720;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#111";
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = "#fff";
  ctx.font = "40px sans-serif";
  ctx.fillText("🎧 KẾT QUẢ TÌM KIẾM YOUTUBE", 50, 70);

  const itemHeight = 120;
  for (let i = 0; i < videos.length; i++) {
    const y = 100 + i * (itemHeight + 10);
    const vid = videos[i];
    const thumb = await loadImage(vid.thumb);
    ctx.drawImage(thumb, 50, y, 200, 120);

    ctx.fillStyle = "#fff";
    ctx.font = "bold 26px sans-serif";
    ctx.fillText(`${i + 1}. ${vid.title.substring(0, 55)}`, 270, y + 40);
    ctx.font = "22px sans-serif";
    ctx.fillStyle = "#aaa";
    ctx.fillText(`👤 ${vid.channel}`, 270, y + 75);
    ctx.fillText(`⏱ ${vid.duration} | 👀 ${vid.views}`, 270, y + 105);
  }

  const tempPath = path.join(mediaSavePath, `menu_${Date.now()}.png`);
  fs.writeFileSync(tempPath, canvas.toBuffer());
  return tempPath;
}

// === HANDLE CHOSEN VIDEO ===
async function handleChosen(api, threadID, messageID, senderID, videoID) {
  try {
    const info = await axios.get(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${videoID}&key=${YT_API_KEY}`
    );
    const v = info.data.items[0];
    const filePath = await downloadAudio(videoID, senderID);

    const text = `🎶 ${v.snippet.title}\n👤 ${v.snippet.channelTitle}\n⏱ ${formatDuration(
      v.contentDetails.duration
    )}\n👀 ${Number(v.statistics.viewCount).toLocaleString()} lượt xem`;

    await api.sendMessage({ body: text, attachment: fs.createReadStream(filePath) }, threadID, () => {
      fs.unlinkSync(filePath);
    });
  } catch (err) {
    console.error(err);
    api.sendMessage("❎ Lỗi khi tải bài hát hoặc API bị lỗi.", threadID, messageID);
  }
}

// === MAIN COMMAND ===
module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  if (!args[0]) return api.sendMessage("❎ Nhập từ khóa hoặc URL YouTube.", threadID, messageID);

  const input = args.join(" ");
  const urlPattern = /^(https?:\/\/)?(www\.)?(m\.)?(youtube\.com|youtu\.be)\/.+/;
  let videoID;

  if (urlPattern.test(input)) {
    const idMatch = input.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    videoID = idMatch ? idMatch[1] : null;
    if (videoID) return await handleChosen(api, threadID, messageID, senderID, videoID);
  }

  const search = await axios.get(
    `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=5&q=${encodeURIComponent(input)}&key=${YT_API_KEY}`
  );

  if (!search.data.items.length) return api.sendMessage("❎ Không tìm thấy kết quả.", threadID, messageID);

  const videoList = [];
  for (const item of search.data.items) {
    const vID = item.id.videoId;
    const info = await axios.get(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${vID}&key=${YT_API_KEY}`
    );
    const v = info.data.items[0];
    videoList.push({
      id: vID,
      title: v.snippet.title,
      channel: v.snippet.channelTitle,
      duration: formatDuration(v.contentDetails.duration),
      views: Number(v.statistics.viewCount).toLocaleString(),
      thumb: v.snippet.thumbnails.medium.url
    });
  }

  const imgPath = await drawMenu(videoList);
  api.sendMessage({ body: "🎵 Reply số thứ tự để chọn bài bạn muốn tải MP3", attachment: fs.createReadStream(imgPath) }, threadID, (err, info) => {
    if (err) return;
    fs.unlinkSync(imgPath);
    global.client.handleReply.push({
      name: module.exports.config.name,
      messageID: info.messageID,
      author: senderID,
      videos: videoList
    });
  });
};

// === HANDLE REPLY ===
module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID != handleReply.author) return;
  const choice = parseInt(body.trim());
  const chosen = handleReply.videos[choice - 1];
  if (!chosen) return api.sendMessage("❎ Số không hợp lệ.", threadID, messageID);

  await handleChosen(api, threadID, messageID, senderID, chosen.id);
};