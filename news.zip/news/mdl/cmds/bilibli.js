const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "bili",
  version: "3.0.1",
  hasPermssion: 0,
  credits: "nvb",
  description: "Tìm kiếm anime/phim từ Bilibili",
  commandCategory: "media",
  usages: "[từ khóa]",
  cooldowns: 5,
  usePrefix: true,
};

module.exports.run = async function ({ api, event, args }) {
  const keyword = args.join(" ");
  if (!keyword)
    return api.sendMessage("🔍 Nhập từ khóa cần tìm trên Bilibili!", event.threadID, event.messageID);

  api.sendMessage(`🔎 Đang tìm kiếm “${keyword}” trên Bilibili...`, event.threadID, event.messageID);

  try {
    const url = "https://api.bilibili.com/x/web-interface/wbi/search/all/v2";
    const params = {
      keyword,
      page: 1,
      page_size: 10,
      web_location: 1280306,
      platform: "h5",
      w_rid: "71ae77eba4325032f5b8bd8e4cadfc57",
      wts: "1762017714"
    };
    const headers = {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36",
      "origin": "https://m.bilibili.com",
      "referer": "https://m.bilibili.com/",
      "accept-language": "vi-VN,vi;q=0.9",
      "cookie": "buvid3=80B50404-2953-A72A-3BF0-4EA4A38ACA3077196infoc; b_nut=1762017677;"
    };

    const res = await axios.get(url, { params, headers });
    const results = res.data?.data?.result?.find(r => r.result_type === "media_bangumi")?.data || [];

    if (results.length === 0)
      return api.sendMessage("❌ Không tìm thấy kết quả nào!", event.threadID, event.messageID);

    let msg = "🎬 Kết quả tìm kiếm Anime/Phim Bilibili:\n\n";
    let attachments = [];

    for (let i = 0; i < Math.min(5, results.length); i++) {
      const item = results[i];
      msg += `${i + 1}. ${item.title.replace(/<[^>]+>/g, "")}\n⭐ Điểm: ${item.media_score?.score || "N/A"}\n📝 ${item.desc}\n🔗 ${item.url}\n\n`;

      try {
        const imgPath = path.join(__dirname, "cache", `bili_${i}.jpg`);
        const imgRes = await axios.get(item.cover, { responseType: "arraybuffer" });
        fs.writeFileSync(imgPath, Buffer.from(imgRes.data, "binary"));
        attachments.push(fs.createReadStream(imgPath));
      } catch (e) {
        console.log("❌ Không tải được ảnh:", e.message);
      }
    }

    msg += "📩 Reply số để xem danh sách tập của phim.";

    api.sendMessage(
      { body: msg, attachment: attachments },
      event.threadID,
      (err, info) => {
        if (err) return console.error(err);
        global.client.handleReply.push({
          name: module.exports.config.name,
          messageID: info.messageID,
          author: event.senderID,
          results,
          type: "chooseAnime"
        });
      },
      event.messageID
    );
  } catch (err) {
    console.error("❌ Lỗi khi tìm kiếm:", err);
    return api.sendMessage("⚠️ Lỗi khi tìm kiếm Bilibili!", event.threadID, event.messageID);
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  if (event.senderID !== handleReply.author) return;
  const choice = parseInt(event.body);

  if (isNaN(choice)) return;

  if (handleReply.type === "chooseAnime") {
    if (choice < 1 || choice > handleReply.results.length)
      return api.sendMessage("⚠️ Vui lòng nhập số hợp lệ!", event.threadID, event.messageID);

    const chosen = handleReply.results[choice - 1];
    api.sendMessage(`⏳ Đang lấy danh sách tập của “${chosen.title.replace(/<[^>]+>/g, "")}”...`, event.threadID, event.messageID);

    try {
      const eps = chosen.eps || [];
      if (eps.length === 0)
        return api.sendMessage(`❌ Phim này hiện chưa có danh sách tập!`, event.threadID, event.messageID);

      let msg = `🎞️ Danh sách tập của ${chosen.title.replace(/<[^>]+>/g, "")}:\n\n`;
      for (let i = 0; i < Math.min(10, eps.length); i++) {
        const ep = eps[i];
        msg += `${i + 1}. ${ep.title} - ${ep.long_title}\n🔗 ${ep.url}\n\n`;
      }

      msg += "📩 Reply số để nhận link tập tương ứng.";
      api.sendMessage(msg, event.threadID, (err, info) => {
        if (err) return console.error(err);
        global.client.handleReply.push({
          name: module.exports.config.name,
          messageID: info.messageID,
          author: event.senderID,
          eps,
          type: "chooseEpisode"
        });
      });
    } catch (err) {
      console.error(err);
      api.sendMessage("⚠️ Lỗi khi lấy danh sách tập!", event.threadID, event.messageID);
    }
  } else if (handleReply.type === "chooseEpisode") {
    if (choice < 1 || choice > handleReply.eps.length)
      return api.sendMessage("⚠️ Vui lòng nhập số hợp lệ!", event.threadID, event.messageID);

    const chosenEp = handleReply.eps[choice - 1];
    api.sendMessage(
      `🎬 Tập ${chosenEp.title}: ${chosenEp.long_title}\n🔗 ${chosenEp.url}`,
      event.threadID,
      event.messageID
    );
  }
};