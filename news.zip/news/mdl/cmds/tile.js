const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  usePrefix: true,
  name: "tile",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Check tỉ lệ hợp nhau giữa trai và gái",
  commandCategory: "Tiện ích",
  usages: "tile [tag]",
};

module.exports.run = async ({ api, event }) => {
  try {
    const { senderID, mentions, threadID } = event;
    const uid1 = senderID;
    let uid2;

    const appToken = "6628568379%7Cc1e620fa708a1d5696fb991c1bde5662"; // token app public

    // === HÀM LẤY INFO getUserInfoV5 ===
    const getInfoV5 = async (uid) => {
      const res = await api.getUserInfoV5(uid);
      const user = res?.[0]?.o0?.data?.messaging_actors?.[0];
      if (!user)
        return { name: "Unknown", gender: "UNKNOWN" };
      return {
        name: user.name || "Unknown",
        gender: user.gender || "UNKNOWN"
      };
    };

    const info1 = await getInfoV5(uid1);
    const gender1 = info1.gender;

    // === CHỌN NGƯỜI THỨ HAI ===
    if (Object.keys(mentions).length > 0) {
      uid2 = Object.keys(mentions)[0];
    } else {
      const threadInfo = await api.getThreadInfo(threadID);
      const members = threadInfo.participantIDs.filter(id => id != uid1);

      const membersInfo = await Promise.all(
        members.map(async id => {
          const info = await getInfoV5(id);
          return { id, gender: info.gender };
        })
      );

      const opposite = membersInfo.filter(mem => {
        if (gender1 === "MALE") return mem.gender === "FEMALE";
        if (gender1 === "FEMALE") return mem.gender === "MALE";
        return true;
      });

      if (opposite.length === 0)
        return api.sendMessage("❌ Không tìm thấy ai khác giới để ghép!", threadID);

      uid2 = opposite[Math.floor(Math.random() * opposite.length)].id;
    }

    const info2 = await getInfoV5(uid2);

    // === RANDOM % ===
    const specialPairs = [
      ["100073639420918", "100064708970278"]
    ];

    const isSpecial = specialPairs.some(
      p => (p[0] === uid1 && p[1] === uid2) || (p[0] === uid2 && p[1] === uid1)
    );
    const percent = isSpecial ? 100 : Math.floor(Math.random() * 101);

    // === THANH BIỂU ĐỒ ===
    const total = 20;
    const filled = Math.round((percent / 100) * total);
    const bar = "❤️".repeat(filled) + "🖤".repeat(total - filled);

    // === LẤY AVATAR TỪ b-graph (full HD, không nén) ===
    const dataDir = path.join(__dirname, "data");
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

    const avatar1Path = path.join(dataDir, `avt_${uid1}.jpg`);
    const avatar2Path = path.join(dataDir, `avt_${uid2}.jpg`);

    const getAvatarHD = async (uid, savePath) => {
      const url = `https://b-graph.facebook.com/${uid}/picture?width=2048&height=2048&access_token=${appToken}`;
      const res = await axios.get(url, {
        responseType: "arraybuffer",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        },
      });
      fs.writeFileSync(savePath, res.data);
    };

    await getAvatarHD(uid1, avatar1Path);
    await getAvatarHD(uid2, avatar2Path);

    // === GỬI KẾT QUẢ ===
    const msg = `
━━━━━━━━━━━━━━━━━━
💞 Tỉ lệ hợp nhau 💞
━━━━━━━━━━━━━━━━━━
👫 ${info1.name} ❤️ ${info2.name}
━━━━━━━━━━━━━━━━━━
${bar} ${percent}%
━━━━━━━━━━━━━━━━━━`;

    api.sendMessage(
      {
        body: msg,
        attachment: [
          fs.createReadStream(avatar1Path),
          fs.createReadStream(avatar2Path),
        ],
      },
      threadID,
      () => {
        fs.unlinkSync(avatar1Path);
        fs.unlinkSync(avatar2Path);
      }
    );
  } catch (err) {
    console.error("Lỗi tile:", err);
    api.sendMessage("❌ Đã xảy ra lỗi khi check tỉ lệ hợp nhau!", event.threadID);
  }
};