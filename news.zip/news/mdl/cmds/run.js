module.exports.config = {
  name: "run",
  version: "1.0.3",
  hasPermssion: 3,
  credits: "Quất - Modified",
  description: "running shell with auto-send",
  commandCategory: "Admin",
  usages: "[Script]",
  cooldowns: 5,
  usePrefix: true
};

module.exports.run = async function({ api, event, args, Users, Threads, Currencies }) {
  const s = async (a) => {
    if (typeof a === "object" || Array.isArray(a)) {
      a = Object.keys(a).length !== 0 ? JSON.stringify(a, null, 4) : "";
    }
    if (typeof a === "number") a = a.toString();
    await api.sendMessage(a, event.threadID, event.messageID);
  };
  
  const { log } = console;
  const o = { api, event, args, Users, Threads, Currencies };
  
  try {
    const code = args.join(" ");
    if (!code) {
      return await s('Vui lòng nhập code để thực thi!');
    }
    
    let result;
    if (code.startsWith('down.')) {
      result = await eval(code);
    } else {
      const vm = require('vm');
      const context = { s, o, log, require, console, process, global };
      result = await vm.runInNewContext(code, context, { 
        timeout: 10000,
        displayErrors: true 
      });
    }
    
    await s(result);
  } catch (e) {
    try {
      const axios = require('axios');
      const translateResponse = await axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=vi&dt=t&q=${encodeURIComponent(e.message)}`);
      const translatedMessage = translateResponse.data[0][0][0];
      
      const errorMessage = `[ Lỗi ] ${e.message}\n[ Dịch ] ${translatedMessage}`;
      await s(errorMessage);
    } catch (translateError) {
      await s(`❌ Lỗi: ${e.message}`);
    }
  }
};