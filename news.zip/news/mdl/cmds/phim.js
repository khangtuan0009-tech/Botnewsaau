const axios = require("axios");
const request = require("request"); 
const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "phim",
  version: "3.1.0",
  hasPermssion: 0,
  credits: "nvhz",
  description: "Tìm kiếm và xem phim",
  commandCategory: "Tiện ích",
  usages: "[tên phim]",
  cooldowns: 5,
  usePrefix: true
};

const APIKEY = "ngvanhungzx";

module.exports.run = async function ({ api, event, args }) {
  if (!args[0]) return api.sendMessage("❗ Nhập tên phim cần tìm.", event.threadID, event.messageID);
  const keyword = encodeURIComponent(args.join(" "));

  try {
    const res = await axios.get(`https://hoangdev.io.vn/khophim/khophim?q=${keyword}&apikey=${APIKEY}`);
    if (!res.data.success || res.data.results === 0) {
      return api.sendMessage("❌ Không tìm thấy phim nào.", event.threadID, event.messageID);
    }

    let msg = "🎬 Danh sách phim:\n\n";
    res.data.data.forEach((film, i) => {
      msg += `${i+1}. ${film.title} (${film.originName})\n📺 ${film.episode}\n\n`;
    });
    msg += "👉 Reply số để chọn phim.";

    return api.sendMessage(msg, event.threadID, (err, info) => {
      global.client.handleReply.push({
        type: "chooseFilm",
        name: this.config.name,
        messageID: info.messageID,
        author: event.senderID,
        data: res.data.data
      });
    }, event.messageID);

  } catch (err) {
    return api.sendMessage("⚠️ Lỗi khi tìm kiếm phim.", event.threadID, event.messageID);
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  if (event.senderID !== handleReply.author) return;
  const { type, data } = handleReply;

  if (type === "chooseFilm") {
    const choice = parseInt(event.body);
    if (isNaN(choice) || choice < 1 || choice > data.length) {
      return api.sendMessage("❗ Nhập số hợp lệ.", event.threadID, event.messageID);
    }

    const film = data[choice - 1];
    try {
      const res = await axios.get(`https://hoangdev.io.vn/khophim/khophimurl?url=${encodeURIComponent(film.slug)}&apikey=${APIKEY}`);
      if (!res.data.success) return api.sendMessage("❌ Không lấy được tập phim.", event.threadID, event.messageID);

      let msg = `📺 ${film.title}\n(${film.originName})\n\n🎞️ ${film.episode}\n👉 Reply số để chọn tập.\n\n`;

      res.data.episodes[0].server_data.slice(0, 10).forEach((ep, i) => {
        msg += `${i+1}. ${ep.name}\n`;
      });

      const imgPath = path.join(__dirname, "cache", `thumb_${Date.now()}.jpg`);
      request(film.thumbnail).pipe(fs.createWriteStream(imgPath)).on("close", () => {
        api.sendMessage({
          body: msg,
          attachment: fs.createReadStream(imgPath)
        }, event.threadID, (err, info) => {
          fs.unlinkSync(imgPath);
          global.client.handleReply.push({
            type: "chooseEpisode",
            name: this.config.name,
            messageID: info.messageID,
            author: event.senderID,
            film,
            episodes: res.data.episodes[0].server_data
          });
        }, event.messageID);
      });

    } catch (e) {
      return api.sendMessage("⚠️ Lỗi khi lấy danh sách tập.", event.threadID, event.messageID);
    }
  }

  if (type === "chooseEpisode") {
    const choice = parseInt(event.body);
    if (isNaN(choice) || choice < 1 || choice > handleReply.episodes.length) {
      return api.sendMessage("❗ Nhập số tập hợp lệ.", event.threadID, event.messageID);
    }

    const ep = handleReply.episodes[choice - 1];
    const playerUrl = `https://player.phimapi.com/player/?url=${encodeURIComponent(ep.link_m3u8)}`;

    return api.sendMessage(
      `🎬 ${handleReply.film.title}\n📺 ${ep.name}\n\n👉 Xem trực tiếp: ${playerUrl}`,
      event.threadID,
      event.messageID
    );
  }
};