module.exports.config = {
    name: 'file',
    version: '1.1.6',
    hasPermssion: 2,
    credits: 'Niio-team (DC-Nam) + ATuan mod thêm',
    description: 'Xem thư mục, xoá, gửi nội dung file lên satoru.site',
    commandCategory: 'Admin',
    usages: '[đường dẫn]',
    cooldowns: 0,
  usePrefix: true,
};

const fs = require('fs');
const {
    readFileSync,
    readdirSync,
    statSync,
    unlinkSync,
    rmdirSync,
    createReadStream,
    copyFileSync,
    existsSync,
    renameSync,
    mkdirSync,
    writeFileSync,
    createWriteStream
} = fs;
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const archiver = require('archiver');
const { v4: uuidv4 } = require('uuid');

const _node_modules_path = process.cwd() + '/node_modules';
let _node_modules = readdirSync(_node_modules_path);
let _node_modules_bytes; size_folder(_node_modules_path);

module.exports.run = function ({ api, event, args }) {
    openFolder(api, event, process.cwd() + (args[0] ? args[0] : ''));
};

module.exports.handleReply = async function ({ handleReply: $, api, event }) {
    try {
        if (!global.config.ADMINBOT.includes(event.senderID)) return;
        let d = $.data[event.args[1]-1];
        let action = event.args[0].toLowerCase();

        if (!['create'].includes(action))
            if (!d && event.args[0])
                return api.sendMessage('⚠️ Không tìm thấy file theo số thứ tự đó.', event.threadID, event.messageID);

        switch (action) {
            case 'open':
                if (d.info.isDirectory()) openFolder(api, event, d.dest);
                else api.sendMessage('⚠️ Không phải thư mục.', event.threadID, event.messageID);
                break;
            case 'del': {
                var arrFile = [];
                for (const i of event.args.slice(1)) {
                    const { dest, info } = $.data[i-1];
                    const ext = dest.split('/').pop();
                    if (info.isFile()) unlinkSync(dest);
                    else if (info.isDirectory()) rmdirSync(dest, { recursive: true });
                    arrFile.push(i + '. ' + ext);
                }
                api.sendMessage(`✅ Đã xoá:\n\n${arrFile.join('\n')}`, event.threadID, event.messageID);
            }; break;
            case 'send': {
                try {
                    const fileContent = readFileSync(d.dest, 'utf8');
                    const uuid = uuidv4();
                    const editUrl = `https://api.satoru.site/api/note/${uuid}`;
                    const rawUrl = `${editUrl}-raw`;

                    await axios.put(editUrl, fileContent, {
                        headers: { 'content-type': 'text/plain; charset=utf-8' }
                    });

                    return api.sendMessage(`${rawUrl}`, event.threadID, event.messageID);
                } catch (err) {
                    console.error('Lỗi khi đọc hoặc upload file:', err);
                    return api.sendMessage('❌ Không thể gửi file này (có thể là file nhị phân hoặc lỗi đọc)', event.threadID, event.messageID);
                }
            }; break;
            case 'view': {
                let p = d.dest;
                let t;
                if (/\.js$/.test(p)) copyFileSync(p, t = p.replace('.js', '.txt'));
                api.sendMessage({ attachment: createReadStream(t || p) }, event.threadID, _ => t && unlinkSync(t), event.messageID);
            }; break;
            case "create": {
                let t;
                fs[(['mkdirSync', 'writeFileSync'][t = /\/$/.test(event.args[1]) ? 0 : 1])]($.directory + event.args[1], [, event.args.slice(2).join(' ')][t]);
                api.sendMessage(`✅ Đã tạo ${['thư mục', 'file'][t]}: ${event.args[1]}`, event.threadID, event.messageID);
            }; break;
            case 'copy':
                copyFileSync(d.dest, d.dest.replace(/(\.[^./]+)$/, ' (COPY)$1'));
                api.sendMessage('✅ Đã sao chép file', event.threadID, event.messageID);
                break;
            case 'rename': {
                let new_path = event.args[2];
                if (!new_path) return api.sendMessage('❎ Thiếu tên mới để đổi tên file', event.threadID, event.messageID);
                renameSync(d.dest, d.dest.replace(/[^/]+$/, new_path));
                api.sendMessage('✅ Đã đổi tên thành: ' + new_path, event.threadID, event.messageID);
            }; break;
            case 'zip':
                catbox(zip($.data.filter((e, i) => event.args.slice(1).includes(String(i+1))).map(e => e.dest))).then(link => api.sendMessage(link, event.threadID, event.messageID));
                break;
            default:
                api.sendMessage(`❎ Reply [open | send | del | view | create | zip | copy | rename] + số thứ tự`, event.threadID, event.messageID);
        }
    } catch (e) {
        console.error(e);
        api.sendMessage('❌ Lỗi xử lý: ' + e.toString(), event.threadID, event.messageID);
    }
};

function convertBytes(bytes) {
    let sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return '0 Byte';
    let i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
}

function openFolder(a, b, c) {
    const hidden = [
        'node_modules', '.git', '.replit', '.cache',
        'package-lock.json', 'package.json',
        'acc.json', 'anti.json', 'config.json.temp',
        'FastConfigFca.json', 'uptime.json', '.upm'
    ];

    let folders_files = readdirSync(c)
        .filter(e => !hidden.includes(e))
        .reduce((o, e) => (o[statSync(c + '/' + e).isFile() ? 1 : 0].push(e), o), [[], []])
        .map(e => e.sort((a, b) => a.localeCompare(b)));

    let txt = '', count = 0;
    array = [], bytes_dir = 0;

    for (const i of [...folders_files[0], ...folders_files[1]]) {
        const dest = `${c}/${i}`;
        const info = statSync(dest);
        if (info.isDirectory()) info.size = size_folder(dest);
        bytes_dir += info.size;
        let icon = info.isDirectory() ? '📁' : '📄';
        txt += `${++count}. ${icon} ${i} (${convertBytes(info.size)})\n`;
        array.push({ dest, info });
    }
    txt += `\n📊 Tổng dung lượng: ${convertBytes(bytes_dir)}\nReply [open | send | del | view | create | zip | copy | rename] + số thứ tự`;
    a.sendMessage(txt, b.threadID, (err, data) => global.client.handleReply.push({
        name: exports.config.name,
        messageID: data.messageID,
        author: b.senderID,
        data: array,
        directory: c + '/',
    }), b.messageID);
}

function size_folder(folder = '') {
    let bytes = 0;
    if (folder === _node_modules_path) {
        const now = readdirSync(folder);
        if (_node_modules.length !== now.length) (_node_modules = now, _node_modules_bytes = undefined);
        if (typeof _node_modules_bytes === 'number') return _node_modules_bytes;
    }

    for (let file of readdirSync(folder)) try {
        let p = folder + '/' + file;
        let info = statSync(p);
        if (info.isDirectory()) bytes += size_folder(p);
        else bytes += info.size;
    } catch { continue }

    if (folder === _node_modules_path) _node_modules_bytes = bytes;
    return bytes;
}

function catbox(stream) {
    let form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', stream);

    return axios({
        method: 'POST',
        url: 'https://catbox.moe/user/api.php',
        headers: form.getHeaders(),
        data: form,
        responseType: 'text',
    }).then(res => res.data);
}

function zip(source_paths, output_path) {
    let archive = archiver('zip', { zlib: { level: 9 } });
    if (output_path) {
        const output = createWriteStream(output_path);
        archive.pipe(output);
    }

    source_paths.forEach(src => {
        if (existsSync(src)) {
            const stat = statSync(src);
            if (stat.isFile()) archive.file(src, { name: path.basename(src) });
            else if (stat.isDirectory()) archive.directory(src, path.basename(src));
        }
    });

    archive.finalize();

    return output_path ? new Promise((res, rej) => {
        output.on('close', _ => res(output));
        archive.on('error', rej);
    }) : (archive.path = 'tmp.zip', archive);
}