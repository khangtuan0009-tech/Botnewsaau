const path = require("path");
const fs = require("fs-extra");

module.exports.config = {
  name: "bc",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Game bầu cua ",
  commandCategory: "Game",
  usages: "[con vật] [tiền cược] | hoặc baucua hu",
  cooldowns: 5,
  usePrefix: true
};

const animals = {
  "bầu": "🍐",
  "cua": "🦀",
  "tôm": "🦐",
  "cá": "🐟",
  "nai": "🦌",
  "gà": "🐓"
};

function convertMoney(str) {
  const n = str.toLowerCase();
  if (n.endsWith("k")) return parseInt(n) * 1000;
  if (n.endsWith("m")) return parseInt(n) * 1000000;
  if (n.endsWith("b")) return parseInt(n) * 100000000;
  if (n.endsWith("t")) return parseInt(n) * 1000000000;
  if (n.endsWith("g")) return parseInt(n) * 1000000000000;
  return parseInt(n);
}

function formatMoney(num) {
  return num.toLocaleString("vi-VN") + "đ";
}

const huPath = path.join(__dirname, "cache", "hu_baucua.json");
if (!fs.existsSync(huPath)) fs.writeFileSync(huPath, JSON.stringify({ hu: 0 }, null, 2));

module.exports.run = async function ({ api, event, args, Currencies }) {
  const { threadID, messageID, senderID } = event;
  const name = (await api.getUserInfo(senderID))[senderID].name;

  // Xem hũ
  if (args[0] && args[0].toLowerCase() === "hu") {
    const { hu } = JSON.parse(fs.readFileSync(huPath));
    return api.sendMessage(`🏦 Hũ bầu cua hiện tại: ${formatMoney(hu)}`, threadID, messageID);
  }

  if (args.length < 2)
    return api.sendMessage(
      `🎲 Dùng: baucua [con vật] [tiền cược]\n🐮 Con: ${Object.keys(animals).join(", ")}\n💡 Ví dụ: baucua tôm 100k`,
      threadID,
      messageID
    );

  const choice = args[0].toLowerCase();
  if (!animals[choice])
    return api.sendMessage(`⚠️ Con vật không hợp lệ!\nChọn: ${Object.keys(animals).join(", ")}`, threadID, messageID);

  let bet = convertMoney(args[1]);
  if (isNaN(bet) || bet <= 0) return api.sendMessage("⚠️ Số tiền cược không hợp lệ!", threadID, messageID);

  const userData = await Currencies.getData(senderID);
  const money = userData.money || 0;
  if (bet > money)
    return api.sendMessage(`💸 Bạn không đủ tiền để cược ${formatMoney(bet)}`, threadID, messageID);

  let huData = JSON.parse(fs.readFileSync(huPath));
  let hu = huData.hu;

  // Hiệu ứng đang tung
  api.sendMessage(`🎲 | ${name} đang tung bầu cua...\n🌀 Đang lắc xúc xắc...`, threadID, async (err, info) => {
    await new Promise(resolve => setTimeout(resolve, 3000));
    api.unsendMessage(info.messageID);

    // Kết quả random
    const keys = Object.keys(animals);
    const result = [
      keys[Math.floor(Math.random() * keys.length)],
      keys[Math.floor(Math.random() * keys.length)],
      keys[Math.floor(Math.random() * keys.length)]
    ];

    const count = result.filter(r => r === choice).length;
    let msg = `🎰 Kết quả: ${animals[result[0]]} | ${animals[result[1]]} | ${animals[result[2]]}\n`;
    msg += `👤 Người chơi: ${name}\n🎯 Bạn chọn: ${animals[choice]} ${choice}\n\n`;

    let moneyNow, win = 0;
    if (count === 0) {
      win = -bet;
      hu += Math.floor(bet * 0.1); // thêm 10% tiền thua vào hũ
      await Currencies.decreaseMoney(senderID, bet);
      moneyNow = (await Currencies.getData(senderID)).money;
      msg += `💸 Không trúng ô nào. Bạn mất: ${formatMoney(bet)} ❌\n\n`;
    } else {
      win = bet * count;
      await Currencies.increaseMoney(senderID, win);
      moneyNow = (await Currencies.getData(senderID)).money;
      msg += `🎉 Trúng ${count} ô! Bạn thắng: ${formatMoney(win)} ✅\n\n`;
    }

    fs.writeFileSync(huPath, JSON.stringify({ hu }, null, 2));

    msg += `💼 Số dư: ${formatMoney(moneyNow)}\n🏦 Hũ hiện tại: ${formatMoney(hu)}`;

    api.sendMessage(msg, threadID, messageID);
  });
};