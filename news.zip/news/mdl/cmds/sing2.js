const fs = require('fs');
const ytdl = require('ytdl-core-enhanced');
const { resolve } = require('path');
const cookieString = process.env.YT_COOKIE || 'VISITOR_PRIVACY_METADATA=CgJWThIEGgAgOA%3D%3D;__Secure-3PSID=g.a0002whtnKeUYTa1iU8ZA8IGlnpsEhvJPAc7ETp7EjgWG9kj5O2YV_2etKZsthxzofjHovQSJwACgYKAcMSARcSFQHGX2MidCNhGfQp66F8pQ_uu5g8UxoVAUF8yKpDibvUywE40ya3RBe_6PSj0076;YSC=QUdt0JBkf9g;__Secure-1PSIDTS=sidts-CjEBwQ9iI_lkk5TZwP5RU9ASz2DrAw0KKkHyMPL0Eqli8HL3t0H0rwCStGfIiH2IkMhLEAA;CONSISTENCY=AKreu9vabxlSXvdZsNyTGHv-m9_ReaFnpA-1mshBph7ijlR_f7LyDcKK71mX2h0PoLf_ZB_xZhEWBxj2kCnHzGGPL4ydB4V2fqb-JXNHfuZe4tLpRSgITvIxnv32uF5eJdvBx_6y_h0d0xmusCrQtVgP;SAPISID=cKmY0TypiTd36JWQ/AhEbMcy81G2NV0sJM;__Secure-1PSIDCC=AKEyXzWoMbF0LlHvLvaPGd6tNMorrYdkiQDQyxFhlnjAwBie5C3KrZ87rurdbj1NHRwy4B6hRw;SSID=A6cYUrwef24NMqHvI;__Secure-1PAPISID=cKmY0TypiTd36JWQ/AhEbMcy81G2NV0sJM;__Secure-1PSID=g.a0002whtnKeUYTa1iU8ZA8IGlnpsEhvJPAc7ETp7EjgWG9kj5O2YrtzRWrYZEV80VNn2xqA0rwACgYKAQkSARcSFQHGX2MihVcDU4QEFosgdb3Dz_IGFhoVAUF8yKovwecKutGjEdHIbZ_QjLAS0076;__Secure-3PAPISID=cKmY0TypiTd36JWQ/AhEbMcy81G2NV0sJM;__Secure-3PSIDCC=AKEyXzW9S9ow1z3dAVRjMFWtXMXqOhfwakiz2b8llabgodSl1CN_8yrVcbeqAqoPwXfn5CMvgA;__Secure-3PSIDTS=sidts-CjEBwQ9iI_lkk5TZwP5RU9ASz2DrAw0KKkHyMPL0Eqli8HL3t0H0rwCStGfIiH2IkMhLEAA;__Secure-ROLLOUT_TOKEN=CNik9ISC89ujtgEQh9_Ds_3ojgMYw7y-iO7GkAM%3D;LOGIN_INFO=AFmmF2swRgIhAKq7Khb8DpGrm_oqXzmNM5ZVBwsaMGU_Tk3uCCP-gApRAiEA3rRv7Wtq-6vvI5IpMS6f5CDin215KijevVzYuOlJ6ck:QUQ3MjNmeWtDU0ZKc1NVLWhXOHhTSHJmMmlZMURXTjk2QnJfUEdfUEpibzhrYnd2Rk1qM2VvWEdzTTA0bmg0SWltaXBONTVJQUJwREFYV196aG9iVjVDeVV0U0REQ09sdU1aSVZVMUM3bElNMEJ5OGNFdkxWMlB6bXRmZHVqWU84Y3V0ei1saVdYQU1hbHVHVTdlRlg0bVo5WkN2OE0xQlp3;PREF=tz=Asia.Bangkok;VISITOR_INFO1_LIVE=YNIePSqtSFU';

async function downloadMusicFromYoutube(link, path) {
  var timestart = Date.now();
  if (!link) return 'Thiếu link';
  return new Promise((resolveFunc, rejectFunc) => {
    ytdl(link, {
      quality: 140,
      filter: 'audioonly',
      requestOptions: {
        headers: {
          'Cookie': cookieString,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          'Accept-Language': 'en-US,en;q=0.9'
        }
      }
    })
      .pipe(fs.createWriteStream(path))
      .on("close", async () => {
        try {
          var data = await ytdl.getInfo(link, {
            requestOptions: { headers: { 'Cookie': cookieString } }
          });
          var result = {
            title: data.videoDetails.title,
            dur: Number(data.videoDetails.lengthSeconds),
            sub: data.videoDetails.author?.subscriberCount || 0,
            viewCount: data.videoDetails.viewCount,
            author: data.videoDetails.author.name,
            timestart: timestart
          };
          resolveFunc(result);
        } catch (err) {
          rejectFunc(err);
        }
      })
      .on("error", (err) => {
        rejectFunc(err);
      });
  });
}

module.exports.config = {
  name: "sing2",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "D-Jukie",
  description: "Phát nhạc thông qua link YouTube hoặc từ khoá tìm kiếm",
  commandCategory: "Nhạc",
  usages: "[searchMusic]",
  cooldowns: 0,
  usePrefix: true
};

module.exports.run = async function ({ api, event, args, Users }) {
  const axios = require('axios');
  const moment = require("moment-timezone");
  var gio = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || D/MM/YYYY");
  var thu = moment.tz('Asia/Ho_Chi_Minh').format('dddd');
  if (thu == 'Sunday') thu = 'Chủ Nhật';
  if (thu == 'Monday') thu = 'Thứ Hai';
  if (thu == 'Tuesday') thu = 'Thứ Ba';
  if (thu == 'Wednesday') thu = 'Thứ Tư';
  if (thu == "Thursday") thu = 'Thứ Năm';
  if (thu == 'Friday') thu = 'Thứ Sáu';
  if (thu == 'Saturday') thu = 'Thứ Bảy';
  let name = await Users.getNameUser(event.senderID);
  api.setMessageReaction("❎", event.messageID, () => {}, true);
  if (args.length == 0 || !args) return api.sendMessage('➣ 𝗣𝗵𝗮̂̀𝗻 𝘁𝗶̀𝗺 𝗸𝗶𝗲̂́𝗺 𝗸𝗵𝗼̂𝗻𝗴 đ𝘂̛𝗼̛̣𝗰 đ𝗲̂̉ 𝘁𝗿𝗼̂́𝗻𝗴!', event.threadID, event.messageID);
  const keywordSearch = args.join(" ");
  var path = `${__dirname}/cache/sing-${event.senderID}.mp3`;
  if (fs.existsSync(path)) fs.unlinkSync(path);
  if (args.join(" ").indexOf("https://") == 0) {
    try {
      const linkYT = args.join(" ");
      api.setMessageReaction("⌛", event.messageID, () => {}, true);
      const data = await downloadMusicFromYoutube(linkYT, path);
      if (fs.statSync(path).size > 150 * 1024 * 1024)
        return api.sendMessage('cc', event.threadID, () => fs.unlinkSync(path), event.messageID);
      api.setMessageReaction("✅", event.messageID, () => {}, true);
      return api.sendMessage({
        body: `🎧 Bài hát: ${data.title}\n👤 Ca sĩ: ${data.author}\n👁️ Lượt xem: ${data.viewCount}\n🕒 Thời lượng: ${module.exports.convertHMS(data.dur)}`,
        attachment: fs.createReadStream(path)
      }, event.threadID, () => fs.unlinkSync(path), event.messageID);
    } catch (e) {
      console.log(e);
      api.sendMessage("❎ Không tải được nhạc từ link này!", event.threadID, event.messageID);
    }
  } else {
    try {
      var link = [], msg = "", num = 0;
      const Youtube = require('youtube-search-api');
      api.setMessageReaction("⌛", event.messageID, () => {}, true);
      var data = (await Youtube.GetListByKeyword(keywordSearch, false, 6)).items;
      for (let value of data) {
        link.push(value.id);
        num += 1;
        msg += (`➣ Kết quả: ${num} - ${value.title}\n➣ 𝐓𝐞̂𝐧 𝐤𝐞̂𝐧𝐡: ${value.channelTitle}\n➣ 𝐓𝐡𝐨̛̀𝐢 𝐥𝐮̛𝐨̛̣𝐧𝐠: ${value.length.simpleText}\n====================\n`);
      }
      var body = `==『 𝙼𝚘̛̀𝚒 𝚋𝚊̣𝚗 𝚘𝚛𝚍𝚎𝚛 𝚖𝚎𝚗𝚞 』==\n====================\n${msg}➝ 𝙼𝚘̛̀𝚒 ${name} 𝚝𝚛𝚊̉ 𝚕𝚘̛̀𝚒 𝚝𝚒𝚗 𝚗𝚑𝚊̆́𝚗 𝚗𝚊̀𝚢 𝚔𝚎̀𝚖 𝚜𝚘̂́ 𝚝𝚑𝚞̛́ 𝚝𝚞̛̣ 𝚖𝚊̀ 𝚋𝚊̣𝚗 𝚖𝚞𝚘̂́𝚗 𝚗𝚐𝚑𝚎`;
      return api.sendMessage({ body: body }, event.threadID, (error, info) =>
        global.client.handleReply.push({
          type: 'reply',
          name: this.config.name,
          messageID: info.messageID,
          author: event.senderID,
          link
        }), event.messageID);
    } catch (e) {
      console.log(e);
      api.setMessageReaction("❎", event.messageID, () => {}, true);
    }
  }
};

module.exports.handleReply = async function ({ api, event, handleReply, Users }) {
  api.setMessageReaction("⌛", event.messageID, () => {}, true);
  const moment = require("moment-timezone");
  var gio = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || D/MM/YYYY");
  var thu = moment.tz('Asia/Ho_Chi_Minh').format('dddd');
  if (thu == 'Sunday') thu = 'Chủ Nhật';
  if (thu == 'Monday') thu = 'Thứ Hai';
  if (thu == 'Tuesday') thu = 'Thứ Ba';
  if (thu == 'Wednesday') thu = 'Thứ Tư';
  if (thu == "Thursday") thu = 'Thứ Năm';
  if (thu == 'Friday') thu = 'Thứ Sáu';
  if (thu == 'Saturday') thu = 'Thứ Bảy';
  let name = await Users.getNameUser(event.senderID);
  try {
    var path = `${__dirname}/cache/sing-${event.senderID}.mp3`;
    var data = await downloadMusicFromYoutube('https://www.youtube.com/watch?v=' + handleReply.link[event.body - 1], path);
    if (fs.statSync(path).size > 150 * 1024 * 1024)
      return api.sendMessage('𝐁𝐚̀𝐢 𝐠𝐢̀ 𝐦𝐚̀ 𝐝𝐚̀𝐢 𝐝𝐮̛̃ 𝐯𝐚̣̂𝐲, đ𝐨̂̉𝐢 𝐛𝐚̀𝐢 đ𝐢 😠', event.threadID, () => fs.unlinkSync(path), event.messageID);
    api.unsendMessage(handleReply.messageID);
    api.setMessageReaction("✅", event.messageID, () => {}, true);
    return api.sendMessage({
      body: ` ㅤㅤㅤ===『 𝚃𝚒𝚎̣̂𝚖 𝙽𝚑𝚊̣𝚌 』===\n🎧 B𝚊̀𝚒 𝚑𝚊́𝚝: ${data.title}\n⏰ 𝚃𝚑𝚘̛̀𝚒 𝙻𝚞̛𝚘̛̣𝚗𝚐: ${module.exports.convertHMS(data.dur)}\n🌐 𝚃𝚎̂𝚗 𝚔𝚎̂𝚗𝐡: ${data.author}\n👥 Lượt theo dõi: ${data.sub}\n👁️ Lượt xem: ${data.viewCount}\n👤 𝙾𝚛𝚍𝚎𝚛: ${name}\n⌛ 𝚃𝚒𝚖𝚎 xử lý: ${Math.floor((Date.now() - data.timestart) / 1000)} giây`,
      attachment: fs.createReadStream(path)
    }, event.threadID, () => fs.unlinkSync(path), event.messageID);
  } catch (e) { console.log(e); }
};

module.exports.convertHMS = function (value) {
  const sec = parseInt(value, 10);
  let hours = Math.floor(sec / 3600);
  let minutes = Math.floor((sec - (hours * 3600)) / 60);
  let seconds = sec - (hours * 3600) - (minutes * 60);
  if (hours < 10) hours = "0" + hours;
  if (minutes < 10) minutes = "0" + minutes;
  if (seconds < 10) seconds = "0" + seconds;
  return (hours != '00' ? hours + ':' : '') + minutes + ':' + seconds;
};