const { createCanvas, loadImage } = require("canvas");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "vietqr",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Tạo mã QR chuyển khoản ngân hàng với giao diện hiện đại",
  commandCategory: "Khác",
  usages: "[tên ngân hàng] [stk] [tên chủ tk] [số tiền] [nội dung] hoặc list",
  cooldowns: 5,
  usePrefix: true
};

// Danh sách ngân hàng chính thức
const officialBankNames = {
  "970415": "VietinBank",
  "970436": "Vietcombank",
  "970448": "OCB",
  "970418": "BIDV",
  "970405": "Agribank",
  "970422": "MB Bank",
  "970407": "Techcombank",
  "970416": "ACB",
  "970432": "VPBank",
  "970423": "TPBank",
  "970403": "Sacombank",
  "970437": "HDBank",
  "970454": "VietCapitalBank",
  "970429": "SCB",
  "970441": "VIB",
  "970443": "SHB",
  "970431": "Eximbank",
  "970426": "MSB",
  "546034": "CAKE by VPBank",
  "546035": "Ubank by VPBank",
  "963388": "TIMO",
  "971005": "ViettelMoney",
  "971011": "VNPTMoney"
};

// Mapping alias sang mã ngân hàng
const bankAliasToCode = {
  "vietinbank": "970415",
  "vietcombank": "970436", "vcb": "970436",
  "ocb": "970448",
  "bidv": "970418",
  "agribank": "970405",
  "mbbank": "970422", "mb": "970422",
  "techcombank": "970407", "techcom": "970407",
  "acb": "970416",
  "vpbank": "970432",
  "tpbank": "970423",
  "sacombank": "970403",
  "hdbank": "970437",
  "vietcapitalbank": "970454",
  "scb": "970429",
  "vib": "970441",
  "shb": "970443",
  "eximbank": "970431",
  "msb": "970426",
  "cake": "546034",
  "ubank": "546035",
  "timo": "963388",
  "viettelmoney": "971005",
  "vnptmoney": "971011"
};

// Vẽ hình chữ nhật bo tròn
function rrect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

async function drawVietQR(bankName, bankCode, accountNumber, accountName, amount, addInfo, qrBuffer, outPath) {
  const width = 768, height = 1152;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  // === NỀN ===
  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, "#0b1c2b");
  gradient.addColorStop(1, "#04101c");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // === VIỀN NGOÀI PHÁT SÁNG ===
  ctx.strokeStyle = "#00ff88";
  ctx.lineWidth = 10;
  ctx.strokeRect(5, 5, width - 10, height - 10);

  // === TIÊU ĐỀ ===
  ctx.fillStyle = "#00ff88";
  ctx.font = "bold 60px Arial";
  const title = bankName.toUpperCase();
  const titleWidth = ctx.measureText(title).width;
  ctx.fillText(title, (width - titleWidth) / 2, 110);

  ctx.font = "28px Arial";
  ctx.fillText("VietQR • NAPAS 247", (width - ctx.measureText("VietQR • NAPAS 247").width) / 2, 160);

  // === QR CODE ===
  const qrImg = await loadImage(qrBuffer);
  ctx.fillStyle = "#ffffff";
  rrect(ctx, 134, 200, 500, 500, 20);
  ctx.fill();
  ctx.drawImage(qrImg, 154, 220, 460, 460);

  // === THÔNG TIN ===
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 30px Arial";
  let y = 770;
  const lineGap = 55;
  const info = [
    ["SỐ TÀI KHOẢN", accountNumber],
    ["NGÂN HÀNG", bankName],
    ["CHỦ TÀI KHOẢN", accountName],
    ["NỘI DUNG CHUYỂN KHOẢN", addInfo],
  ];

  for (const [label, value] of info) {
    ctx.font = "bold 26px Arial";
    ctx.fillStyle = "#9cb6d4";
    ctx.fillText(label, 120, y);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 28px Arial";
    ctx.fillText(value, 120, y + 35);
    y += lineGap + 20;
  }

  // === KHUNG SỐ TIỀN ===
  const boxY = y + 20;
  ctx.fillStyle = "#00ff88";
  rrect(ctx, 90, boxY, width - 180, 120, 25);
  ctx.fill();

  ctx.font = "bold 36px Arial";
  ctx.fillStyle = "#0b1c2b";
  ctx.fillText("SỐ TIỀN CHUYỂN KHOẢN", 150, boxY + 45);

  ctx.font = "bold 60px Arial";
  ctx.fillStyle = "#ffffff";
  ctx.fillText(`${Number(amount).toLocaleString()} đ`, (width - ctx.measureText(`${Number(amount).toLocaleString()} đ`).width) / 2, boxY + 100);

  // === NÚT QUÉT MÃ ===
  const buttonY = boxY + 160;
  ctx.fillStyle = "#00ff88";
  rrect(ctx, 230, buttonY, 310, 70, 35);
  ctx.fill();

  ctx.font = "bold 28px Arial";
  ctx.fillStyle = "#0b1c2b";
  const text = "QUÉT MÃ ĐỂ THANH TOÁN";
  ctx.fillText(text, (width - ctx.measureText(text).width) / 2, buttonY + 45);

  // === LƯU ẢNH ===
  const out = fs.createWriteStream(outPath);
  const stream = canvas.createJPEGStream();
  stream.pipe(out);
  return new Promise((resolve) => out.on("finish", resolve));
}

module.exports.run = async function ({ api, event, args }) {
  const command = args[0] ? args[0].toLowerCase() : "";

  if (command === "list") {
    const bankList = Object.values(officialBankNames).map(name => `• ${name}`).join("\n");
    return api.sendMessage(
      `📌 Danh sách ngân hàng hỗ trợ:\n${bankList}`,
      event.threadID, event.messageID
    );
  }

  if (args.length < 5) {
    return api.sendMessage(
      "⚠️ Vui lòng nhập đúng định dạng:\nvietqr [tên ngân hàng] [stk] [tên chủ tk] [số tiền] [nội dung]\n\nVí dụ:\nvietqr mbbank 123456789 Nguyễn Văn A 50000 napgame\n\nHoặc dùng: vietqr list để xem danh sách ngân hàng hỗ trợ.",
      event.threadID, event.messageID
    );
  }

  const [bankAlias, accountNumber, ...rest] = args;
  const amount = rest[rest.length - 2];
  const additionalInfo = rest[rest.length - 1];
  const accountName = rest.slice(0, -2).join(" ");

  const bankCode = bankAliasToCode[bankAlias.toLowerCase()];
  if (!bankCode) {
    return api.sendMessage(`❌ Không tìm thấy ngân hàng: ${bankAlias}\nBạn có thể thử lại bằng tên khác như: mbbank, vcb, timo, cake,...`, event.threadID, event.messageID);
  }

  try {
    const qrUrl = `https://api.vietqr.io/image/${bankCode}-${accountNumber}-wgEtlNH.jpg?accountName=${encodeURIComponent(accountName)}&amount=${encodeURIComponent(amount)}&addInfo=${encodeURIComponent(additionalInfo)}`;
    const qrResponse = await axios.get(qrUrl, { responseType: "arraybuffer" });

    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);
    const outPath = path.join(cacheDir, `vietqr_${event.senderID}.jpg`);

    await drawVietQR(
      officialBankNames[bankCode],
      bankCode,
      accountNumber,
      accountName,
      amount,
      additionalInfo,
      qrResponse.data,
      outPath
    );

    const message = `✅ Mã QR chuyển khoản đã được tạo:\n\n🏦 Ngân hàng: ${officialBankNames[bankCode]} (${bankAlias})\n🔢 STK: ${accountNumber}\n👤 Tên: ${accountName}\n💰 Số tiền: ${amount} VND\n📝 Nội dung: ${additionalInfo}`;
    api.sendMessage({
      body: message,
      attachment: fs.createReadStream(outPath)
    }, event.threadID, () => fs.unlinkSync(outPath), event.messageID);

  } catch (error) {
    console.error("Lỗi khi tạo mã QR:", error);
    return api.sendMessage("❌ Lỗi tạo mã QR, vui lòng kiểm tra lại thông tin hoặc thử lại sau.", event.threadID, event.messageID);
  }
};