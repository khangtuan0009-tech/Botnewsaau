const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");
const ytdl = require("ytdl-core-enhanced");
const { createCanvas, loadImage } = require("canvas");

const mediaSavePath = path.join(__dirname, "cache/Youtube");
if (!fs.existsSync(mediaSavePath)) fs.mkdirSync(mediaSavePath, { recursive: true });

const YT_API_KEY = "AIzaSyAygWrPYHFVzL0zblaZPkRcgIFZkBNAW9g";

module.exports.config = {
  name: "yts",
  version: "6.5.0",
  hasPermssion: 0,
  credits: "nvh",
  description: "Tải video từ YouTube",
  commandCategory: "Tiện ích",
  usages: "video <từ khóa hoặc URL>",
  cooldowns: 3,
  usePrefix: true,
  useprefix: false
};

function formatDuration(duration) {
  const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
  const h = (match[1] || "").replace("H", "") || 0;
  const m = (match[2] || "").replace("M", "") || 0;
  const s = (match[3] || "").replace("S", "") || 0;
  return `${h > 0 ? h + ":" : ""}${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

// === Vẽ menu kết quả bằng Canvas ===
async function drawMenu(videos) {
  const width = 1280, height = 720;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  // Nền
  ctx.fillStyle = "#111";
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = "#fff";
  ctx.font = "40px sans-serif";
  ctx.fillText("🎬 Kết quả tìm kiếm YouTube", 50, 70);

  const itemHeight = 120;
  for (let i = 0; i < videos.length; i++) {
    const y = 100 + i * (itemHeight + 10);
    const vid = videos[i];
    const thumb = await loadImage(vid.thumb);
    ctx.drawImage(thumb, 50, y, 200, 120);

    ctx.fillStyle = "#fff";
    ctx.font = "bold 26px sans-serif";
    ctx.fillText(`${i + 1}. ${vid.title.substring(0, 55)}`, 270, y + 40);
    ctx.font = "22px sans-serif";
    ctx.fillStyle = "#aaa";
    ctx.fillText(`👤 ${vid.channel}`, 270, y + 75);
    ctx.fillText(`⏱ ${vid.duration} | 👀 ${vid.views}`, 270, y + 105);
  }

  const tempPath = path.join(mediaSavePath, `menu_${Date.now()}.png`);
  fs.writeFileSync(tempPath, canvas.toBuffer());
  return tempPath;
}

// === Tải video với giới hạn 25MB ===
async function downloadVideo(videoID, userID) {
  const info = await ytdl.getInfo(videoID);
  const formats = ytdl.filterFormats(info.formats, "videoandaudio");
  const valid = formats
    .filter(f => f.contentLength && Number(f.contentLength) <= 25 * 1024 * 1024)
    .sort((a, b) => Number(b.contentLength) - Number(a.contentLength)); // chọn lớn nhất trong phạm vi ≤25MB

  const chosen = valid[0] || formats.find(f => f.qualityLabel === "144p") || formats[0];
  if (!chosen) throw new Error("Không có bản nào dưới 25MB");

  const filePath = path.join(mediaSavePath, `${Date.now()}_${userID}.mp4`);
  const stream = ytdl(videoID, { format: chosen });
  await new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(filePath);
    stream.pipe(ws);
    ws.on("finish", resolve);
    ws.on("error", reject);
  });
  return filePath;
}

// === Gửi video sau khi chọn ===
async function handleChosen(api, threadID, messageID, senderID, videoID) {
  try {
    const info = await axios.get(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${videoID}&key=${YT_API_KEY}`
    );
    const v = info.data.items[0];
    const filePath = await downloadVideo(videoID, senderID);

    const text = `🎥 ${v.snippet.title}\n👤 ${v.snippet.channelTitle}\n⏱ ${formatDuration(
      v.contentDetails.duration
    )}\n👀 ${Number(v.statistics.viewCount).toLocaleString()} lượt xem`;

    await api.sendMessage({ body: text, attachment: fs.createReadStream(filePath) }, threadID, () => {
      fs.unlinkSync(filePath);
    });
  } catch (err) {
    console.error("Video download error:", err.message);
    api.sendMessage("❎ Lỗi khi tải video hoặc không có bản ≤25MB.", threadID, messageID);
  }
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID } = event;
  if (!args[0]) return api.sendMessage("❎ Nhập từ khóa hoặc URL YouTube.", threadID, messageID);

  const input = args.join(" ");
  const urlPattern = /^(https?:\/\/)?(www\.)?(m\.)?(youtube\.com|youtu\.be)\/.+/;
  let videoID;

  if (urlPattern.test(input)) {
    try {
      videoID = ytdl.getURLVideoID(input);
      return await handleChosen(api, threadID, messageID, senderID, videoID);
    } catch {}
  }

  // === Tìm 6 kết quả ===
  const search = await axios.get(
    `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=6&q=${encodeURIComponent(input)}&key=${YT_API_KEY}`
  );
  if (!search.data.items.length) return api.sendMessage("❎ Không tìm thấy kết quả.", threadID, messageID);

  const videoList = [];
  for (const item of search.data.items) {
    const vID = item.id.videoId;
    const info = await axios.get(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${vID}&key=${YT_API_KEY}`
    );
    const v = info.data.items[0];
    videoList.push({
      id: vID,
      title: v.snippet.title,
      channel: v.snippet.channelTitle,
      duration: formatDuration(v.contentDetails.duration),
      views: Number(v.statistics.viewCount).toLocaleString(),
      thumb: v.snippet.thumbnails.medium.url
    });
  }

  // === Vẽ menu ===
  const imgPath = await drawMenu(videoList);
  const msg = {
    body: "🎬 Reply số để chọn video bạn muốn tải (≤25 MB)",
    attachment: fs.createReadStream(imgPath)
  };

  api.sendMessage(msg, threadID, (err, info) => {
    if (err) return;
    fs.unlinkSync(imgPath);
    global.client.handleReply.push({
      name: module.exports.config.name,
      messageID: info.messageID,
      author: senderID,
      videos: videoList
    });
  });
};

// === Khi người dùng reply chọn video ===
module.exports.handleReply = async function ({ api, event, handleReply }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID != handleReply.author) return;
  const choice = parseInt(body.trim());
  const chosen = handleReply.videos[choice - 1];
  if (!chosen) return api.sendMessage("❎ Số không hợp lệ.", threadID, messageID);

  await handleChosen(api, threadID, messageID, senderID, chosen.id);
};