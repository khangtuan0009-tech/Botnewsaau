const axios = require('axios');
const fs = require('fs');
const path = require('path');

this.config = {
    name: "",
    version: "1.0.0",
    hasPermission: 0,
    credits: "DC-Nam",
    description: "gái",
    commandCategory: "no prefix",
    usages: "",
    cooldowns: 3,
    usePrefix: true
};

// Đường dẫn file timestart
const startTimePath = path.join(__dirname, "..", "..", "nvhz", "timestart.json");

// Hàm đọc thời gian khởi động
function getBotStartTime() {
    try {
        if (fs.existsSync(startTimePath)) {
            const data = JSON.parse(fs.readFileSync(startTimePath, "utf8"));
            if (data.startTime) return new Date(data.startTime);
        }
    } catch (e) {
        console.error("⚠️ Lỗi đọc timestart.json:", e);
    }
    return new Date(); // fallback nếu file không tồn tại
}

// Hàm tính uptime từ startTime
function getUptime() {
    const startTime = getBotStartTime();
    const diff = Date.now() - startTime.getTime();
    const sec = Math.floor(diff / 1000);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h}h ${m}m ${s}s`;
}

this.run = async function (o) {
    // Lấy thông tin người dùng
    const userInfo = await o.api.getUserInfo(o.event.senderID);
    const userName = userInfo[o.event.senderID].name;
    
    // Lấy thính random từ API
    const response = await axios.get('https://raw.githubusercontent.com/Sang070801/api/main/thinh1.json');
    const data = response.data;
    const thinhArray = Object.values(data.data);
    const randomThinh = thinhArray[Math.floor(Math.random() * thinhArray.length)];
    
    // Lấy uptime từ file
    const uptime = getUptime();
    
    // Tạo tin nhắn
    const msg = {
        body: `Hi ${userName} 🧸\nTime on: ${uptime}\nThính: ${randomThinh}`,
        attachment: vdanime.splice(0, 1) // Lấy một attachment từ mảng vdnhac
    };
    
    // Gửi tin nhắn và tự xóa sau 30 giây
    o.api.sendMqttMessage(msg, o.event.threadID, async (err, info) => {
        setTimeout(() => {
            o.api.unsendMessage(info?.messageID);
        }, 30 * 1000);
    }, o.event.messageID);
};