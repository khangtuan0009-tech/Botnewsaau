const crypto = require("crypto");

module.exports.config = {
  name: "ping",
  version: "3.0.0",
  hasPermssion: 1,
  credits: "nvh",
  description: "Tag ẩn toàn bộ thành viên",
  commandCategory: "QTV",
  usages: "[text]",
  cooldowns: 20,
  usePrefix: true
};

module.exports.run = async function({ api, event, args }) {
  try {
    const botID = api.getCurrentUserID();
    const threadID = event.threadID;
    const senderID = event.senderID;

    // Lọc ra toàn bộ thành viên trừ bot và người gửi
    const listUserID = event.participantIDs.filter(id => id !== botID && id !== senderID);

    // Nếu nhóm trống
    if (!listUserID.length)
      return api.sendMessage("⚠️ Không có thành viên nào khác trong nhóm!", threadID, event.messageID);

    // Nội dung tin nhắn
    const body = args.length ? args.join(" ") : "Cook ra chỗ khác";
    const mentions = listUserID.map(id => ({ id, tag: "@" }));

    // --- Gửi tin nhắn duy nhất (MQTT auto sync trong sendMessage mới) ---
    await api.sendMessage(
      {
        body,
        mentions
      },
      threadID,
      event.messageID
    );

    // Log nội bộ (debug)
    console.log(`[PING] Đã ping ${listUserID.length} thành viên trong thread ${threadID}`);

  } catch (err) {
    console.error("[PING ERROR]", err);
    return api.sendMessage(
      "❌ Lỗi khi thực hiện ping toàn bộ thành viên.",
      event.threadID,
      event.messageID
    );
  }
};