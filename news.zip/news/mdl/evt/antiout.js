const fs = require("fs");
const path = require("path");

module.exports.config = {
  usePrefix: true,
    name: "antiout",
    eventType: ["log:unsubscribe"],
    version: "1.0.0",
    credits: "nvh",
    description: "Chặn thành viên tự ý rời nhóm"
};

module.exports.run = async function ({ api, event, Threads }) {
    try {
        const statusFile = path.join(__dirname, "../../utils/antiout.json");

        // Tạo file config nếu chưa có
        if (!fs.existsSync(statusFile)) {
            fs.writeFileSync(statusFile, JSON.stringify({}, null, 2));
        }

        let data = JSON.parse(fs.readFileSync(statusFile, "utf8"));
        const { threadID, logMessageData, author } = event;

        if (!data[threadID]) {
            data[threadID] = { status: false };
            fs.writeFileSync(statusFile, JSON.stringify(data, null, 2));
        }

        // Nếu chưa bật thì bỏ qua
        if (!data[threadID].status) return;

        const { leftParticipantFbId } = logMessageData;

        // Nếu người bị out chính là bot thì bỏ qua
        if (leftParticipantFbId == api.getCurrentUserID()) return;

        // Nếu admin kick thì bỏ qua (antiout chỉ chặn tự ý out)
        if (author !== leftParticipantFbId) return;

        try {
            await api.addUserToGroup(leftParticipantFbId, threadID);
            const userInfo = await api.getUserInfo(leftParticipantFbId);
            const name = userInfo[leftParticipantFbId]?.name || "Người dùng";
            api.sendMessage(`${name} Out Con cặc đéo có mồm xin à`, threadID);
        } catch (e) {
            api.sendMessage(`Không thể add lại người dùng ${leftParticipantFbId} (có thể đã chặn bot hoặc không còn kết bạn).`, threadID);
        }
    } catch (error) {
        console.error("Lỗi ở antiout:", error);
    }
};