const fs = require('fs');
const path = require('path');
const moment = require("moment-timezone");
const stringSimilarity = require('string-similarity');
const escapeRegex = str => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const logger = require("../../utils/log.js");

module.exports = function ({ api, models, Users, Threads, Currencies }) {


    const startTimePath = path.join(__dirname, "../../nvhz/timestart.json");

    function getBotStartTime() {
        try {
            if (fs.existsSync(startTimePath)) {
                const data = JSON.parse(fs.readFileSync(startTimePath, "utf8"));
                if (data.startTime) return new Date(data.startTime);
            }
        } catch (e) {
            console.error("⚠️ Lỗi đọc timestart.json:", e);
        }
        return new Date(); // fallback nếu file không tồn tại
    }

    function getUptime() {
        const startTime = getBotStartTime();
        const diff = Date.now() - startTime.getTime();
        const sec = Math.floor(diff / 1000);
        const h = Math.floor(sec / 3600);
        const m = Math.floor((sec % 3600) / 60);
        const s = sec % 60;
        return `${h.toString().padStart(2,'0')}h:${m.toString().padStart(2,'0')}m:${s.toString().padStart(2,'0')}s`;
    }

    return async function ({ event }) {
        const dateNow = Date.now();
        const time = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss DD/MM/YYYY");
        const { allowInbox, PREFIX, ADMINBOT, NDH, DeveloperMode } = global.config;
        const { userBanned, threadBanned, threadInfo, threadData, commandBanned } = global.data;
        const { commands, cooldowns } = global.client;
        let { body, senderID, threadID, messageID } = event;

        const threadSettingBox = global.data.threadData.get(threadID) || {};
        const prefixbox = threadSettingBox.PREFIX || PREFIX;

        senderID = String(senderID);
        threadID = String(threadID);

        const prefixRegex = new RegExp(`^(<@!?${senderID}>|${escapeRegex(threadSettingBox.PREFIX || PREFIX)})\\s*`);
        const adminbot = require('../../vh/config.json');

        // --- Giới hạn quyền sử dụng bot ---
        if (typeof body === 'string' && body.startsWith(prefixbox)) {
            if (!NDH.includes(senderID) && !ADMINBOT.includes(senderID)) {
                if (adminbot.adminOnly)
                    return api.sendMessage(`⚠️ Chỉ admin bot mới có thể sử dụng bot!`, threadID, messageID);
                if (adminbot.adminPaseOnly && !event.isGroup)
                    return api.sendMessage(`⚠️ Chỉ admin bot mới được sử dụng bot trong chat riêng!`, threadID, messageID);
                if (adminbot.ndhOnly)
                    return api.sendMessage(`⚠️ Chỉ người điều hành mới có thể sử dụng bot!`, threadID, messageID);
            }
        }

        const dataAdbox = require('../../mdl/cmds/data/dataAdbox.json');
        const threadInf = threadInfo.get(threadID) || await Threads.getInfo(threadID);
        const isQtv = threadInf.adminIDs.some(el => el.id == senderID);

        if (typeof body === 'string' && body.startsWith(prefixbox) &&
            dataAdbox.adminbox?.[threadID] === true &&
            !NDH.includes(senderID) && !ADMINBOT.includes(senderID) &&
            !isQtv && event.isGroup)
            return api.sendMessage(`⚠️ Chỉ quản trị viên nhóm mới có thể sử dụng bot!`, threadID, messageID);

        // --- Kiểm tra bị cấm ---
        if (userBanned.has(senderID) || threadBanned.has(threadID) || (!allowInbox && senderID == threadID)) {
            if (!body.startsWith(PREFIX)) return;
            if (!NDH.includes(senderID) && !ADMINBOT.includes(senderID)) {
                if (userBanned.has(senderID)) {
                    const { reason, dateAdded } = userBanned.get(senderID);
                    return api.sendMessage(global.getText("handleCommand", "userBanned", reason, dateAdded), threadID);
                } else if (threadBanned.has(threadID)) {
                    const { reason, dateAdded } = threadBanned.get(threadID);
                    return api.sendMessage(global.getText("handleCommand", "threadBanned", reason, dateAdded), threadID);
                }
            }
        }

        body = body || '';
        const [matchedPrefix] = body.match(prefixRegex) || [''];
        let args = body.slice(matchedPrefix.length).trim().split(/ +/);
        let commandName = args.shift()?.toLowerCase();
        let command = commands.get(commandName);

        // --- Kiểm tra usePrefix và thuê bot ---
        if (!prefixRegex.test(body)) {
            args = (body || '').trim().split(/ +/);
            commandName = args.shift()?.toLowerCase();
            command = commands.get(commandName);

            if (command?.config) {
                const isHighPerm = NDH.includes(senderID) || ADMINBOT.includes(senderID);
                let isBoxRented = false;

                try {
                    const rentPath = path.join(__dirname, '../../mdl/cmds/data/thuebot.json');
                    if (fs.existsSync(rentPath)) {
                        const rentData = JSON.parse(fs.readFileSync(rentPath));
                        isBoxRented = rentData[threadID]?.status === true;
                    }
                } catch { }

                if (command.config.usePrefix && !body.startsWith(PREFIX)) return;

                if (!command.config.usePrefix && !isBoxRented && !isHighPerm) {
                    return api.sendMessage(
                        `⚠️ Box này chưa thuê bot nên không thể dùng lệnh "${command.config.name}"!\n🪙 Vui lòng thuê bot để sử dụng.`,
                        threadID, messageID
                    );
                }
            }
        }

        // --- Gợi ý lệnh gần giống ---
        if (!command) {
            if (!body.startsWith(prefixbox)) return;
            const allCommandName = Array.from(commands.keys());
            const checker = stringSimilarity.findBestMatch(commandName, allCommandName);
            if (checker.bestMatch.rating >= 0.5) {
                command = commands.get(checker.bestMatch.target);
            } else {
                const name = await Users.getNameUser(senderID);
                return api.sendMessage(`${name}\n✏️ Lệnh gần giống: "${checker.bestMatch.target}"\n⏳ Uptime: ${getUptime()}`, threadID);
            }
        }

        if (!command) return;

        // --- Kiểm tra quyền ---
        const ten = await Users.getNameUser(senderID);
        let permssion = 0;
        const threadInfoo = threadInfo.get(threadID) || await Threads.getInfo(threadID);
        const isAdminBox = threadInfoo.adminIDs.some(el => el.id == senderID);

        if (NDH.includes(senderID)) permssion = 3;
        else if (ADMINBOT.includes(senderID)) permssion = 2;
        else if (isAdminBox) permssion = 1;

        let quyenhan = "";
        if (command.config.hasPermssion == 1) quyenhan = "Quản Trị Viên";
        else if (command.config.hasPermssion == 2) quyenhan = "ADMIN_BOT";
        else if (command.config.hasPermssion == 3) quyenhan = "Người Điều Hành";

        if (command.config.hasPermssion > permssion)
            return api.sendMessage(`👤 ${ten}\n⛔ Chỉ ${quyenhan} mới được dùng lệnh ${command.config.name}`, threadID, messageID);

        // --- Cooldown ---
        if (!cooldowns.has(command.config.name)) cooldowns.set(command.config.name, new Map());
        const timestamps = cooldowns.get(command.config.name);
        const expirationTime = (command.config.cooldowns || 1) * 1000;

        if (timestamps.has(senderID) && dateNow < timestamps.get(senderID) + expirationTime) {
            return api.sendMessage(`⚠️ Vui lòng chờ ${(timestamps.get(senderID) + expirationTime - dateNow) / 1000}s để dùng lại lệnh "${command.config.name}"`, threadID);
        }

        const getText2 = (...values) => {
            if (command.languages && typeof command.languages == 'object') {
                const pack = command.languages[global.config.language] || {};
                let lang = pack[values[0]] || '';
                for (let i = values.length; i > 0; i--) {
                    const expReg = RegExp('%' + i, 'g');
                    lang = lang.replace(expReg, values[i]);
                }
                if (lang) return lang;
            }
            return global.getText(...values);
        };

        try {
            const Obj = { api, event, args, models, Users, Threads, Currencies, permssion, getText: getText2 };
            await command.run(Obj);
            timestamps.set(senderID, dateNow);
            if (DeveloperMode)
                logger(global.getText("handleCommand", "executeCommand", time, commandName, senderID, threadID, args.join(" "), Date.now() - dateNow), "[ DEV MODE ]");
        } catch (e) {
            return api.sendMessage(global.getText("handleCommand", "commandError", commandName, e), threadID);
        }
    };
};