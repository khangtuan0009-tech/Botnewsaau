/* Ng Van Hungg */
"use strict";

var utils = require("../utils");
var log = require("npmlog");

/**
 * Approve or decline group join request
 * @param {String} threadID - ID nhóm
 * @param {String} userID - ID user
 * @param {Boolean} isApprove - true = approve, false = decline
 * @param {Function} callback - callback(err, result)
 */

module.exports = function (defaultFuncs, api, ctx) {
  return function groupJoin(threadID, userID, isApprove, callback) {
    if (!callback) callback = function () {};

    if (!threadID || !userID) {
      return callback({ error: "groupJoin: need threadID and userID" });
    }

    const friendlyName = isApprove
      ? "GroupCometApprovePendingMemberMutation"
      : "GroupCometDeclinePendingMemberMutation";

    const form = {
      av: ctx.userID,
      fb_api_req_friendly_name: friendlyName,
      fb_api_caller_class: "RelayModern",
      doc_id: isApprove ? "4782349058507434" : "5031153473636327",
      variables: JSON.stringify({
        input: {
          client_mutation_id: Math.floor(Math.random() * 17).toString(),
          actor_id: ctx.userID,
          group_id: threadID.toString(),
          user_id: userID.toString(),
          source: "pending_approval_queue",
        },
      }),
    };

    defaultFuncs
      .post("https://www.facebook.com/api/graphql/", ctx.jar, form)
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then((resData) => {
        try {
          const res = Array.isArray(resData) ? resData[0] : resData;
          if (res.errors) {
            throw res.errors;
          }

          const key = isApprove
            ? "group_approve_pending_member"
            : "group_decline_pending_member";

          if (res.data && res.data[key]) {
            return callback(null, {
              success: true,
              action: isApprove ? "approved" : "declined",
              data: res.data[key],
            });
          } else {
            throw { error: "groupJoin: no data returned", resData };
          }
        } catch (e) {
          log.error("groupJoin", e);
          return callback(e);
        }
      })
      .catch((err) => {
        log.error("groupJoin", err);
        return callback(err);
      });
  };
};