"use strict";

var utils = require("../utils");
var log = require("npmlog");
var axios = require("axios");

module.exports = function (defaultFuncs, api, ctx) {

  // ====== Hàm upload ảnh lên FB ======
  function handleUpload(image, callback) {
    var form = {
      images_only: "true",
      "attachment[]": image
    };

    defaultFuncs
      .postFormData("https://upload.facebook.com/ajax/mercury/upload.php", ctx.jar, form, {})
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then(function (resData) {
        if (resData.error) throw resData;
        return callback(null, resData.payload.metadata[0]);
      })
      .catch(function (err) {
        log.error("handleUpload", err);
        return callback(err);
      });
  }

  // ====== Hàm generate ảnh AI (demo dùng pollinations API free) ======
  async function generateAIImage(prompt) {
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}`;
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return Buffer.from(res.data, "binary"); // trả về buffer
  }

  // ====== Hàm chính: đổi avatar box bằng AI ======
  return async function changeGroupImageAI(prompt, threadID, callback) {
    var resolveFunc = function () { };
    var rejectFunc = function () { };
    var returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err) {
        if (err) return rejectFunc(err);
        resolveFunc();
      };
    }

    try {
      // 1. Generate ảnh từ prompt
      const imageBuffer = await generateAIImage(prompt);

      // 2. Upload ảnh lên FB
      handleUpload(imageBuffer, function (err, payload) {
        if (err) return callback(err);

        var messageAndOTID = utils.generateOfflineThreadingID();
        var form = {
          client: "mercury",
          action_type: "ma-type:log-message",
          author: "fbid:" + ctx.userID,
          log_message_type: "log:thread-image",
          message_id: messageAndOTID,
          offline_threading_id: messageAndOTID,
          source: "source:chat:web",
          "source_tags[0]": "source:chat",
          thread_fbid: threadID,
          thread_image_id: payload.image_id,
          timestamp: Date.now(),
        };

        // 3. Gửi request đổi ảnh nhóm
        defaultFuncs
          .post("https://www.facebook.com/messaging/set_thread_image/", ctx.jar, form)
          .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
          .then(function (resData) {
            if (resData.error) throw resData;
            return callback(null, resData);
          })
          .catch(function (err) {
            log.error("changeGroupImageAI", err);
            return callback(err);
          });
      });
    } catch (e) {
      return callback(e);
    }

    return returnPromise;
  };
};