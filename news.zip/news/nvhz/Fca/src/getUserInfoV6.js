"use strict";

var utils = require("../utils");
var log = require("npmlog");
// Nvh mod
// ====== Hàm format dữ liệu ======
function formatData(profile) {
  return {
    id: profile.id,
    name: profile.name,
    firstName: profile.firstName,
    vanity: profile.vanity,
    thumbSrc: profile.profile_picture?.uri,
    profileUrl: profile.url || profile.uri,
    gender: profile.gender,
    type: profile.type,
    isFriend: profile.is_friend,
    isBirthday: !!profile.is_birthday,
    joinTime: profile.joined_facebook_time?.timestamp || null,
    mutualFriends: profile.mutual_friends?.count || 0,
    followers: profile.subscribers?.count || 0,
    following: profile.following?.count || 0,
    work: profile.work?.map(w => w.employer?.name).filter(Boolean) || [],
    education: profile.education?.map(e => e.school?.name).filter(Boolean) || [],
    relationship: profile.relationship_status || null,
    hometown: profile.hometown?.name || null,
    currentCity: profile.current_city?.name || null,
    coverPhoto: profile.cover_photo?.uri || null
  };
}

module.exports = function (defaultFuncs, api, ctx) {
  return function getUserInfoV6(id, callback) {
    var resolveFunc = function () {};
    var rejectFunc = function () {};
    var returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, userInfo) {
        if (err) return rejectFunc(err);
        resolveFunc(userInfo);
      };
    }

    if (utils.getType(id) !== "Array") id = [id];

    // Tạo form query GraphQL
    var queries = {};
    id.forEach((uid, i) => {
      queries["q" + i] = {
        priority: 0,
        q: `node(${uid}) {
          id,
          name,
          firstName,
          vanity,
          gender,
          uri,
          url,
          type,
          is_friend,
          is_birthday,
          profile_picture { uri },
          cover_photo { uri },
          joined_facebook_time { timestamp },
          mutual_friends { count },
          subscribers { count },
          following { count },
          work { employer { name } },
          education { school { name } },
          relationship_status,
          hometown { name },
          current_city { name }
        }`
      };
    });

    // Gửi request
    defaultFuncs
      .post("https://www.facebook.com/api/graphqlbatch/", ctx.jar, {
        queries: JSON.stringify(queries)
      })
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then(function (resData) {
        if (!Array.isArray(resData)) {
          throw new Error("Invalid GraphQL response");
        }

        let result = {};
        resData.forEach(item => {
          if (item.error) return;
          if (item.data) {
            for (let key in item.data) {
              result[item.data[key].id] = formatData(item.data[key]);
            }
          }
        });

        callback(null, result);
      })
      .catch(function (err) {
        log.error("getUserInfoV6", err);
        return callback(err, null);
      });

    return returnPromise;
  };
};