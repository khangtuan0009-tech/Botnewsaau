"use strict";

const log = require("npmlog");
var utils = require("../utils");

module.exports = function (defaultFuncs, api, ctx) {
  /**
   * Mute thread on Messenger (GraphQL API)
   * @param {string} threadID - ID of the conversation (t_...)
   * @param {number} muteSeconds - Seconds to mute (0 = unmute, -1 = forever)
   * @param {function} [callback]
   */
  return function muteThread(threadID, muteSeconds, callback) {
    let resolveFunc, rejectFunc;
    const returnPromise = new Promise((resolve, reject) => {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) return rejectFunc(err);
        resolveFunc(data);
      };
    }

    // Facebook GraphQL doc_id for mute mutation (updated 2025)
    const doc_id = "8102690529788871"; // FBMessengerMuteThreadMutation
    const form = {
      av: ctx.userID,
      fb_api_req_friendly_name: "FBMessengerMuteThreadMutation",
      fb_api_caller_class: "RelayModern",
      doc_id,
      variables: JSON.stringify({
        input: {
          client_mutation_id: "mute_" + Date.now(),
          actor_id: ctx.userID,
          thread_id: threadID.toString(),
          mute_seconds: muteSeconds === -1 ? 630720000 : muteSeconds, // ~20 năm nếu mute vĩnh viễn
        },
      }),
    };

    defaultFuncs
      .post("https://www.facebook.com/api/graphql/", ctx.jar, form)
      .then(defaultFuncs.parseAndCheckLogin(ctx, defaultFuncs))
      .then(resData => {
        if (resData.errors) throw resData.errors;
        return callback(null, { success: true, threadID, muteSeconds });
      })
      .catch(err => {
        log.error("muteThread", err);
        return callback(err);
      });

    return returnPromise;
  };
};
