"use strict";

const utils = require("../utils");
const log = require("npmlog");
const bluebird = require("bluebird");
const fs = require("fs-extra");
const { Readable } = require("stream");

// ===== Hiệu ứng tin nhắn =====
const MESSAGE_EFFECTS = {
  HEART: { id: "369239263222822", unified_id: "369239263222822", effect_name: "heart" },
  CELEBRATION: { id: "370940413392601", unified_id: "370940413392601", effect_name: "celebration" },
  CONFETTI: { id: "369239343222814", unified_id: "369239343222814", effect_name: "confetti" },
  LOVE: { id: "369239383222810", unified_id: "369239383222810", effect_name: "love" },
  FIRE: { id: "369239433222805", unified_id: "369239433222805", effect_name: "fire" },
  GIFT: { id: "706630394217537", unified_id: "706630394217537", effect_name: "gift" } // 🎁 hộp quà
};

const allowedProperties = {
  attachment: true,
  url: true,
  sticker: true,
  emoji: true,
  emojiSize: true,
  body: true,
  mentions: true,
  location: true,
  messageEffect: true
};

module.exports = function (defaultFuncs, api, ctx) {

  // === Upload file đính kèm ===
  function uploadAttachment(attachments) {
    if (!attachments) return Promise.resolve([]);
    if (!Array.isArray(attachments)) attachments = [attachments];

    const uploads = attachments.map(item => {
      if (Array.isArray(item) && item.length >= 2 && /_id$/.test(item[0])) {
        return bluebird.resolve({ [item[0]]: item[1] });
      }

      let stream = item;
      if (!utils.isReadableStream(item)) {
        if (Buffer.isBuffer(item)) {
          const s = new Readable();
          s.push(item);
          s.push(null);
          stream = s;
        } else if (typeof item === "string" && fs.existsSync(item)) {
          stream = fs.createReadStream(item);
        } else return Promise.reject(new Error("Attachment must be stream, Buffer, or valid file path"));
      }

      const form = { upload_1024: stream, voice_clip: "true" };
      return defaultFuncs
        .postFormData("https://upload.facebook.com/ajax/mercury/upload.php", ctx.jar, form)
        .then(defaultFuncs.parseAndCheckLogin(ctx, defaultFuncs))
        .then(resData => {
          if (resData.error) throw resData;
          return resData.payload.metadata[0];
        });
    });

    return Promise.all(uploads);
  }

  // === Lấy URL chia sẻ ===
  function getUrl(url) {
    const form = { image_height: 960, image_width: 960, uri: url };
    return defaultFuncs.post("https://www.facebook.com/message_share_attachment/fromURI/", ctx.jar, form)
      .then(defaultFuncs.parseAndCheckLogin(ctx, defaultFuncs))
      .then(resData => {
        if (resData.error) throw resData;
        if (!resData.payload) throw new Error("Invalid URL");
        return resData.payload.share_data.share_params;
      });
  }

  // === Fallback gửi qua HTTPS ===
  function sendContent(form, threadID, messageAndOTID, callback) {
    form["thread_fbid"] = threadID;

    if (ctx.globalOptions.pageID) {
      form["author"] = "fbid:" + ctx.globalOptions.pageID;
      form["creator_info[creatorID]"] = ctx.userID;
      form["creator_info[creatorType]"] = "direct_admin";
      form["creator_info[labelType]"] = "sent_message";
      form["creator_info[pageID]"] = ctx.globalOptions.pageID;
      form["request_user_id"] = ctx.globalOptions.pageID;
      form["creator_info[profileURI]"] =
        "https://www.facebook.com/profile.php?id=" + ctx.userID;
    }

    defaultFuncs
      .post("https://www.facebook.com/messaging/send/", ctx.jar, form)
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then(resData => {
        if (!resData) return callback({ error: "Send message failed." });
        if (resData.error) return callback(resData);

        const messageInfo = resData.payload.actions.reduce((p, v) => {
          return {
            threadID: v.thread_fbid,
            messageID: v.message_id,
            timestamp: v.timestamp,
          } || p;
        }, null);

        callback(null, messageInfo);
      })
      .catch(err => {
        log.error("sendMessage", err);
        callback(err);
      });
  }

  // === Gửi tin nhắn qua MQTT ===
  function send(form, threadID, messageAndOTID, callback) {
    try {
      const ThreadID = Array.isArray(threadID) ? threadID[0] : threadID;
      form["specific_to_list"] = [];

      if (ThreadID.length <= 15) {
        form["specific_to_list"][0] = "fbid:" + ThreadID;
        form["specific_to_list"][1] = "fbid:" + ctx.userID;
        form["other_user_fbid"] = ThreadID;
      } else {
        form["thread_fbid"] = ThreadID;
      }

      const requestData = {
        app_id: "2220391788200892",
        payload: JSON.stringify({
          payload: JSON.stringify(form),
          tasks: [{
            label: 46,
            payload: JSON.stringify(form),
            queue_name: ThreadID,
            task_id: Math.floor(Math.random() * 1001),
            failure_count: null
          }],
          epoch_id: messageAndOTID,
          version_id: "7553237234719461"
        }),
        request_id: ++ctx.req_ID,
        type: 3
      };

      ctx.mqttClient.publish('/ls_req', JSON.stringify(requestData), { qos: 1 });
      ctx.callback_Task[ctx.req_ID] = {
        type: "sendMqttMessage",
        callback: (err) => {
          if (err) {
            // Nếu lỗi => fallback gửi qua HTTPS
            sendContent(form, ThreadID, messageAndOTID, callback);
          } else {
            callback(null, { threadID: ThreadID, messageID: messageAndOTID, timestamp: Date.now() });
          }
        }
      };
    } catch (e) {
      log.error("sendMqttMessage", e);
      sendContent(form, threadID, messageAndOTID, callback);
    }
  }

  // === Các handler ===
  async function handleAttachment(msg, form) {
    if (msg.attachment) {
      form.image_ids = [];
      form.gif_ids = [];
      form.file_ids = [];
      form.video_ids = [];
      form.audio_ids = [];

      const files = await uploadAttachment(msg.attachment);
      files.forEach(file => {
        const key = Object.keys(file)[0];
        form[key + "s"].push(file[key]);
      });
    }
  }

  async function handleUrl(msg, form) {
    if (msg.url) form["shareable_attachment[share_params]"] = await getUrl(msg.url);
  }

  function handleSticker(msg, form) {
    if (msg.sticker) form["sticker_id"] = msg.sticker;
  }

  function handleEmoji(msg, form) {
    if (msg.emoji) {
      if (!msg.emojiSize) msg.emojiSize = "medium";
      if (!["small", "medium", "large"].includes(msg.emojiSize))
        throw new Error("Invalid emojiSize");
      form.body = msg.emoji;
      form["tags[0]"] = "hot_emoji_size:" + msg.emojiSize;
    }
  }

  function handleMention(msg, form) {
    if (msg.mentions) {
      const emptyChar = "\u200E";
      form.body = emptyChar + form.body;
      msg.mentions.forEach((mention, i) => {
        const offset = form.body.indexOf(mention.tag, mention.fromIndex || 0);
        form[`profile_xmd[${i}][offset]`] = offset + 1;
        form[`profile_xmd[${i}][length]`] = mention.tag.length;
        form[`profile_xmd[${i}][id]`] = mention.id || 0;
        form[`profile_xmd[${i}][type]`] = "p";
      });
    }
  }

  function handleLocation(msg, form) {
    if (msg.location) {
      if (msg.location.latitude == null || msg.location.longitude == null)
        throw new Error("location requires latitude & longitude");
      form["location_attachment[coordinates][latitude]"] = msg.location.latitude;
      form["location_attachment[coordinates][longitude]"] = msg.location.longitude;
      form["location_attachment[is_current_location]"] = !!msg.location.current;
    }
  }

  function handleMessageEffect(msg, form) {
    if (msg.messageEffect) {
      const effect = MESSAGE_EFFECTS[msg.messageEffect.toUpperCase()];
      if (effect) {
        form.tags = form.tags || [];
        form.tags.push({
          id: effect.id,
          offset: 0,
          length: form.body.length,
          type: "message_effect"
        });
        form.message_effects = {
          effect_id: effect.id,
          effect_unified_id: effect.unified_id,
          effect_type: "MESSAGE_EFFECT",
          effect_name: effect.effect_name
        };
      }
    }
  }

  // === Hàm chính ===
  return async function sendMqttMessage(msg, threadID, replyToMessage = null) {
    if (typeof msg === "string") msg = { body: msg };

    const disallowed = Object.keys(msg).filter(p => !allowedProperties[p]);
    if (disallowed.length) throw new Error("Disallowed props: " + disallowed.join(", "));

    const messageAndOTID = utils.generateOfflineThreadingID();
    const form = {
      client: "mercury",
      action_type: "ma-type:user-generated-message",
      author: "fbid:" + ctx.userID,
      timestamp: Date.now(),
      source: "source:chat:web",
      body: msg.body ? msg.body.toString() : "",
      offline_threading_id: messageAndOTID,
      message_id: messageAndOTID,
      threading_id: utils.generateThreadingID(ctx.clientID),
      has_attachment: !!(msg.attachment || msg.url || msg.sticker),
      replied_to_message_id: replyToMessage
    };

    await handleLocation(msg, form);
    handleSticker(msg, form);
    await handleAttachment(msg, form);
    await handleUrl(msg, form);
    handleEmoji(msg, form);
    handleMention(msg, form);
    handleMessageEffect(msg, form);

    return new Promise((resolve, reject) => {
      send(form, threadID, messageAndOTID, (err, res) => {
        if (err) reject(err);
        else resolve(res);
      });
    });
  };
};