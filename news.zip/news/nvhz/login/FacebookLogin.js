const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const querystring = require('querystring');
const speakeasy = require('speakeasy');
const logger = require('../../utils/log.js');

module.exports = class FacebookLogin {
  static async getTokenFromCredentials(username, password, twofactor = '0', _2fa = '0') {
    try {
      const form = {
        adid: uuidv4(),
        email: username,
        password: password,
        format: 'json',
        device_id: uuidv4(),
        cpl: 'true',
        family_device_id: uuidv4(),
        locale: 'en_US',
        client_country_code: 'US',
        credentials_type: 'device_based_login_password',
        generate_session_cookies: '1',
        generate_analytics_claim: '1',
        generate_machine_id: '1',
        currently_logged_in_userid: '0',
        irisSeqID: 1,
        try_num: "1",
        enroll_misauth: "false",
        meta_inf_fbmeta: "NO_FILE",
        source: 'login',
        machine_id: this._randomString(24),
        meta_inf_fbmeta: '',
        fb_api_req_friendly_name: 'authenticate',
        fb_api_caller_class: 'com.facebook.account.login.protocol.Fb4aAuthHandler',
        api_key: '882a8490361da98702bf97a021ddc14d',
        access_token: '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
      };

      form.sig = this._encodeSig(this._sort(form));

      const options = {
        url: 'https://b-graph.facebook.com/auth/login',
        method: 'post',
        data: form,
        transformRequest: [(data) => querystring.stringify(data)],
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'x-fb-friendly-name': form.fb_api_req_friendly_name,
          'x-fb-http-engine': 'Liger',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
        }
      };

      try {
        // Login lần đầu
        const response = await axios.request(options);
        const data = response.data;

        data.access_token_eaad6v7 = await this._convertToken(data.access_token);
        data.cookies = await this._convertCookie(data.session_cookies);
        data.session_cookies = data.session_cookies.map(e => ({
          key: e.name,
          value: e.value,
          domain: "facebook.com",
          path: e.path,
          hostOnly: false
        }));

        return { status: true, message: 'Lấy thông tin thành công!', data };
      } catch (error) {
        const errData = error.response?.data?.error || {};
        const errorData = errData.error_data || {};

        // Nếu 401 thì trả luôn
        if (errData.code === 401) {
          return { status: false, message: errData.message || 'Unauthorized' };
        }

        // Nếu không có 2FA
        if (twofactor === '0' && (!_2fa || _2fa === "0")) {
          return { status: false, message: 'Vui lòng nhập mã xác thực 2 lớp!' };
        }

        // Lấy 2FA
        let twoFactorCode = (_2fa !== "0") ? _2fa : null;

        // Nếu chưa có, thử speakeasy
        if (!twoFactorCode && twofactor && twofactor.length > 8) {
          try {
            twoFactorCode = speakeasy.totp({ secret: twofactor.replace(/\s+/g,'').toLowerCase(), encoding: 'base32' });
          } catch {}
        }

        // Nếu vẫn chưa có, fallback API 2fa.live
        if (!twoFactorCode) {
          try {
            const resp = await axios.get(`https://2fa.live/tok/${encodeURIComponent(twofactor)}`, { timeout: 10000 });
            if (resp?.data?.token) twoFactorCode = String(resp.data.token);
          } catch {}
        }

        if (!twoFactorCode) return { status: false, message: 'Mã xác thực 2 lớp không hợp lệ!' };

        // Prepare form cho 2FA
        form.twofactor_code = twoFactorCode;
        form.encrypted_msisdn = "";
        form.userid = errorData.uid || form.userid || "0";
        form.machine_id = errorData.machine_id || form.machine_id;
        form.first_factor = errorData.login_first_factor || form.first_factor || '';
        form.credentials_type = "two_factor";
        form.sig = this._encodeSig(this._sort(form));
        options.data = form;

        // Login 2FA
        const response2 = await axios.request(options);
        const data2 = response2.data;

        data2.access_token_eaad6v7 = await this._convertToken(data2.access_token);
        data2.cookies = await this._convertCookie(data2.session_cookies);
        data2.session_cookies = data2.session_cookies.map(e => ({
          key: e.name,
          value: e.value,
          domain: "facebook.com",
          path: e.path,
          hostOnly: false
        }));

        return { status: true, message: 'Lấy thông tin thành công!', data: data2 };
      }
    } catch (e) {
      return { status: false, message: 'Vui lòng kiểm tra lại tài khoản, mật khẩu!' };
    }
  }

  static async _convertCookie(session = []) {
    return session.map(e => `${e.name}=${e.value}`).join('; ');
  }

  static async _convertToken(token) {
    try {
      const resp = await axios.get(
        `https://api.facebook.com/method/auth.getSessionforApp?format=json&access_token=${encodeURIComponent(token)}&new_app_id=275254692598279`,
        { timeout: 10000 }
      );
      return resp.data && !resp.data.error ? resp.data.access_token : undefined;
    } catch {
      return undefined;
    }
  }

  static _randomString(length) {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = chars.charAt(Math.floor(Math.random() * 26));
    for (let i = 1; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  static _encodeSig(obj) {
    const str = Object.entries(obj).map(([k,v]) => `${k}=${v}`).join('');
    return crypto.createHash('md5').update(str + '62f8ce9f74b12f84c123cc23437a4a32').digest('hex');
  }

  static _sort(obj) {
    return Object.keys(obj).sort().reduce((acc, key) => { acc[key] = obj[key]; return acc; }, {});
  }
}