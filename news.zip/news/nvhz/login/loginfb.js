const axios = require("axios");
const qs = require("querystring");
const { join } = require("path");
const fs = require("fs-extra");
const logger = require(process.cwd() + '/utils/log.js');
const FacebookLogin = require('./FacebookLogin.js');

exports.handleRelogin = async function() {
    try {
        const configPath = join(process.cwd(), './vh/config.json');
        if (!fs.existsSync(configPath)) return false;

        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (!config.facebookAccount || !config.facebookAccount.email || !config.facebookAccount.password || !config.facebookAccount["2FA"]) {
            logger('Thiếu thông tin tài khoản trong config.json', '[ ERROR ]');
            return false;
        }

        const { email, password, "2FA": twoFA } = config.facebookAccount;
        logger('Tiến hành đăng nhập lại', '[ LOGIN ]');

        // Truyền only secret, FacebookLogin sẽ tự xử lý speakeasy và fallback 2fa.live
        const loginResult = await FacebookLogin.getTokenFromCredentials(email, password, twoFA, '0');
        
        if (!loginResult.status) {
            logger(`Đăng nhập thất bại: ${loginResult.message}`, '[ ERROR ]');
            return false;
        }

        // Cập nhật cookie global
        const newCookie = loginResult.data.session_cookies
            .filter(cookie => ['c_user', 'xs', 'fr', 'datr'].includes(cookie.key))
            .map(cookie => `${cookie.key}=${cookie.value}`)
            .join('; ');

        fs.writeFileSync(join(process.cwd(),'vh', 'cookie.txt'), newCookie);
        global.account = global.account || {};
        global.account.cookie = newCookie; // cập nhật cookie global

        logger('Cập nhật cookie thành công', '[ COOKIE ]');

        // Cập nhật tokens
        const tokensPath = join(process.cwd(),'utils', 'tokens.json');
        let tokens = {};
        if (fs.existsSync(tokensPath)) {
            tokens = JSON.parse(fs.readFileSync(tokensPath, 'utf8'));
        }

        if (loginResult.data.access_token_eaad6v7) {
            tokens.EAAD6V7 = loginResult.data.access_token_eaad6v7;
            logger('Cập nhật token EAAD6V7 thành công', '[ TOKEN ]');
        }
        if (loginResult.data.access_token) {
            tokens.EAAAAU = loginResult.data.access_token;
            logger('Cập nhật token EAAAAU thành công', '[ TOKEN ]');
        }

        fs.writeFileSync(tokensPath, JSON.stringify(tokens, null, 2));
        logger('Đăng nhập thành công, tiến hành khởi động lại...', '[ SUCCESS ]');

        global.client.commands = new Map();
        global.client.events = new Map();

        setTimeout(() => process.exit(1), 1000);
        return true;

    } catch (error) {
        logger(`Lỗi khi đăng nhập lại: ${error.message}`, '[ ERROR ]');
        return false;
    }
};

/**
 * bypassAutomation: phát hiện checkpoint / automation page rồi cố gắng bypass và refresh cookie
 * Lưu ý: hàm này dùng các helper có sẵn trong project của bạn: get, post, saveCookies, getFrom, logger, this.options
 */
exports.bypassAutomation = async function(resp, jar) {
    global.fca = global.fca || {};
    global.fca.BypassAutomationNotification = this.bypassAutomation.bind(this);

    const s = (x) => (typeof x === "string" ? x : String(x ?? ""));
    const u = (r) => r?.request?.res?.responseUrl || (r?.config?.baseURL ? new URL(r.config.url || "/", r.config.baseURL).toString() : r?.config?.url || "");
    const isCp = (r) => {
      try {
        const url = u(r);
        if (!url || typeof url !== "string") return false;
        return url.includes("checkpoint/601051028565049") || /checkpoint\/|automation\/|security_check/.test(url);
      } catch {
        return false;
      }
    };

    const cookieUID = async () => {
      try {
        const cookies = typeof jar?.getCookies === "function" ? await jar.getCookies("https://www.facebook.com") : [];
        return cookies.find((c) => c.key === "i_user")?.value || cookies.find((c) => c.key === "c_user")?.value;
      } catch { return undefined; }
    };

    const htmlUID = (body) => s(body).match(/"USER_ID"\s*:\s*"(\d+)"/)?.[1] || s(body).match(/\["CurrentUserInitialData",\[\],\{.*?"USER_ID":"(\d+)".*?\},\d+\]/)?.[1] || s(body).match(/"c_user"\s*:\s*"(\d+)"/)?.[1];
    const getUID = async (body) => (await cookieUID()) || htmlUID(body);

    const refreshJar = async () => get("https://www.facebook.com/", jar, null, this.options, null, null).then(saveCookies(jar));

    const bypass = async (body) => {
      const b = s(body);
      const UID = await getUID(b);
      const fb_dtsg = getFrom(b, '"DTSGInitData",[],{"token":"', '",') || b.match(/name="fb_dtsg"\s+value="([^"]+)"/)?.[1] || b.match(/"fb_dtsg"\s*:\s*"([^"]+)"/)?.[1];
      const jazoest = getFrom(b, 'name="jazoest" value="', '"') || getFrom(b, "jazoest=", '",') || b.match(/name="jazoest"\s+value="([^"]+)"/)?.[1] || b.match(/"jazoest"\s*:\s*"([^"]+)"/)?.[1];
      const lsd = getFrom(b, '["LSD",[],{"token":"', '"}') || b.match(/name="lsd"\s+value="([^"]+)"/)?.[1] || b.match(/"LSD"\s*:\s*"([^"]+)"/)?.[1];

      const form = {
        av: UID,
        fb_dtsg,
        jazoest,
        lsd,
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "FBScrapingWarningMutation",
        variables: "{}",
        server_timestamps: true,
        doc_id: 6339492849481770
      };

      await post("https://www.facebook.com/api/graphql/", jar, form, this.options, null, null).then(saveCookies(jar));
      logger.warn("Facebook automation warning detected, handling...");
      try { this.reconnectAttempts = 0; } catch(e){}
    };

    try {
      if (resp) {
        if (isCp(resp)) {
          await bypass(s(resp.data));
          const refreshed = await refreshJar();
          if (isCp(refreshed)) logger.warn("Checkpoint still present after refresh");
          else logger.success("Bypass complete, cookies refreshed");
          return refreshed;
        }
        return resp;
      }

      const res = await get("https://www.facebook.com/", jar, null, this.options, null, null).then(saveCookies(jar));
      if (isCp(res)) {
        await bypass(s(res.data));
        const refreshed = await refreshJar();
        if (!isCp(refreshed)) logger.success("Bypass complete, cookies refreshed");
        else logger.warn("Checkpoint still present after refresh");
        return refreshed;
      }
      return res;
    } catch (e) {
      logger.error("Bypass automation error:", e?.message ?? e);
      return resp;
    }
};