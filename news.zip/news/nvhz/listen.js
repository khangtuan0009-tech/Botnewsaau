module.exports = function ({ api, models }) {
const Users = require("./database/controllers/users")({ models, api });
const Threads = require("./database/controllers/threads")({ models, api });
const Currencies = require("./database/controllers/currencies")({ models });
const logger = require("../utils/log.js");
const fs = require("fs-extra");
const moment = require('moment-timezone');
const axios = require("axios");
const path = require('path');

var day = moment.tz("Asia/Ho_Chi_Minh").day();  
const checkttDataPath = __dirname + '/../mdl/cmds/checktt/';  

// === CHỈNH: delay 2s mỗi nhóm, gửi lúc 00h15 ===
setInterval(async () => {  
    const now = moment.tz("Asia/Ho_Chi_Minh");  
    const day_now = now.day();  
    const hour = now.hour();  
    const minute = now.minute();

    // Gửi lúc 00:15 mỗi ngày (thay vì đổi ngay khi sang ngày)
    if (hour === 0 && minute === 25 && day != day_now) {  
        day = day_now;  
        const checkttData = fs.readdirSync(checkttDataPath);  
        console.log('--> CHECKTT: Gửi bảng xếp hạng ngày mới (00:15)');  

        // Duyệt từng nhóm, delay 2s giữa các lần gửi
        for (const checkttFile of checkttData) {
            try {
                const checktt = JSON.parse(fs.readFileSync(checkttDataPath + checkttFile));  
                let storage = [], count = 1;  

                for (const item of checktt.day) {  
                    const userName = await Users.getNameUser(item.id) || 'Facebook User';  
                    const itemToPush = item;  
                    itemToPush.name = userName;  
                    storage.push(itemToPush);  
                }  

                storage.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));  
                const timechecktt = moment.tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY || HH:mm:ss');  
                const haha = `\n────────────────────\n💬 Tổng tin nhắn: ${storage.reduce((a, b) => a + b.count, 0)}\n⏰ Time: ${timechecktt}\n✏️ Các bạn khác cố gắng tương tác nếu muốn lên top nha`;  
                let checkttBody = '[ TOP TƯƠNG TÁC NGÀY ]\n────────────────────\n📝 Top 10 người tương tác nhiều nhất hôm qua:\n\n';  
                checkttBody += storage.slice(0, 10).map(item => `${count++}. ${item.name} - 💬 ${item.count} tin nhắn`).join('\n');  

                await api.sendMessage(checkttBody + haha, checkttFile.replace('.json', ''), (err) => err && console.log(err));  
                await new Promise(r => setTimeout(r, 2000)); // ⏱️ Delay 2s mỗi nhóm

                checktt.day.forEach(e => e.count = 0);  
                checktt.time = day_now;  
                fs.writeFileSync(checkttDataPath + checkttFile, JSON.stringify(checktt, null, 4));  
            } catch (err) {
                console.log("❌ Lỗi gửi checktt ngày:", err);
            }
        }  

        // Tuần mới
        if (day_now == 1) {  
            console.log('--> CHECKTT: Tuần Mới');  
            for (const checkttFile of checkttData) {
                try {
                    const checktt = JSON.parse(fs.readFileSync(checkttDataPath + checkttFile));  
                    let storage = [], count = 1;  
                    for (const item of checktt.week) {  
                        const userName = await Users.getNameUser(item.id) || 'Facebook User';  
                        const itemToPush = item;  
                        itemToPush.name = userName;  
                        storage.push(itemToPush);  
                    }  
                    storage.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));  
                    const tctt = moment.tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY || HH:mm:ss');  
                    const dzvcl = `\n────────────────────\n⏰ Time: ${tctt}\n✏️ Các bạn khác cố gắng tương tác nếu muốn lên top nha`;  
                    let checkttBody = '[ TOP TƯƠNG TÁC TUẦN ]\n────────────────────\n📝 Top 10 người tương tác nhiều nhất tuần qua:\n\n';  
                    checkttBody += storage.slice(0, 10).map(item => `${count++}. ${item.name} - 💬 ${item.count} tin nhắn`).join('\n');  

                    await api.sendMessage(checkttBody + dzvcl, checkttFile.replace('.json', ''), (err) => err && console.log(err));  
                    await new Promise(r => setTimeout(r, 2000)); // ⏱️ Delay 2s giữa nhóm tuần

                    checktt.week.forEach(e => e.count = 0);  
                    fs.writeFileSync(checkttDataPath + checkttFile, JSON.stringify(checktt, null, 4));  
                } catch (err) {
                    console.log("❌ Lỗi gửi checktt tuần:", err);
                }
            }  
        }  
        global.client.sending_top = false;  
    }  
}, 1000 * 10);  // kiểm tra mỗi 10s

// --- Giữ nguyên toàn bộ phần dưới ---
(async function () {  
    try {  
        logger(global.getText('listen', 'startLoadEnvironment'), '[ DATABASE ]');  
        let threads = await Threads.getAll(),  
            users = await Users.getAll(['userID', 'name', 'data']),  
            currencies = await Currencies.getAll(['userID']);  

        for (const data of threads) {  
            const idThread = String(data.threadID);  
            global.data.allThreadID.push(idThread);  
            global.data.threadData.set(idThread, data.data || {});  
            global.data.threadInfo.set(idThread, data.threadInfo || {});  
            if (data.data?.banned)  
                global.data.threadBanned.set(idThread, { reason: data.data.reason || '', dateAdded: data.data.dateAdded || '' });  
            if (data.data?.commandBanned?.length)  
                global.data.commandBanned.set(idThread, data.data.commandBanned);  
            if (data.data?.NSFW)  
                global.data.threadAllowNSFW.push(idThread);  
        }  

        logger.loader(global.getText('listen', 'loadedEnvironmentThread'));  
        for (const dataU of users) {  
            const idUsers = String(dataU.userID);  
            global.data.allUserID.push(idUsers);  
            if (dataU.name?.length)  
                global.data.userName.set(idUsers, dataU.name);  
            if (dataU.data?.banned == 1)  
                global.data.userBanned.set(idUsers, { reason: dataU.data.reason || '', dateAdded: dataU.data.dateAdded || '' });  
            if (dataU.data?.commandBanned?.length)  
                global.data.commandBanned.set(idUsers, dataU.data.commandBanned);  
        }  

        for (const dataC of currencies)  
            global.data.allCurrenciesID.push(String(dataC.userID));  
    } catch (error) {  
        return logger.loader(global.getText('listen', 'failLoadEnvironment', error), 'error');  
    }  
})();  

const handleCommand = require("./handle/handleCommand")({ api, models, Users, Threads, Currencies });  
const handleCommandEvent = require("./handle/handleCommandEvent")({ api, models, Users, Threads, Currencies });  
const handleReply = require("./handle/handleReply")({ api, models, Users, Threads, Currencies });  
const handleReaction = require("./handle/handleReaction")({ api, models, Users, Threads, Currencies });  
const handleEvent = require("./handle/handleEvent")({ api, models, Users, Threads, Currencies });  
const handleRefresh = require("./handle/handleRefresh")({ api, models, Users, Threads, Currencies });  
const handleCreateDatabase = require("./handle/handleCreateDatabase")({ api, Threads, Users, Currencies, models });  

logger.loader(`Ping load source code: ${Date.now() - global.client.timeStart}ms`);  

return async function (event) {  
    const { threadID, author, image, type, logMessageType, logMessageBody, logMessageData } = event;  
    var data_anti = JSON.parse(fs.readFileSync(global.anti, "utf8"));  
    const botID = api.getCurrentUserID();  
    const threadInf = await api.getThreadInfo(threadID);  
    const findAd = threadInf.adminIDs.find(el => el.id === author);  

    if (type == "change_thread_image") {  
        const findAnti = data_anti.boximage.find(item => item.threadID === threadID);  
        if (findAnti) {  
            if (findAd || botID.includes(author)) {  
                api.sendMessage(`🖼️ | [CẬP NHẬT NHÓM] ${event.snippet}`, threadID);  
                const res = await axios.post("https://api.imgur.com/3/image", { image: image.url }, { headers: { Authorization: "Client-ID fc9369e9aea767c" } });  
                findAnti.url = res.data.data.link;  
                fs.writeFileSync(global.anti, JSON.stringify(data_anti, null, 4));  
            } else {  
                const res = await axios.get(findAnti.url, { responseType: "stream" });  
                api.sendMessage("🚫 | Bạn không có quyền đổi ảnh nhóm!", threadID);  
                return api.changeGroupImage(res.data, threadID);  
            }  
        }  
    }  

    if (logMessageType === "log:thread-name") {  
        const findAnti = data_anti.boxname.find(item => item.threadID === threadID);  
        if (findAnti) {  
            if (findAd || botID.includes(author)) {  
                api.sendMessage(`✏️ | [CẬP NHẬT NHÓM] ${logMessageBody}`, threadID);  
                findAnti.name = logMessageData.name;  
                fs.writeFileSync(global.anti, JSON.stringify(data_anti, null, 4));  
            } else {  
                api.sendMessage("🚫 | Bạn không có quyền đổi tên nhóm!", threadID);  
                api.setTitle(findAnti.name, threadID);  
            }  
        }  
    }  

    if (logMessageType === "log:user-nickname") {  
        const findAnti = data_anti.antiNickname.find(item => item.threadID === threadID);  
        if (findAnti) {  
            if (findAd || botID.includes(author)) {  
                api.sendMessage(`🪪 | [CẬP NHẬT NHÓM] ${logMessageBody}`, threadID);  
                findAnti.data[logMessageData.participant_id] = logMessageData.nickname;  
                fs.writeFileSync(global.anti, JSON.stringify(data_anti, null, 4));  
            } else {  
                api.sendMessage("🚫 | Bạn không có quyền đổi biệt danh người khác!", threadID);  
                api.changeNickname(findAnti.data[logMessageData.participant_id] || "", threadID, logMessageData.participant_id);  
            }  
        }  
    }  

    if (logMessageType === "log:unsubscribe") {  
        const findAnti = !!data_anti.antiout[threadID];  
        if (findAnti) {  
            const typeOut = author == logMessageData.leftParticipantFbId ? "out" : "kick";  
            if (typeOut == "out") {  
                api.addUserToGroup(logMessageData.leftParticipantFbId, threadID, (error) => {  
                    if (error) api.sendMessage(`❎ | Không thể thêm người này trở lại!\n[ MODE ]: Chống thoát nhóm bật`, threadID);  
                    else api.sendMessage(`✅ | Đã thêm người dùng trở lại nhóm!\n[ MODE ]: Chống thoát nhóm bật`, threadID);  
                });  
            }  
        }  
    }  

    if (logMessageType === "log:thread-emoji") {  
        const findAnti = data_anti.antiEmoji?.find(item => item.threadID === threadID);  
        if (findAnti) {  
            if (findAd || botID.includes(author)) {  
                api.sendMessage(`✨ | [CẬP NHẬT NHÓM] Icon nhóm đã được ${logMessageData.emoji} bởi admin.`, threadID);  
                findAnti.emoji = logMessageData.emoji;  
                fs.writeFileSync(global.anti, JSON.stringify(data_anti, null, 4));  
            } else {  
                api.sendMessage("🚫 | Bạn không có quyền đổi icon nhóm!", threadID);  
                api.changeThreadEmoji(findAnti.emoji || "👍", threadID);  
            }  
        }  
    }  

    if (logMessageType === "log:thread-color") {  
        const findAnti = data_anti.antiColor?.find(item => item.threadID === threadID);  
        if (findAnti) {  
            if (findAd || botID.includes(author)) {  
                api.sendMessage(`🎨 | [CẬP NHẬT NHÓM] Màu chủ đề nhóm đã được đổi thành #${logMessageData.theme_color} bởi admin.`, threadID);  
                findAnti.color = logMessageData.theme_color;  
                fs.writeFileSync(global.anti, JSON.stringify(data_anti, null, 4));  
            } else {  
                api.sendMessage("🚫 | Bạn không có quyền đổi màu nhóm!", threadID);  
                api.changeThreadColor(findAnti.color || "0084ff", threadID);  
            }  
        }  
    }  

    // Check thuê bot + prefix + usePrefix  
    if (event.type == "message" || event.type == "message_reply") {  
        let threadData = global.data.threadData.get(threadID) || {};  
        let prefix = threadData.PREFIX || global.config.PREFIX;  
        let usePrefix = threadData.usePrefix !== false; // true nếu undefined hoặc true  
        if (usePrefix && (event.body || "").startsWith(prefix) && event.senderID != botID && !global.config.ADMINBOT.includes(event.senderID)) {  
            let thuebot;  
            try {  
                thuebot = JSON.parse(fs.readFileSync(process.cwd() + "/mdl/cmds/data/thuebot.json"));  
            } catch {  
                thuebot = [];  
            }  
            let find_thuebot = thuebot.find(($) => $.t_id == threadID);  
            if (!find_thuebot) {  
                await api.shareContact("⛔ Nhóm của bạn chưa thuê bot!\nLiên hệ Admin: Ng Van Hungg", global.config.ADMINBOT[0], threadID);  
                return;  
            }  
            const expirationTime = moment.tz(find_thuebot.time_end, "DD/MM/YYYY HH:mm:ss", "Asia/Ho_Chi_Minh").valueOf();  
            if (expirationTime <= Date.now()) {  
                await api.shareContact("⚠️ Nhóm của bạn đã hết hạn thuê bot!\nLiên hệ Admin: Ng Van Hungg", global.config.ADMINBOT[0], threadID);  
                return;  
            }  
        }  
    }  

    switch (event.type) {  
        case "message":  
        case "message_reply":  
        case "message_unsend":  
            handleCreateDatabase({ event });  
            handleCommand({ event });  
            handleReply({ event });  
            handleCommandEvent({ event });  
            break;  
        case "event":  
            handleEvent({ event });  
            handleRefresh({ event });  
            break;  
        case "message_reaction":  
            var { iconUnsend } = global.config;  
            if (iconUnsend.status && event.senderID == api.getCurrentUserID() && event.reaction == iconUnsend.icon)  
                api.unsendMessage(event.messageID);  
            handleReaction({ event });  
            break;  
    }  
};

};